package com.bosch.rbcd.device2.common.util;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;

/**
 * Created by admin on 2018/2/2.
 */
@Slf4j
public class CCUUtil {


    public static String getHashCode(String destFilePath) throws IOException {
        MessageDigest messageDigest;
        String encodestr = "";
        File destFile=new File(destFilePath);
        InputStream destFileStream =new FileInputStream(destFile);
        int length=destFileStream.available();
        byte[] buffer=new byte[length];
//        int len=0;
//        try {
//            messageDigest = MessageDigest.getInstance("SHA-256");
//            while((len=destFileStream.read(buffer,0,2048))!=-1){
//                messageDigest.update(buffer);
//            }
//            encodestr = FilesUtil.bytesToHex(messageDigest.digest());
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }
        destFileStream.read(buffer,0,length);
        encodestr=String.format("%64x",  CRCUtil.CRC_CCITT_16(0,buffer,length));
        encodestr= encodestr.replace(" ","0");
        destFileStream.close();
        return encodestr;
    }

    public static String getSha256Code(String destFilePath)
            throws IOException {
        File file = new File(destFilePath);

        return getFileSHA256(file);
    }

    private static String getFileSHA256(File file) {
        String str = "";

        try {
            str = getHash(file, "SHA-256");
        } catch (Exception e) {
            log.error("com.bosch.rbcd.solution.utils.CCUUtil.getFileSHA256 error!", e);
        }

        return str;
    }

    private static String getHash(File file, String hashType)
            throws Exception {
        InputStream fis = new FileInputStream(file);
        byte[] buffer = new byte[1024];
        MessageDigest md5 = MessageDigest.getInstance(hashType);

        for (int numRead = 0; (numRead = fis.read(buffer)) > 0;) {
            md5.update(buffer, 0, numRead);
        }

        fis.close();

        return toHexString(md5.digest());
    }

    private static String toHexString(byte[] b) {
        StringBuilder sb = new StringBuilder();

        for (byte aB : b) {
//            sb.append(Integer.toHexString(aB & 0xFF));
            sb.append(String.format("%02x",aB));
        }

        return sb.toString();
    }
}
