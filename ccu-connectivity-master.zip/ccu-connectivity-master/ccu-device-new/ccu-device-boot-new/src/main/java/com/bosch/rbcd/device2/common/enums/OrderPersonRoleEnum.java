package com.bosch.rbcd.device2.common.enums;

/**
 * CCU订单角色枚举类
 */
public enum OrderPersonRoleEnum {

    COST_CENTER_MANAGER(0, "成本中心责任人", true),
    APPROVER(1, "审批人", true),
    CARBON_COPY_RECIPIENT(2,"抄送人", false),
    STOCK_MANAGER(3, "备货负责人", false),
    PROJECT_MANAGER(4, "项目负责人", true)
    ;

    private final int code;

    private final String description;

    private boolean needApprove;

    OrderPersonRoleEnum(int code, String description, boolean needApprove) {
        this.code = code;
        this.description = description;
        this.needApprove = needApprove;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public boolean isNeedApprove() {
        return needApprove;
    }
}
