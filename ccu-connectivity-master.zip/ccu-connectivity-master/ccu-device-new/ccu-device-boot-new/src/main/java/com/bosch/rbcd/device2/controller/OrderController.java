package com.bosch.rbcd.device2.controller;

import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.device2.pojo.form.DeviceOrderForm;
import com.bosch.rbcd.device2.pojo.form.OrderAuditForm;
import com.bosch.rbcd.device2.pojo.form.OrderTransferForm;
import com.bosch.rbcd.device2.pojo.query.DeviceInfoQuery;
import com.bosch.rbcd.device2.pojo.query.OrderApplyQuery;
import com.bosch.rbcd.device2.pojo.query.OrderAuditQuery;
import com.bosch.rbcd.device2.pojo.vo.DeviceInfoVO;
import com.bosch.rbcd.device2.pojo.vo.DeviceOrderVO;
import com.bosch.rbcd.device2.service.AppAuthorityService;
import com.bosch.rbcd.device2.service.DeviceInfoService;
import com.bosch.rbcd.device2.service.DeviceOrderAttachmentService;
import com.bosch.rbcd.device2.service.DeviceOrderService;
import com.bosch.rbcd.system.common.ProcessCheckStatusEnum;
import com.bosch.rbcd.system.vo.FileVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

@Api(tags = "CCU申请单管理")
@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private DeviceOrderService deviceOrderService;

    @Autowired
    private DeviceOrderAttachmentService deviceOrderAttachmentService;

    @Autowired
    private DeviceInfoService deviceInfoService;

    @Autowired
    private AppAuthorityService appAuthorityService;

    @ApiOperation("新建申请单")
    @PostMapping("/apply")
    public Result<Long> apply(@Validated @RequestBody DeviceOrderForm deviceOrderForm) {
        return Result.success(deviceOrderService.apply(deviceOrderForm));
    }

    /**
     * 申请单分页查询
     * @return 用户名下的全部申请的单，包括转让过来的
     */
    @ApiOperation("申请单 - 分页查询")
    @GetMapping("/apply/pageQuery")
    public PageResult<DeviceOrderVO> applyPageQuery(OrderApplyQuery orderApplyQuery) {
        if (!appAuthorityService.currentUserIsAppRoot()) {
            orderApplyQuery.setOwnerId(UserUtils.getUserId());
        }
        return PageResult.success(deviceOrderService.applyPageQuery(orderApplyQuery));
    }

    @ApiOperation("申请单 - 下载")
    @PostMapping("/apply/download")
    public void applyDownload(HttpServletResponse response, @RequestBody OrderApplyQuery orderApplyQuery) throws IOException {
        if (!appAuthorityService.currentUserIsAppRoot()) {
            orderApplyQuery.setOwnerId(UserUtils.getUserId());
        }
        List<DeviceOrderVO> orderList = new ArrayList<>();
        for (int pageNum=1, pageSize=20; ; pageNum++) {
            orderApplyQuery.setPageNum(pageNum);
            orderApplyQuery.setPageSize(pageSize);
            IPage<DeviceOrderVO> page = deviceOrderService.applyPageQuery(orderApplyQuery);
            if (page == null || CollectionUtils.isEmpty(page.getRecords())) {
                break;
            }
            orderList.addAll(page.getRecords());
        }

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        String fileName = URLEncoder.encode("CCU申请记录", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
        EasyExcel.write(response.getOutputStream(), DeviceOrderVO.class).sheet("出库记录").doWrite(orderList);
    }

    @ApiOperation("申请单 - 转让（仅管理员）")
    @PostMapping("/apply/transfer")
    public Result<Void> transferOrder(@Validated @RequestBody OrderTransferForm orderTransferForm) {
        if (!appAuthorityService.currentUserIsAppRoot()) {
            return Result.failed("请联系云平台工程师进行操作");
        }
        orderTransferForm.setModifierId(UserUtils.getUserId());
        deviceOrderService.transfer(orderTransferForm);
        return Result.success();
    }

    @ApiOperation("申请单 - 详情")
    @GetMapping("/detail")
    public Result<DeviceOrderVO> getDetail(@ApiParam(value = "申请单id", required = true) @RequestParam Long orderId) {
        return Result.success(deviceOrderService.getDetail(orderId));
    }

    @ApiOperation("申请单 - 仅附件")
    @GetMapping("/attachment")
    public Result<List<FileVO>> getAttachmentList(@ApiParam(value = "申请单id", required = true) @RequestParam Long orderId) {
        return Result.success(deviceOrderAttachmentService.getAttachmentList(orderId));
    }

    @ApiOperation("申请单审批列表-分页查询")
    @GetMapping("/audit/pageQuery")
    public PageResult<DeviceOrderVO> auditPageQuery(OrderAuditQuery orderAuditQuery) {
        orderAuditQuery.setCurrentUserId(UserUtils.getUserId());
        return PageResult.success(deviceOrderService.auditPageQuery(orderAuditQuery));
    }

    @ApiOperation("审批申请单")
    @PostMapping("/audit")
    public Result<Void> audit(@Validated @RequestBody OrderAuditForm orderAuditForm) {
        if (orderAuditForm.getApproveStatus().equals(ProcessCheckStatusEnum.REJECTED.getCode()) && StringUtils.isBlank(orderAuditForm.getReason())) {
            return Result.failed("请输入驳回理由");
        }
        deviceOrderService.audit(orderAuditForm);
        return Result.success();
    }

    @ApiOperation("撤销申请单")
    @DeleteMapping("/revoke")
    public Result<Void> revoke(@ApiParam(value = "申请单id", required = true) @RequestParam Long orderId) {
        deviceOrderService.revoke(orderId);
        return Result.success();
    }

    @ApiOperation("申请单 - 查询已出库的CCU")
    @GetMapping("/ccu/pageQuery")
    public PageResult<DeviceInfoVO> ccuPageQuery(DeviceInfoQuery deviceInfoQuery) {
        if (deviceInfoQuery.getOrderId() == null) {
            // 没有指定申请单id，则查询当前登录用户创建的全部申请单下的CCU
            deviceInfoQuery.setOwnerId(UserUtils.getUserId());
        }
        return PageResult.success(deviceInfoService.queryCcuInOrder(deviceInfoQuery));
    }
}
