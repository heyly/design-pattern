package com.bosch.rbcd.device2.common.enums;

/**
 * ccu故障类型枚举类
 */
public enum DeviceErrorTypeEnum {

    APPLICATION_ERROR(0, "应用问题", true),
    SOFTWARE_ERROR(1, "软件问题", true),
    HARDWARE_ERROR(2, "硬件问题", false);

    private final int code;

    private final String description;

    /**
     * 是否支持重新入库
     */
    private final boolean reInStorage;

    DeviceErrorTypeEnum(int code, String description, boolean reInStorage) {
        this.code = code;
        this.description = description;
        this.reInStorage = reInStorage;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public boolean isReInStorage() {
        return reInStorage;
    }
}
