package com.bosch.rbcd.device2.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Created by feng- on 2017/5/24.
 */
@Component
@ConfigurationProperties(prefix="system")
public class SystemConfig {
    private String env;
    private String filePath;
    private String pythonPath;

    public final static String TOKEN = "X-boschrbcd-Token";

    public String getEnv() {
        return env;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getPythonPath() {
        return pythonPath;
    }

    public void setPythonPath(String pythonPath) {
        this.pythonPath = pythonPath;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}
