package com.bosch.rbcd.device2.controller.feign;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.dto.DeviceLogRecordDTO;
import com.bosch.rbcd.device2.pojo.entity.DeviceLogRecord;
import com.bosch.rbcd.device2.service.DeviceLogRecordService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;

@ApiIgnore
@RestController
@RequestMapping("/feign/ccu-device/log")
public class DeviceLogFeignController {

    @Autowired
    private DeviceLogRecordService deviceLogRecordService;

    @GetMapping("/requestDeviceLog")
    public Result<?> requestDeviceLog(@RequestParam String ccuId, @RequestParam String creator, @RequestParam Long occurDay) {
        return deviceLogRecordService.requestDeviceLogForFeign(ccuId, creator, new Date(occurDay));
    }

    @GetMapping("/queryDeviceLog")
    public Result<DeviceLogRecordDTO> queryDeviceLog(@RequestParam String vehicleId, @RequestParam Long occurDay, @RequestParam String creator) {
//        log.info( "收到请求，ccuId = {}, startTime = {}, creator = {}", ccuId, startTimeLong, creator );
        Date requestDay = new Date(occurDay);
        DeviceLogRecord deviceLogRecord = deviceLogRecordService.queryDeviceLog(vehicleId, requestDay, creator);
        DeviceLogRecordDTO dto = null;
        if (deviceLogRecord != null) {
            dto = new DeviceLogRecordDTO();
            BeanUtils.copyProperties(deviceLogRecord, dto);
        }
        return Result.success(dto);
    }

    @GetMapping("/updateDeviceLogRequest")
    Result<Integer> updateDeviceLogRequest(String logRequestId, String status, String fileName, String obsPath) {
        return Result.success(deviceLogRecordService.updateDeviceLogRequest(logRequestId, status, fileName, obsPath));
    }

    @GetMapping("/ccuVoluntaryUpload")
    Result<Long> ccuVoluntaryUpload(@RequestParam String imei, @RequestParam String fileName, @RequestParam String obsPath, @RequestParam String timestamp) {
        if (StringUtils.isBlank(imei)) {
            return Result.success(null);
        }
        return Result.success(deviceLogRecordService.ccuVoluntaryUpload(imei, fileName, obsPath, timestamp));
    }
}
