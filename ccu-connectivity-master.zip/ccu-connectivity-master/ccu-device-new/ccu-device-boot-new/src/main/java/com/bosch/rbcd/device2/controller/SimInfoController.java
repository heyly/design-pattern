package com.bosch.rbcd.device2.controller;


import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.poi.excel.ExcelReader;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.pojo.entity.SimInfo;
import com.bosch.rbcd.device2.pojo.form.SimRenewForm;
import com.bosch.rbcd.device2.pojo.query.SimDailyGprsPageQuery;
import com.bosch.rbcd.device2.pojo.query.SimInfoPageQuery;
import com.bosch.rbcd.device2.pojo.query.SimMonthGprsPageQuery;
import com.bosch.rbcd.device2.pojo.vo.SimDailyGprsVO;
import com.bosch.rbcd.device2.pojo.vo.SimInfoVO;
import com.bosch.rbcd.device2.pojo.vo.SimMonthGprsVO;
import com.bosch.rbcd.device2.pojo.vo.SimWaringCardVO;
import com.bosch.rbcd.device2.service.SimDailyGprsService;
import com.bosch.rbcd.device2.service.SimInfoService;
import com.bosch.rbcd.device2.service.SimMonthGprsService;
import com.bosch.rbcd.device2.service.SimRenewRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * sim卡信息(CcuSimInfo)表控制层
 *
 * @author wang bo
 * @since 2023-08-11 14:25:40
 */
@Api(tags = "sim卡信息API")
@Slf4j
@RestController
@RequestMapping("/ccuSimInfo")
@RequiredArgsConstructor
public class SimInfoController {

    private final SimInfoService simInfoService;
    private final SimDailyGprsService simDailyGprsService;
    private final SimMonthGprsService simMonthGprsService;
    private final SimRenewRecordService simRenewRecordService;

    @ApiOperation(value = "sim卡信息-分页查询")
    @PostMapping("/page")
    public PageResult<SimInfoVO> page(@RequestBody SimInfoPageQuery query) {
        IPage<SimInfoVO> result = simInfoService.listCcuSimInfoPage(query);
        return PageResult.success(result);
    }

    @ApiOperation(value = "sim卡信息-获取预警卡片")
    @PostMapping("/getWarningCards")
    public Result<SimWaringCardVO> getWarningCards(@RequestBody SimInfoPageQuery query) {
        return Result.success(simInfoService.getWarningCards(query));
    }

    @ApiOperation(value = "sim卡信息-通过主键查询单条数据")
    @GetMapping("/getById/{id}")
    public Result<SimInfo> getById(@PathVariable Serializable id) {
        return Result.success(simInfoService.getById(id));
    }

    @ApiOperation(value = "sim卡信息-新增数据")
    @PostMapping("/insert")
    public Result<Boolean> insert(@RequestBody SimInfo simInfo) {
        return Result.success(simInfoService.saveOrUpdate(simInfo));
    }

    @ApiIgnore(value = "sim卡信息-修改数据")
    @PutMapping("/update")
    public Result<Boolean> update(@RequestBody SimInfo simInfo) {
        return Result.success(simInfoService.updateById(simInfo));
    }

    @ApiIgnore(value = "sim卡信息-删除数据")
    @DeleteMapping("/delete/{ids}")
    public Result<Boolean> delete(@ApiParam("主键id，多个以英文逗号(,)分割")  @PathVariable String ids) {
        List<Long> idList = Arrays.stream(ids.split(",")).map(Long::parseLong).collect(Collectors.toList());
        return Result.success(simInfoService.removeByIds(idList));
    }

    @ApiOperation("sim卡信息-导出sim信息")
    @RequestMapping(value = "/export", method = RequestMethod.POST)
    public Result<Void> export(HttpServletResponse response, @RequestBody SimInfoPageQuery query) {
        response.setCharacterEncoding("utf-8");
        response.setHeader("Content-disposition", "attachment;filename=sim_detail.xlsx");
        response.setContentType("application/vnd.ms-excel;charset=UTF-8");
        try (Workbook workbook = simInfoService.getSimWorkBook(query);
             OutputStream os = response.getOutputStream()) {
            workbook.write(os);
        } catch (IOException e) {
            log.error("com.bosch.rbcd.device.controller.CcuSimInfoController.export error!", e);
        }
        return Result.success();
    }

    @ApiOperation(value = "sim卡信息-分页查询单日流量")
    @PostMapping("/pageDailyGprs")
    public PageResult<SimDailyGprsVO> pageDailyGprs(@RequestBody SimDailyGprsPageQuery query) {
        IPage<SimDailyGprsVO> result = simDailyGprsService.listCcuSimGprsRecordPage(query);
        return PageResult.success(result);
    }

    @ApiOperation(value = "sim卡信息-分页查询单月流量")
    @PostMapping("/pageMonthGprs")
    public PageResult<SimMonthGprsVO> pageMonthGprs(@RequestBody SimMonthGprsPageQuery query) {
        IPage<SimMonthGprsVO> result = simMonthGprsService.listCcuSimMonthGprsPage(query);
        return PageResult.success(result);
    }

    @ApiOperation(value = "sim卡信息-批量续费")
    @PostMapping("/batchRenew")
    public Result<Boolean> batchRenew(@ApiParam(value = "file", required = true) MultipartFile file) {
        if(!StrUtil.equalsAnyIgnoreCase(FileUtil.extName(file.getOriginalFilename()),"xls", "xlsx")){
            return Result.failed("只能上传Excel文件类型");
        }
        try (ExcelReader reader = new ExcelReader(file.getInputStream(), 0);) {
            List<SimRenewForm> renewFormList = reader.readAll(SimRenewForm.class);
            return Result.success(simRenewRecordService.batchRenew(renewFormList));
        } catch (IOException e) {
            return Result.failed("Excel解析失败");
        }
    }

}

