package com.bosch.rbcd.device2.controller;

import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.web.validate.Create;
import com.bosch.rbcd.common.web.validate.Update;
import com.bosch.rbcd.device2.pojo.form.DataPoolForm;
import com.bosch.rbcd.device2.pojo.query.DataPoolQuery;
import com.bosch.rbcd.device2.pojo.vo.DataPoolHistoryVO;
import com.bosch.rbcd.device2.pojo.vo.DataPoolVO;
import com.bosch.rbcd.device2.service.DataPoolService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "系统管理 - 流量池")
@RestController
@RequestMapping("/dataPool")
public class DataPoolController {

    @Autowired
    private DataPoolService dataPoolService;

    @ApiOperation("流量池-创建")
    @PostMapping("/create")
    public Result<Long> create(@Validated(Create.class) @RequestBody DataPoolForm dataPoolForm) {
        return Result.success(dataPoolService.create(dataPoolForm));
    }

    @ApiOperation("流量池-更新")
    @PostMapping("/update")
    public Result<Void> update(@Validated(Update.class) @RequestBody DataPoolForm dataPoolForm) {
        dataPoolService.update(dataPoolForm);
        return Result.success();
    }

    @ApiOperation("流量池-删除")
    @DeleteMapping("/delete")
    public Result<Void> delete(@ApiParam(value = "主键id", required = true) @RequestParam Long id) {
        dataPoolService.delete(id);
        return Result.success();
    }

    @ApiOperation("流量池-分页查询")
    @GetMapping("/pageQuery")
    public PageResult<DataPoolVO> pageQuery(DataPoolQuery dataPoolQuery) {
        return PageResult.success(dataPoolService.pageQuery(dataPoolQuery));
    }

    @ApiOperation("流量池-历史价格")
    @GetMapping("/priceLog")
    public Result<List<DataPoolHistoryVO>> priceLog(@ApiParam(value = "主键id", required = true) @RequestParam Long id) {
        return Result.success(dataPoolService.priceLog(id));
    }
}
