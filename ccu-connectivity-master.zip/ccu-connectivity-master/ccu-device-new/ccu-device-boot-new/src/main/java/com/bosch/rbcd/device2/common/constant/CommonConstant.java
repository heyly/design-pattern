package com.bosch.rbcd.device2.common.constant;

public interface CommonConstant {

    Long PROJECT_MANAGER = 342L;
    String PROJECT_MANAGER_EMAIL = "xiaoqiu.chen@cn.bosch.com";

    /**
     * SIM卡的制卡费
     */
    Double SIM_CARD_MAKE_COST = 2.0;

    /**
     * redis出库与返件key
     */
    String CCU_REDIS_KEY = "CCU_STORAGE_KEY";

}
