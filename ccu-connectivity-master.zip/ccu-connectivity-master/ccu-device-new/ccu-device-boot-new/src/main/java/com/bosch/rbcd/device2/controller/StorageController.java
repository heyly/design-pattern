package com.bosch.rbcd.device2.controller;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.io.FileUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bosch.rbcd.common.huawei.util.ObsUtil;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.result.ResultCode;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.device2.config.SystemConfig;
import com.bosch.rbcd.device2.pojo.form.DeviceStorageInForm;
import com.bosch.rbcd.device2.pojo.form.DeviceStorageOutForm;
import com.bosch.rbcd.device2.pojo.query.DeviceInStorageQuery;
import com.bosch.rbcd.device2.pojo.query.OutStorageRecordQuery;
import com.bosch.rbcd.device2.pojo.vo.*;
import com.bosch.rbcd.device2.service.BatchInfoService;
import com.bosch.rbcd.device2.service.DeviceStorageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Api(tags = "CCU库存管理")
@RestController
@RequestMapping("/storage")
public class StorageController {

    @Autowired
    private DeviceStorageService deviceStorageService;

    @Autowired
    private BatchInfoService batchInfoService;

    @Autowired
    private ObsUtil obsUtil;

    @Autowired
    private SystemConfig systemConfig;

    @Value("${huawei.foldPath}")
    private String foldPath;

    /**
     * CCU入库EOL文件模板
     */
    private static final String IN_STORAGE_TEMPLATE_PATH = "download/CCU_EOL_template_V3.xlsx";

    private static final String OUT_STORAGE_TEMPLATE_PATH = "download/out_storage_input_file.xlsx";


    @ApiOperation("获取EOL文件模板下载地址（入库文件模板）")
    @GetMapping("/file/template/in")
    public Result<String> getInStorageTemplate() {
        return Result.success(foldPath + IN_STORAGE_TEMPLATE_PATH);
    }

    @ApiOperation("出库CCU模板下载地址（出库文件模板）")
    @GetMapping("/file/template/out")
    public Result<String> getOutStorageTemplate() {
        return Result.success(foldPath + OUT_STORAGE_TEMPLATE_PATH);
    }

    @ApiOperation("设备入库")
    @PostMapping("/in")
    public Result<String> inStorage(@RequestBody @Validated DeviceStorageInForm form) {

        String obsPath = form.getFilePath();
        if (obsPath.startsWith(foldPath)) {
            obsPath = obsPath.substring(foldPath.length());
        }
        if (!obsUtil.isExisted(obsPath)) {
            return Result.failed("HuaWei OBS不存在此文件:" + form.getFilePath());
        }
        String destFilePath = systemConfig.getFilePath() + File.separator + obsPath.replace("/", File.separator);
        File file = obsUtil.getFile(obsPath, destFilePath);

        List<DeviceEolVO> addList = new ArrayList<>();
        try (ExcelReader excelReader = EasyExcel.read(file, DeviceEolVO.class, new AnalysisEventListener<DeviceEolVO>() {
            @Override
            public void invoke(DeviceEolVO ccuDeviceEolVO, AnalysisContext analysisContext) {
                if (ccuDeviceEolVO.isAllFieldNull()) {
                    return;
                }
                addList.add(ccuDeviceEolVO);
            }

            @Override
            public void doAfterAllAnalysed(AnalysisContext analysisContext) {

            }
        }).build()) {
            ReadSheet readSheet = EasyExcel.readSheet(0).build();
            excelReader.read(readSheet);
            // 这里千万别忘记关闭，读的时候会创建临时文件，到时磁盘会崩的
            excelReader.finish();
        }

        FileUtil.del(destFilePath);

        if (CollectionUtil.isEmpty(addList)) {
            return Result.failed(ResultCode.USER_UPLOAD_FILE_ERROR, "文件内不存在有效数据");
        }

        String batchNo = deviceStorageService.inStorage(form, addList);

        obsUtil.deleteFile(obsPath);

        return Result.success(batchNo);
    }

    @ApiOperation("设备出库")
    @PostMapping("/out")
    public void outStorage(HttpServletResponse response, @RequestBody DeviceStorageOutForm form) throws IOException {
        List<OutStorageDetailVO> outStorageList = null;

        if (form.getOrderId() == null) {
            throw new BizException("请选择申请单");
        }
        if (form.getManual() == null) {
            throw new BizException("请选择出库方式");
        } else if (form.getManual()) {
            if (CollectionUtil.isEmpty(form.getSnList())) {
                throw new BizException("请选择CCU");
            }
            outStorageList = deviceStorageService.outStorage(form.getOrderId(), form.getSnList());
        } else {
            if (StringUtils.isBlank(form.getSnFilePath())) {
                throw new BizException("请上传待出库CCU的文件");
            }

            if (!obsUtil.isExisted(form.getSnFilePath())) {
                throw new BizException("HuaWei OBS不存在此文件:" + form.getSnFilePath());
            }
            String destFilePath = systemConfig.getFilePath() + File.separator + form.getSnFilePath().replace("/", File.separator);
            File snFile = obsUtil.getFile(form.getSnFilePath(), destFilePath);

            List<String> snInExcel = new ArrayList<>();
            try (ExcelReader excelReader = EasyExcel.read(snFile, OutStorageInputFileVO.class, new AnalysisEventListener<OutStorageInputFileVO>() {
                @Override
                public void invoke(OutStorageInputFileVO outStorageInputFileVO, AnalysisContext analysisContext) {
                    snInExcel.add(outStorageInputFileVO.getSn());
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext analysisContext) {

                }
            }).build()) {
                ReadSheet readSheet = EasyExcel.readSheet(0).build();
                excelReader.read(readSheet);
                // 这里千万别忘记关闭，读的时候会创建临时文件，到时磁盘会崩的
                excelReader.finish();
            } catch (Exception e) {
                log.error("读出CCU出库文件出错", e);
                throw new BizException("读取文件出错");
            }
            outStorageList = deviceStorageService.outStorage(form.getOrderId(), snInExcel);

            FileUtil.del(destFilePath);
            obsUtil.deleteFile(form.getSnFilePath());
        }

        if (CollectionUtil.isNotEmpty(outStorageList)) {
            try {
                response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                response.setCharacterEncoding("utf-8");
                // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
                String fileName = URLEncoder.encode("CCU出库清单", "UTF-8").replaceAll("\\+", "%20");
                response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
                // 这里需要设置不关闭流
                EasyExcel.write(response.getOutputStream(), OutStorageDetailVO.class)
                        .autoCloseStream(Boolean.FALSE)
                        .sheet("ccu")
                        .doWrite(outStorageList);
            } catch (Exception e) {
                // 重置response
                response.reset();
                response.setContentType("application/json");
                response.setCharacterEncoding("utf-8");
                Result result = Result.failed("设备已出库，但是导出异常！");
                response.getWriter().println(JSON.toJSONString(result));
            }
        }


    }

    @ApiOperation("获取全部入库批次号")
    @GetMapping("/batchNo/list")
    public Result<List<String>> getBatchList(@ApiParam(value = "硬件类型id", required = false) Long hardwareTypeId,
                                             @ApiParam(value = "硬件版本id", required = false) Long hardwareVersionId) {
        return Result.success(batchInfoService.getBatchNoList(hardwareTypeId, hardwareVersionId));
    }

    @ApiOperation("查询库存中的CCU")
    @GetMapping("/ccu/page")
    public PageResult<DeviceInfoVO> deviceInStoragePageQuery(DeviceInStorageQuery deviceInStorageQuery) {
        return PageResult.success(deviceStorageService.deviceInStoragePageQuery(deviceInStorageQuery));
    }

    @ApiOperation("库存管理 - 统计信息出图")
    @GetMapping("/overview")
    public Result<DeviceStorageOverviewVO> overview() {
        return Result.success(deviceStorageService.overview());
    }

    @ApiOperation("出库记录 - 分页查询")
    @GetMapping("/history/record")
    public PageResult<OutStorageRecordVO> queryOutStorageRecord(OutStorageRecordQuery outStorageRecordQuery) {
        return PageResult.success(deviceStorageService.queryOutStorageRecord(outStorageRecordQuery));
    }

    @ApiOperation("出库记录 - 详情")
    @GetMapping("/history/detail")
    public PageResult<OutStorageDetailVO> queryOutStorageDetail(@ApiParam(value = "出库单id", required = true) @RequestParam Long recordId,
                                                                @ApiParam(value = "页码", required = false, defaultValue = "1") @RequestParam(required = false, defaultValue = "1") Integer pageNum,
                                                                @ApiParam(value = "每页记录数", required = false, defaultValue = "10") @RequestParam(required = false, defaultValue = "10") Integer pageSize) {
        return PageResult.success(deviceStorageService.queryOutStorageDetail(Collections.singletonList(recordId), pageNum, pageSize));
    }

    @ApiOperation("出库记录 - 下载")
    @PostMapping("/history/download")
    public void downloadSelected(HttpServletResponse response, @RequestBody OutStorageRecordQuery outStorageRecordQuery) throws IOException {
        List<OutStorageRecordVO> recordVOList = new ArrayList<>();
        for (int pageNum = 1, pageSize = 50; ; pageNum++) {
            outStorageRecordQuery.setPageNum(pageNum);
            outStorageRecordQuery.setPageSize(pageSize);
            IPage<OutStorageRecordVO> page = deviceStorageService.queryOutStorageRecord(outStorageRecordQuery);
            if (page == null || CollectionUtil.isEmpty(page.getRecords())) {
                break;
            }
            recordVOList.addAll(page.getRecords());
        }
        if (CollectionUtil.isEmpty(recordVOList)) {
            throw new BizException("无匹配的出库记录");
        }

        List<Long> recordIdList = recordVOList.stream().map(OutStorageRecordVO::getId).distinct().collect(Collectors.toList());
        List<OutStorageDetailVO> detailVOList = new ArrayList<>();
        for (int pageNum = 1, pageSize = 50; ; pageNum++) {
            IPage<OutStorageDetailVO> page = deviceStorageService.queryOutStorageDetail(recordIdList, pageNum, pageSize);
            if (page == null || CollectionUtil.isEmpty(page.getRecords())) {
                break;
            }
            detailVOList.addAll(page.getRecords());
        }

        try {
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setCharacterEncoding("utf-8");
            // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
            String fileName = URLEncoder.encode("CCU出库记录", "UTF-8").replaceAll("\\+", "%20");
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
            // 这里需要设置不关闭流
            ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream())
                    .autoCloseStream(Boolean.FALSE)
                    .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                    .build();

            // 第一个sheet存出库单
            WriteSheet recordSheet = EasyExcel.writerSheet(0, "出库单").head(OutStorageRecordVO.class).build();
            excelWriter.write(recordVOList, recordSheet);

            // 第二个sheet存出库单详情
            WriteSheet detailSheet = EasyExcel.writerSheet(1, "出库单详情").head(OutStorageDetailVO.class).build();
            excelWriter.write(detailVOList, detailSheet);

            excelWriter.finish();

        } catch (Exception e) {
            response.reset();
            response.setContentType("application/json");
            response.setCharacterEncoding("utf-8");
            Result result = Result.failed("导出异常！");
            response.getWriter().println(JSON.toJSONString(result));
        }

    }

}
