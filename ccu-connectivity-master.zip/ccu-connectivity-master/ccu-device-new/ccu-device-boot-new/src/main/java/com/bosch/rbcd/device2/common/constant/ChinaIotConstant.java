package com.bosch.rbcd.device2.common.constant;

public interface ChinaIotConstant {

    /**
     * 缓存中国移动api调用token的key
     */
    String IOT_TOKEN_KEY = "chinaMobile:token";

    /**
     * 移动IOT平台调用成功返回的状态码
     */
    String IOT_RESPONSE_OK_STATUS = "0";

    /**
     * 移动sim卡归属平台
     */
    String SIM_PLATFORM_PB = "OneLink-PB";
    String SIM_PLATFORM_CT = "OneLink-CT";

    /**
     * 移动平台获取token url
     */
    String IOT_GET_TOKEN_URL = "https://api.iot.10086.cn/v5/ec/get/token?appid=%s&password=%s";

    /**
     * 移动平台根据iccid获取sim卡的归属平台url
     */
    String IOT_SIM_PLATFORM_URL = "https://api.iot.10086.cn/v5/ec/query/sim-platform/batch?transid=%s&token=%s&iccids=%s";

    /**
     * 单卡基本信息查询
     */
    String IOT_SIM_BASIC_URL = "https://api.iot.10086.cn/v5/ec/query/sim-basic-info?transid=%s&token=%s&iccid=%s";

    /**
     * 实时查询物联卡本月套餐内流量使用量url
     */
    String IOT_SIM_DATA_URL = "https://api.iot.10086.cn/v5/ec/query/sim-data-margin?transid=%s&iccid=%s&token=%s";

    /**
     * 查询指定资费的详细信息url
     */
    String IOT_OFFERING_DETAIL_URL = "https://api.iot.10086.cn/v5/ec/query/offerings-detail?transid=%s&token=%s&offeringId=%s";

    /**
     * 通过卡号查询物联卡的状态信息url
     */
    String IOT_SIM_STATUS_URL = "https://api.iot.10086.cn/v5/ec/query/sim-status?transid=%s&token=%s&iccid=%s";

    /**
     * 批量查询物联卡单月流量
     */
    String SIM_MONTH_GPRS_BATCH = "https://api.iot.10086.cn/v5/ec/query/sim-data-usage-monthly/batch?transid=%s&token=%s&iccids=%s&queryDate=%s";


    /**
     * 批量查询物联卡单日流量
     */
    String SIM_DAILY_GPRS_BATCH = "https://api.iot.10086.cn/v5/ec/query/sim-data-usage-daily/batch?transid=%s&token=%s&iccids=%s&queryDate=%s";


    /**
     * 查询物联卡最后位置
     */
    String SIM_LOCATION_BATCH = "https://api.iot.10086.cn/v5/ec/query/last-position-location?transid=%s&token=%s&iccid=%s";

    /**
     * 查询物联卡最后在线信息
     */
    String SIM_ONLINE_URL = "https://api.iot.10086.cn/v5/ec/query/sim-session?transid=%s&token=%s&iccid=%s";

    /**
     * CMIOT_API23E05-集团生命周期各状态用户数查询
     */
    String SIM_STATUS_NUM_URL = "https://api.iot.10086.cn/v5/ec/query/ec-sim-status-number?transid=%s&token=%s";

    /**
     * CMIOT_API23B01-单卡余额信息实时查询
     */
    String SIM_BALANCE_URL = "https://api.iot.10086.cn/v5/ec/query/balance-info?transid=%s&token=%s&iccid=%s";

    /**
     * CMIOT_API23E06-集团群组信息查询
     */
    String ALL_GROUP_URL = "https://api.iot.10086.cn/v5/ec/query/group-info?transid=%s&token=%s&pageSize=40&startNum=1";

    /**
     * CMIOT_API23E02-成员归属群组查询
     */
    String SIM_GROUP_URL = "https://api.iot.10086.cn/v5/ec/query/group-by-member?transid=%s&token=%s&iccid=%s";

    /**
     * CMIOT_API23U04-群组本月套餐内流量使用量实时查询
     */
    String GROUP_MONTH_DATA_URL = "https://api.iot.10086.cn/v5/ec/query/group-data-margin?transid=%s&token=%s&groupId=%s";
}
