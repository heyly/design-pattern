package com.bosch.rbcd.device2.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.device2.pojo.entity.DataPoolHistory;

public interface DataPoolHistoryMapper extends BaseMapper<DataPoolHistory> {

    void saveHistory(Long dataPoolId);
}
