package com.bosch.rbcd.device2.common.enums;

import com.bosch.rbcd.common.base.IBaseEnum;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname SimSupplierEnum
 * @description TODO
 * @date 2023/8/15 13:45
 */
public enum SimSupplierEnum implements IBaseEnum<String> {
    CMCC("CMCC", "China Mobile", "中国移动"),
    CUCC("CUCC", "China Unicom", "中国联通"),
    CTCC("CTCC", "China Telecom", "中国电信");
    private String value;

    private String label;

    private String cnLabel;

    SimSupplierEnum(String value, String label, String cnLabel) {
        this.value = value;
        this.label = label;
        this.cnLabel = cnLabel;
    }

    @Override
    public String getValue() {
        return this.value;
    }

    @Override
    public String getLabel() {
        return this.label;
    }
}
