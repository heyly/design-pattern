package com.bosch.rbcd.device2.controller;

import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.web.validate.Create;
import com.bosch.rbcd.common.web.validate.Update;
import com.bosch.rbcd.device2.pojo.form.OtaSoftwareForm;
import com.bosch.rbcd.device2.pojo.form.SoftwareInfoAbleForm;
import com.bosch.rbcd.device2.pojo.query.OtaSoftwareQuery;
import com.bosch.rbcd.device2.pojo.vo.OtaSoftwareVO;
import com.bosch.rbcd.device2.service.OtaSoftwareService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Api(tags = "软件库")
@RestController
@RequestMapping("/software")
public class OtaSoftwareController {

    @Autowired
    private OtaSoftwareService otaSoftwareService;

    @ApiOperation("新增OTA软件包")
    @PostMapping("/create")
    public Result<Long> insert(@Validated(Create.class) @RequestBody OtaSoftwareForm otaSoftwareForm) throws Exception {
        if (otaSoftwareForm.getType() == 0 && CollectionUtils.isEmpty(otaSoftwareForm.getPowerTrainIdList())) {
            return Result.failed("未选择软件包绑定的动力总成");
        }
        if (StringUtils.isNotBlank(otaSoftwareForm.getSequence()) && otaSoftwareForm.getSequence().length() > 8) {
            return Result.failed("版本序列过长");
        }
        long softwareId = otaSoftwareService.saveSoftware(otaSoftwareForm);
        return Result.success(softwareId);
    }

    @ApiOperation("修改OTA软件包")
    @PostMapping("/update")
    public Result<Void> update(@Validated(Update.class) @RequestBody OtaSoftwareForm otaSoftwareForm) {
        if (otaSoftwareForm.getType() == 0 && CollectionUtils.isEmpty(otaSoftwareForm.getPowerTrainIdList())) {
            return Result.failed("未选择软件包绑定的业务类型");
        }
        otaSoftwareService.updateSoftware(otaSoftwareForm);
        return Result.success();
    }

    @ApiOperation("启用或禁用OTA软件包")
    @PostMapping("/enableOrDisable")
    public Result<Void> enableOrDisable(@Validated @RequestBody SoftwareInfoAbleForm softwareInfoAbleForm) {
        if (softwareInfoAbleForm.getStatus() == 0 && StringUtils.isBlank(softwareInfoAbleForm.getDisableReason())) {
            return Result.failed("请输入禁用理由");
        }
        otaSoftwareService.enableOrDisable(softwareInfoAbleForm);
        return Result.success();
    }

    @ApiOperation("查看OTA软件包详情")
    @GetMapping("/detail")
    public Result<OtaSoftwareVO> detail(@ApiParam(value = "软件包id", required = true) @RequestParam Long softwareId) {
        return Result.success(otaSoftwareService.getDetail(softwareId));
    }

    @ApiOperation("分页查询OTA软件包信息")
    @GetMapping("/page")
    public PageResult<OtaSoftwareVO> page(OtaSoftwareQuery otaSoftwareQuery) {
        if (otaSoftwareQuery.getStatus() != null && (otaSoftwareQuery.getStatus() < 0 || otaSoftwareQuery.getStatus() > 1)) {
            return PageResult.failed("启用状态异常");
        }
        return PageResult.success(otaSoftwareService.pageQuery(otaSoftwareQuery));
    }

    @ApiOperation("查询支持指定项目的全部OTA软件包")
    @GetMapping("/listForProject")
    public Result<List<OtaSoftwareVO>> listForProject(@ApiParam(value = "项目id", required = true) @RequestParam Long projectId) {
        return Result.success(otaSoftwareService.listForProject(projectId));
    }

    @ApiOperation("删除OTA软件包")
    @DeleteMapping("/delete")
    public Result<Void> delete(@ApiParam(value = "软件包id", required = true) @RequestParam Long softwareId) {
        otaSoftwareService.deleteSoftware(softwareId);
        return Result.success();
    }

}
