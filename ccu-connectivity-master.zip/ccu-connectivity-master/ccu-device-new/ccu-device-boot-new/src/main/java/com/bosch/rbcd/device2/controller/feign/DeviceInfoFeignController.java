package com.bosch.rbcd.device2.controller.feign;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.dto.DevicePeriodUploadDTO;
import com.bosch.rbcd.device2.dto.DeviceSelfCheckDTO;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import com.bosch.rbcd.device2.dto.SimStatusDTO;
import com.bosch.rbcd.device2.pojo.bo.iot.SimSessionResponse;
import com.bosch.rbcd.device2.pojo.bo.iot.SimStatusResponse;
import com.bosch.rbcd.device2.pojo.entity.DeviceInfo;
import com.bosch.rbcd.device2.pojo.entity.SimInfo;
import com.bosch.rbcd.device2.query.DevicePeriodUploadQuery;
import com.bosch.rbcd.device2.query.DeviceSelfCheckQuery;
import com.bosch.rbcd.device2.service.ChinaMobileIotService;
import com.bosch.rbcd.device2.service.DeviceInfoService;
import com.bosch.rbcd.device2.service.DeviceStatusService;
import com.bosch.rbcd.device2.service.SimInfoService;
import com.bosch.rbcd.device2.vo.DevicePeriodUploadVO;
import com.bosch.rbcd.device2.vo.DeviceSelfCheckParamVO;
import com.bosch.rbcd.device2.vo.DeviceSelfCheckVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@ApiIgnore
@RestController
@RequestMapping("/feign/ccu")
public class DeviceInfoFeignController {

    @Autowired
    private DeviceInfoService deviceInfoService;

    @Autowired
    private DeviceStatusService deviceStatusService;

    @Autowired
    private SimInfoService simInfoService;

    @Autowired
    private ChinaMobileIotService chinaMobileIotService;

    @GetMapping("/findByCcuId")
    Result<ProjectVehicleCcuDTO> findByCcuId(@RequestParam String ccuId){
        DeviceInfo deviceInfo = deviceInfoService.getByCcuId(ccuId);
        ProjectVehicleCcuDTO projectVehicleCcuDTO = null;
        if(deviceInfo != null){
            projectVehicleCcuDTO = new ProjectVehicleCcuDTO();
            BeanUtils.copyProperties(deviceInfo, projectVehicleCcuDTO);
        }
        return Result.success(projectVehicleCcuDTO);
    }

    @GetMapping("/findCcuNoByCcuIds")
    Result<String> findCcuNoByCcuIds(@RequestParam String ccuIds) {
        List<String> ccuNos = deviceInfoService.listObjs(
                new LambdaQueryWrapper<DeviceInfo>().select(DeviceInfo::getCcuNo)
                        .in(DeviceInfo::getCcuId, StrUtil.split(ccuIds, ",")), o -> (String) o);
        return Result.success(StrUtil.join(",", ccuNos));
    }

    @GetMapping("/findByImei")
    Result<ProjectVehicleCcuDTO> findByImei(@RequestParam String imei) {
        DeviceInfo deviceInfo = deviceInfoService.getByImei(imei);
        ProjectVehicleCcuDTO projectVehicleCcuDTO = null;
        if(deviceInfo != null){
            projectVehicleCcuDTO = new ProjectVehicleCcuDTO();
            BeanUtils.copyProperties(deviceInfo, projectVehicleCcuDTO);
        }
        return Result.success(projectVehicleCcuDTO);
    }

    @GetMapping("/findBySn")
    Result<List<ProjectVehicleCcuDTO>> findBySn(@RequestParam String snList) {
        List<DeviceInfo> list = deviceInfoService.list(new LambdaQueryWrapper<DeviceInfo>().in(DeviceInfo::getShortSn, Arrays.asList(snList.split(","))));
        List<ProjectVehicleCcuDTO> result = list.stream().map(item -> Convert.convert(ProjectVehicleCcuDTO.class, item)).collect(Collectors.toList());
        return Result.success(result);
    }

    @GetMapping("/findByCcuNo")
    Result<ProjectVehicleCcuDTO> findByCcuNo(@RequestParam String ccuNo) {
        DeviceInfo deviceInfo = deviceInfoService.getByCcuNo(ccuNo);
        ProjectVehicleCcuDTO projectVehicleCcuDTO = null;
        if(deviceInfo != null){
            projectVehicleCcuDTO = new ProjectVehicleCcuDTO();
            BeanUtils.copyProperties(deviceInfo, projectVehicleCcuDTO);
        }
        return Result.success(projectVehicleCcuDTO);
    }

    @PostMapping("/update")
    Result<?> update(@RequestBody ProjectVehicleCcuDTO ccuDeviceInfo) {
        if (ccuDeviceInfo == null || ccuDeviceInfo.getId() == null) {
            return Result.success();
        }
        DeviceInfo deviceInfo = new DeviceInfo();
        BeanUtils.copyProperties(ccuDeviceInfo, deviceInfo);
        deviceInfoService.updateById(deviceInfo);
        return Result.success();
    }

    @GetMapping("/listProjectCcu")
    Result<List<ProjectVehicleCcuDTO>> listProjectCcu(@RequestParam long projectId) {
        List<ProjectVehicleCcuDTO> list = deviceInfoService.listProjectVehicleCcu(projectId);
        return Result.success(list);
    }

    @PostMapping("/selfCheck/insert")
    Result<Void> insertSelfCheck(@RequestBody DeviceSelfCheckDTO deviceSelfCheckDTO) {
        deviceStatusService.insertSelfCheck(deviceSelfCheckDTO);
        return Result.success();
    }

    @PostMapping("/selfCheck/page")
    PageResult<DeviceSelfCheckVO> pageSelfCheckRecord(DeviceSelfCheckQuery deviceSelfCheckQuery) {
        return PageResult.success(deviceStatusService.pageQuerySelfCheck(deviceSelfCheckQuery));
    }

    @GetMapping("/selfCheck/getErrorTypeTree")
    Result<List<DeviceSelfCheckParamVO>> getErrorTypeTree() {
        return Result.success(deviceStatusService.getSelfCheckParamsFromRedis());
    }

    @PostMapping("/period/insertPeriodUpload")
    Result<Void> insertPeriodUpload(@RequestBody DevicePeriodUploadDTO devicePeriodUploadDTO) {
        deviceStatusService.insertPeriodUpload(devicePeriodUploadDTO);
        return Result.success();
    }

    @PostMapping("/period/pageCcuStatusUp")
    PageResult<DevicePeriodUploadVO> pageCcuStatusUp(@RequestBody DevicePeriodUploadQuery devicePeriodUploadQuery) {
        return PageResult.success(deviceStatusService.pageQueryPeriodUpload(devicePeriodUploadQuery));
    }

    /**
     * 如果不是中国移动的卡，则返回null
     * @param ccuId
     * @return
     */
    @GetMapping("/sim/lastOnlineTime")
    Result<SimStatusDTO> simLastOnlineTime(@RequestParam String ccuId) {
        if (ccuId == null) {
            return Result.success(null);
        }

        DeviceInfo deviceInfoPO = deviceInfoService.getByCcuId(ccuId);
        if (deviceInfoPO == null) {
            return Result.success(null);
        }
        SimStatusDTO simStatusDTO = new SimStatusDTO();
        String iccid = null;
        if (deviceInfoPO.getSimId() != null) {
            SimInfo ccuSimInfo = simInfoService.getById(deviceInfoPO.getSimId());
            if (ccuSimInfo != null) {
                iccid = ccuSimInfo.getIccid();
                simStatusDTO.setCardStatus(ccuSimInfo.getCardStatus());
            }
        }

        if (StrUtil.isBlank(iccid)) {
            return Result.success(null);
        }

        // 实时查询最后在线时间
        SimSessionResponse simSession = chinaMobileIotService.getSimSessionInfo(iccid);
        log.info("simLastOnlineTime 查询请求iccid = {}，结果：{}", iccid, JSON.toJSONString(simSession));
        if (simSession != null && CollectionUtil.isNotEmpty(simSession.getSimSessionList())) {
            String status = simSession.getSimSessionList().get(0).getStatus();
            String createDate = simSession.getSimSessionList().get(0).getCreateDate();
            simStatusDTO.setCreateDate(createDate);
            simStatusDTO.setStatus(status);
        } else if (simSession == null && StrUtil.isBlank(simStatusDTO.getStatus())) {
            // 查询是否是中国移动的sim卡
            SimStatusResponse simStatusResponse = chinaMobileIotService.getSimStatus(iccid);
            log.info("simStatusResponse 查询请求iccid = {}, 结果：{}", iccid, JSON.toJSONString(simStatusResponse));
            if (simStatusResponse == null) {
                return Result.success(null);
            }
            simStatusDTO.setCardStatus(simStatusResponse.getCardStatus());
        }

        return Result.success(simStatusDTO);
    }
}
