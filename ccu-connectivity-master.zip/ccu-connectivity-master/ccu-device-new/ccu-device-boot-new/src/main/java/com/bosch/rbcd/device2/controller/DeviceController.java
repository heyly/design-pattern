package com.bosch.rbcd.device2.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.huawei.util.ObsUtil;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.result.ResultCode;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.device2.pojo.entity.DeviceEol;
import com.bosch.rbcd.device2.pojo.entity.DeviceLogRecord;
import com.bosch.rbcd.device2.pojo.form.DeviceChangeProjectForm;
import com.bosch.rbcd.device2.pojo.form.DeviceUpdateForm;
import com.bosch.rbcd.device2.pojo.query.DeviceInfoQuery;
import com.bosch.rbcd.device2.pojo.query.DeviceLogRecordQuery;
import com.bosch.rbcd.device2.pojo.vo.*;
import com.bosch.rbcd.device2.query.DevicePeriodUploadQuery;
import com.bosch.rbcd.device2.query.DeviceSelfCheckQuery;
import com.bosch.rbcd.device2.service.DeviceEolService;
import com.bosch.rbcd.device2.service.DeviceInfoService;
import com.bosch.rbcd.device2.service.DeviceLogRecordService;
import com.bosch.rbcd.device2.service.DeviceStatusService;
import com.bosch.rbcd.device2.vo.DevicePeriodUploadVO;
import com.bosch.rbcd.device2.vo.DeviceSelfCheckParamVO;
import com.bosch.rbcd.device2.vo.DeviceSelfCheckVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@Api(tags = "系统管理 - CCU列表")
@RestController
@RequestMapping("/device")
public class DeviceController {

    @Autowired
    private DeviceInfoService deviceInfoService;

    @Autowired
    private DeviceEolService deviceEolService;

    @Autowired
    private DeviceLogRecordService deviceLogRecordService;

    @Autowired
    private ObsUtil obsUtil;

    @Autowired
    private DeviceStatusService deviceStatusService;

    @ApiOperation("分页查询CCU（全部信息）")
    @GetMapping("/pageQueryAllItem")
    public PageResult<DeviceInfoVO> pageQueryAllItem(DeviceInfoQuery deviceInfoQuery) {
        return PageResult.success(deviceInfoService.pageQueryAllItem(deviceInfoQuery));
    }

    @ApiOperation("分页查询CCU（指定项目下的）")
    @GetMapping("/queryCcuInProject")
    public PageResult<DeviceInfoVO> queryCcuInProject(DeviceInfoQuery deviceInfoQuery) {
        if (deviceInfoQuery.getProjectId() == null) {
            return PageResult.failed("请选择项目");
        }
        return PageResult.success(deviceInfoService.queryCcuInProject(deviceInfoQuery));
    }

    @ApiOperation("查询ccu数量的汇总信息")
    @GetMapping("/summaryInfo")
    public Result<DeviceSummaryVO> summary() {
        return Result.success(deviceInfoService.summary());
    }

    @ApiOperation("更新ccu信息")
    @PostMapping("/update")
    public Result<?> updateDevice(@Validated @RequestBody DeviceUpdateForm deviceUpdateForm) {
        deviceInfoService.updateCcuInfo(deviceUpdateForm);
        return Result.success();
    }

    @ApiOperation("查询EOL记录")
    @GetMapping("/eol/query")
    public Result<DeviceEolVO> queryEolInfo(@ApiParam(value = "eolId", required = true) Long eolId) {
        if (eolId == null) {
            return Result.failed(ResultCode.PARAM_IS_NULL);
        }
        DeviceEol po = deviceEolService.getById(eolId);
        DeviceEolVO vo = null;
        if (po != null) {
            vo = new DeviceEolVO();
            BeanUtils.copyProperties(po, vo);
        }
        return Result.success(vo);
    }

    @ApiOperation("请求设备最新日志")
    @GetMapping(value = "/log/request")
    public Result<?> requestLog(@RequestParam String imei) {
        return deviceLogRecordService.requestDeviceLog(imei, UserUtils.getRealName(), null, null);
    }

    @ApiOperation("获取设备日志记录")
    @PostMapping(value = "/log/query")
    public PageResult<DeviceLogRecordVO> listLogRecord(@RequestBody DeviceLogRecordQuery query) {
        IPage<DeviceLogRecord> poPage = deviceLogRecordService.pageDeviceLogRecord(query);
        if (poPage == null || CollectionUtils.isEmpty(poPage.getRecords())) {
            return PageResult.success(new Page<DeviceLogRecordVO>(query.getPageNum(), query.getPageSize()));
        } else {
            IPage<DeviceLogRecordVO> voPage = JSON.parseObject(JSON.toJSONString(poPage), new TypeReference<Page<DeviceLogRecordVO>>(){});
            if (voPage != null && CollectionUtils.isNotEmpty(voPage.getRecords())) {
                for (DeviceLogRecordVO deviceLogRecordVO : voPage.getRecords()) {
                    String obsPath = deviceLogRecordVO.getObsPath();
                    String fullPath = obsPath;
                    try {
                        fullPath = obsUtil.getFileUrl(null, obsPath);
                    } catch (Exception e) {
                        log.error("获取OBS全链接异常！", e);
                    }
                    deviceLogRecordVO.setObsPath(fullPath);
                }
            }
            return  PageResult.success(voPage);
        }
    }

    @ApiOperation("自诊断记录-获取诊断类型参数")
    @GetMapping(value = "/status/getSelfCheckParam")
    public Result<List<DeviceSelfCheckParamVO>> getSelfCheckParam() {
        return  Result.success(deviceStatusService.getSelfCheckParamsFromRedis());
    }

    @ApiOperation("自诊断记录-分页查询获取ccu车辆自检信息")
    @GetMapping(value = "/status/pageSelfCheckRecord")
    public PageResult<DeviceSelfCheckVO> pageSelfCheckRecord(DeviceSelfCheckQuery deviceSelfCheckQuery) {
        if (StringUtils.isBlank(deviceSelfCheckQuery.getCcuId()) && StringUtils.isBlank(deviceSelfCheckQuery.getImei())) {
            return PageResult.failed("请输入ccuId或IMEI");
        }

        if (deviceSelfCheckQuery.getStartTime() == null || deviceSelfCheckQuery.getEndTime() == null) {
            return PageResult.failed("请输入查询时间范围");
        }

        if (deviceSelfCheckQuery.getEndTime().getTime() - deviceSelfCheckQuery.getStartTime().getTime() > 24 * 60 * 60 * 1000) {
            return PageResult.failed("查询时间范围过大，请缩短至24小时内，或至Kibana查看");
        }

        return PageResult.success(deviceStatusService.pageQuerySelfCheck(deviceSelfCheckQuery));
    }

    @ApiOperation("查询CCU周期状态报文")
    @GetMapping("/status/pageCcuStatusUp")
    public PageResult<DevicePeriodUploadVO> pageCcuStatusUp(DevicePeriodUploadQuery devicePeriodUploadQuery) {
        if (StringUtils.isBlank(devicePeriodUploadQuery.getCcuId()) && StringUtils.isBlank(devicePeriodUploadQuery.getImei())) {
            return PageResult.failed("请输入ccuId或IMEI");
        }

        if (devicePeriodUploadQuery.getStartTime() == null || devicePeriodUploadQuery.getEndTime() == null) {
            return PageResult.failed("请输入查询时间范围");
        }

        if (devicePeriodUploadQuery.getEndTime().getTime() - devicePeriodUploadQuery.getStartTime().getTime() > 24 * 60 * 60 * 1000) {
            return PageResult.failed("查询时间范围过大，请缩短至24小时内，或至Kibana查看");
        }

        return PageResult.success(deviceStatusService.pageQueryPeriodUpload(devicePeriodUploadQuery));
    }

    @ApiOperation("变更CCU所属项目")
    @PostMapping("/changeProject")
    public Result<List<DeviceChangeProjectVO>> changeProject(@Validated @RequestBody DeviceChangeProjectForm deviceChangeProjectForm) {
        return Result.success(deviceInfoService.changeProject(deviceChangeProjectForm));
    }

    @ApiOperation("查询CCU支持的CAN通道数量")
    @GetMapping("/queryCanLimit")
    public Result<Integer> queryCanLimit(@RequestParam String ccuId) {
        return Result.success(deviceInfoService.queryCanLimit(ccuId));
    }
}
