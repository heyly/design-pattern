package com.bosch.rbcd.device2.controller.feign;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.dto.OtaDeviceHistoryDTO;
import com.bosch.rbcd.device2.service.OtaFeignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@RestController
@RequestMapping("/feign/ota")
public class OtaFeignController {

    @Autowired
    private OtaFeignService otaFeignService;

    @GetMapping("/getResendOtaTask")
    Result<OtaDeviceHistoryDTO> getResendOtaTask(@RequestParam String imei){
        return Result.success(otaFeignService.getResendOtaTask(imei));
    }

    @PutMapping("/resetSelfOTAStatus")
    Result<Integer> resetSelfOTAStatus(String imei){
        return Result.success(otaFeignService.resetSelfOTAStatus(imei));
    }

    @GetMapping("/updateStatus")
    Result<Integer> updateStatus(@RequestParam Integer statusCode, @RequestParam String timestamp,@RequestParam Long taskId, @RequestParam String imei) {
        return Result.success(otaFeignService.updateStatus(statusCode, timestamp, taskId, imei));
    }

    @GetMapping("/execOtaFinish")
    Result<Object> execOtaFinish(@RequestParam Long taskId, @RequestParam String imei) {
        return Result.success(otaFeignService.execOtaFinish(taskId, imei));
    }
}
