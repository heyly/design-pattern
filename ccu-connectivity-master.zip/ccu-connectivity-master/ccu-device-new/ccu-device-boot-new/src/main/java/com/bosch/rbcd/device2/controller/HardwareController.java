package com.bosch.rbcd.device2.controller;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.web.validate.Create;
import com.bosch.rbcd.common.web.validate.Update;
import com.bosch.rbcd.device2.pojo.form.HardwareTypeForm;
import com.bosch.rbcd.device2.pojo.form.HardwareVersionForm;
import com.bosch.rbcd.device2.pojo.form.HardwareVersionPriceForm;
import com.bosch.rbcd.device2.pojo.vo.HardwareTypeVO;
import com.bosch.rbcd.device2.pojo.vo.HardwareVersionPriceHistoryVO;
import com.bosch.rbcd.device2.pojo.vo.HardwareVersionPriceVO;
import com.bosch.rbcd.device2.pojo.vo.HardwareVersionVO;
import com.bosch.rbcd.device2.service.HardwareService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Api(tags = "系统管理 - 硬件类型管理")
@RestController
@RequestMapping("/hardware")
public class HardwareController {

    @Autowired
    private HardwareService hardwareService;

    @ApiOperation("获取全部硬件类型与硬件版本")
    @GetMapping("/allInfo")
    public Result<List<HardwareTypeVO>> getAllHardwareInfo() {
        return Result.success(hardwareService.getAllHardwareInfo());
    }

    @ApiOperation("获取全部硬件类型")
    @GetMapping("/type/all")
    public Result<List<HardwareTypeVO>> getAllHardwareType() {
        return Result.success(hardwareService.allHardwareType());
    }

    @ApiOperation("新增硬件类型")
    @PostMapping("/type/create")
    public Result<Long> createHardwareType(@Validated @RequestBody HardwareTypeForm hardwareTypeForm) {
        return Result.success(hardwareService.createHardwareType(hardwareTypeForm));
    }

    @ApiOperation("删除硬件类型")
    @DeleteMapping("/type/delete")
    public Result<Void> deleteHardwareType(@ApiParam(value = "硬件类型id", required = true) @RequestParam Long typeId) {
        hardwareService.deleteHardwareType(typeId);
        return Result.success();
    }

    @ApiOperation("获取硬件类型下的全部硬件版本")
    @GetMapping("/version/all")
    public Result<List<HardwareVersionVO>> getAllHardwareVersion(@ApiParam(value = "硬件类型id", required = true) @RequestParam Long typeId) {
        return Result.success(hardwareService.getAllHardwareVersion(typeId));
    }

    @ApiOperation("新增硬件版本")
    @PostMapping("/version/create")
    public Result<Long> createHardwareVersion(@Validated(Create.class) @RequestBody HardwareVersionForm hardwareVersionForm) {
        return Result.success(hardwareService.createHardwareVersion(hardwareVersionForm));
    }

    @ApiOperation("修改硬件版本")
    @PostMapping("/version/update")
    public Result<Void> updateHardwareVersion(@Validated(Update.class) @RequestBody HardwareVersionForm hardwareVersionForm) {
        hardwareService.updateHardwareVersion(hardwareVersionForm);
        return Result.success();
    }

    @ApiOperation("删除硬件版本")
    @DeleteMapping("/version/delete")
    public Result<Void> deleteHardwareVersion(@ApiParam(value = "硬件版本id", required = true) @RequestParam Long versionId) {
        hardwareService.deleteHardwareVersion(versionId);
        return Result.success();
    }

    @ApiOperation("设置硬件版本的价格")
    @PostMapping("/version/setPrice")
    public Result<Long> setHardwareVersionPrice(@Valid @RequestBody HardwareVersionPriceForm hardwareVersionPriceForm) {
        hardwareService.setHardwareVersionPrice(hardwareVersionPriceForm);
        return Result.success();
    }

    @ApiOperation("硬件版本历史价格")
    @GetMapping("/version/priceLog")
    public Result<List<HardwareVersionPriceHistoryVO>> hardwareVersionPriceLog(@ApiParam(value = "硬件版本id", required = true) @RequestParam Long versionId,
                                                                               @ApiParam(value = "动力总成id", required = true) @RequestParam Long powerTrainId) {
        return Result.success(hardwareService.getPriceLog(versionId, powerTrainId));
    }

    @ApiOperation("查询硬件版本的当前价格")
    @GetMapping("/version/queryPrice")
    public Result<Double> queryPrice(@ApiParam(value = "硬件版本id", required = true) @RequestParam Long versionId,
                                     @ApiParam(value = "动力总成id", required = true) @RequestParam Long powerTrainId) {
        return Result.success(hardwareService.queryPrice(versionId, powerTrainId));
    }

    @ApiOperation("查询指定的硬件版本在不同控制器下的价格")
    @GetMapping("/version/powerTrain/priceList")
    public Result<List<HardwareVersionPriceVO>> queryPriceInPowerTrain(@ApiParam(value = "硬件版本id", required = true) @RequestParam Long versionId) {
        return Result.success(hardwareService.queryVersionPriceInPowerTrain(versionId));
    }
}
