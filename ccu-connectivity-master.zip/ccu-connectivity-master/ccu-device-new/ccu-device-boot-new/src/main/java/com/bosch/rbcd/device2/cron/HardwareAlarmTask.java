package com.bosch.rbcd.device2.cron;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.utils.communication.MailUtil;
import com.bosch.rbcd.device2.common.constant.CommonConstant;
import com.bosch.rbcd.device2.pojo.entity.HardwareVersion;
import com.bosch.rbcd.device2.service.DeviceInfoService;
import com.bosch.rbcd.device2.service.HardwareVersionService;
import com.bosch.rbcd.system.api.UserFeignClient;
import com.bosch.rbcd.system.dto.UserDetailDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HardwareAlarmTask {

    @Autowired
    private HardwareVersionService hardwareVersionService;

    @Autowired
    private DeviceInfoService deviceInfoService;

    @Autowired
    private UserFeignClient userFeignClient;

    @Autowired
    private MailUtil mailUtil;

    @Value("${spring.profiles.active}")
    private String env;

    //@Scheduled(cron = "0 0 10 * * ?")
    public void checkQuantityInStock() {
        if (!StringUtils.equalsIgnoreCase(env, "prod")) {
            return;
        }

        LambdaQueryWrapper<HardwareVersion> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(HardwareVersion::getStatus, 1);
        queryWrapper.eq(HardwareVersion::getDeleted, 0);

        List<HardwareVersion> hardwareVersionList = hardwareVersionService.list();
        for (HardwareVersion hardwareVersion : hardwareVersionList) {

            int inStorageNum = deviceInfoService.inStorageNum(hardwareVersion.getId());
            if (hardwareVersion.getAlarmThreshold() != null && inStorageNum < hardwareVersion.getAlarmThreshold()) {
                Result<UserDetailDTO> adminResult = userFeignClient.getUserDetail(hardwareVersion.getAdminId());
                String[] to = new String[1];
                to[0] = adminResult.getData().getEmail();

                String[] cc = new String[1];
                cc[0] = CommonConstant.PROJECT_MANAGER_EMAIL;
                String subject = "CCU库存告警";
                String content = hardwareVersion.getName() + " 库存已不足 " + hardwareVersion.getAlarmThreshold() + " 个，请及时补货！";
                mailUtil.asyncSendSimpleMail(to, cc, subject, content);
            }

        }
    }
}
