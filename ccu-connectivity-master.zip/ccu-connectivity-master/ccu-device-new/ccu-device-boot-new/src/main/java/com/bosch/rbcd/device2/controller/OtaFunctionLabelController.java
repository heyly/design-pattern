package com.bosch.rbcd.device2.controller;

import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.pojo.entity.OtaFunctionLabel;
import com.bosch.rbcd.device2.pojo.form.OtaFunctionLabelForm;
import com.bosch.rbcd.device2.pojo.query.OtaFunctionLabelQuery;
import com.bosch.rbcd.device2.service.OtaFunctionLabelService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Api(tags = "系统管理 - OTA功能标签")
@RestController
@RequestMapping("/otaFunctionLabel")
public class OtaFunctionLabelController {

    @Autowired
    private OtaFunctionLabelService otaFunctionLabelService;

    @ApiOperation("创建OTA功能标签")
    @PostMapping("/create")
    public Result<Long> createLabel(@Validated @RequestBody OtaFunctionLabelForm otaFunctionLabelForm) {
        return Result.success(otaFunctionLabelService.createLabel(otaFunctionLabelForm));
    }

    @ApiOperation("删除OTA功能标签")
    @DeleteMapping("/delete")
    public Result<Void> deleteLabel(@ApiParam(value = "主键id", required = true) @RequestParam("id") Long id) {
        otaFunctionLabelService.deleteLabel(id);
        return Result.success();
    }

    @ApiOperation("分页查询OTA功能标签")
    @GetMapping("/page")
    public PageResult<OtaFunctionLabel> pageQuery(OtaFunctionLabelQuery otaFunctionLabelQuery) {
        return PageResult.success(otaFunctionLabelService.pageQuery(otaFunctionLabelQuery));
    }
}
