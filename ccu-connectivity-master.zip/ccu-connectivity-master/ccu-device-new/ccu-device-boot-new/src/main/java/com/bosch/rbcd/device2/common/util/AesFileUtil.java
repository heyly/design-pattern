package com.bosch.rbcd.device2.common.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;

@Slf4j
public class AesFileUtil {

    /**
     * 加密方法
     *
     * @param data 要加密的数据
     * @param key  加密key
     * @param iv   加密iv
     * @return 加密的结果
     * @throws Exception
     */
    public static String encrypt(String data, byte[] key, byte[] iv) throws Exception {
        try {

            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");//"算法/模式/补码方式"NoPadding PkcsPadding
            int blockSize = cipher.getBlockSize();

            byte[] dataBytes = data.getBytes();
            int plaintextLength = dataBytes.length;
            if (plaintextLength % blockSize != 0) {
                plaintextLength = plaintextLength + (blockSize - (plaintextLength % blockSize));
            }

            byte[] plaintext = new byte[plaintextLength];
            System.arraycopy(dataBytes, 0, plaintext, 0, dataBytes.length);

            SecretKeySpec keyspec = new SecretKeySpec(key, "AES");
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
            byte[] encrypted = cipher.doFinal(plaintext);

            return new Base64().encodeToString(encrypted);

        } catch (Exception e) {
            log.error("com.bosch.rbcd.device.utils.AesFileUtil.encrypt error!", e);
            return null;
        }
    }

    /**
     * 解密方法
     *
     * @param data 要解密的数据
     * @param key  解密key
     * @param iv   解密iv
     * @return 解密的结果
     * @throws Exception
     */
    public static String desEncrypt(String data, byte[] key, byte[] iv) throws Exception {
        try {
            byte[] encrypted1 = new Base64().decode(data);

            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            SecretKeySpec keyspec = new SecretKeySpec(key, "AES");
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);

            byte[] original = cipher.doFinal(encrypted1);
            String originalString = new String(original);
            return originalString;
        } catch (Exception e) {
            log.error("com.bosch.rbcd.device.utils.AesFileUtil.desEncrypt error!", e);
            return null;
        }
    }

    public static byte[] readFile(String fileName) throws IOException {

        File f = new File(fileName);
        int filesize=(int)f.length();
        byte[] buffer = new byte[filesize];

        if (f.isFile() && f.exists()) {
            try (FileInputStream fi=new FileInputStream(f)) {
                int offset = 0;
                int numRead = 0;
                while (offset < filesize
                        && (numRead = fi.read(buffer, offset, filesize - offset)) >= 0) {
                    offset += numRead;
                }
            } catch (Exception e) {
                log.error("com.bosch.rbcd.solution.utils.AesFileUtil.readFile error!", e);
            }
        }
        return buffer;

    }

    public static void writeFile(String fileName, byte[] fileContent)
    {
        File f = new File(fileName);
        try {
            if (!f.exists()) {
                f.createNewFile();
            } else {
                f.delete();
                f.createNewFile();
            }
        } catch (Exception e) {
            log.error("com.bosch.rbcd.device.utils.AesFileUtil.writeFile error!", e);
            return;
        }
        try(FileOutputStream fos=new FileOutputStream(f)) {
            fos.write(fileContent);
        } catch (Exception e) {
            log.error("com.bosch.rbcd.device.utils.AesFileUtil.writeFile error!", e);
        }
    }
    public static byte[] hexToByte(String hex){
        int m = 0, n = 0;
        int byteLen = hex.length() / 2; // 每两个字符描述一个字节
        byte[] ret = new byte[byteLen];
        for (int i = 0; i < byteLen; i++) {
            m = i * 2 + 1;
            n = m + 1;
            int intVal = Integer.decode("0x" + hex.substring(i * 2, m) + hex.substring(m, n));
            ret[i] = Byte.valueOf((byte)intVal);
        }
        return ret;
    }

    public static boolean refile(String destFile,String destFilePath,int time) {
        System.gc();//在删除之前调用垃圾回收,这样jvm就不会占用文件了
        Boolean de=null;
        Boolean re=null;
        File src = new File(destFilePath);
        de = src.delete();
        File dest = new File(destFile);
        re = dest.renameTo(new File(destFilePath));
        if(de==true&&re==true){
            return true;
        }else {
            return false;
        }
    }

    /**
     * 加密方法
     *
     * @param data 要加密的数据
     * @param key  加密key
     * @param iv   加密iv
     * @return 加密的结果
     * @throws Exception
     */
    public static byte[] encryptBinFile(byte[] data, byte[] key, byte[] iv) throws Exception {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");//"算法/模式/补码方式"NoPadding PkcsPadding
            int blockSize = cipher.getBlockSize();
            SecretKeySpec keyspec = new SecretKeySpec(key, "AES");
            IvParameterSpec ivspec = new IvParameterSpec(iv);
            cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
            byte[] encrypted = cipher.doFinal(data);
            log.info("com.bosch.rbcd.device.utils.AesFileUtil.encryptBinFile data.length = {}, key.length = {}, iv.length = {}, encrypted.length = {}", data.length, key.length, iv.length, encrypted.length);
            return encrypted;
        } catch (Exception e) {
            log.error("com.bosch.rbcd.device.utils.AesFileUtil.encryptBinFile error!", e);
            return null;
        }
    }
    public static String getJavaEncode(String filePath) throws IOException {
        BufferedInputStream bin = new BufferedInputStream(new FileInputStream(filePath));
        int p = (bin.read() << 8) + bin.read();
        bin.close();
        String code = null;

        switch (p) {
            case 0xefbb:
                code = "UTF-8";
                break;
            case 0xfffe:
                code = "Unicode";
                break;
            case 0xfeff:
                code = "UTF-16BE";
                break;
            default:
                code = "GBK";
        }

        return code;
    }

}