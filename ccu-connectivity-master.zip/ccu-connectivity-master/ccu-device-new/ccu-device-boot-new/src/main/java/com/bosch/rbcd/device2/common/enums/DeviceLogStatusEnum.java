package com.bosch.rbcd.device2.common.enums;

/**
 * ccu日志状态枚举类
 */
public enum DeviceLogStatusEnum {

    HAS_SEND("0", "已下发"),
    TO_BE_ONLINE("1", "已上线"),
    HAS_RECEIVED("2", "已接收"),
    HAS_UPLOADED("3", "已上传"),
    TIME_OUT("4", "已超时")
    ;

    private String code;

    private String description;

    DeviceLogStatusEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
