package com.bosch.rbcd.device2.cron;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.huawei.util.IotDaUtil;
import com.bosch.rbcd.common.huawei.util.ObsUtil;
import com.bosch.rbcd.device2.common.enums.DeviceLogStatusEnum;
import com.bosch.rbcd.device2.pojo.entity.DeviceLogRecord;
import com.bosch.rbcd.device2.service.DeviceLogRecordService;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DeviceLogRecordTask {

    @Autowired
    private DeviceLogRecordService deviceLogRecordService;

    @Autowired
    private ObsUtil obsUtil;

    @Autowired
    private IotDaUtil iotDaUtil;

    private final static String LOG_REQUEST_COMMAND = "ccuLogRequest";

    /**
     * 清除半年前的数据
     */
    @XxlJob("cleanExpiredData")
    public void cleanExpiredData() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.clear(Calendar.MINUTE);
        calendar.clear(Calendar.SECOND);
        calendar.add(Calendar.DAY_OF_MONTH, -180);

        LambdaQueryWrapper<DeviceLogRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.le(DeviceLogRecord::getCreateTime, calendar.getTime());


        for (int pageNum=1, pageSize = 50; ;pageNum++){
            IPage<DeviceLogRecord> iPage = new Page<>(pageNum, pageSize);
            iPage = deviceLogRecordService.page(iPage, queryWrapper);
            if (iPage == null || CollectionUtils.isEmpty(iPage.getRecords())) {
                break;
            }
            List<Long> idList = new ArrayList<>(iPage.getRecords().size());
            List<String> obsPathList = new ArrayList<>(iPage.getRecords().size());
            for (DeviceLogRecord deviceLogRecord : iPage.getRecords()) {
                idList.add(deviceLogRecord.getId());
                if (StrUtil.isNotBlank(deviceLogRecord.getObsPath())) {
                    obsPathList.add(deviceLogRecord.getObsPath());
                }
            }
            obsUtil.deleteFiles(obsPathList);
            deviceLogRecordService.removeByIds(idList);
        }
    }

    /**
     * 更新设备日志上传状态
     * 0 0 1 * * ?
     */
    @XxlJob("updateDeviceLogRequestStatus")
    public void updateDeviceLogRequestStatus(){
        LambdaQueryWrapper<DeviceLogRecord> query = new LambdaQueryWrapper<>();
        // 记录超过一天，将已上传以外的状态置为已超时
        query.ne(DeviceLogRecord::getStatus, DeviceLogStatusEnum.HAS_UPLOADED.getCode()).lt(DeviceLogRecord::getCreateTime, DateUtil.yesterday());
        List<DeviceLogRecord> offlineTimoutRecords = deviceLogRecordService.list(query);
        // 离线状态置为超时状态
        offlineTimoutRecords.forEach(record -> {
            record.setStatus(DeviceLogStatusEnum.TIME_OUT.getCode());
            // hwmqtt下发日志请求给ccu
            Map<String, Object> commandParas = new HashMap<>();
            commandParas.put("device", record.getImei());
            commandParas.put("logRequestId", record.getId());
            commandParas.put("messageType", LOG_REQUEST_COMMAND);
            commandParas.put("timestamp", System.currentTimeMillis());
            commandParas.put("msgId", record.getId());
            iotDaUtil.createMessage(record.getImei(), commandParas);
        });
        deviceLogRecordService.updateBatchById(offlineTimoutRecords);
    }
}
