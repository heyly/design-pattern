package com.bosch.rbcd.device2.cron;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.redis.bo.RealTimeData;
import com.bosch.rbcd.device2.common.enums.CommissionStatusEnum;
import com.bosch.rbcd.device2.pojo.entity.DeviceInfo;
import com.bosch.rbcd.device2.service.DeviceInfoService;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Component
@Slf4j
@RequiredArgsConstructor
public class UpdateDeviceTask {

    public static final String QUERY_ADDRESS_URL = "https://restapi.amap.com/v3/geocode/regeo?output=JSON&location=%s&key=%s&radius=1000";
    public static final String MAP_KEY = "4e2ab804a44ab77b8d93ee209bba57a5";

    private final StringRedisTemplate redisTemplate;
    private final DeviceInfoService deviceInfoService;
    private final RestTemplate restTemplate;

    /**
     * 每日凌晨2点自动刷新设备休眠状态
     * 0 0 2 * * ?
     */
    @XxlJob("autoToBeDeactivated")
    public void autoToBeDeactivated() {
        Date today = new Date();
        for (int pageNum = 1, pageSize = 20; ; pageNum++) {
            IPage<DeviceInfo> iPage = new Page<>(pageNum, pageSize);
            iPage = deviceInfoService.page(iPage);
            if (iPage == null || CollectionUtil.isEmpty(iPage.getRecords())) {
                break;
            }
            iPage.getRecords().parallelStream().forEach(ccuDeviceInfoPO -> {
                String key = "RealTimeData:" + ccuDeviceInfoPO.getCcuId();
                String content = (String) redisTemplate.opsForHash().get(key, "data");
                JSONObject parseObject = JSONObject.parseObject(content);
                if (Objects.nonNull(parseObject)) {
                    Date createAt = parseObject.getDate("createAt");
                    // 超过60天未发送消息,设备标记为休眠状态
                    if (DateUtil.betweenDay(createAt, today, true) > 60) {
                        if (ccuDeviceInfoPO.getCommissionStatus() == null || !ccuDeviceInfoPO.getCommissionStatus().equals(CommissionStatusEnum.DEACTIVE.getCode())) {
                            ccuDeviceInfoPO.setCommissionStatus(CommissionStatusEnum.DEACTIVE.getCode());
                            deviceInfoService.updateById(ccuDeviceInfoPO);
                        }
                    }
                }
            });
        }
    }

    /**
     * 更新设备运行状态
     * 0 0/1 * * * ?
     */
    @XxlJob("updateDeviceCommissionStatus")
    public void updateDeviceCommissionStatus() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        QueryWrapper<DeviceInfo> queryWrapper = new QueryWrapper<>();
        for (int pageNum = 1, pageSize = 50; ; pageNum++) {
            IPage<DeviceInfo> iPage = new Page<>(pageNum, pageSize);
            iPage = deviceInfoService.page(iPage, queryWrapper);
            if (iPage == null || CollectionUtil.isEmpty(iPage.getRecords())) {
                break;
            }

            List<DeviceInfo> updateList = new ArrayList<>(pageSize);

            for (DeviceInfo deviceInfoPO : iPage.getRecords()) {
                boolean needUpdate = false;

                Integer oldStatus = deviceInfoPO.getCommissionStatus();
                Integer realStatus = deviceInfoPO.getCommissionStatus();

                HashOperations<String, Object, Object> forHash = redisTemplate.opsForHash();
                String key = "RealTimeData:" + deviceInfoPO.getCcuId();
                Long redisSize = forHash.size(key);
                Object o = forHash.get(key, "data");
                if (redisSize == 0) {
                    realStatus = CommissionStatusEnum.REGISTER.getCode();
                } else if (o == null) {
                    realStatus = CommissionStatusEnum.STOP.getCode();
                } else {
                    RealTimeData realTimeData = JSON.parseObject((String) o, RealTimeData.class);

                    if (realTimeData.getCreateAt() != null) {
                        try {

                            Date createAt = df.parse(realTimeData.getCreateAt());
                            long createTime = createAt.getTime();
                            long date = new Date().getTime();
                            long diff = date - createTime;
                            long fix = 5L * 60 * 1000;
                            if (diff - fix < 0) {
                                realStatus = CommissionStatusEnum.RUN.getCode();
                            } else {
                                realStatus = CommissionStatusEnum.STOP.getCode();
                            }

                            // 更新最后数据时间
                            if (deviceInfoPO.getLastDataTime() == null || !DateUtil.isSameTime(createAt, deviceInfoPO.getLastDataTime())) {
                                deviceInfoPO.setLastDataTime(createAt);
                                needUpdate = true;
                            }

                        } catch (Exception e) {
                            log.error("ParseException error!", e);
                        }
                    } else {
                        realStatus = CommissionStatusEnum.STOP.getCode();
                    }
                }

                if (oldStatus == null) {
                    // 历史状态缺失，则以当前为准
                    needUpdate = true;
                } else if (!oldStatus.equals(realStatus)) {
                    // 状态发生变更
                    if (oldStatus.equals(CommissionStatusEnum.DEACTIVE.getCode()) && !Objects.equals(realStatus, CommissionStatusEnum.RUN.getCode())) {
                        // 历史状态是休眠，但是实际状态不是运行，不进行任何处理
                    } else {
                        // 更新设备状态
                        needUpdate = true;
                    }
                }

                if (needUpdate) {
                    deviceInfoPO.setCommissionStatus(realStatus);
                    updateList.add(deviceInfoPO);
                }

            }

            for (DeviceInfo deviceInfoPO : updateList) {
                LambdaUpdateWrapper<DeviceInfo> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.eq(DeviceInfo::getId, deviceInfoPO.getId());
                updateWrapper.set(DeviceInfo::getCommissionStatus, deviceInfoPO.getCommissionStatus());
                deviceInfoService.update(updateWrapper);
            }
        }
    }

    /**
     * 更新CCU的位置信息
     * 0 0/10 * * * ?
     */
    @XxlJob("updateDevicePosition")
    public void updateDevicePosition() {
        LambdaQueryWrapper<DeviceInfo> queryWrapper = new LambdaQueryWrapper<DeviceInfo>()
                .eq(DeviceInfo::getCommissionStatus, 1);
        for (int pageNum = 1, pageSize = 50; ; pageNum++) {
            IPage<DeviceInfo> iPage = new Page<>(pageNum, pageSize);
            iPage = deviceInfoService.page(iPage, queryWrapper);
            if (iPage == null || CollectionUtil.isEmpty(iPage.getRecords())) {
                break;
            }

            List<DeviceInfo> deviceInfoPOList = iPage.getRecords();

            for (DeviceInfo deviceInfoPO : deviceInfoPOList) {

                HashOperations<String, Object, Object> forHash = redisTemplate.opsForHash();
                String key = "RealTimeData:" + deviceInfoPO.getCcuId();

                try {
                    String longitude = (String) redisTemplate.opsForHash().get("imei:" + deviceInfoPO.getImei(), "longitude");
                    String latitude = (String) redisTemplate.opsForHash().get("imei:" + deviceInfoPO.getImei(), "latitude");
                    if (StrUtil.isAllNotBlank(longitude, latitude)) {
                        deviceInfoPO.setLongitude(longitude);
                        deviceInfoPO.setLatitude(latitude);

                        String startLocation = longitude + "," + latitude;
                        String urlReplace = String.format(QUERY_ADDRESS_URL, startLocation, MAP_KEY);
                        JSONObject geoDeResult = restTemplate.getForObject(urlReplace, JSONObject.class);
                        if (geoDeResult != null && geoDeResult.get("regeocode") != null) {
                            JSONObject regeocode = geoDeResult.getJSONObject("regeocode");
                            String address = regeocode.getString("formatted_address");
                            address = StrUtil.removeAny(address, "殡仪馆", "火葬场");
                            if (!StrUtil.equals("[]", address)) {
                                deviceInfoPO.setAddress(address);
                                forHash.put(key, "address", address);
                            }

                            String province = regeocode.getJSONObject("addressComponent").getString("province");
                            if (!StrUtil.equals("[]", province)) {
                                String cityInfo = regeocode.getJSONObject("addressComponent").getString("city");
                                if (!StrUtil.equals("[]", cityInfo)) {
                                    province = province + cityInfo;
                                }
                                deviceInfoPO.setCityInfo(province);
                                forHash.put(key, "city", deviceInfoPO.getCityInfo());
                            }
                        }
                    }

                } catch (Exception e) {
                    log.error("updateDeviceCommissionStatus query address error!", e);
                }

            }

            for (DeviceInfo deviceInfoPO : deviceInfoPOList) {
                LambdaUpdateWrapper<DeviceInfo> updateWrapper = new LambdaUpdateWrapper<>();
                updateWrapper.eq(DeviceInfo::getId, deviceInfoPO.getId());
                updateWrapper.set(DeviceInfo::getLongitude, deviceInfoPO.getLongitude());
                updateWrapper.set(DeviceInfo::getLatitude, deviceInfoPO.getLatitude());
                updateWrapper.set(DeviceInfo::getAddress, deviceInfoPO.getAddress());
                updateWrapper.set(DeviceInfo::getCityInfo, deviceInfoPO.getCityInfo());
                deviceInfoService.update(updateWrapper);

            }
        }
    }
}
