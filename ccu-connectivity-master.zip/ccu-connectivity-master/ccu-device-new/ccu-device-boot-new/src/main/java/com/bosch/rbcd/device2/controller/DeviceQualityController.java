package com.bosch.rbcd.device2.controller;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.result.ResultCode;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.device2.pojo.form.DataQualityForm;
import com.bosch.rbcd.device2.pojo.form.DeviceQualityAnalysisForm;
import com.bosch.rbcd.device2.pojo.form.DeviceQualityDealForm;
import com.bosch.rbcd.device2.pojo.query.DeviceQualityApplyQuery;
import com.bosch.rbcd.device2.pojo.query.DeviceQualityDetailQuery;
import com.bosch.rbcd.device2.pojo.vo.DeviceQualityApplyVO;
import com.bosch.rbcd.device2.pojo.vo.DeviceQualityDetailVO;
import com.bosch.rbcd.device2.service.AppAuthorityService;
import com.bosch.rbcd.device2.service.DeviceQualityService;
import com.bosch.rbcd.fleet.api.OemFeignClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Api(tags = "返件")
@RestController
@RequestMapping("/quality")
public class DeviceQualityController {

    @Autowired
    private DeviceQualityService deviceQualityService;

    @Autowired
    private AppAuthorityService appAuthorityService;

    @ApiOperation("新建返件申请单")
    @PostMapping("/apply/create")
    public Result<Long> createReturnApplication(@RequestBody @Validated DataQualityForm dataQualityForm) {

        if (CollectionUtils.isEmpty(dataQualityForm.getCcuIdList())) {
            throw new BizException("返件的CCU为空");
        }
        if (dataQualityForm.getReasonType()==0) {
            if (StringUtils.isBlank(dataQualityForm.getRemark())) {
                throw new BizException("问题件描述为空");
            }
            if (dataQualityForm.getReturnType() == null) {
                throw new BizException("返件方式为空");
            }
            if (dataQualityForm.getReceiveUserId() == null) {
                throw new BizException("接受人为空");
            }
            if (dataQualityForm.getReturnType() == 1) {
                if (StringUtils.isBlank(dataQualityForm.getExpressNo())) {
                    throw new BizException("快递单号为空");
                }
            }
        }

        return Result.success(deviceQualityService.createNewApply(dataQualityForm));
    }


    @ApiOperation("返件记录 - 分页查询")
    @GetMapping("/apply/pageQuery")
    public PageResult<DeviceQualityApplyVO> returnPageQuery(DeviceQualityApplyQuery deviceQualityApplyQuery) {
        if (!appAuthorityService.currentUserIsAppRoot()) {
            deviceQualityApplyQuery.setCreatorId(UserUtils.getUserId());
        }
        return PageResult.success(deviceQualityService.pageQueryApply(deviceQualityApplyQuery));
    }

    @ApiOperation("返件记录 - 详情")
    @GetMapping("/apply/info")
    public Result<DeviceQualityApplyVO> getApplyById(@ApiParam(value = "返件记录表id", required = true) @RequestParam Long applyId) {
        return Result.success(deviceQualityService.getApplyById(applyId));
    }

    @ApiOperation("返件记录 - 分页查询指定返件申请中的CCU")
    @GetMapping("/apply/detailPageQuery")
    public PageResult<DeviceQualityDetailVO> pageQueryDetailByApplyId(@ApiParam(value = "返件记录表id", required = true) @RequestParam Long applyId,
                                                                      @ApiParam(value = "页码", defaultValue = "1") @RequestParam(required = false, defaultValue = "1") Integer pageNum,
                                                                      @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(required = false, defaultValue = "10") Integer pageSize) {
        DeviceQualityDetailQuery query = new DeviceQualityDetailQuery();
        query.setApplyId(applyId);
        query.setPageNum(pageNum);
        query.setPageSize(pageSize);
        return PageResult.success(deviceQualityService.pageQueryDetailForApply(query));
    }

    @ApiOperation("返件处理 - 以CCU维度查询返件记录")
    @GetMapping("/detail/pageQuery")
    public PageResult<DeviceQualityDetailVO> detailPageQuery(DeviceQualityDetailQuery deviceQualityDetailQuery) {
        return PageResult.success(deviceQualityService.pageQueryDetail(deviceQualityDetailQuery));
    }

    @ApiOperation("返件处理 - 查看具体的CCU返件记录")
    @GetMapping("/detail/info")
    public Result<DeviceQualityDetailVO> getDetailById(@ApiParam(value = "主键id", required = true) @RequestParam Long detailId) {
        return Result.success(deviceQualityService.findApplyDetailById(detailId));
    }

    @ApiOperation("返件处理 - 处理分析")
    @PostMapping("/analysis")
    public Result<Void> analysisError(@Validated @RequestBody DeviceQualityAnalysisForm deviceQualityAnalysisForm) {
        if (CollectionUtil.isEmpty(deviceQualityAnalysisForm.getIdList()) || deviceQualityAnalysisForm.getErrorType() == null || StrUtil.isBlank(deviceQualityAnalysisForm.getAnalysis())) {
            return Result.failed(ResultCode.PARAM_IS_NULL);
        }
        deviceQualityService.analysisError(deviceQualityAnalysisForm);
        return Result.success();
    }

    @ApiOperation("返件处理 - 入库")
    @PostMapping("/reInStorage")
    public Result<?> reInStorage(@RequestBody DeviceQualityDealForm deviceQualityDealForm) {
        if (CollectionUtil.isEmpty(deviceQualityDealForm.getIdList())) {
            return Result.failed("id缺失");
        }
        if (StrUtil.isBlank(deviceQualityDealForm.getStoragePosition())) {
            return Result.failed("存储位置缺失");
        }
        deviceQualityService.reInStorage(deviceQualityDealForm);
        return Result.success();
    }

    @ApiOperation("返件处理 - 报废")
    @PostMapping("/scrap")
    public Result<Void> scrap(@RequestBody DeviceQualityDealForm deviceQualityDealForm) {
        if (CollectionUtil.isEmpty(deviceQualityDealForm.getIdList())) {
            return Result.failed(ResultCode.PARAM_IS_NULL);
        }
        deviceQualityService.scrap(deviceQualityDealForm);
        return Result.success();
    }
}
