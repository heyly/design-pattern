package com.bosch.rbcd.device2.common.enums;

import com.bosch.rbcd.common.base.IBaseEnum;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname SimSupplierEnum
 * @description TODO
 * @date 2023/8/15 13:45
 */
public enum SimDueStatusEnum implements IBaseEnum<Integer> {
    VALID(0, "China Mobile", "有效"),
    DUE_MONTH(1, "Due in Month", "临期1月"),
    DUE_WEEK(2, "Due in Week", "临期1周"),
    OVERDUE(3, "Be overdue", "已过期"),
    OVERDUE_MONTH(4, "Overdue over month", "已过期1月");

    private Integer value;

    private String label;

    private String cnLabel;

    SimDueStatusEnum(Integer value, String label, String cnLabel) {
        this.value = value;
        this.label = label;
        this.cnLabel = cnLabel;
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    @Override
    public String getLabel() {
        return this.label;
    }

    public String getCnLabel() {
        return this.cnLabel;
    }
}
