package com.bosch.rbcd.device2.common.enums;

/**
 * CCU服役状态 枚举类
 */
public enum CommissionStatusEnum {

    /**
     * 激活：停止传输数据
     */
    STOP(0, "Stop","停止"),
    /**
     * 激活：正在传送数据
     */
    RUN(1, "Running","运行"),
    /**
     * 下线： 车辆和设备的对应关系解除（解绑）
     */
    OFFLINE(2, "Offline","下线"),
    /**
     * 出厂
     */
    MANUFACTURED(3, "Manufactured", "出厂"),
    /**
     * 注册： 设备和车辆绑定
     */
    REGISTER(4, "Registered", "注册"),
    /**
     * 休眠：6个月没有数据传回
     */
    DEACTIVE(5, "Deactivated", "休眠");

    private final Integer code;
    private final String message;

    private final String chLabel;

    CommissionStatusEnum(Integer code, String enLabel, String chLabel) {
        this.code = code;
        this.message = enLabel;
        this.chLabel = chLabel;
    }


    public static String getMessage(Integer code) {
        String message = "";
        for (CommissionStatusEnum status : values()) {
            if (code.equals(status.getCode())) {
                message = status.getMessage();
            }
        }
        return message;
    }

    public static String getChLabel(Integer code) {
        String chLabel = "";
        for (CommissionStatusEnum status : values()) {
            if (code.equals(status.getCode())) {
                chLabel = status.getChLabel();
            }
        }
        return chLabel;
    }


    public Integer getCode() {
        return code;
    }


    public String getMessage() {
        return message;
    }


    public String getChLabel() {
        return chLabel;
    }

}
