package com.bosch.rbcd.device2.cron;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.bosch.rbcd.device2.pojo.entity.DeviceOrder;
import com.bosch.rbcd.device2.service.DeviceOrderService;
import com.bosch.rbcd.system.common.ProcessCheckStatusEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class OrderScheduleTask {

    @Autowired
    private DeviceOrderService deviceOrderService;

    @Value("${spring.profiles.active}")
    private String env;

    /**
     * 自动取消超过3个月未审批完成的申请单
     */
    //@Scheduled(cron = "0 0 1 * * ?")
    public void cancelOverdueOrder() {
        if (!StringUtils.equalsIgnoreCase(env, "prod")) {
            return;
        }

        Date now = new Date();
        Date ninetyDaysAgo = new Date(now.getTime() - 90L * 24 * 60 * 60 * 1000);
        LambdaUpdateWrapper<DeviceOrder> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(DeviceOrder::getApproveStatus, ProcessCheckStatusEnum.TIME_OUT.getCode());
        updateWrapper.set(DeviceOrder::getModifierId, 1L);
        updateWrapper.set(DeviceOrder::getUpdateTime, now);
        updateWrapper.eq(DeviceOrder::getDeleted, 0);
        updateWrapper.in(DeviceOrder::getApproveStatus, ProcessCheckStatusEnum.WAIT_APPROVE.getCode(), ProcessCheckStatusEnum.APPROVING.getCode());
        updateWrapper.lt(DeviceOrder::getCreateTime, ninetyDaysAgo);
        deviceOrderService.update(updateWrapper);

    }
}
