package com.bosch.rbcd.device2.common.enums;

/**
 * ccu管理状态枚举类
 */
public enum ManageStatusEnum {

    IN_STORAGE(0, "已入库"),
    OUT_STORAGE(1, "已出库"),
    REVERSE(2, "已返回"),
    SCRAP(3, "已报废")
    ;


    private final int code;

    private final String description;

    ManageStatusEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static ManageStatusEnum getByCode(Integer code){
        if (code == null){
            return null;
        }
        for (ManageStatusEnum e : ManageStatusEnum.values()) {
            if (e.getCode() == code){
                return e;
            }
        }
        return null;
    }
}
