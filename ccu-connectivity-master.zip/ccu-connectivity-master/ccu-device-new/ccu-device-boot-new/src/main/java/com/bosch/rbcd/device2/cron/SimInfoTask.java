package com.bosch.rbcd.device2.cron;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.utils.FreeMarkerUtil;
import com.bosch.rbcd.common.utils.communication.MailUtil;
import com.bosch.rbcd.device2.common.enums.SimDueStatusEnum;
import com.bosch.rbcd.device2.mapper.SimInfoMapper;
import com.bosch.rbcd.device2.pojo.bo.iot.*;
import com.bosch.rbcd.device2.pojo.entity.*;
import com.bosch.rbcd.device2.pojo.query.SimGroupMonthPageQuery;
import com.bosch.rbcd.device2.pojo.query.SimInfoPageQuery;
import com.bosch.rbcd.device2.pojo.vo.SimGroupMonthVO;
import com.bosch.rbcd.device2.pojo.vo.SimInfoVO;
import com.bosch.rbcd.device2.pojo.vo.SimWaringCardVO;
import com.bosch.rbcd.device2.service.*;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.fleet.dto.ProjectDTO;
import com.bosch.rbcd.system.dto.UserDetailDTO;
import com.bosch.rbcd.system.utils.SysUserUtil;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname SimUpdateTask
 * @description TODO
 * @date 2023/8/15 18:46
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class SimInfoTask {
    private final SimInfoService ccuSimInfoService;
    private final SimInfoMapper ccuSimInfoMapper;
    private final SimDailyGprsService ccuSimDailyGprsService;
    private final SimMonthGprsService ccuSimMonthGprsService;
    private final SimGroupMonthService ccuSimGroupMonthService;
    private final ChinaMobileIotService chinaMobileIotService;
    private final ProjectFeignClient projectFeignClient;
    private final DeviceInfoService deviceInfoService;
    private final FreeMarkerUtil freeMarkerUtil;
    private final MailUtil mailUtil;
    private final SysUserUtil sysUserUtil;

    private final static String DUE_SIM_PROJECT_TEMPLATE = "simDueProject.ftl";
    private final static String PROJECT_DUE_SIM_TOPIC = "Project[{}] Sim Due Tip";

    private final static String DUE_SIM_PLATFORM_TEMPLATE = "simDuePlatform.ftl";
    private final static String DATA_POOL_WARN_TEMPLATE = "dataPoolWarn.ftl";
    private final static String PLATFORM_DUE_SIM_TOPIC = "RBCD Cloud Platform Sim Due Tip";
    private final static String DATA_POOL_WARN_TOPIC = "Sim Data Pool Used Warn Tip";

    private static final String SIM_WARN_RECEIVER = "liang.chen12@cn.bosch.com;Wenru.LI@cn.bosch.com;";

    @XxlJob("dailyUpdateCMCCSimInfo")
    public void dailyUpdateCMCCSimInfo() {
        updateEmptySupplierSim();
        Date yesterday = DateUtil.yesterday();
        updateCMCCSimInfo(yesterday);
    }

    public void updateEmptySupplierSim() {
        List<SimInfo> emptySimList = ccuSimInfoMapper.selectList(new LambdaQueryWrapper<SimInfo>().isNull(SimInfo::getSupplier).or().ne(SimInfo::getSupplier, "CMCC"));
        for (SimInfo SimInfo : emptySimList) {
            Future<SimInfo> future = ccuSimInfoService.asyncUpdateCcuSimInfo(SimInfo);
            try {
                future.get();
            } catch (Exception e) {
                log.error("异步查询出错", e);
            }
        }
    }

    public void updateCMCCSimInfo(Date date) {
        String dayStr = DateUtil.format(date, DatePattern.PURE_DATE_PATTERN);
        String month = DateUtil.format(DateUtil.yesterday(), DatePattern.SIMPLE_MONTH_PATTERN);

        // 月初始标志
        boolean monthBeginFlag = !DateUtil.isSameMonth(date, new Date());
        SimInfoPageQuery queryParams = new SimInfoPageQuery();
        Page<SimInfo> simPage = new Page<>(1, 100);
        queryParams.setSupplier("CMCC");
        List<SimInfo> simInfos = ccuSimInfoMapper.pageCcuSimInfoPage(simPage, queryParams);

        // 查询当前所有的分组信息
        AllGroupResponse allGroupInfo = chinaMobileIotService.getSimAllGroup();
        Map<String, SimGroupInfo> groupIdMap = allGroupInfo.getGroupList().stream().collect(Collectors.toMap(SimGroupInfo::getGroupId, g -> g));

        while (simPage.getCurrent() <= simPage.getPages()) {

            // 更新sim卡套餐 状态 在线时间信息
            simInfos.forEach(simInfo -> {
                try {
                    // 更新sim卡运营商状态
                    SimStatusResponse simStatus = chinaMobileIotService.getSimStatus(simInfo.getIccid());
                    if (simStatus != null) {
                        simInfo.setCardStatus(simStatus.getCardStatus());

                        // 查询套餐id和群组名称
                        SimInGroupResponse groupInfo = chinaMobileIotService.getSimGropuInfo(simInfo.getIccid());
                        if (Objects.nonNull(groupInfo) && CollectionUtil.isNotEmpty(groupInfo.getGroupList())) {
                            String groupId = groupInfo.getGroupList().get(0).getGroupId();
                            SimGroupInfo groupDetailInfo = groupIdMap.get(groupId);
                            // 设置流量池群组id和名称
                            simInfo.setOfferingId(groupDetailInfo.getGroupId());
                            simInfo.setOfferingName(groupDetailInfo.getGroupName());
                        }

                        // 如果sim状态由待激活变为已激活，则更新激活过期时间
                        if (Objects.isNull(simInfo.getDueTime())) {
                            SimBasicInfo simBasicInfo = chinaMobileIotService.getSimBasicInfo(simInfo.getIccid());
                            // 如果查询到激活时间，则设置过期时间和激活时间
                            if (Objects.nonNull(simBasicInfo) && StrUtil.isNotBlank(simBasicInfo.getActiveDate())) {
                                simInfo.setActiveDate(DateUtil.parse(simBasicInfo.getActiveDate()));
                                simInfo.setDueTime(DateUtil.offsetMonth(simInfo.getActiveDate(), 12));
                            }
                        }

                        // 更新最后在线时间
                        SimSessionResponse simSession = chinaMobileIotService.getSimSessionInfo(simInfo.getIccid());
                        if (simSession != null && CollectionUtil.isNotEmpty(simSession.getSimSessionList())) {
                            String onlineTime = simSession.getSimSessionList().get(0).getCreateDate();
                            simInfo.setLastOnlineTime(DateUtil.parse(onlineTime));
                        }
                    } else {
                        // 状态为null时，更新为已销户
                        simInfo.setCardStatus("8");
                    }
                } catch (Exception e) {
                    log.warn("daily Update CMCC Sim Info occur error:", e);
                }
            });

            List<String> iccidList = simInfos.stream().map(SimInfo::getIccid).collect(Collectors.toList());
            // 批量查询指定日期使用流量
            SimGPRSResponse dailySimGPRSResponse = chinaMobileIotService.batchSimDailyGprs(dayStr, String.join("_", iccidList));
            Map<String, String> dailySimDataMap =
                    Optional.ofNullable(dailySimGPRSResponse).orElse(new SimGPRSResponse()).getDataAmountList().stream().filter(d -> StrUtil.isNotBlank(d.getIccid()) && StrUtil.isNotBlank(d.getDataAmount())).collect(Collectors.toMap(SimGPRSResponse.DataAmount::getIccid, SimGPRSResponse.DataAmount::getDataAmount));
            // 批量查询指定月份使用流量
            SimGPRSResponse monthSimGPRSResponse = chinaMobileIotService.batchSimMonthGprs(month, String.join("_", iccidList));
            Map<String, String> monthSimDataMap =
                    Optional.ofNullable(monthSimGPRSResponse).orElse(new SimGPRSResponse()).getDataAmountList().stream().filter(d -> StrUtil.isNotBlank(d.getIccid()) && StrUtil.isNotBlank(d.getDataAmount())).collect(Collectors.toMap(SimGPRSResponse.DataAmount::getIccid, SimGPRSResponse.DataAmount::getDataAmount));

            // 新增每日使用流量记录
            simInfos.stream().filter(s -> !StrUtil.equalsAny(s.getCardStatus(),"4","8")).forEach(simInfo -> {
                try {
                    SimDailyGprs ccuSimDailyGprs = new SimDailyGprs();
                    ccuSimDailyGprs.setSimId(simInfo.getId());
                    ccuSimDailyGprs.setOnlineDate(dayStr);
                    int dateAmount = NumberUtil.div(dailySimDataMap.getOrDefault(simInfo.getIccid(), "0"), "1024").setScale(0, RoundingMode.HALF_UP).intValue();
                    ccuSimDailyGprs.setDateAmount(dateAmount);

                    int monthAmount = NumberUtil.div(monthSimDataMap.getOrDefault(simInfo.getIccid(), "0"), "1024").setScale(0, RoundingMode.HALF_UP).intValue();
                    // 更新sim info主表  月套餐已用流量
                    if (monthBeginFlag) {
                        simInfo.setMonthAmount(0);
                    } else {
                        simInfo.setMonthAmount(monthAmount);
                    }

                    ccuSimDailyGprs.setUseAmount(monthAmount);
                    // 校验是否重复
                    long existedDailyRecord =
                            ccuSimDailyGprsService.count(new LambdaQueryWrapper<SimDailyGprs>().eq(SimDailyGprs::getSimId, simInfo.getId()).eq(SimDailyGprs::getOnlineDate, dayStr));
                    if (existedDailyRecord == 0) {
                        ccuSimDailyGprsService.save(ccuSimDailyGprs);
                    }

                    // 更新月记录
                    SimMonthGprs existedMonthRecord =
                            ccuSimMonthGprsService.getOne(new LambdaQueryWrapper<SimMonthGprs>().eq(SimMonthGprs::getSimId, simInfo.getId()).eq(SimMonthGprs::getMonth,
                                    month).last("limit 1"));
                    existedMonthRecord = Optional.ofNullable(existedMonthRecord).orElse(new SimMonthGprs().setSimId(simInfo.getId()).setMonth(month));
                    existedMonthRecord.setAmount(monthAmount);
                    ccuSimMonthGprsService.saveOrUpdate(existedMonthRecord);
                } catch (Exception e) {
                    log.warn("daily Update CMCC Sim Info occur error:", e);
                }
            });

            // 更新sim信息
            ccuSimInfoService.updateBatchById(simInfos);

            // 翻页查询
            simPage.setCurrent(simPage.getCurrent() + 1);
            simInfos = ccuSimInfoMapper.pageCcuSimInfoPage(simPage, queryParams);
        }
    }

    @XxlJob("dailyUpdateGroupMonthData")
    public void updateGroupMonthData() {
        Date date = new Date();
        String month = DateUtil.format(date, DatePattern.SIMPLE_MONTH_PATTERN);
        // 查询当前所有的分组信息
        AllGroupResponse allGroupInfo = chinaMobileIotService.getSimAllGroup();
        if (Objects.nonNull(allGroupInfo) && CollectionUtil.isNotEmpty(allGroupInfo.getGroupList())) {
            for (SimGroupInfo simGroupInfo : allGroupInfo.getGroupList()) {
                GroupMonthDataRes groupMonthDataRes = chinaMobileIotService.getGroupMonthData(simGroupInfo.getGroupId());
                if (groupMonthDataRes != null && CollectionUtil.isNotEmpty(groupMonthDataRes.getFlowPoolSharingInfo())) {
                    // 查询当月已存在的记录
                    SimGroupMonth ccuSimGroupMonth = ccuSimGroupMonthService.getOne(new LambdaQueryWrapper<SimGroupMonth>().eq(SimGroupMonth::getGroupId,
                            simGroupInfo.getGroupId()).eq(SimGroupMonth::getMonth, month));
                    GroupMonthDataRes.GroupMonthData groupMonthData = groupMonthDataRes.getFlowPoolSharingInfo().get(0);
                    // 若为月初第一天则创建记录
                    if (ccuSimGroupMonth == null) {
                        ccuSimGroupMonth = BeanUtil.copyProperties(simGroupInfo, SimGroupMonth.class);
                        ccuSimGroupMonth.setMonth(month);
                    }
                    ccuSimGroupMonth.setGprsOfferingId(groupMonthData.getOfferingId());
                    ccuSimGroupMonth.setGprsOfferingName(groupMonthData.getOfferingName());
                    ccuSimGroupMonth.setTotalAmount(NumberUtil.div(groupMonthData.getTotalAmount(), "1024").intValue());
                    ccuSimGroupMonth.setUseAmount(NumberUtil.div(groupMonthData.getUseAmount(), "1024").intValue());
                    ccuSimGroupMonth.setRemainAmount(NumberUtil.div(groupMonthData.getRemainAmount(), "1024").intValue());
                    ccuSimGroupMonth.setUseRatio((ccuSimGroupMonth.getUseAmount() * 100) / ccuSimGroupMonth.getTotalAmount());
                    ccuSimGroupMonthService.saveOrUpdate(ccuSimGroupMonth);
                }
            }
        }
        SimGroupMonthPageQuery simGroupMonthQuery = new SimGroupMonthPageQuery();
        simGroupMonthQuery.setMonth(month);
        List<SimGroupMonthVO> dataPoolList = ccuSimGroupMonthService.listCcuSimGroupMonthPage(simGroupMonthQuery).getRecords();
        boolean dataWarnFlag = dataPoolList.stream().anyMatch(dataPool -> dataPool.getUseRatio() > 80);
        SimBalanceRes balanceInfo = chinaMobileIotService.getSimBalanceInfo("89860404102090055142");
        boolean balanceWarn = false;
        if (balanceInfo != null) {
            balanceWarn = NumberUtil.sub(balanceInfo.getAmount(), balanceInfo.getConSume()).intValue() < 0;
        }
        if (dataWarnFlag || balanceWarn) {
            // 定义邮件ftl数据节点
            Map<String, Object> dataWarnMap = new HashMap<>();
            dataWarnMap.put("dataPoolSize", dataPoolList.size());
            dataWarnMap.put("dataPoolList", dataPoolList);
            // 查询账号余额信息
            dataWarnMap.put("balanceInfo", balanceInfo);
            String dataWarnContent = freeMarkerUtil.fillTemplate(DATA_POOL_WARN_TEMPLATE, dataWarnMap);
            // 发送邮件至ETC7所有用户
            mailUtil.sendAttachmentsMail(SIM_WARN_RECEIVER, DATA_POOL_WARN_TOPIC, 1, dataWarnContent, null, true);
        }

    }

    @XxlJob("dailyUpdateSimDueInfo")
    public void dailyUpdateSimDueInfo() {
        Date today = new Date();
        SimInfoPageQuery queryParams = new SimInfoPageQuery();
        Page<SimInfo> simPage = new Page<>(1, 1000);
        List<SimInfo> simInfos = ccuSimInfoMapper.pageCcuSimInfoPage(simPage, queryParams);
        while (simPage.getCurrent() <= simPage.getPages()) {
            simInfos.stream().filter(sim -> sim.getDueTime() != null).forEach(simInfo -> {
                try {
                    long dueDayCount = DateUtil.between(today, simInfo.getDueTime(), DateUnit.DAY, false);
                    if (dueDayCount > 30) {
                        simInfo.setDueStatus(SimDueStatusEnum.VALID.getValue());
                    } else if (dueDayCount > 7) {
                        simInfo.setDueStatus(SimDueStatusEnum.DUE_MONTH.getValue());
                    } else if (dueDayCount > 0) {
                        simInfo.setDueStatus(SimDueStatusEnum.DUE_WEEK.getValue());
                    } else if (dueDayCount > -30) {
                        simInfo.setDueStatus(SimDueStatusEnum.OVERDUE.getValue());
                    } else {
                        simInfo.setDueStatus(SimDueStatusEnum.OVERDUE_MONTH.getValue());
                    }
                } catch (Exception e) {
                    log.warn("daily Update Sim Due Info occur error:", e);
                }
            });
            // 更新过期状态
            ccuSimInfoService.updateBatchById(simInfos);
            // 翻页查询
            simPage.setCurrent(simPage.getCurrent() + 1);
            simInfos = ccuSimInfoMapper.pageCcuSimInfoPage(simPage, queryParams);
        }
    }


    @XxlJob("sendPlatformDueMail")
    public void sendPlatformDueMail() {
        try {
            List<ProjectDTO> activeProjects = projectFeignClient.listActiveProject().getData();
            SimInfoPageQuery query = new SimInfoPageQuery();
            query.setProjectIdList(activeProjects.stream().map(ProjectDTO::getId).collect(Collectors.toList()));
            SimWaringCardVO dueInfo = ccuSimInfoService.getWarningCards(query);
            // 如果包含过期sim卡，则邮件提醒
            if (dueInfo.hasDueSim()) {
                boolean balanceWarn = false;
                // 定义邮件ftl数据节点
                Map<String, Object> dueProjectMap = new HashMap<>();
                long ccuSum = deviceInfoService.count(new LambdaQueryWrapper<DeviceInfo>().in(DeviceInfo::getProjectId, query.getProjectIdList()));
                query.setPageSize(-1);
                query.setDueTipFlag(true);
                IPage<SimInfoVO> dueSimInfos = ccuSimInfoService.listCcuSimInfoPage(query);
                dueProjectMap.put("ccuSum", ccuSum);
                dueProjectMap.put("dueInfo", dueInfo);
                dueProjectMap.put("dueSimList", dueSimInfos.getRecords());
                // 查询账号余额信息
                SimBalanceRes balanceInfo = chinaMobileIotService.getSimBalanceInfo(dueSimInfos.getRecords().get(0).getIccid());
                if (balanceInfo != null) {
                    balanceWarn = NumberUtil.sub(balanceInfo.getAmount(), balanceInfo.getConSume()).intValue() < 0;
                }
                dueProjectMap.put("balanceInfo", balanceInfo);
                String dueProjectContent = freeMarkerUtil.fillTemplate(DUE_SIM_PLATFORM_TEMPLATE, dueProjectMap);

                // 临期提醒sim信息汇总表
                String summaryExcel = FileUtils.getTempDirectoryPath() + File.separator + "RBCD_Cloud_Platform_Sim_Due_Tip.xlsx";
                Workbook workbook = ccuSimInfoService.getSimWorkBook(query);
                // 生成汇总excel附件并发送邮件
                try (FileOutputStream fos = new FileOutputStream(summaryExcel)) {
                    workbook.write(fos);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                // 发送邮件 "Wenru.LI@cn.bosch.com"
                mailUtil.sendAttachmentsMail("Wenru.LI@cn.bosch.com", PLATFORM_DUE_SIM_TOPIC, balanceWarn ? 1 : null, dueProjectContent, summaryExcel, true);
            }
        } catch (Exception e) {
            log.error("平台每周CCU过期提醒邮件发送失败", e);
        }
    }

    @XxlJob("sendProjectDueMail")
    public void sendProjectDueMail() {
        List<ProjectDTO> activeProjects = projectFeignClient.listActiveProject().getData();
        activeProjects.forEach(projectInfo -> {
            try {
                SimInfoPageQuery query = new SimInfoPageQuery();
                query.setProjectIdList(Collections.singletonList(projectInfo.getId()));
                SimWaringCardVO dueInfo = ccuSimInfoService.getWarningCards(query);
                // 如果包含过期sim卡，则邮件提醒
                if (dueInfo.hasDueSim()) {
                    // 定义邮件ftl数据节点
                    Map<String, Object> dueProjectMap = new HashMap<>();
                    long ccuSum = deviceInfoService.count(new LambdaQueryWrapper<DeviceInfo>().eq(DeviceInfo::getProjectId, projectInfo.getId()));
                    query.setPageSize(-1);
                    query.setDueTipFlag(true);
                    IPage<SimInfoVO> dueSimInfos = ccuSimInfoService.listCcuSimInfoPage(query);
                    dueProjectMap.put("ccuSum", ccuSum);
                    dueProjectMap.put("project", projectInfo);
                    dueProjectMap.put("dueInfo", dueInfo);
                    dueProjectMap.put("dueSimList", dueSimInfos.getRecords());
                    String dueProjectContent = freeMarkerUtil.fillTemplate(DUE_SIM_PROJECT_TEMPLATE, dueProjectMap);

                    // 临期提醒sim信息汇总表
                    ExportParams exportParams = new ExportParams();
                    exportParams.setType(ExcelType.XSSF);
                    String sheetName = projectInfo.getBm() + "Sim_Due_Tip";
                    exportParams.setSheetName(sheetName);
                    String summaryExcel = FileUtils.getTempDirectoryPath() + File.separator + sheetName + ".xlsx";
                    Workbook workbook = ExcelExportUtil.exportExcel(exportParams, SimInfoVO.class, dueSimInfos.getRecords());
                    // 生成汇总excel附件并发送邮件
                    try (FileOutputStream fos = new FileOutputStream(summaryExcel)) {
                        workbook.write(fos);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    // 发送邮件
                    UserDetailDTO user = sysUserUtil.getUserById(projectInfo.getUserId());
                    mailUtil.sendAttachmentsMail(user.getEmail(), StrUtil.format(PROJECT_DUE_SIM_TOPIC, projectInfo.getName()), null, dueProjectContent, summaryExcel, true);
                }
            } catch (Exception e) {
                log.error("项目{}每周CCU过期提醒邮件发送失败", projectInfo.getName(), e);
            }
        });
    }


}
