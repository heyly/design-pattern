package com.bosch.rbcd.device2.controller;

import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.pojo.form.OtaTaskForm;
import com.bosch.rbcd.device2.pojo.query.OtaDeviceQuery;
import com.bosch.rbcd.device2.pojo.query.OtaTaskQuery;
import com.bosch.rbcd.device2.pojo.vo.OtaDeviceVO;
import com.bosch.rbcd.device2.pojo.vo.OtaTaskVO;
import com.bosch.rbcd.device2.service.OtaDeviceService;
import com.bosch.rbcd.device2.service.OtaTaskService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Map;

@Api(tags = "OTA控制类")
@RestController
@RequestMapping("/ota")
public class OtaController {

    @Autowired
    private OtaTaskService otaTaskService;

    @Autowired
    private OtaDeviceService otaDeviceService;


    @ApiOperation("OTA任务管理 - 创建任务")
    @PostMapping("/task/create")
    public Result<Long> createOtaTask(@Validated @RequestBody OtaTaskForm otaTaskForm) {
        Long id = otaTaskService.createOtaTask(otaTaskForm);
        return Result.success(id);
    }

    @ApiOperation("OTA任务管理 - 分页查询任务")
    @GetMapping("/task/page")
    public PageResult<OtaTaskVO> pageQueryTask(OtaTaskQuery otaTaskQuery) {
        return PageResult.success(otaTaskService.pageQuery(otaTaskQuery));
    }

    @ApiOperation("OTA任务管理 - 取消任务")
    @DeleteMapping("/task/cancel")
    public Result<Void> cancelTask(@ApiParam(value = "ota任务id", required = true) @RequestParam Long otaTaskId) {
        otaDeviceService.cancelAllTaskOta(otaTaskId);
        return Result.success();
    }

    @ApiOperation("OTA任务管理 - 任务详情")
    @GetMapping("/task/detail")
    public Result<OtaTaskVO> taskDetail(@ApiParam(value = "ota任务id", required = true) @RequestParam Long otaTaskId) {
        return Result.success(otaTaskService.taskDetail(otaTaskId));
    }

    @ApiOperation("OTA任务管理 - 分页查询执行任务的CCU")
    @GetMapping("/task/device/page")
    public PageResult<OtaDeviceVO> taskCcuList(@ApiParam(value = "任务id", required = true) @RequestParam Long taskId,
                                               @ApiParam(value = "页码", defaultValue = "1") @RequestParam(required = false, defaultValue = "1") Integer pageNum,
                                               @ApiParam(value = "每页记录数", defaultValue = "10") @RequestParam(required = false, defaultValue = "10") Integer pageSize) {
        OtaDeviceQuery otaDeviceQuery = new OtaDeviceQuery();
        otaDeviceQuery.setTaskId(taskId);
        otaDeviceQuery.setPageNum(pageNum);
        otaDeviceQuery.setPageSize(pageSize);
        return PageResult.success(otaDeviceService.pageQueryCcuOta(otaDeviceQuery));
    }

    @ApiOperation("OTA状态 - 分页查询每个ccu的OTA任务")
    @GetMapping("/device/page")
    public PageResult<OtaDeviceVO> pageQueryDevice(OtaDeviceQuery otaDeviceQuery) {
        return PageResult.success(otaDeviceService.pageQueryCcuOta(otaDeviceQuery));
    }

    @ApiOperation("OTA状态 - 取消单个ccu任务")
    @DeleteMapping("/device/cancel")
    public Result<Void> cancelDeviceTask(@ApiParam(value = "ccu的OTA记录id", required = true) @RequestParam Long otaDeviceId) {
        otaDeviceService.cancelSingleCcuOta(otaDeviceId);
        return Result.success();
    }

    @ApiOperation("OTA状态 - 执行进展")
    @GetMapping("/device/upgradeProcess")
    public Result<OtaDeviceVO> upgradeProcess(@ApiParam(value = "ccu的OTA记录id", required = true) @RequestParam Long otaDeviceId) {;
        return Result.success(otaDeviceService.getUpgradeProcess(otaDeviceId));
    }

    /**
     * 检查设备（CCU-A）是否需要更新
     *
     * @param deviceImei
     * @return
     */
    @ApiIgnore
    @PostMapping("/ccu-a/devicecheck-needupdate")
    @ResponseBody
    public Result<Map<String, Object>> checkNeedUpdateForCcuA(@RequestParam("deviceImei") @ApiParam(value = "设备imei号", required = true) String deviceImei) {
        Map<String, Object> data = otaDeviceService.checkNeedUpdateForCcuA(deviceImei.trim());
        return Result.success(data);
    }

    /**
     * 设置设备（CCU-A）的更新状态和时间
     *
     * @param deviceImei
     * @return
     */
    @ApiIgnore
    @PostMapping("/ccu-a/setOTAStatus")
    public Result<?> setSelfOTAStatusForCcuA(
            @RequestParam("deviceImei") @ApiParam(value = "设备imei号", required = true) String deviceImei,
            @RequestParam("otaStatus") @ApiParam(value = "ota状态", required = true) String otaStatus,
            @RequestParam("timeStamps") @ApiParam(value = "要更新的时间戳字段，英文逗号分隔", required = true) String timeStamps) {
        otaDeviceService.setSelfOTAStatusForCcuA(deviceImei.trim(), otaStatus);
        return Result.success();
    }


    /**
     * 重置设备的更新状态
     *
     * @param deviceImei
     * @return
     */
    @ApiIgnore
    @PostMapping("/ccu-a/resetSelfOTAStatus")
    public Result<?> resetSelfOTAStatus(@RequestParam("deviceImei") @ApiParam(value = "设备imei号", required = true) String deviceImei) {
        otaDeviceService.resetSelfOtaStatus(deviceImei.trim());
        return Result.success();
    }
}
