package com.bosch.rbcd.device2.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.device2.pojo.entity.AesKey;

public interface AesKeyMapper extends BaseMapper<AesKey> {
}
