package com.bosch.rbcd.device2.api;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.dto.OtaDeviceHistoryDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname CcuOtaFeignClient
 * @description TODO
 * @date 2023/3/27 16:05
 */
@FeignClient(name = "ccu-device-new", contextId = "ccu-device-ccuOta")
@RequestMapping("/feign/ota")
public interface OtaFeignClient {

    @GetMapping("/getResendOtaTask")
    Result<OtaDeviceHistoryDTO> getResendOtaTask(@RequestParam String imei);

    @PutMapping("/resetSelfOTAStatus")
    Result<Integer> resetSelfOTAStatus(String imei);

    @GetMapping("/updateStatus")
    Result<Integer> updateStatus(@RequestParam Integer statusCode, @RequestParam String timestamp,@RequestParam Long taskId, @RequestParam String imei);

    @GetMapping("/execOtaFinish")
    Result<Object> execOtaFinish(@RequestParam Long taskId, @RequestParam String imei);
}
