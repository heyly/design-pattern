package com.bosch.rbcd.device2.dto;

import lombok.Data;

@Data
public class SimStatusDTO {

    /**
     * 在线状态 00-离线 01-在线
     */
    private String status;

    /**
     * 会话创建时间
     */
    private String createDate;

    /**
     * 当开卡平台为OneLink-PB时：00-正常、01-单向停机、02-停机、03-预销号、05-过户、06-休眠、07-待激活、99-号码不存在；当开卡平台为OneLink-CT时：1：待激活、2：已激活、4：停机、6：可测试、7：库存、8：预销户
     */
    private String cardStatus;
}
