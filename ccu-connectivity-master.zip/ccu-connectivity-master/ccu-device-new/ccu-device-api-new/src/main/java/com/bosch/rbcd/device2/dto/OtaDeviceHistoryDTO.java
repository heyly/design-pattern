package com.bosch.rbcd.device2.dto;

import lombok.Data;

@Data
public class OtaDeviceHistoryDTO {

    private OtaDeviceDTO otaDeviceDTO;

    private OtaSoftwareDTO otaSoftwareDTO;
}
