package com.bosch.rbcd.device2.dto;


import lombok.Data;

import java.util.Date;

/**
 * (DeviceLogRecord)表实体类
 *
 * @author wang bo
 * @since 2022-11-09 14:20:06
 */
@Data
public class DeviceLogRecordDTO {

    private Long id;

    /**
     * 设备imei
     */
    private String imei;

    /**
     * 车辆id
     */
    private String vehicleId;

    /**
     * 日志文件名称
     */
    private String filename;

    /**
     * obs路径
     */
    private String obsPath;

    /**
     * 日志状态 0:已下发 1:待上线 2:已接收 3:已上传 4:已超时
     */
    private String status;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;
}



