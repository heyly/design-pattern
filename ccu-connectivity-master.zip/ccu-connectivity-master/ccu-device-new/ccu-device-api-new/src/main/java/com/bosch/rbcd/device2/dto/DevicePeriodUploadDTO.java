package com.bosch.rbcd.device2.dto;

import lombok.Data;
import lombok.experimental.Accessors;


@Data
@Accessors(chain = true)
public class DevicePeriodUploadDTO {

    private String imei;

    private Long mcuTimestamp;

    private Integer dataPackSequence;

    private Integer ch0TaskStatus;

    private Integer ch1TaskStatus;

    private Integer mrdyStatus;

    private Integer t15Status;

    private Integer configStatus;

    private Integer ecuDataStatus;

    private Integer watchdogStatus;

    private Integer wakeupSleepStatus;

    private Integer loginStatus;

    private Integer tcpConnectionStatus;

    private Integer rootfsStatus;

    private Integer gpsStatus;

    private Integer localDataStorageStatus;

    private Integer mqttConnectionStatus;

    private Integer mpuDataReceptionStatus;

    private Integer mpuDataUploadStatus;

    private Integer mpuConfigSyncStatus;

    private Integer sdCardStatus;

    private Long timestamp;

}
