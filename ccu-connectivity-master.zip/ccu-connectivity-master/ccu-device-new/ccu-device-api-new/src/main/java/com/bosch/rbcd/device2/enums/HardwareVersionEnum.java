package com.bosch.rbcd.device2.enums;

/**
 * 硬件版本枚举类
 */
public enum HardwareVersionEnum {

    CCU_A(2L, "CCU-A", "CCU-A", 1L),
    CCU_S(3L, "CCU-S", "CCU-S", 2L),
    CCU_E(4L, "CCU-E", "CCU-E", 3L),
    CCU_E_L2(5L, "CCU-E-L2", "CCU-E-L2", 3L),
    CCU_E_L3(6L, "CCU-E-L3", "CCU-E-L3", 3L),
    CCU_EV(7L, "CCU-EV", "CCU-EV", 4L);

    private final Long id;

    private final String name;

    private final String code;

    private final Long typeId;

    HardwareVersionEnum(Long id, String name, String code, Long typeId) {
        this.id = id;
        this.name = name;
        this.code = code;
        this.typeId = typeId;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public Long getTypeId() {
        return typeId;
    }
}
