package com.bosch.rbcd.device2.dto;

import lombok.Data;

import java.util.Date;

@Data
public class ProjectVehicleCcuDTO {

    private Long id;

    private Long projectId;


    private Long vehicleId;

    /**
     * vehicle name
     */
    private String vehicleName;

    private String vin;

    private Long vehicleTypeId;


    /**
     * ccu_id，系统生成
     */
    private String ccuId;

    private String ccuNo;

    /**
     * 通信模组的序列号(RedisKey)
     */
    private String imei;


    /**
     * 数据采集配置id
     */
    private Long configId;

    /**
     * ccu_hardware_type表id
     */
    private Long hardwareTypeId;

    private Long hardwareVersionId;

    /**
     * CCU软件版本
     */
    private String softwareVersion;

    /**
     * 完整的sn号
     */
    private String sn;

    /**
     * 缩写的SN号
     */
    private String shortSn;

    /**
     * 最后所在城市
     */
    private String cityInfo;

    /**
     * 最近具体位置
     */
    private String address;

    /**
     * 最后数据时间
     */
    private Date lastDataTime;


    /**
     * 经度
     */
    private String longitude;

    /**
     * 纬度
     */
    private String latitude;

    /**
     * 里程
     */
    private Double totalMileage;

    /**
     * 服役状态: 已注册 运行中 已休眠 已停止 参照老的
     */
    private Integer commissionStatus;
}
