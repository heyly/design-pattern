package com.bosch.rbcd.device2.dto;

import com.bosch.rbcd.common.base.BaseEntity;
import com.bosch.rbcd.device2.enums.OtaStatusEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

@EqualsAndHashCode(callSuper = true)
@Data
public class OtaDeviceDTO extends BaseEntity {

    private static final long serialVersionUID = -3482458770342787284L;

    private Long id;

    /**
     * 任务id
     */
    private Long taskId;

    /**
     * ccu_id
     */
    private String ccuId;

    /**
     * 做OTA时绑定的车辆
     */
    private Long vehicleId;

    /**
     * OTA状态 0任务启动，1开始下载，2下载完成，21下载失败，3文件校验成功，31文件校验失败，4正在刷写，41刷写失败，5已完成,10已取消
     * @see OtaStatusEnum
     */
    private Integer otaStatus;

    /**
     * 下载开始时间
     */
    private Date startDownloadTime;

    /**
     * 下载结束时间
     */
    private Date finishDownloadTime;

    /**
     * 刷写开始时间
     */
    private Date startFlashTime;

    /**
     * 刷写结束时间
     */
    private Date finishFlashTime;

    /**
     * 任务取消时间
     */
    private Date taskCanceledTime;

    /**
     * 文件校验时间
     */
    private Date fileCheckTime;

    /**
     * 任务开始时间
     */
    private Date taskStartTime;

    /**
     * 任务修改者id
     */
    private Long modifierId;

    /**
     * 升级前的软件版本
     */
    private String oldSoftwareVersion;
}
