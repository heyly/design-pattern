package com.bosch.rbcd.device2.enums;

/**
 * 硬件类型枚举类
 */
public enum HardwareTypeEnum {

    CCU_A(1L, "CCU-A", "CCU-A"),
    CCU_S(2L, "CCU-S", "CCU-S"),
    CCU_E(3L, "CCU-E", "CCU-E"),
    CCU_EV(3L, "CCU_EV", "CCU_EV")
    ;

    private final Long id;

    private final String name;

    private final String code;

    HardwareTypeEnum(Long id, String name, String code) {
        this.id = id;
        this.name = name;
        this.code = code;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }
}
