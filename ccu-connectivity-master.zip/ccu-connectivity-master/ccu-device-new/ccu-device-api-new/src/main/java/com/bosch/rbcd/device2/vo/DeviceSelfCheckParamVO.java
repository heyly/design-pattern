package com.bosch.rbcd.device2.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel("自诊断记录 - 诊断类别")
public class DeviceSelfCheckParamVO {

    @ApiModelProperty("参数名")
    private String label;

    @ApiModelProperty("参数值")
    private String value;

    @ApiModelProperty("子参数列表")
    private List<DeviceSelfCheckParamVO> children;
}
