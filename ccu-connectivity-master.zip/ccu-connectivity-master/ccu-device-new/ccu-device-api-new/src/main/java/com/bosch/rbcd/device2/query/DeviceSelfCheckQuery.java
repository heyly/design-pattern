package com.bosch.rbcd.device2.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
public class DeviceSelfCheckQuery extends BasePageQuery {

    private static final long serialVersionUID = 7643872383209394738L;

    @ApiParam("ccuId，如果IMEI为空，则必填")
    private String ccuId;

    @ApiParam(value = "imei，如果ccu_id为空，则必填")
    private String imei;

    @ApiParam("错误类型编码")
    private String errorType;

    @ApiParam("错误数据编码")
    private String errorData;

    @ApiParam("通道编码")
    private String canNo;
}
