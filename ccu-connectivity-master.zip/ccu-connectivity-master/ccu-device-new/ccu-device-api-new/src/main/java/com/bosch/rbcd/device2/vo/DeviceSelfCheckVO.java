package com.bosch.rbcd.device2.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel("CCU自诊断信息")
public class DeviceSelfCheckVO {

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("错误类型编码")
    private String errorType;

    @ApiModelProperty("错误类型名称")
    private String errorTypeName;

    @ApiModelProperty("错误数据编码")
    private String errorData;

    @ApiModelProperty("错误数据名称")
    private String errorDataName;

    @ApiModelProperty("上报时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Shanghai")
    private Date createTime;

    @ApiModelProperty("原始时间戳")
    private Long timestamp;

    @ApiModelProperty("CAN通道")
    private String canNo;
}
