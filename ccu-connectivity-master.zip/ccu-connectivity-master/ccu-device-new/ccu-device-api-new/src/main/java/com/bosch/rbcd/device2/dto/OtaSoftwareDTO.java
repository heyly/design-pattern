package com.bosch.rbcd.device2.dto;

import com.bosch.rbcd.common.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class OtaSoftwareDTO extends BaseEntity {

    private static final long serialVersionUID = -307214557356669833L;

    private Long id;

    /**
     * 软件类型，0-非平台，1-平台
     */
    private Integer type;


    /**
     * 软件包名称
     */
    private String name;

    /**
     * 原始软件包路径
     */
    private String obsPathRaw;

    /**
     * 加密软件包路径
     */
    private String obsPathEncrypt;

    /**
     * 哈希值
     */
    private String hashcode;

    /**
     * 软件包长度
     */
    private Long length;

    /**
     * 需求文档-docupedia地址
     */
    private String prdPath;

    /**
     * 测试文档-docupedia地址
     */
    private String testDocumentPath;

    /**
     * 更新内容概述
     */
    private String content;

    /**
     * 软件状态，Test：测试版, Release：正式版
     */
    private String releaseStatus;

    /**
     * 功能标签主键id
     */
    private Long functionLabelId;

    /**
     * 版本序列
     */
    private String sequence;

    /**
     * 软件版本，唯一键
     * 版本号 = 软件状态_功能标签_版本序列
     */
    private String version;

    /**
     * 状态，-1：删除，0-禁用，1-启用
     */
    private Integer status;

    /**
     * 禁用理由
     */
    private String disableReason;

    /**
     * 创建人id
     */
    private Long creatorId;

    /**
     * 修改人
     */
    private Long modifierId;

}
