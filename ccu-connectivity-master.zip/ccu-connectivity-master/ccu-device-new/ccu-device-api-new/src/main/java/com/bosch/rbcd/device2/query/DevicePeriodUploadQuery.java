package com.bosch.rbcd.device2.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class DevicePeriodUploadQuery extends BasePageQuery {

    @ApiParam("ccuId，如果IMEI为空，则必填")
    private String ccuId;

    @ApiParam(value = "imei，如果ccu_id为空，则必填")
    private String imei;


}
