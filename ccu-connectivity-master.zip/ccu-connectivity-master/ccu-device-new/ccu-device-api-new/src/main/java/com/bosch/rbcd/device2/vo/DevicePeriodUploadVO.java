package com.bosch.rbcd.device2.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * ccu状态信息周期上报记录(CcuStatusUploadRecord)视图对象
 *
 * @author wang bo
 * @since 2023-12-05 13:38:39
 */
@ApiModel("ccu状态信息周期上报记录视图对象")
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DevicePeriodUploadVO {

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("mcu 状态更新时间戳")
    private Long mcuTimestamp;

    @ApiModelProperty("mcu 状态更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Shanghai")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date mcuTime;

    @ApiModelProperty("数据包序列号")
    private Long dataPackSequence;

    @ApiModelProperty("通道0的任务状态 1.运行中，2 未运行")
    private Integer ch0TaskStatus;

    @ApiModelProperty("通道1的任务状态 1.运行中，2 未运行")
    private Integer ch1TaskStatus;

    @ApiModelProperty("SPI的mrdy的状态	1.ready  2，not ready")
    private Integer mrdyStatus;

    @ApiModelProperty("T15状态 1.ON,  2. OFF(RTC唤醒，MCU未发送T15状态默认值), 3. Timeout")
    private Integer t15Status;

    @ApiModelProperty("配置表状态 1.有配置+配置ID，2.无配置")
    private Integer configStatus;

    @ApiModelProperty("ECU 数据状态	1.上传中   2.无实时数据上传  3.等待MPU就绪  4.RTC唤醒使用休眠前状态")
    private Integer ecuDataStatus;

    @ApiModelProperty("MCU看门狗状态, 1：IWDG运行； 0:  IWDG未运行")
    private Integer watchdogStatus;

    @ApiModelProperty("休眠唤醒状态休眠唤醒状态	1 休眠，2 唤醒")
    private Integer wakeupSleepStatus;

    @ApiModelProperty("登陆状态 1 正常，2 异常")
    private Integer loginStatus;

    @ApiModelProperty("TCP 连接状态	1已连接，2 未连接")
    private Integer tcpConnectionStatus;

    @ApiModelProperty("内存状态	1.小于70%报正常 2. 大于 70% 执行存储清理，上报清理状态.")
    private Integer rootfsStatus;

    @ApiModelProperty("GPS状态	 1.工作中  2. 定位成功  3. 未定位成功    4.未工作")
    private Integer gpsStatus;

    @ApiModelProperty("本地数据库存储状态	1. 写数据库  2.补传中  3.空闲 4. 数据库满  5.数据库异常")
    private Integer localDataStorageStatus;

    @ApiModelProperty("mqtt 连接状态	1. MQTT连接成功  2. 断开 3. 连接失败")
    private Integer mqttConnectionStatus;

    @ApiModelProperty("mpu 数据接收状态	1.接收中  2. 未收到")
    private Integer mpuDataReceptionStatus;

    @ApiModelProperty("mpu 数据上报状态	1. ECU数据上传中， 2. GPS数据上传中  3. ECU数据和GPS数据上传中， 4. 空闲")
    private Integer mpuDataUploadStatus;

    @ApiModelProperty("mpu 配置同步状态	1.已完成 2. 未完成 3.无配置")
    private Integer mpuConfigSyncStatus;

    @ApiModelProperty("SD 卡状态	1.挂载成功可读可写 2.挂载成功，读写异常 3. 挂载失败")
    private Integer sdCardStatus;

    @ApiModelProperty("上传时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Shanghai")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTime;

    @ApiModelProperty("上传时间戳")
    private Long timestamp;

}
