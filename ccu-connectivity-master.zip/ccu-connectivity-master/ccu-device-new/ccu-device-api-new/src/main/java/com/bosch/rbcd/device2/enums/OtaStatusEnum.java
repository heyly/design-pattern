package com.bosch.rbcd.device2.enums;

public enum OtaStatusEnum {

    TASK_START(0, "任务启动"),
    DOWNLOAD_START(1, "开始下载"),
    DOWNLOAD_SUCCESS(2, "下载完成"),
    DOWNLOAD_FAILURE(21, "下载失败"),
    FILE_CHECK_SUCCESS(3, "文件校验成功"),
    FILE_CHECK_FAILURE(31, "文件校验失败"),
    FLUSHING(4, "正在刷写"),
    FLUSH_FAILURE(41, "刷写失败"),
    TASK_SUCCESS(5, "已完成"),
    TASK_CANCEL(10, "已取消"),
    WAIT_CHECK(99, "流程审核中");

    private final int code;

    private final String description;

    OtaStatusEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
