package com.bosch.rbcd.device2.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;


@Data
@Accessors(chain = true)
public class DeviceSelfCheckDTO {

    private String imei;

    private String errorType;

    private String errorData;

    private String errorDataName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Shanghai")
    private Date createTime;

    private Long timestamp;

    private String canNo;

}