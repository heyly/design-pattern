package com.bosch.rbcd.device2.api;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.dto.DeviceLogRecordDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@FeignClient(name = "ccu-device-new", contextId = "ccu-device-log")
@RequestMapping("/feign/ccu-device/log")
public interface DeviceLogFeignClient {

    @GetMapping("/requestDeviceLog")
    Result<?> requestDeviceLog(@RequestParam String ccuId, @RequestParam String creator, @RequestParam Long occurDay);

    @GetMapping("/queryDeviceLog")
    Result<DeviceLogRecordDTO> queryDeviceLog(@RequestParam String vehicleId, @RequestParam Long occurDay, @RequestParam String creator);

    @GetMapping("/updateDeviceLogRequest")
    Result<Integer> updateDeviceLogRequest(@RequestParam String logRequestId, @RequestParam String status, @RequestParam String fileName, @RequestParam String obsPath);

    @GetMapping("/ccuVoluntaryUpload")
    Result<Long> ccuVoluntaryUpload(@RequestParam String imei, @RequestParam String fileName, @RequestParam String obsPath, @RequestParam String timestamp);
}
