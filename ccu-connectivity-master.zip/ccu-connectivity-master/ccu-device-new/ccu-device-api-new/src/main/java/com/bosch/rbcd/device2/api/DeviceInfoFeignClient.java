package com.bosch.rbcd.device2.api;

import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.dto.DevicePeriodUploadDTO;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import com.bosch.rbcd.device2.dto.DeviceSelfCheckDTO;
import com.bosch.rbcd.device2.dto.SimStatusDTO;
import com.bosch.rbcd.device2.query.DevicePeriodUploadQuery;
import com.bosch.rbcd.device2.query.DeviceSelfCheckQuery;
import com.bosch.rbcd.device2.vo.DevicePeriodUploadVO;
import com.bosch.rbcd.device2.vo.DeviceSelfCheckParamVO;
import com.bosch.rbcd.device2.vo.DeviceSelfCheckVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@FeignClient(name = "ccu-device-new", contextId = "ccu-device-info")
@RequestMapping("/feign/ccu")
public interface DeviceInfoFeignClient {

    @GetMapping("/findByCcuId")
    Result<ProjectVehicleCcuDTO> findByCcuId(@RequestParam String ccuId);

    @GetMapping("/findCcuNoByCcuIds")
    Result<String> findCcuNoByCcuIds(@RequestParam String ccuIds);

    @GetMapping("/findByImei")
    Result<ProjectVehicleCcuDTO> findByImei(@RequestParam String imei);

    @GetMapping("/findByCcuNo")
    Result<ProjectVehicleCcuDTO> findByCcuNo(@RequestParam String ccuNo);

    @PostMapping("/update")
    Result<?> update(@RequestBody ProjectVehicleCcuDTO ccuDeviceInfo);

//    @PostMapping("/pageForFleetMonitor")
//    PageResult<CcuDeviceInfoDTO> pageForFleetMonitor(@RequestBody DeviceInfoFeignQuery deviceInfoFeignQuery);

    @GetMapping("/listProjectCcu")
    Result<List<ProjectVehicleCcuDTO>> listProjectCcu(@RequestParam long projectId);

    @PostMapping("/selfCheck/insert")
    Result<Void> insertSelfCheck(@RequestBody DeviceSelfCheckDTO deviceSelfCheckDTO);

    @PostMapping("/selfCheck/page")
    PageResult<DeviceSelfCheckVO> pageSelfCheckRecord(DeviceSelfCheckQuery deviceSelfCheckQuery);

    @GetMapping("/selfCheck/getErrorTypeTree")
    Result<List<DeviceSelfCheckParamVO>> getErrorTypeTree();

    /**
     * 如果不是中国移动的卡，则返回null
     * @param ccuId
     * @return
     */
    @GetMapping("/sim/lastOnlineTime")
    Result<SimStatusDTO> simLastOnlineTime(@RequestParam String ccuId);
//
//    @PostMapping("/updateDeviceVersion")
//    Result<?> updateDeviceVersion(@RequestBody DeviceVersionDTO deviceVersionDTO);

    @PostMapping("/period/insertPeriodUpload")
    Result<Void> insertPeriodUpload(@RequestBody DevicePeriodUploadDTO devicePeriodUploadDTO);

    @PostMapping("/period/pageCcuStatusUp")
    PageResult<DevicePeriodUploadVO> pageCcuStatusUp(@RequestBody DevicePeriodUploadQuery devicePeriodUploadQuery);
//
//    @PostMapping("/getErrorCheckInfo")
//    Result<CcuSelfCheckConfigDTO> getErrorCheckInfo(@RequestBody List<String> codeList);

    @GetMapping("/findBySn")
    Result<List<ProjectVehicleCcuDTO>> findBySn(@RequestParam String snList);
}
