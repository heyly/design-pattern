//package com.bosch.rbcd.quality;
//
//import cn.hutool.core.util.StrUtil;
//import com.alibaba.fastjson.JSONObject;
//import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
//import com.bosch.rbcd.quality.service.QualityVehicleDataCountService;
//import org.elasticsearch.index.query.QueryBuilders;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
//import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
//import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import java.time.LocalDate;
//import java.util.Arrays;
//import java.util.HashSet;
//import java.util.Optional;
//import java.util.Set;
//
//@SpringBootTest
//@RunWith(SpringRunner.class)
//public class ElasticTest {
//
//    private static final String[] PROTOCOL_LIST = {"06a6", "06b6", "06c6", "06d6"};
//    private static final String PHRASE = "IMEI: %s, Handler processor: process%s";
//
//    @Autowired
//    private ElasticsearchRestTemplate restTemplate;
//
//    @Autowired
//    private QualityVehicleDataCountService qualityVehicleDataCountService;
//
//    @Autowired
//    private StringRedisTemplate stringRedisTemplate;
//
//    @Test
//    public void testElastic() {
//        NativeSearchQueryBuilder builder = new NativeSearchQueryBuilder()
//                .withQuery(QueryBuilders.matchPhraseQuery("message", "IMEI: 863418057578007, Handler processor: process06d6"));
//        long count = restTemplate.count(builder.build(), JSONObject.class, IndexCoordinates.of("filebeat-7.6.2-2023.04.20"));
//        System.out.println(count);
//    }
//
//    @Test
//    public void testCountVehicleData() {
//        Set<String> imeiList = Optional.ofNullable(stringRedisTemplate.opsForSet().members("ImeiSet")).orElse(new HashSet<>());
//        System.out.println(imeiList.size());
//
//        int count = Arrays.stream(PROTOCOL_LIST)
//                .map(protocol -> String.format(PHRASE, "863418057578007", protocol))
//                .map(queryPhrase -> new NativeSearchQueryBuilder()
//                        .withQuery(QueryBuilders.matchPhraseQuery("message", queryPhrase)))
//                .mapToInt(builder -> (int) restTemplate.count(builder.build(), JSONObject.class, IndexCoordinates.of("filebeat-7.6.2-2023.04.20")))
//                .sum();
//        LocalDate countDate = LocalDate.of(2023, 4, 20);
//        String vehicleName = (String) stringRedisTemplate.opsForHash().get("imei:863418057578007", "name");
//
//        QualityVehicleDataCount entity = new QualityVehicleDataCount()
//                .setTotalCount(count).setCountDate(countDate)
//                .setVehicleName(vehicleName)
//                .setImei("863418057578007")
//                .setType(0);
//        int dataExist = qualityVehicleDataCountService.count(new LambdaQueryWrapper<QualityVehicleDataCount>()
//                .eq(QualityVehicleDataCount::getImei, "863418057578007")
//                .eq(QualityVehicleDataCount::getCountDate, countDate)
//                .eq(QualityVehicleDataCount::getType, 0));
//        if (dataExist > 0) {
//            System.out.println("data count exist!!");
//            return;
//        }
//        qualityVehicleDataCountService.save(entity);
//    }
//
//    @Test
//    public void testLocalDate() {
//        LocalDate countDate = LocalDate.now().plusDays(-1);
//        int year = countDate.getYear();
//
//        int month = countDate.getMonth().getValue();
//        int day = countDate.getDayOfMonth();
//
//        String mm = StrUtil.padPre(String.valueOf(month), 2, "0");
//        String dd = StrUtil.padPre(String.valueOf(day), 2, "0");
//
//        System.out.println(year);
//        System.out.println(month);
//        System.out.println(day);
//        System.out.println(mm);
//        System.out.println(dd);
//    }
//}
