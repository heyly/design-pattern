package com.bosch.rbcd.quality;

import cn.hutool.core.util.StrUtil;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.quality.cron.DeviceExpireTask;
import com.bosch.rbcd.quality.service.DeviceExpireTaskService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname CcuExpireTest
 * @description TODO
 * @date 2023/12/15 14:15
 */
@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class CcuExpireTest {

    @Autowired
    private DeviceExpireTaskService deviceExpireTaskService;

    @Autowired
    private DeviceInfoFeignClient deviceInfoFeignClient;

    @Autowired
    private DeviceExpireTask deviceExpireTask;

//    @Autowired
//    private QualityEventRecordTask qualityEventRecordTask;
//
//    @Test
//    public void testExpireTask() {
//        deviceExpireTask.ccuDailyExpireTask();
//    }
//
//    @Test
//    public void testExpire() {
//        List<DeviceInfoDTO> ccuList = deviceInfoFeignClient.listProjectCcu(72L).getData();
//        for (CcuDeviceInfoDTO ccuDevice : ccuList) {
//            deviceExpireTaskService.detectOneCcuExpire(ccuDevice, new Date());
//        }
//    }
//
//    @Test
//    public void testOneExpire() {
//        CcuDeviceInfoDTO ccuDevice = deviceInfoFeignClient.findByImei("868922052486004").getData();
//        deviceExpireTaskService.detectOneCcuExpire(ccuDevice, DateUtil.yesterday());
//    }

    @Test
    public void testCompareSw() {
        int result = StrUtil.compareVersion("V1.7.2", "V1.9.0");
        System.out.println(result);
    }


//    @Test
//    public void testDataLossSelfCheck() {
//        qualityEventRecordTask.dailySelfCheckDateLoss();
//    }
}
