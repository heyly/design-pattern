package com.bosch.rbcd.quality;

import com.bosch.rbcd.quality.cron.QualityDailyTask;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
public class SendEmailTest {

    @Autowired
    private QualityDailyTask qualityDailyTask;

    @Test
    public void sendEmail() {
        qualityDailyTask.sendDailySummaryTask();
    }
}
