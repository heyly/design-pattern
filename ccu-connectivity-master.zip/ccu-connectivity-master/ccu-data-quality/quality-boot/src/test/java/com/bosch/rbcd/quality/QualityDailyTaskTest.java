package com.bosch.rbcd.quality;

import com.bosch.rbcd.quality.cron.QualityDailyTask;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.concurrent.TimeUnit;

@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class QualityDailyTaskTest {

    @Autowired
    private QualityDailyTask qualityDailyTask;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;
//
//    @Test
//    public void calculateDataScoreTest() {
//        qualityDailyTask.calculateDataScore();
//    }

    @Test
    public void testRedisKey() {
        System.out.println(stringRedisTemplate.hasKey("dataError_1461890421876723712_2024-01-23_count"));
        System.out.println(stringRedisTemplate.getExpire("dataError_1461890421876723712_2024-01-23_count", TimeUnit.SECONDS));
        ;
    }
}
