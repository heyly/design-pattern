package com.bosch.rbcd.quality.cron;

import cn.hutool.core.date.DateUtil;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.fleet.dto.ProjectDTO;
import com.bosch.rbcd.quality.service.DeviceExpireTaskService;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname DeviceExpireTask
 * @description TODO
 * @date 23/12/11 11:22
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DeviceExpireTask {

    private final DeviceExpireTaskService deviceExpireTaskService;

    private final ProjectFeignClient projectFeignClient;
    private final DeviceInfoFeignClient deviceInfoFeignClient;

    @XxlJob("ccuDailyExpireTask")
    public void ccuDailyExpireTask() {
        Date today = DateUtil.yesterday();
        List<ProjectDTO> activeProjectList = projectFeignClient.listActiveProject().getData();
        for (ProjectDTO projectInfoDTO : activeProjectList) {
            List<ProjectVehicleCcuDTO> ccuList = deviceInfoFeignClient.listProjectCcu(projectInfoDTO.getId()).getData();
            for (ProjectVehicleCcuDTO ccuDevice : ccuList) {
                deviceExpireTaskService.detectOneCcuExpire(ccuDevice, today);
            }
        }
    }

}
