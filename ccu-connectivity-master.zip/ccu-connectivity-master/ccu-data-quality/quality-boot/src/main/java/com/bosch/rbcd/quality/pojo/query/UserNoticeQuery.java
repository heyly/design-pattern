package com.bosch.rbcd.quality.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class UserNoticeQuery extends BasePageQuery {

    @ApiParam(value = "项目id", required = true)
    private Long projectId;

    @ApiParam("用户真名")
    private String username;
}
