package com.bosch.rbcd.quality.controller;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.common.web.vo.echarts.LineChartVO;
import com.bosch.rbcd.common.web.vo.echarts.PieChartVO;
import com.bosch.rbcd.data.api.CcuOnlineFeignClient;
import com.bosch.rbcd.data.query.CcuOnlineRecordFeignQuery;
import com.bosch.rbcd.data.vo.CcuOnlineRecordStatisticVO;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.fleet.api.VehicleFeignClient;
import com.bosch.rbcd.fleet.query.VehicleFeignQuery;
import com.bosch.rbcd.fleet.vo.VehicleBindStatisticVO;
import com.bosch.rbcd.quality.enums.ExpireCodeEnum;
import com.bosch.rbcd.quality.pojo.entity.CcuExpireRecord;
import com.bosch.rbcd.quality.pojo.query.CcuExpireRecordPageQuery;
import com.bosch.rbcd.quality.pojo.query.DataLossQuery;
import com.bosch.rbcd.quality.pojo.query.DataLossRateQuery;
import com.bosch.rbcd.quality.pojo.query.OverviewQuery;
import com.bosch.rbcd.quality.pojo.vo.*;
import com.bosch.rbcd.quality.service.CcuExpireRecordService;
import com.bosch.rbcd.quality.service.DataLossRateService;
import com.bosch.rbcd.quality.service.DataLossService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@Api(tags = "总览")
@RestController
@RequestMapping("/overview")
public class OverviewController {

    @Autowired
    private VehicleFeignClient vehicleFeignClient;

    @Autowired
    private DataLossRateService dataLossRateService;

    @Autowired
    private DataLossService dataLossService;

    @Autowired
    private ProjectFeignClient projectFeignClient;

    @Autowired
    private CcuExpireRecordService ccuExpireRecordService;

    @Autowired
    private CcuOnlineFeignClient ccuOnlineFeignClient;

    @ApiOperation("OEM应用记录")
    @GetMapping("/vehicleBindStatistic")
    public Result<List<VehicleBindStatisticVO>> vehicleBindStatistic (OverviewQuery overviewQuery) {
        List<Long> projectIdList = checkTimeAndGetProjectIdList(overviewQuery);
        if (CollectionUtils.isEmpty(projectIdList)) {
            return Result.success();
        }

        VehicleFeignQuery vehicleFeignQuery = new VehicleFeignQuery();
        vehicleFeignQuery.setProjectIdList(projectIdList);
        vehicleFeignQuery.setStartTime(overviewQuery.getStartTime());
        vehicleFeignQuery.setEndTime(overviewQuery.getEndTime());

        Result<List<VehicleBindStatisticVO>> feignResult = vehicleFeignClient.queryVehicleBindStatistic(vehicleFeignQuery);
        if (feignResult == null || CollectionUtils.isEmpty(feignResult.getData())) {
            return Result.success();
        }

        List<VehicleBindStatisticVO> res = new ArrayList<>();

        Map<String, VehicleBindStatisticVO> day2StatisticMap = new HashMap<>();
        Date startDay = DateUtil.beginOfDay(overviewQuery.getStartTime());
        Date endDay = DateUtil.endOfDay(overviewQuery.getEndTime());
        for (Date day=startDay; !day.after(endDay); day = DateUtil.tomorrow()) {
            VehicleBindStatisticVO vehicleBindStatisticVO = new VehicleBindStatisticVO();
//            vehicleBindStatisticVO.setBindDay(day);
            vehicleBindStatisticVO.setDay(day);
            vehicleBindStatisticVO.setCnt(0);
            res.add(vehicleBindStatisticVO);

            String dayStr = DateUtil.format(day, DatePattern.PURE_DATE_PATTERN);
            day2StatisticMap.put(dayStr, vehicleBindStatisticVO);
        }

        for (VehicleBindStatisticVO each : feignResult.getData()) {
            String dayStr = DateUtil.format(each.getBindDay(), DatePattern.PURE_DATE_PATTERN);
            if (!day2StatisticMap.containsKey(dayStr)) {
                continue;
            }
            day2StatisticMap.get(dayStr).setCnt(each.getCnt());
        }

        return Result.success(res);
    }

    @ApiOperation("数据丢失")
    @GetMapping("/dataLossStatistic")
    public Result<DataLossStatisticVO> dataLossStatistic (OverviewQuery overviewQuery) {
        DataLossStatisticVO dataLossStatisticVO = new DataLossStatisticVO();

        List<Long> projectIdList = checkTimeAndGetProjectIdList(overviewQuery);
        if (CollectionUtils.isEmpty(projectIdList)) {
            return Result.success(dataLossStatisticVO);
        }

        DataLossRateQuery dataLossRateQuery = new DataLossRateQuery();
        dataLossRateQuery.setProjectIdList(projectIdList);
        dataLossRateQuery.setStartTime(overviewQuery.getStartTime());
        dataLossRateQuery.setEndTime(overviewQuery.getEndTime());

        dataLossStatisticVO.setLossRate(dataLossRateService.getAverageRate(dataLossRateQuery));

        DataLossQuery dataLossQuery = new DataLossQuery();
        dataLossQuery.setProjectIdList(projectIdList);
        dataLossQuery.setStartTime(overviewQuery.getStartTime());
        dataLossQuery.setEndTime(overviewQuery.getEndTime());
        dataLossStatisticVO.setLostMileageCount(dataLossService.countLostMileage(dataLossQuery));
        dataLossStatisticVO.setLostDeviceCount(dataLossService.countLostDevice(dataLossQuery));
        dataLossStatisticVO.setLostEventCount(dataLossService.countLostEvent(dataLossQuery));

        return Result.success(dataLossStatisticVO);
    }

    @ApiOperation("CCU运行情况")
    @GetMapping("/ccuRunStatisticVO")
    public Result<CcuRunStatisticVO> ccuRunStatisticVO (OverviewQuery overviewQuery) {
        CcuRunStatisticVO ccuRunStatisticVO = new CcuRunStatisticVO();

        List<Long> projectIdList = checkTimeAndGetProjectIdList(overviewQuery);
        if (CollectionUtils.isEmpty(projectIdList)) {
            return Result.success(ccuRunStatisticVO);
        }

        CcuOnlineRecordFeignQuery ccuOnlineRecordFeignQuery = new CcuOnlineRecordFeignQuery();
        ccuOnlineRecordFeignQuery.setProjectIdList(projectIdList);
        ccuOnlineRecordFeignQuery.setStartTime(overviewQuery.getStartTime());
        ccuOnlineRecordFeignQuery.setEndTime(overviewQuery.getEndTime());
        List<CcuOnlineRecordStatisticVO> onlineRecordStatisticList = ccuOnlineFeignClient.statistics(ccuOnlineRecordFeignQuery).getData();

        List<CcuExpireRecordStatisticVO> expireRecordStatisticList = ccuExpireRecordService.statistics(projectIdList, overviewQuery.getStartTime(), overviewQuery.getEndTime());

        List<CcuStatusStatisticVO> ccuStatusStatisticVOList = new ArrayList<>();
        Map<String, CcuStatusStatisticVO> day2StatusMap = new HashMap<>();
        Date startDay = DateUtil.beginOfDay(overviewQuery.getStartTime());
        Date endDay = DateUtil.endOfDay(overviewQuery.getEndTime());
        for (Date day=startDay; !day.after(endDay); day = DateUtil.tomorrow()) {
            CcuStatusStatisticVO ccuStatusStatisticVO = new CcuStatusStatisticVO();
            ccuStatusStatisticVO.setDay(day);
            ccuStatusStatisticVOList.add(ccuStatusStatisticVO);

            String dayStr = DateUtil.format(day, DatePattern.PURE_DATE_PATTERN);
            day2StatusMap.put(dayStr, ccuStatusStatisticVO);
        }

        if (CollectionUtils.isNotEmpty(expireRecordStatisticList)) {
            for (CcuExpireRecordStatisticVO expireRecordStatisticVO : expireRecordStatisticList) {
                String expireDateStr = expireRecordStatisticVO.getExpireDate();
                if (day2StatusMap.containsKey(expireDateStr)) {
                    CcuStatusStatisticVO ccuStatusStatisticVO = day2StatusMap.get(expireDateStr);
                    ccuStatusStatisticVO.setExpireCcuCount(expireRecordStatisticVO.getExpireCount());
                }
            }
        }

        if (CollectionUtils.isNotEmpty(onlineRecordStatisticList)) {
            for (CcuOnlineRecordStatisticVO onlineRecordStatisticVO : onlineRecordStatisticList) {
                String onlineDateStr = onlineRecordStatisticVO.getOnlineDate();
                if (day2StatusMap.containsKey(onlineDateStr)) {
                    CcuStatusStatisticVO ccuStatusStatisticVO = day2StatusMap.get(onlineDateStr);
                    ccuStatusStatisticVO.setOnlineCcuCount(onlineRecordStatisticVO.getOnlineCount());
                }
            }
        }

        ccuRunStatisticVO.setCcuStatusStatisticVOList(ccuStatusStatisticVOList);

        String startDayStr = DateUtil.format(overviewQuery.getStartTime(), DatePattern.PURE_DATE_PATTERN);
        String endDayStr = DateUtil.format(overviewQuery.getEndTime(), DatePattern.PURE_DATE_PATTERN);

        LambdaQueryWrapper<CcuExpireRecord> expireRecordQuery = new LambdaQueryWrapper<>();
        expireRecordQuery.between(CcuExpireRecord::getExpireDate, startDayStr, endDayStr);
        expireRecordQuery.in(CcuExpireRecord::getProjectId, projectIdList);
        expireRecordQuery.eq(CcuExpireRecord::getExpireType, 2);

        expireRecordQuery.eq(CcuExpireRecord::getExpireCode, ExpireCodeEnum.CAN_LINE_EXPIRE.getValue());
        ccuRunStatisticVO.setCanErrorNum(ccuExpireRecordService.count(expireRecordQuery));

        expireRecordQuery.eq(CcuExpireRecord::getExpireCode, ExpireCodeEnum.CCU_SW_EXPIRE.getValue());
        ccuRunStatisticVO.setCcuSoftwareErrorNum(ccuExpireRecordService.count(expireRecordQuery));

        expireRecordQuery.eq(CcuExpireRecord::getExpireCode, ExpireCodeEnum.RBCD_CLOUD_EXPIRE.getValue());
        ccuRunStatisticVO.setCloudErrorNum(ccuExpireRecordService.count(expireRecordQuery));

        return Result.success(ccuRunStatisticVO);

    }

    @ApiOperation(value = "图表 - Top10饼状图数据")
    @GetMapping("topVehiclePie")
    public Result<PieChartVO> topVehiclePie(OverviewQuery overviewQuery) {
        List<Long> projectIdList = checkTimeAndGetProjectIdList(overviewQuery);
        if (CollectionUtils.isEmpty(projectIdList)) {
            return Result.success(null);
        }
        CcuExpireRecordPageQuery query = buildQuery(projectIdList, overviewQuery);

        PieChartVO pieChartVO = ccuExpireRecordService.topVehiclePie(query);
        return Result.success(pieChartVO);
    }

    @ApiOperation(value = "图表 - 折线图数据")
    @GetMapping("/lineChartData")
    public Result<LineChartVO> lineChartData(OverviewQuery overviewQuery) {
        List<Long> projectIdList = checkTimeAndGetProjectIdList(overviewQuery);
        if (CollectionUtils.isEmpty(projectIdList)) {
            return Result.success(null);
        }
        CcuExpireRecordPageQuery query = buildQuery(projectIdList, overviewQuery);

        LineChartVO pieChartVO = ccuExpireRecordService.lineChartData(query);
        return Result.success(pieChartVO);
    }

    @ApiOperation(value = "图表 - 二维图表数据")
    @GetMapping("/tableData")
    public Result<EventCountTableVO> tableData(OverviewQuery overviewQuery) {
        List<Long> projectIdList = checkTimeAndGetProjectIdList(overviewQuery);
        if (CollectionUtils.isEmpty(projectIdList)) {
            return Result.success(null);
        }
        CcuExpireRecordPageQuery query = buildQuery(projectIdList, overviewQuery);

        EventCountTableVO pieChartVO = ccuExpireRecordService.tableData(query);
        return Result.success(pieChartVO);
    }

    private List<Long> checkTimeAndGetProjectIdList(OverviewQuery overviewQuery) {
        if (overviewQuery.getStartTime() == null || overviewQuery.getEndTime() == null || overviewQuery.getStartTime().after(overviewQuery.getEndTime())) {
            throw new BizException("请选择有效时间范围");
        }

        List<Long> projectIdList = null;
        if (overviewQuery.getProjectId() == null) {
            projectIdList = projectFeignClient.queryAllAuthorityProjectId(UserUtils.getUserId()).getData();
        } else {
            projectIdList = Collections.singletonList(overviewQuery.getProjectId());
        }

        return projectIdList;
    }

    private CcuExpireRecordPageQuery buildQuery(List<Long> projectIdList, OverviewQuery overviewQuery) {
        CcuExpireRecordPageQuery expressRecordPageQuery = new CcuExpireRecordPageQuery();
        expressRecordPageQuery.setProjectIdList(projectIdList);
        expressRecordPageQuery.setStartTime(overviewQuery.getStartTime());
        expressRecordPageQuery.setEndTime(overviewQuery.getEndTime());
        expressRecordPageQuery.setExpireType(2);
        expressRecordPageQuery.setExpireCode(overviewQuery.getExpireCode());
        return expressRecordPageQuery;
    }

}
