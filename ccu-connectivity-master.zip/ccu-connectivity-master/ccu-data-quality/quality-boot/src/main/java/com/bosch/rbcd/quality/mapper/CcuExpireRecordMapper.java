package com.bosch.rbcd.quality.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.web.vo.echarts.NameValueVO;
import com.bosch.rbcd.quality.pojo.entity.CcuExpireRecord;
import com.bosch.rbcd.quality.pojo.query.CcuExpireRecordPageQuery;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireRecordStatisticVO;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireRecordVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 数据质量-ccu失效记录(QualityCcuExpireRecord)表数据库访问层
 *
 * @author wang bo
 * @since 2023-12-12 16:22:01
 */
@Mapper
public interface CcuExpireRecordMapper extends BaseMapper<CcuExpireRecord> {

    /**
     * 获取QualityCcuExpireRecord分页列表
     *
     * @param page
     * @param queryParams 查询参数
     * @return
     */
    Page<CcuExpireRecordVO> listQualityCcuExpireRecordPage(Page<CcuExpireRecordVO> page, @Param("queryParams") CcuExpireRecordPageQuery queryParams);

    List<NameValueVO> getTop10CcuPieData(@Param("queryParams") CcuExpireRecordPageQuery query);

    List<Map<String, Object>> pageOverviewTable(Page<Map<String, Object>> page, @Param("queryParams") CcuExpireRecordPageQuery query);

    long getSummaryCardInfo(@Param("queryParams") CcuExpireRecordPageQuery query);

    List<CcuExpireRecordStatisticVO> statistics(@Param("projectIdList") List<Long> projectIdList, @Param("startTime") Date startTime, @Param("endTime") Date endTime);

    CcuExpireRecordVO queryById(@Param("id") Long id);
}

