package com.bosch.rbcd.quality.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.quality.pojo.entity.CcuSelfCheckConfig;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * ccu自诊断信息配置表(CcuSelfCheckConfig)表数据库访问层
 *
 * @author wang bo
 * @since 2023-12-15 14:00:55
 */
@Mapper
public interface CcuSelfCheckConfigMapper extends BaseMapper<CcuSelfCheckConfig> {

    CcuSelfCheckConfig getErrorCheckInfo(List<String> codeList);
}

