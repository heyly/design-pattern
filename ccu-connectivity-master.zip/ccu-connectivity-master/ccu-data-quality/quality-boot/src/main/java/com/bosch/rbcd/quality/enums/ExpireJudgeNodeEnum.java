package com.bosch.rbcd.quality.enums;

import com.bosch.rbcd.common.base.IBaseEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * ccu失效诊断节点枚举类
 * @author WBO3WX
 */
public enum ExpireJudgeNodeEnum implements IBaseEnum {
    CCU_ON_T("ccuOnT","CCU当天有数据","CCU has today's data"),
    CCU_ON_F("ccuOnF","CCU当天无数据","CCU doesn't have today's data"),

    CCU_A_T("ccuAT","CCU-A设备","CCU-A Device"),
    CCU_A_F("ccuAF","CCU-S/E设备","CCU-S/E Device"),

    SIM_4G_T("sim4gT","中国移动无锡4G卡","China Mobile Wuxi 4G Card"),
    SIM_4G_F("sim4gF","非中国移动无锡4G卡","Non China Mobile Wuxi 4G Card"),

    SIM_ON_T("simOnT","SIM卡当天在线","SIM card online today"),
    SIM_ON_F("simOnF","SIM卡当天离线","SIM card offline today"),

    CCU_WEEK_ON_T("ccuWeekOnT","常运行且最近一周在线过","Frequently running and online in the past week"),
    CCU_WEEK_ON_F("ccuWeekOnF","常运行且最近一周离线","Frequently running and offline in the past week"),

    CCU_V190_T("ccuV190T","CCU软件V1.9.0及以上","CCU software V1.9.0 and above"),
    CCU_V190_F("ccuV190F","CCU软件V1.9.0以下","CCU software below V1.9.0"),

    CCU_STATUS_T("ccuStatusT","CCU有周期状态上报","CCU has periodic status reporting"),
    CCU_STATUS_F("ccuStatusF","CCU没有周期状态上报","CCU has no periodic status reporting"),

    MQTT_ON_T("mqttOnT","当天有MQTT消息","CCU has MQTT messages today"),
    MQTT_ON_F("mqttOnF","当天无MQTT消息","CCU has no MQTT messages today"),

    T15_ON_T("t15OnT","当天有T15上电信号","CCU has T15 powered on"),
    T15_ON_F("t15OnF","当天无T15上电信号","CCU has no T15 powered on"),

    TCP_LOG_T("tcpLogT","当天有TCP报文","CCU has TCP messages"),
    TCP_LOG_F("tcpLogF","当天无TCP报文","CCU has no TCP messages"),

    TCP_LOGIN_T("tcpLoginT","当天有TCP登陆报文","CCU has Login messages"),
    TCP_LOGIN_F("tcpLoginF","当天无TCP登陆报文","CCU has no Login messages"),

    TCP_DATA_T("tcpDataT","当天有TCP实时数据报文","CCU has raw data messages"),
    TCP_DATA_F("tcpDataF","当天无TCP实时数据报文","CCU has no raw data messages"),

    CCU_CHECK_T("ccuCheckT","当天有CCU自诊断报错","CCU has self diagnostic errors"),
    CCU_CHECK_F("ccuCheckF","当天无CCU自诊断报错","CCU has no self diagnostic errors"),

    CONFIG_CHECK_T("configCheckT","CCU与Cloud数据配置长度一致","CCU and Cloud data lengths are consistent"),
    CONFIG_CHECK_F("configCheckF","CCU与Cloud数据配置长度不一致","The data length of CCU and Cloud is inconsistent"),

    HP_CCU_T("hpCcuT","CCU接入RBHP Cloud","CCU Connected RBHP"),
    HP_CCU_F("hpCcuF","CCU接入RBCD Cloud","CCU Connected RBCD"),

    HP_DATA_T("hpDataT","RBHP有当天CCU数据","RBHP has CCU data"),
    HP_DATA_F("hpDataF","RBHP无当天CCU数据","RBHP has no CCU data"),

    HP_KAFKA_OFF_T("HpKafkaOffT", "RBHP未转发数据","RBHP did not forward data"),
    HP_KAFKA_OFF_F("HpKafkaOffF", "RBHP转发了数据","RBHP forwarded the data");

    private final String value;

    private final String label;
    private final String enLabel;

    ExpireJudgeNodeEnum(String value, String label, String enLabel) {
        this.value = value;
        this.label = label;
        this.enLabel = enLabel;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public String getEnLabel() {
        return enLabel;
    }


    private static final Map<String, Object> map = new HashMap<>();

    static {
        for (ExpireJudgeNodeEnum e : ExpireJudgeNodeEnum.values()) {
            HashMap<Object, Object> subMap = new HashMap<>();
            subMap.put("code",e.getValue());
            subMap.put("cnLabel",e.getLabel());
            subMap.put("enLabel",e.getEnLabel());
            map.put(e.getValue(), subMap);
        }
    }

    public static Map<String, Object> getMap() {
        return map;
    }
}
