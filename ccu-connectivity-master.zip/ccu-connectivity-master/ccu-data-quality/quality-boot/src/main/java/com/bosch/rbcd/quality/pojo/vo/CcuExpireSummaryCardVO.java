package com.bosch.rbcd.quality.pojo.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname CcuExpireSummaryCardVO
 * @description TODO
 * @date 2024/1/8 11:20
 */
@Data
public class CcuExpireSummaryCardVO {

    @ApiModelProperty("疑似失效CCU数量")
    private long doubtCcu;

    @ApiModelProperty("确认失效CCU数量")
    private long confirmCcu;

}
