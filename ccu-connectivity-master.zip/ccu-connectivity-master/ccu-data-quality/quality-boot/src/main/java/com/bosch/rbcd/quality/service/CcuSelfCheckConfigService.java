package com.bosch.rbcd.quality.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.quality.pojo.entity.CcuSelfCheckConfig;

import java.util.List;

/**
 * ccu自诊断信息配置表(CcuSelfCheckConfig)表服务接口
 *
 * @author wang bo
 * @since 2023-12-15 14:00:55
 */
public interface CcuSelfCheckConfigService extends IService<CcuSelfCheckConfig> {

    CcuSelfCheckConfig getErrorCheckInfo(List<String> codeList);
}

