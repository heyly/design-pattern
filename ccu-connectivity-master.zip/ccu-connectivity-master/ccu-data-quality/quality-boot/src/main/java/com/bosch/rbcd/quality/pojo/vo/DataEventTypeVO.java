package com.bosch.rbcd.quality.pojo.vo;

import com.bosch.rbcd.quality.enums.DataEventTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("异常事件状态枚举类")
public class DataEventTypeVO {

    @ApiModelProperty("值")
    private int value;

    @ApiModelProperty("中文描述")
    private String label;

    @ApiModelProperty("英文描述")
    private String labelEng;


    public DataEventTypeVO() {
    }

    public DataEventTypeVO(DataEventTypeEnum e) {
        this.value = e.getValue();
        this.label = e.getLabel();
        this.labelEng = e.getLabelEng();
    }
}
