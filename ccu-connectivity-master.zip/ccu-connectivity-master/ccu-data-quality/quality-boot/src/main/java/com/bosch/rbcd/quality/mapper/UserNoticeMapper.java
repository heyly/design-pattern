package com.bosch.rbcd.quality.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bosch.rbcd.quality.pojo.entity.UserNotice;
import com.bosch.rbcd.quality.pojo.query.UserNoticeQuery;
import com.bosch.rbcd.quality.pojo.vo.UserNoticeVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserNoticeMapper extends BaseMapper<UserNotice> {

    IPage<UserNoticeVO> pageQuery(IPage<UserNoticeVO> page, @Param("query") UserNoticeQuery query);
}
