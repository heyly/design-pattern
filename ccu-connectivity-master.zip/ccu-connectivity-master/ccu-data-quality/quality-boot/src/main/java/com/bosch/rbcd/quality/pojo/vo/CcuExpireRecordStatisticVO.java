package com.bosch.rbcd.quality.pojo.vo;

import lombok.Data;

@Data
public class CcuExpireRecordStatisticVO {

    private Integer expireCount;

    // yyyyMMdd
    private String expireDate;
}
