package com.bosch.rbcd.quality.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("quality_user_notice")
public class UserNotice {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long projectId;

    private Long userId;

    /**
     * 是否发送邮件，0-否，1-是
     */
    private Boolean sendEmail;

    /**
     * 设备失效
     */
    private Boolean ccuExpire;

    /**
     * 里程丢失
     */
    private Boolean dataLoss;

    /**
     * GPS失效
     */
    private Boolean gpsLoss;

}
