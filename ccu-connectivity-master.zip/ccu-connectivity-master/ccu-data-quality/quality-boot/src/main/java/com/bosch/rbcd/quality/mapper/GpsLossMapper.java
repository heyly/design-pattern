package com.bosch.rbcd.quality.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.quality.pojo.entity.GpsLoss;
import com.bosch.rbcd.quality.pojo.query.GpsLossPageQuery;
import com.bosch.rbcd.quality.pojo.vo.GpsLossVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * GPS数据质量事件记录(3、4)(QualityGpsLoss)表数据库访问层
 *
 * @author wang bo
 * @since 2023-05-11 11:10:28
 */
@Mapper
public interface GpsLossMapper extends BaseMapper<GpsLoss> {

    /**
     * 获取QualityGpsLoss分页列表
     *
     * @param page
     * @param query 查询参数
     * @return
     */
    Page<GpsLossVO> pageQuery(Page<GpsLossVO> page, @Param("query") GpsLossPageQuery query);

    GpsLossVO detail(@Param("id") Long id);
}

