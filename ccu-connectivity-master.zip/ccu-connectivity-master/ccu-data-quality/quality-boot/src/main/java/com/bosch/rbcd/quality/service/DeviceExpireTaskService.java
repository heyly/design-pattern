package com.bosch.rbcd.quality.service;

import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;

import java.util.Date;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname DeviceExpireTaskService
 * @description TODO
 * @date 23/12/11 11:28
 */
public interface DeviceExpireTaskService {

    void detectOneCcuExpire(ProjectVehicleCcuDTO ccuDevice, Date today);
}
