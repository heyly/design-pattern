package com.bosch.rbcd.quality.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.quality.pojo.entity.UserNotice;
import com.bosch.rbcd.quality.pojo.query.UserNoticeQuery;
import com.bosch.rbcd.quality.pojo.vo.UserNoticeVO;

public interface UserNoticeService extends IService<UserNotice> {

    /**
     * 查询指定分组下的全部人员信息
     * @return
     */
    IPage<UserNoticeVO> query(UserNoticeQuery userNoticeQuery);

    /**
     * 逐个设置用户权限
     * @param userNoticeVO
     * @return
     */
    Long saveOrUpdateUserNotice(UserNoticeVO userNoticeVO);
}
