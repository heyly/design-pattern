package com.bosch.rbcd.quality.enums;

import com.bosch.rbcd.common.base.IBaseEnum;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname ExpireCodeEnum
 * @description TODO
 * @date 23/12/15 11:16
 */
@Getter
public enum ExpireCodeEnum implements IBaseEnum {
    DOUBT_POWER("Doubt_Power","疑似CCU供电问题","Doubt power supply issue with CCU"),
    DOUBT_SW("Doubt_SW","疑似CCU软件问题","Doubt software issue with CCU"),
    RBCD_CLOUD_EXPIRE("RBCD_Cloud_Expire","RBCD数据链路问题","RBCD Data Flow Link Issues"),
    CCU_CONFIG_EXPIRE("CCU_Config_Expire","CCU数据采集配置问题","CCU data collection configuration issue"),
    CCU_SW_EXPIRE("CCU_SW_Expire","CCU 软件问题","CCU software issue"),
    CAN_LINE_EXPIRE("Can_Line_Expire","CAN线错误","CAN line error"),
    HP_KAFKA_EXPIRE("HP_Kafka_Expire","RBHP数据链路问题","RBHP Data Flow Link Issues");

    private final String value;

    private final String label;

    private final String enLabel;

    ExpireCodeEnum(String value, String label, String enLabel) {
        this.value = value;
        this.label = label;
        this.enLabel = enLabel;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public String getEnLabel() {
        return enLabel;
    }


    private static final Map<String, Object> map = new HashMap<>();

    static {
        for (ExpireCodeEnum e : ExpireCodeEnum.values()) {
            HashMap<Object, Object> subMap = new HashMap<>();
            subMap.put("code",e.getValue());
            subMap.put("cnLabel",e.getLabel());
            subMap.put("enLabel",e.getEnLabel());
            map.put(e.getValue(), subMap);
        }
    }

    public static Map<String, Object> getMap() {
        return map;
    }
}
