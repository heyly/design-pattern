package com.bosch.rbcd.quality.controller;

import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.result.ResultCode;
import com.bosch.rbcd.quality.pojo.query.UserNoticeQuery;
import com.bosch.rbcd.quality.pojo.vo.UserNoticeVO;
import com.bosch.rbcd.quality.service.UserNoticeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


@Api(tags = "通知管理")
@RestController
@RequestMapping("/user/email")
public class UserNoticeController {

    @Autowired
    private UserNoticeService userNoticeService;

    @ApiOperation("查询指定项目下人员权限")
    @GetMapping("/getByProjectId")
    public PageResult<UserNoticeVO> getByProjectId(UserNoticeQuery userNoticeQuery) {
        if (userNoticeQuery.getProjectId() == null) {
            return PageResult.failed("请选择项目");
        }
        return PageResult.success(userNoticeService.query(userNoticeQuery));
    }

    @ApiOperation("设置或修改权限")
    @PostMapping("/saveOrUpdateUserNotice")
    public Result<?> saveOrUpdateUserNotice(@RequestBody @Validated UserNoticeVO userNoticeVO) {
        if (userNoticeVO.getProjectId() == null || userNoticeVO.getUserId() == null){
            return Result.failed(ResultCode.PARAM_ERROR);
        }

        return Result.success(userNoticeService.saveOrUpdateUserNotice(userNoticeVO));
    }
}
