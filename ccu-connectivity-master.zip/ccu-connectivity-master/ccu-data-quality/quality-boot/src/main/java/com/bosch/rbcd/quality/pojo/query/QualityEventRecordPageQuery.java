package com.bosch.rbcd.quality.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * 数据质量事件记录信息表(QualityEventRecord)分页查询对象
 *
 * @author wang bo
 * @since 2023-04-27 11:20:56
 */
@ApiModel("数据质量事件记录信息表分页查询对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Accessors(chain = true)
public class QualityEventRecordPageQuery extends BasePageQuery {

    @ApiModelProperty(value = "数据事件类型", hidden = true)
    private List<Integer> eventTypeList;

    @ApiModelProperty("时间类型 3-定位丢失，6-里程丢失")
    private Integer eventType;

    @ApiModelProperty("处理人")
    private Long handlerId;

    @ApiModelProperty("解决状态，0-待处理，1-已处理")
    private String solveStatus;

    @ApiModelProperty("问题类型，0-应用问题, 1-软件问题, 2-硬件问题")
    private Integer reasonType;

    @ApiModelProperty(value = "项目id")
    private Long projectId;

    @ApiModelProperty(hidden = true)
    private List<Long> projectIdList;

    @ApiModelProperty("车架号")
    private String vin;

    @ApiModelProperty("IMEI")
    private String imei;

    @ApiModelProperty("软件版本")
    private String softwareVersion;

    @ApiModelProperty("SN")
    private String sn;
}
