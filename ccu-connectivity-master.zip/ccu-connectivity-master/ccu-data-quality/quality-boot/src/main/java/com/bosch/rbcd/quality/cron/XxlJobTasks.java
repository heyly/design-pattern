//package com.bosch.rbcd.quality.cron;
//
//import com.xxl.job.core.handler.annotation.XxlJob;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.stereotype.Component;
//
//@Component
//@Slf4j
//@RequiredArgsConstructor
//public class XxlJobTasks {
//
//    private final QualityDailyTask qualityDailyTask;
//    private final QualityEventRecordTask qualityEventRecordTask;
////    private final VehicleDataCountTask vehicleDataCountTask;
//
//    /**
//     * 0 0 7 * * ?
//     */
//    @XxlJob("sendDailySummaryTask")
//    public void sendDailySummaryTask(){
//        qualityDailyTask.sendDailySummaryTask();
//    }
//
//    /**
//     * 读取 quality_event_record 表，查询前一天的异常事件，要求ccu，重发数据
//     * 0 0 3 * * ?
//     */
//    @XxlJob("requestDeviceLog")
//    public void requestDeviceLog() {
//        qualityEventRecordTask.requestDeviceLog();
//    }
//
//    /**
//     * 为每条记录增加责任人
//     * 0 30 0/1 * * ?
//     */
//    @XxlJob("addPersonInCharge")
//    public void addPersonInCharge() {
////        qualityEventRecordTask.addPersonInCharge();
//    }
//
//    /**
//     * 每天凌晨一点执行一次车辆数据统计
//     * 0 0 1 * * ?
//     */
//    @XxlJob("countVehicleData")
//    public void countVehicleData() {
////        vehicleDataCountTask.countVehicleData();
//    }
//
//    /**
//     * 每两小时统计一次车辆数据量
//     */
//    @XxlJob("countVehicleDataPer2Hour")
//    public void countVehicleDataPer2Hour() {
////        vehicleDataCountTask.countVehicleDataPer2Hour();
//    }
//
//    /**
//     * 计算数据评分
//     * 每天凌晨2点执行，计算前一天的
//     */
//    @XxlJob("calculateDataScore")
//    public void calculateDataScore() {
////        qualityDailyTask.calculateDataScore();
//    }
//}
