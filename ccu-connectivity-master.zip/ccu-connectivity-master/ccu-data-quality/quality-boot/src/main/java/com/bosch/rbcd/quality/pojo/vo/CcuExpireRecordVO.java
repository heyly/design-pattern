package com.bosch.rbcd.quality.pojo.vo;

import cn.afterturn.easypoi.excel.annotation.Excel;
import cn.afterturn.easypoi.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 数据质量-ccu失效记录(QualityCcuExpireRecord)视图对象
 *
 * @author wang bo
 * @since 2023-12-12 16:22:01
 */
@ApiModel("数据质量-ccu失效记录视图对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CcuExpireRecordVO {

    @ApiModelProperty("主键，唯一标识")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private Long id;

    @ApiModelProperty("ccu 标识")
    @ExcelIgnore
    @ExcelProperty("ccuId")
    private String ccuId;

    @ApiModelProperty("ccu编号")
    @Excel(name = "ccu编号", width = 30)
    @ExcelProperty("ccu编号")
    private String ccuNo;

    @ApiModelProperty("CCU的软件版本")
    @Excel(name = "CCU的软件版本")
    @ExcelProperty("CCU的软件版本")
    private String softwareVersion;

    @ApiModelProperty("vin")
    @Excel(name = "vin", width = 30)
    @ExcelProperty("vin")
    private String vin;

    @ApiModelProperty("发动机编号")
    @Excel(name = "发动机编号", width = 30)
    @ExcelProperty("发动机编号")
    private String engineNo;

    @ApiModelProperty("车辆别名")
    @Excel(name = "车辆别名", width = 30)
    @ExcelProperty("车辆别名")
    private String vehicleName;

    @ApiModelProperty("imei")
    @Excel(name = "IMEI", width = 30)
    private String imei;

    @ApiModelProperty("完整SN")
    @Excel(name = "完整SN", width = 30)
    @ExcelProperty("完整SN")
    private String sn;

    @ApiModelProperty("SN短号")
    @Excel(name = "SN短号", width = 30)
    @ExcelProperty("SN短号")
    private String shortSn;

    @ApiModelProperty("长运行车辆标志，0_非常运行，1_常运行")
    @Excel(name = "是否常运行",replace = {"否_0","是_1"})
    @ExcelProperty("是否常运行")
    private Integer regularFlag;

    @ApiModelProperty("失效日期")
    @Excel(name = "失效日期")
    @ExcelProperty("失效日期")
    private String expireDate;

    @ApiModelProperty("失效流程节点")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private String flowNode;

    @ApiModelProperty("失效流程节点")
    @Excel(name = "诊断流程")
    @ExcelProperty("诊断流程")
    private String flowNodeLabel;

    @ApiModelProperty("失效等级 1_疑似失效 2_确认失效")
    @Excel(name = "失效等级",replace = {"疑似失效_1","确认失效_2"})
    @ExcelProperty("失效等级")
    private Integer expireType;

    @ApiModelProperty("失效类型code")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private String expireCode;

    @ApiModelProperty("失效类型code")
    @Excel(name = "失效类型")
    @ExcelProperty("失效类型code")
    private String expireCodeLabel;

    @ApiModelProperty("失效分析")
    @Excel(name = "失效分析")
    @com.alibaba.excel.annotation.ExcelIgnore
    private String analysis;

    @ApiModelProperty("解决方案")
    @Excel(name = "解决方案")
    @com.alibaba.excel.annotation.ExcelIgnore
    private String solution;

    @ApiModelProperty("处理状态")
    @com.alibaba.excel.annotation.ExcelIgnore
    private Integer solveStatus;

    @ApiModelProperty("处理人id")
    @com.alibaba.excel.annotation.ExcelIgnore
    @ExcelIgnore
    private Long userId;

    @ApiModelProperty("处理人")
    @Excel(name = "处理人")
    @com.alibaba.excel.annotation.ExcelIgnore
    private String userName;

    @ApiModelProperty("创建时间")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private Date createTime;

    @ApiModelProperty("更新时间")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private Date updateTime;

    @ApiModelProperty("硬件类型id")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private Long hardwareTypeId;

    @ApiModelProperty("硬件类型名字")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private String hardwareTypeName;
}
