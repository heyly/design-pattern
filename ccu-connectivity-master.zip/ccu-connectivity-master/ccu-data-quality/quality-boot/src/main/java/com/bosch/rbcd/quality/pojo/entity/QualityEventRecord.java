package com.bosch.rbcd.quality.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.bosch.rbcd.common.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * 数据质量事件记录信息表(QualityEventRecord)实体类
 *
 * @author wang bo
 * @since 2023-04-27 11:20:56
 */
@EqualsAndHashCode(callSuper = true)
@ApiModel("数据质量事件记录信息表实体类")
@Data
@Accessors(chain=true)
public class QualityEventRecord extends BaseEntity {

    @ApiModelProperty("主键")
    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("数据事件类型")
    private Integer eventType;

    @ApiModelProperty("事件记录主键")
    private Long eventId;

    @ApiModelProperty("车架号")
    @TableField(exist = false)
    private String vin;

    @ApiModelProperty("事件发生时间")
    private Date occurTime;

    @ApiModelProperty("事件完成时间")
    private Date finishTime;

    @ApiModelProperty("处理人")
    private Long handlerId;

    @ApiModelProperty("问题类型")
    private Integer reasonType;

    @ApiModelProperty("原因分析")
    private String causeAnalysis;

    @ApiModelProperty("解决状态")
    private String solveStatus;

    /**
     * @since 2023-09-01
     */
    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("车辆id")
    private Long vehicleId;

    /**
     * @since 2023-09-01
     */
    @ApiModelProperty("ccu_id")
    private String ccuId;


    @ApiModelProperty("软件版本")
    private String softwareVersion;
}
