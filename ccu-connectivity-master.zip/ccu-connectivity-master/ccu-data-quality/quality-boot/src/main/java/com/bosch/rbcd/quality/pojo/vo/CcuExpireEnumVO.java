package com.bosch.rbcd.quality.pojo.vo;


import com.bosch.rbcd.quality.enums.ExpireCodeEnum;
import com.bosch.rbcd.quality.enums.ExpireJudgeNodeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Map;

@Data
@ApiModel("数据丢失实体类")
public class CcuExpireEnumVO {
    @ApiModelProperty("失效code列表")
    Map<String, Object> expireCodeMap = ExpireCodeEnum.getMap();

    @ApiModelProperty("诊断节点列表")
    Map<String, Object> judgeNodeMap = ExpireJudgeNodeEnum.getMap();
}
