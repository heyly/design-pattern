package com.bosch.rbcd.quality.enums;

import com.bosch.rbcd.common.base.IBaseEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.HashMap;
import java.util.Map;

/**
 * 异常事件状态枚举类
 * @author WBO3WX
 */
@ApiModel("异常事件状态枚举类")
public enum DataEventTypeEnum implements IBaseEnum<Integer> {


    CCU_EXPIRE(0, "设备失效", "CCU expire", true, "设备失效"),

    /**
     * Don't show again.
     * @since 2024.01.31
     */
    @Deprecated
    CCU_CHECK_ERROR(1,"CCU自检报错", "CCU_CHECK_ERROR", false, "其他事件"),

    /**
     * Don't show again.
     * @since 2024.01.31
     */
    @Deprecated
    HAS_GPS_NO_DATA(2,"Hbase有GPS数据无车辆数据", "HAS_GPS_NO_DATA", false, "其他事件"),

    /**
     * GPS失效事件
     */
    HAS_DATA_NO_GPS(3,"GPS失效事件", "GPS loss", true, "其他事件"),

    /**
     * Don't show again.
     * @since 2024.01.31
     */
    @Deprecated
    LOST_CAN_DATA(4,"丢失单路数据", "LOST_CAN_DATA", false, "其他事件"),

    /**
     * Don't show again.
     * @since 2024.01.31
     */
    @Deprecated
    HAS_MQTT_NO_DATA(5,"有MQTT消息但是无数据", "HAS_MQTT_NO_DATA", false, "其他事件"),

    /**
     * 里程丢失事件
     */
    LOST_ALL_DATA(6,"里程丢失事件", "Mileage loss", true, "其他事件"),

    /**
     * 数据异常事件
     */
    DATA_VALUE_ERROR(7,"数据异常事件", "Data error", true, "其他事件"),

    /**
     * 丢包率过高事件
     */
    LOSS_RATE_TOO_LARGE(8,"丢包率过高事件", "Loss rate too large", true, "其他事件"),

    DATA_SCORE_TOO_LOW(9, "数据评分过低", "Data score too low", true, "数据评分")
    ;

    @ApiModelProperty("值")
    private final int value;

    @ApiModelProperty("中文描述")
    private final String label;

    @ApiModelProperty("英文描述")
    private final String labelEng;

    @ApiModelProperty(hidden = true)
    private final boolean showable;

    @ApiModelProperty(hidden = true)
    private final String type;

    DataEventTypeEnum(int value, String label, String labelEng, boolean showable, String type) {
        this.value = value;
        this.label = label;
        this.labelEng = labelEng;
        this.showable = showable;
        this.type = type;
    }

    public Integer getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public String getLabelEng() {
        return labelEng;
    }

    public boolean isShowable() {
        return showable;
    }

    public String getType() {
        return type;
    }

    private static final Map<Integer, String> otherEventMap = new HashMap<>();

    static {
        for (DataEventTypeEnum e : DataEventTypeEnum.values()) {
            if (e.showable && e.getType().equals("其他事件")) {
                otherEventMap.put(e.getValue(), e.getLabel());
            }
        }
    }

    public static Map<Integer, String> getOtherEventMap() {
        return otherEventMap;
    }
}
