package com.bosch.rbcd.quality.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.quality.pojo.entity.GpsLoss;
import com.bosch.rbcd.quality.pojo.form.BatchSolveRecordForm;
import com.bosch.rbcd.quality.pojo.query.GpsLossPageQuery;
import com.bosch.rbcd.quality.pojo.vo.GpsLossVO;

/**
 * GPS数据质量事件记录(3、4)(QualityGpsLoss)表服务接口
 *
 * @author wang bo
 * @since 2023-05-11 11:10:28
 */
public interface GpsLossService extends IService<GpsLoss> {

    /**
     * QualityGpsLoss 分页列表
     *
     * @param: queryParams 分页查询条件
     * @return: IPage<QualityGpsLossVO>
     * @author: wang bo
     * @date: 2023-05-11 11:10:28
     */
    IPage<GpsLossVO> pageQuery(GpsLossPageQuery queryParams);

    GpsLossVO detail(Long id);

    void solve(BatchSolveRecordForm batchSolveRecordForm);
}

