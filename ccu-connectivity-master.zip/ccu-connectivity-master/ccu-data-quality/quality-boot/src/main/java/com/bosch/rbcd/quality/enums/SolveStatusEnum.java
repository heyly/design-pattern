package com.bosch.rbcd.quality.enums;

import com.bosch.rbcd.common.base.IBaseEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * OTA状态枚举类
 * @author WBO3WX
 */
public enum SolveStatusEnum implements IBaseEnum {
    CCU_CHECK_ERROR("0","未解决"),
    SOLVED("1","已解决");

    private final String value;

    private final String label;

    SolveStatusEnum(String value, String label) {
        this.value = value;
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    private static final Map<String, String> map = new HashMap<>();

    static {
        for (SolveStatusEnum e : SolveStatusEnum.values()) {
            map.put(e.getValue(), e.getLabel());
        }
    }

    public static Map<String, String> getMap() {
        return map;
    }
}
