package com.bosch.rbcd.quality.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.quality.pojo.form.CcuExpireRecordForm;
import com.bosch.rbcd.quality.pojo.query.CcuExpireRecordPageQuery;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireEnumVO;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireRecordVO;
import com.bosch.rbcd.quality.service.CcuExpireRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * 数据质量-ccu失效记录(QualityCcuExpireRecord)表控制层
 *
 * @author wang bo
 * @since 2023-12-26 13:27:32
 */
@Api(tags = "数据质量-ccu失效记录API")
@RestController
@RequestMapping("/qualityCcuExpireRecord")
@RequiredArgsConstructor
public class CcuExpireRecordController {

    private final CcuExpireRecordService ccuExpireRecordService;

    @ApiOperation(value = "分页查询")
    @PostMapping("/page")
    public PageResult<CcuExpireRecordVO> page(@RequestBody CcuExpireRecordPageQuery query) {
        Page<CcuExpireRecordVO> result = ccuExpireRecordService.listQualityCcuExpireRecordPage(query);
        return PageResult.success(result);
    }

    @ApiOperation("获取CCU失效国际化信息")
    @PostMapping("/getCcuExpireEnum")
    public Result<CcuExpireEnumVO> getCcuExpireEnum() {
        return Result.success(new CcuExpireEnumVO());
    }

    @ApiOperation(value = "分析处理CCU失效记录")
    @PostMapping("/solve")
    public Result<Void> solve(@Validated @RequestBody CcuExpireRecordForm qualityCcuExpireRecordForm) {
        ccuExpireRecordService.solve(qualityCcuExpireRecordForm);
        return Result.success();
    }

    @ApiOperation(value = "详情")
    @GetMapping("/getById/")
    public Result<CcuExpireRecordVO> getById(@RequestParam Long id) {
        return Result.success(ccuExpireRecordService.queryById(id));
    }

}

