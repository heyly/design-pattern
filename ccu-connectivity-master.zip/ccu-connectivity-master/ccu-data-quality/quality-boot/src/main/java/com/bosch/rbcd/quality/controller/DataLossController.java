package com.bosch.rbcd.quality.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.quality.pojo.form.BatchSolveRecordForm;
import com.bosch.rbcd.quality.pojo.query.DataLossQuery;
import com.bosch.rbcd.quality.pojo.vo.DataLossVO;
import com.bosch.rbcd.quality.service.DataLossService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

;

@Api(tags = "里程丢失")
@RestController
@RequestMapping("/dataLoss")
public class DataLossController {

    @Autowired
    private DataLossService dataLossService;

    @Autowired
    private ProjectFeignClient projectFeignClient;

    @ApiOperation(value = "分页获取数据丢失记录")
    @PostMapping("/pageQuery")
    public PageResult<DataLossVO> pageQuery(@RequestBody DataLossQuery query) {
        List<Long> projectIdList = checkTimeAndGetProjectIdList(query);
        if (CollectionUtils.isEmpty(projectIdList)) {
            return PageResult.success(new Page<>());
        }
        query.setProjectIdList(projectIdList);

        return PageResult.success(dataLossService.pageQuery(query));
    }

    @ApiOperation(value = "详情")
    @GetMapping("/detail")
    public Result<DataLossVO> detail(@RequestParam Long id) {
        return Result.success(dataLossService.detail(id));
    }

    @ApiOperation(value = "分析处理事件")
    @PostMapping("/solve")
    public Result<Void> solve(@RequestBody @Validated BatchSolveRecordForm batchSolveRecordForm) {
        dataLossService.solve(batchSolveRecordForm);
        return Result.success();
    }

    private List<Long> checkTimeAndGetProjectIdList(DataLossQuery dataLossQuery) {
        if (dataLossQuery.getStartTime() == null || dataLossQuery.getEndTime() == null || dataLossQuery.getStartTime().after(dataLossQuery.getEndTime())) {
            throw new BizException("请选择有效时间范围");
        }

        List<Long> projectIdList = null;
        if (dataLossQuery.getProjectId() == null) {
            projectIdList = projectFeignClient.queryAllAuthorityProjectId(UserUtils.getUserId()).getData();
        } else {
            projectIdList = Collections.singletonList(dataLossQuery.getProjectId());
        }

        return projectIdList;
    }
}
