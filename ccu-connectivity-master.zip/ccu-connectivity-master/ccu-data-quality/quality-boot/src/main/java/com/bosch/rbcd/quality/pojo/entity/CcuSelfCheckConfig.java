package com.bosch.rbcd.quality.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.bosch.rbcd.common.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * ccu自诊断信息配置表(CcuSelfCheckConfig)实体类
 *
 * @author wang bo
 * @since 2023-12-15 14:00:55
 */
@ApiModel("ccu自诊断信息配置表实体类")
@Data
@Accessors(chain=true)
public class CcuSelfCheckConfig extends BaseEntity {

    @ApiModelProperty("主键，唯一标识")
    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("错误类型Code")
    private String errorTypeCode;

    @ApiModelProperty("错误类型Label")
    private String errorTypeLabel;

    @ApiModelProperty("错误原因Code")
    private String errorReasonCode;

    @ApiModelProperty("错误原因Label")
    private String errorReasonLabel;

    @ApiModelProperty("自检信息类型  信息 错误")
    private String checkType;

    @ApiModelProperty("根本原因")
    private String rootType;

    @ApiModelProperty("备注")
    private String comment;

    @ApiModelProperty("措施")
    private String tips;

    @ApiModelProperty("优先级")
    private String priority;

}
