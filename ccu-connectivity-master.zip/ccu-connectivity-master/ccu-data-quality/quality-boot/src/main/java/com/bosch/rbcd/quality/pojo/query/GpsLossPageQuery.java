package com.bosch.rbcd.quality.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * GPS数据质量事件记录(3、4)(QualityGpsLoss)分页查询对象
 *
 * @author wang bo
 * @since 2023-05-11 11:10:28
 */
@ApiModel("定位丢失分页查询请求类")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GpsLossPageQuery extends BasePageQuery {

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty(value = "项目id列表", hidden = true)
    private List<Long> projectIdList;

    @ApiModelProperty("车架号")
    private String vin;

    @ApiModelProperty("IMEI")
    private String imei;

    @ApiModelProperty("sn")
    private String sn;

    @ApiModelProperty("软件版本")
    private String softwareVersion;

    @ApiModelProperty("分析状态，0-待处理，1-已处理")
    private Integer solveStatus;

    @ApiModelProperty("问题分类，0-应用问题, 1-软件问题, 2-硬件问题")
    private Integer reasonType;

}
