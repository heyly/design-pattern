package com.bosch.rbcd.quality.service.impl;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.common.base.IBaseEnum;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.common.web.vo.echarts.LineChartVO;
import com.bosch.rbcd.common.web.vo.echarts.NameValueVO;
import com.bosch.rbcd.common.web.vo.echarts.PieChartVO;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.quality.enums.ExpireCodeEnum;
import com.bosch.rbcd.quality.enums.ExpireJudgeNodeEnum;
import com.bosch.rbcd.quality.mapper.CcuExpireRecordMapper;
import com.bosch.rbcd.quality.pojo.entity.CcuExpireRecord;
import com.bosch.rbcd.quality.pojo.form.CcuExpireRecordForm;
import com.bosch.rbcd.quality.pojo.query.CcuExpireRecordPageQuery;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireRecordStatisticVO;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireRecordVO;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireSummaryCardVO;
import com.bosch.rbcd.quality.pojo.vo.EventCountTableVO;
import com.bosch.rbcd.quality.service.CcuExpireRecordService;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 数据质量-ccu失效记录(QualityCcuExpireRecord)表服务实现类
 *
 * @author wang bo
 * @since 2023-12-12 16:22:01
 */
@Service("qualityCcuExpireRecordService")
@RequiredArgsConstructor
public class CcuExpireRecordServiceImpl extends ServiceImpl<CcuExpireRecordMapper, CcuExpireRecord> implements CcuExpireRecordService {

    private final ProjectFeignClient projectFeignClient;

    @Override
    public Page<CcuExpireRecordVO> listQualityCcuExpireRecordPage(CcuExpireRecordPageQuery queryParams) {
        Page<CcuExpireRecordVO> page = new Page<>(queryParams.getPageNum(), queryParams.getPageSize());
        // 校验账号下有权限的项目
        if (CollectionUtil.isEmpty(queryParams.getProjectIdList())) {
            List<Long> projectIdList = projectFeignClient.queryAllAuthorityProjectId(UserUtils.getUserId()).getData();
            queryParams.setProjectIdList(projectIdList);
        }
        if (CollectionUtil.isNotEmpty(queryParams.getProjectIdList())) {
            if (CollectionUtil.isNotEmpty(queryParams.getOrders())) {
                page.addOrder(queryParams.getOrders());
            } else {
                page.addOrder(OrderItem.desc("qcer.create_time"));
            }

            page = this.baseMapper.listQualityCcuExpireRecordPage(page, queryParams);
//            dealPageShowLabel(list);
//            page.setRecords(list);
        }
        return page;
    }

    @Override
    public Workbook generateExpireExcel(CcuExpireRecordPageQuery query) {
        query.setPageSize(-1);
        List<CcuExpireRecordVO> dfcHandBookList = this.listQualityCcuExpireRecordPage(query).getRecords();
        ExportParams exportParams = new ExportParams();
        exportParams.setType(ExcelType.XSSF);
        String sheetName = StrUtil.format("CCU_Expire_Record", DateUtil.format(query.getStartTime(), DatePattern.PURE_DATE_PATTERN), DateUtil.format(query.getEndTime(),
                DatePattern.PURE_DATE_PATTERN));
        exportParams.setSheetName(sheetName);
        return ExcelExportUtil.exportExcel(exportParams, CcuExpireRecordVO.class, dfcHandBookList);
    }


    private void dealPageShowLabel(List<CcuExpireRecordVO> list) {
        if (CollectionUtil.isNotEmpty(list)) {
            Map<String, ExpireJudgeNodeEnum> judegeNodeMap = Arrays.stream(ExpireJudgeNodeEnum.values()).collect(Collectors.toMap(ExpireJudgeNodeEnum::getValue, e -> e));
            list.forEach(expireRecord -> {
                if (StrUtil.isNotBlank(expireRecord.getFlowNode())) {
                    List<String> splitNodes = StrUtil.split(expireRecord.getFlowNode(), ",");
                    String flowNodeLabel = splitNodes.stream().map(code -> judegeNodeMap.get(code).getLabel()).collect(Collectors.joining(","));
                    expireRecord.setFlowNodeLabel(flowNodeLabel);
                }

                String expireCodeLabel = IBaseEnum.getLabelByValue(expireRecord.getExpireCode(), ExpireCodeEnum.class);
                expireRecord.setExpireCodeLabel(expireCodeLabel);
            });
        }
    }

    private void dealPageShowLabel(CcuExpireRecordVO expireRecord) {
        if (expireRecord == null) {
            return;
        }

        Map<String, ExpireJudgeNodeEnum> judegeNodeMap = Arrays.stream(ExpireJudgeNodeEnum.values()).collect(Collectors.toMap(ExpireJudgeNodeEnum::getValue, e -> e));

        if (StrUtil.isNotBlank(expireRecord.getFlowNode())) {
            List<String> splitNodes = StrUtil.split(expireRecord.getFlowNode(), ",");
            String flowNodeLabel = splitNodes.stream().map(code -> judegeNodeMap.get(code).getLabel()).collect(Collectors.joining(","));
            expireRecord.setFlowNodeLabel(flowNodeLabel);
        }

        String expireCodeLabel = IBaseEnum.getLabelByValue(expireRecord.getExpireCode(), ExpireCodeEnum.class);
        expireRecord.setExpireCodeLabel(expireCodeLabel);
    }


    @Override
    public PieChartVO topVehiclePie(CcuExpireRecordPageQuery query) {
        PieChartVO pieChart = new PieChartVO();
        List<NameValueVO> data = this.baseMapper.getTop10CcuPieData(query);
        pieChart.setData(data);
        return pieChart;
    }

    @Override
    public LineChartVO lineChartData(CcuExpireRecordPageQuery query) {
        LineChartVO lineChartData = new LineChartVO();

        String dateFormat = "MM-dd";
        List<DateTime> dateList = DateUtil.rangeToList(query.getStartTime(), query.getEndTime(), DateField.DAY_OF_MONTH, 1);
        List<String> xAxisData = new ArrayList<>();
        List<Double> data = new ArrayList<>();

        query.setPageSize(-1);
        List<CcuExpireRecordVO> expireRecordList = listQualityCcuExpireRecordPage(query).getRecords();
        Map<String, List<CcuExpireRecordVO>> expireDateGroup = expireRecordList.stream().collect(Collectors.groupingBy(CcuExpireRecordVO::getExpireDate));

        // 遍历时间区间，查询数据质量记录数量
        for (DateTime date : dateList) {
            xAxisData.add(DateUtil.format(date, dateFormat));
            String dateStr = DateUtil.format(date, DatePattern.PURE_DATE_PATTERN);
            int dateSize = 0;
            if (expireDateGroup.containsKey(dateStr)) {
                dateSize = expireDateGroup.get(dateStr).size();
            }
            data.add((double) dateSize);
        }

        lineChartData.setXAxisData(xAxisData);
        lineChartData.setData(data);
        return lineChartData;
    }

    @Override
    public EventCountTableVO tableData(CcuExpireRecordPageQuery query) {
        EventCountTableVO eventCountTableVO = new EventCountTableVO();
        // 设置分页
        Page<Map<String, Object>> page = new Page<>(query.getPageNum(), query.getPageSize());
        eventCountTableVO.setPageData(page);
        if (CollectionUtil.isNotEmpty(query.getOrders())) {
            page.addOrder(query.getOrders());
        } else {
            page.addOrder(OrderItem.desc("sum"));
        }
        // 获取分页查询结果
        List<Map<String, Object>> tableRecordPage = this.baseMapper.pageOverviewTable(page, query);
        page.setRecords(tableRecordPage);

        String dateFormat = "MM-dd";
        List<DateTime> dateList = DateUtil.rangeToList(query.getStartTime(), query.getEndTime(), DateField.DAY_OF_MONTH, 1);
        // 动态日期标题
        List<String> titles = new ArrayList<>();
        eventCountTableVO.setTitles(titles);

        // 设置分页
        query.setPageSize(-1);
        List<CcuExpireRecordVO> expireRecordList = listQualityCcuExpireRecordPage(query).getRecords();
        Map<String, List<CcuExpireRecordVO>> expireDateGroup = expireRecordList.stream().collect(Collectors.groupingBy(CcuExpireRecordVO::getCcuId));

        // 添加动态表头
        dateList.forEach(date -> titles.add(DateUtil.format(date, dateFormat)));

        // 按车辆赋值每个时间区间的数据质量时间总数
        for (Map<String, Object> pageMap : tableRecordPage) {
            List<CcuExpireRecordVO> yLabelList = expireDateGroup.get((String) pageMap.get("ccuId"));
            if (CollectionUtil.isNotEmpty(yLabelList)) {
                Map<String, CcuExpireRecordVO> subCellMap = yLabelList.stream().collect(Collectors.toMap(e -> String.format("%s-%s", e.getExpireDate().substring(4, 6),
                        e.getExpireDate().substring(6, 8)), e -> e, (k1, k2) -> k1));
                pageMap.putAll(subCellMap);
            }
        }

        return eventCountTableVO;
    }

    @Override
    public void solve(CcuExpireRecordForm ccuExpireForm) {
        LambdaUpdateWrapper<CcuExpireRecord> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(CcuExpireRecord::getAnalysis, ccuExpireForm.getAnalysis());
        updateWrapper.set(CcuExpireRecord::getSolution, ccuExpireForm.getSolution());
        updateWrapper.set(CcuExpireRecord::getUserId, UserUtils.getUserId());
        updateWrapper.set(CcuExpireRecord::getSolveStatus, 1);
        updateWrapper.in(CcuExpireRecord::getId, ccuExpireForm.getIdList());
        this.update(updateWrapper);
    }

    @Override
    public CcuExpireSummaryCardVO getSummaryCard(CcuExpireRecordPageQuery query) {
        CcuExpireSummaryCardVO summaryCardVO = new CcuExpireSummaryCardVO();
        query.setExpireType(1);
        long doubtNumber = this.baseMapper.getSummaryCardInfo(query);
        summaryCardVO.setDoubtCcu(doubtNumber);

        query.setExpireType(2);
        long confirmNumber = this.baseMapper.getSummaryCardInfo(query);
        summaryCardVO.setConfirmCcu(confirmNumber);
        return summaryCardVO;
    }

    @Override
    public List<CcuExpireRecordStatisticVO> statistics(List<Long> projectIdList, Date startTime, Date endTime) {
        return getBaseMapper().statistics(projectIdList, startTime, endTime);
    }

    @Override
    public CcuExpireRecordVO queryById(Long id) {
        if (id == null || id <= 0) {
            return null;
        }
        CcuExpireRecordVO ccuExpireRecordVO = this.getBaseMapper().queryById(id);
        if (ccuExpireRecordVO != null) {
            dealPageShowLabel(ccuExpireRecordVO);
        }
        return ccuExpireRecordVO;
    }
}

