package com.bosch.rbcd.quality.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.bosch.rbcd.common.base.BaseEntity;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;
import java.util.Objects;

/**
 * GPS数据质量事件记录(3、4)(QualityGpsLoss)实体类
 *
 * @author wang bo
 * @since 2023-05-11 11:10:28
 */
@Data
@Accessors(chain=true)
@TableName("quality_gps_loss")
public class GpsLoss extends BaseEntity {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 当时的项目id
     */
    private Long projectId;

    /**
     * 当时的车辆id
     */
    private Long vehicleId;

    private String ccuId;

    /**
     * 当时的软件版本
     */
    private String softwareVersion;

    /**
     * 检测窗口开始时间
     */
    private Date startTime;

    /**
     * 检测窗口结束时间
     */
    private Date endTime;

    /**
     * 0:有GPS无数据；1：无GPS有数据
     */
    private Long type;

    /**
     * 处理人id
     */
    private Long handlerId;

    /**
     * 问题分类，0-应用问题, 1-软件问题, 2-硬件问题
     */
    private Integer reasonType;

    /**
     * 原因分析
     */
    private String causeAnalysis;

    /**
     * 解决状态 0-待处理 1-已处理
     */
    private Integer solveStatus;

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        GpsLoss gpsLoss = (GpsLoss) o;
        return Objects.equals(projectId, gpsLoss.projectId) && Objects.equals(vehicleId, gpsLoss.vehicleId) && Objects.equals(ccuId, gpsLoss.ccuId) && Objects.equals(softwareVersion, gpsLoss.softwareVersion) && Objects.equals(startTime, gpsLoss.startTime) && Objects.equals(endTime, gpsLoss.endTime) && Objects.equals(type, gpsLoss.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectId, vehicleId, ccuId, softwareVersion, startTime, endTime, type);
    }
}
