package com.bosch.rbcd.quality.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.quality.mapper.UserNoticeMapper;
import com.bosch.rbcd.quality.pojo.entity.UserNotice;
import com.bosch.rbcd.quality.pojo.query.UserNoticeQuery;
import com.bosch.rbcd.quality.pojo.vo.UserNoticeVO;
import com.bosch.rbcd.quality.service.UserNoticeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class UserNoticeServiceImpl extends ServiceImpl<UserNoticeMapper, UserNotice> implements UserNoticeService {

    @Override
    public IPage<UserNoticeVO> query(UserNoticeQuery query) {
        IPage<UserNoticeVO> ipage = new Page<>(query.getPageNum(), query.getPageSize());
        return getBaseMapper().pageQuery(ipage, query);
    }

    @Override
    public Long saveOrUpdateUserNotice(UserNoticeVO vo) {
        if (vo == null){
            return null;
        }
        if (vo.getProjectId() == null || vo.getUserId() == null){
            return vo.getId();
        }

        UserNotice po = new UserNotice();
        po.setProjectId(vo.getProjectId());
        po.setUserId(vo.getUserId());
        po.setSendEmail(vo.getSendEmail());
        if (vo.getSendEmail() != null && vo.getSendEmail()) {
            po.setCcuExpire(vo.getCcuExpire());
            po.setDataLoss(vo.getDataLoss());
            po.setGpsLoss(vo.getGpsLoss());
        } else {
            po.setCcuExpire(false);
            po.setDataLoss(false);
            po.setGpsLoss(false);
        }

        Long id = null;
        if (vo.getId() == null) {
            this.save(po);
            id = po.getId();
        } else {
            po.setId(vo.getId());
            this.updateById(po);
            id = vo.getId();
        }

        return id;
    }
}
