package com.bosch.rbcd.quality.controller;



import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.quality.pojo.form.BatchSolveRecordForm;
import com.bosch.rbcd.quality.pojo.query.GpsLossPageQuery;
import com.bosch.rbcd.quality.pojo.vo.GpsLossVO;
import com.bosch.rbcd.quality.service.GpsLossService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

/**
 * GPS数据质量事件记录(3、4)(QualityGpsLoss)表控制层
 *
 * @author wang bo
 * @since 2023-05-11 11:10:28
 */
@Api(tags = "定位丢失")
@RestController
@RequestMapping("/gpsLoss")
@RequiredArgsConstructor
public class GpsLossController {

    private final GpsLossService gpsLossService;

    private final ProjectFeignClient projectFeignClient;

    @ApiOperation(value = "分页查询")
    @PostMapping("/page")
    public PageResult<GpsLossVO> page(@RequestBody GpsLossPageQuery query) {
        List<Long> projectIdList = checkTimeAndGetProjectIdList(query);
        if (CollectionUtils.isEmpty(projectIdList)) {
            return PageResult.success(new Page<>());
        }
        query.setProjectIdList(projectIdList);
        IPage<GpsLossVO> result = gpsLossService.pageQuery(query);
        return PageResult.success(result);
    }

    @ApiOperation(value = "详情")
    @GetMapping("/detail")
    public Result<GpsLossVO> detail(@RequestParam Long id) {
        return Result.success(gpsLossService.detail(id));
    }

    @ApiOperation(value = "分析处理事件")
    @PostMapping("/solve")
    public Result<Void> solve(@RequestBody @Validated BatchSolveRecordForm batchSolveRecordForm) {
        gpsLossService.solve(batchSolveRecordForm);
        return Result.success();
    }

    private List<Long> checkTimeAndGetProjectIdList(GpsLossPageQuery query) {
        if (query.getStartTime() == null || query.getEndTime() == null || query.getStartTime().after(query.getEndTime())) {
            throw new BizException("请选择有效时间范围");
        }

        List<Long> projectIdList = null;
        if (query.getProjectId() == null) {
            projectIdList = projectFeignClient.queryAllAuthorityProjectId(UserUtils.getUserId()).getData();
        } else {
            projectIdList = Collections.singletonList(query.getProjectId());
        }

        return projectIdList;
    }
}

