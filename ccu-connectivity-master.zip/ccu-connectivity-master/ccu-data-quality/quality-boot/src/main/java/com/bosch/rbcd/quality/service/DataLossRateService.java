package com.bosch.rbcd.quality.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.quality.pojo.entity.DataLossRate;
import com.bosch.rbcd.quality.pojo.query.DataLossRateQuery;

public interface DataLossRateService extends IService<DataLossRate> {

    Double getAverageRate(DataLossRateQuery queryParams);

}
