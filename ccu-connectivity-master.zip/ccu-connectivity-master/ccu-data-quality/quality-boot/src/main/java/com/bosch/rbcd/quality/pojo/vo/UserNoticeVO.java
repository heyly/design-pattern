package com.bosch.rbcd.quality.pojo.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@ApiModel("数据质量用户权限")
public class UserNoticeVO {

    @ApiModelProperty("主键id，不存在则为新增，存在这位更新")
    private Long id;

    @ApiModelProperty(value = "项目id", required = true)
    @NotNull(message = "请选择项目")
    private Long projectId;

    @ApiModelProperty(value = "用户id", required = true)
    @NotNull(message = "请选择用户")
    private Long userId;

    @ApiModelProperty("用户名")
    private String username;

    @ApiModelProperty("是否发送邮件")
    private Boolean sendEmail;

    @ApiModelProperty("发送邮件 - 设备失效")
    private Boolean ccuExpire;

    @ApiModelProperty("发送邮件 - 里程丢失")
    private Boolean dataLoss;

    @ApiModelProperty("发送邮件 - GPS失效")
    private Boolean gpsLoss;
}
