package com.bosch.rbcd.quality.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.quality.pojo.entity.DataLossRate;
import com.bosch.rbcd.quality.pojo.query.DataLossRateQuery;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface DataLossRateMapper extends BaseMapper<DataLossRate> {

    Double getAverageRate(@Param( "pageQuery" ) DataLossRateQuery queryParams);

}
