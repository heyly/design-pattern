package com.bosch.rbcd.quality.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.common.web.vo.echarts.LineChartVO;
import com.bosch.rbcd.common.web.vo.echarts.PieChartVO;
import com.bosch.rbcd.quality.pojo.entity.CcuExpireRecord;
import com.bosch.rbcd.quality.pojo.form.CcuExpireRecordForm;
import com.bosch.rbcd.quality.pojo.query.CcuExpireRecordPageQuery;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireRecordStatisticVO;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireRecordVO;
import com.bosch.rbcd.quality.pojo.vo.CcuExpireSummaryCardVO;
import com.bosch.rbcd.quality.pojo.vo.EventCountTableVO;
import org.apache.poi.ss.usermodel.Workbook;

import java.util.Date;
import java.util.List;

/**
 * 数据质量-ccu失效记录(QualityCcuExpireRecord)表服务接口
 *
 * @author wang bo
 * @since 2023-12-12 16:22:01
 */
public interface CcuExpireRecordService extends IService<CcuExpireRecord> {

    /**
     * QualityCcuExpireRecord 分页列表
     *
     * @param: queryParams 分页查询条件
     * @return: IPage<QualityCcuExpireRecordVO>
     * @author: wang bo
     * @date: 2023-12-12 16:22:01
     */
    Page<CcuExpireRecordVO> listQualityCcuExpireRecordPage(CcuExpireRecordPageQuery queryParams);

    Workbook generateExpireExcel(CcuExpireRecordPageQuery query);

    PieChartVO topVehiclePie(CcuExpireRecordPageQuery query);

    LineChartVO lineChartData(CcuExpireRecordPageQuery query);

    EventCountTableVO tableData(CcuExpireRecordPageQuery query);

    void solve(CcuExpireRecordForm qualityCcuExpireRecordForm);

    CcuExpireSummaryCardVO getSummaryCard(CcuExpireRecordPageQuery query);

    List<CcuExpireRecordStatisticVO> statistics(List<Long> projectIdList, Date startTime, Date endTime);

    CcuExpireRecordVO queryById(Long id);
}

