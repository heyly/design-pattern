package com.bosch.rbcd.quality.pojo.vo;

import cn.afterturn.easypoi.excel.annotation.Excel;
import cn.afterturn.easypoi.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 数据质量事件记录信息表(QualityEventRecord)视图对象
 *
 * @author wang bo
 * @since 2023-04-27 11:20:56
 */
@ApiModel("数据质量事件记录信息表视图对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class QualityEventRecordVO {

    @ApiModelProperty("主键")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private Long id;

    @ApiModelProperty("数据事件类型")
    @ExcelIgnore
    @ExcelProperty("数据事件类型-编号")
    private Integer eventType;

    @ApiModelProperty("数据事件类型")
    @Excel(name = "事件类型", width = 20)
    @ExcelProperty("数据事件类型")
    private String eventName;

    @ApiModelProperty("事件记录主键")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private Long eventId;

    @ApiModelProperty("ccu状态")
    @Excel(name = "ccu状态", width = 10)
    @ExcelProperty("ccu状态")
    private Integer ccuStatus;

    @ApiModelProperty("gps状态")
    @Excel(name = "gps状态", width = 10)
    @ExcelProperty("gps状态")
    private Integer gpsStatus;

    @ApiModelProperty("mqtt链路状态")
    @Excel(name = "mqtt链路状态", width = 10)
    @ExcelProperty("mqtt链路状态")
    private Integer mqttStatus;

    @ApiModelProperty("事件发生时间")
    @Excel(name = "事件发生时间", format = "yyyy-MM-dd HH:mm:ss",width = 30)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    @ExcelProperty("事件发生时间")
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    private Date occurTime;

    @ApiModelProperty("事件完成时间")
    @Excel(name = "事件完成时间", format = "yyyy-MM-dd HH:mm:ss",width = 30)
    @ExcelProperty("事件完成时间")
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    private Date finishTime;

    @ApiModelProperty("问题类型")
    @Excel(name = "问题类型", replace = {"应用问题_0", "软件问题_1", "硬件问题_2"}, width = 30)
    @com.alibaba.excel.annotation.ExcelIgnore
    private Integer reasonType;

    @ApiModelProperty("原因分析")
    @Excel(name = "原因分析", width = 30)
    @com.alibaba.excel.annotation.ExcelIgnore
    private String causeAnalysis;

    @ApiModelProperty("解决状态")
    @Excel(name = "解决状态", width = 10)
    @com.alibaba.excel.annotation.ExcelIgnore
    private String solveStatus;

    @ApiModelProperty("责任人，逗号分隔")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private String personInCharge;

    @ApiModelProperty("处理人Id")
    @ExcelIgnore
    @com.alibaba.excel.annotation.ExcelIgnore
    private Long handlerId;

    @ApiModelProperty("处理人")
    @Excel(name = "处理人", width = 10)
    @com.alibaba.excel.annotation.ExcelIgnore
    private String handlerName;

    @ApiModelProperty("创建时间")
    @ExcelIgnore
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    @com.alibaba.excel.annotation.ExcelIgnore
    private Date createTime;

    @ApiModelProperty("更新时间")
    @ExcelIgnore
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    @com.alibaba.excel.annotation.ExcelIgnore
    private Date updateTime;

    @ExcelIgnore
    @ApiModelProperty("log-日志文件名称")
    @com.alibaba.excel.annotation.ExcelIgnore
    private String logFilename;

    @ExcelIgnore
    @ApiModelProperty("log-obs路径，默认obs桶：obs://rbcd-filestorage/")
    @com.alibaba.excel.annotation.ExcelIgnore
    private String logObsPath;

    @ExcelIgnore
    @ApiModelProperty(value = "log-日志状态", example = "0:已下发 1:待上线 2:已接收 3:已上传 4:已超时")
    @com.alibaba.excel.annotation.ExcelIgnore
    private String logStatus;

    /**
     * 项目id
     * @since 2023-09-01
     */
    @ApiModelProperty("项目id")
    @Excel(name = "项目id", width = 30)
    @ExcelProperty("项目id")
    private Long projectId;

    /**
     * ccu_id
     * @since 2023-09-01
     */
    @ApiModelProperty("ccu_id")
    @Excel(name = "ccu_id", width = 30)
    @ExcelProperty("ccu_id")
    private String ccuId;

    /**
     * ccu编号
     * @since 2023-09-01
     */
    @ApiModelProperty("ccu编号")
    @Excel(name = "ccu编号", width = 30)
    @ExcelProperty("ccu编号")
    private String ccuNo;

    @ApiModelProperty("ccu的软件版本")
    @Excel(name = "ccu的软件版本", width = 30)
    @ExcelProperty("ccu的软件版本")
    private String softwareVersion;

}
