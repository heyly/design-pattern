package com.bosch.rbcd.quality.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.Date;

@Data
@TableName("quality_loss_rate")
@ApiModel("数据丢失记录")
public class DataLossRate {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 当时的项目id
     */
    private Long projectId;

    /**
     * 当时的车辆id
     */
    private Long vehicleId;

    private String ccuId;

    /**
     * 丢失率
     */
    private Double rate;

    /**
     * 日期
     */
    private Date countDay;

}
