package com.bosch.rbcd.quality.pojo.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@ApiModel("ccu运行情况")
@Data
public class CcuRunStatisticVO {

    @ApiModelProperty("CCU状态记录")
    private List<CcuStatusStatisticVO> ccuStatusStatisticVOList;

    @ApiModelProperty("CAN问题")
    private long canErrorNum;

    @ApiModelProperty("CCU软件问题")
    private long ccuSoftwareErrorNum;

    @ApiModelProperty("Cloud链路问题")
    private long cloudErrorNum;
}
