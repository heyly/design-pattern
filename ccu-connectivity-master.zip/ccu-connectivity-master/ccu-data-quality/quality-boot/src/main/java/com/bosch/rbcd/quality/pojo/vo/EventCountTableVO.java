package com.bosch.rbcd.quality.pojo.vo;

import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname EventCountTableVO
 * @description TODO
 * @date 2023/5/9 11:44
 */
@Data
@ApiModel("数据质量事件数量表格")
@AllArgsConstructor
@NoArgsConstructor
public class EventCountTableVO {
    @ApiModelProperty("动态表格列名")
    List<String> titles ;

    @ApiModelProperty("动态表格数据")
    IPage<Map<String,Object>> pageData;
}
