package com.bosch.rbcd.quality.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.quality.mapper.DataLossMapper;
import com.bosch.rbcd.quality.pojo.entity.DataLoss;
import com.bosch.rbcd.quality.pojo.form.BatchSolveRecordForm;
import com.bosch.rbcd.quality.pojo.query.DataLossQuery;
import com.bosch.rbcd.quality.pojo.vo.DataLossVO;
import com.bosch.rbcd.quality.service.DataLossService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
public class DataLossServiceImpl extends ServiceImpl<DataLossMapper, DataLoss> implements DataLossService {

    @Override
    public IPage<DataLossVO> pageQuery(DataLossQuery dataLossQuery) {
        Page<DataLossVO> page = new Page<>(dataLossQuery.getPageNum(), dataLossQuery.getPageSize());
        if (CollectionUtils.isNotEmpty(dataLossQuery.getOrders())) {
            page.setOrders(dataLossQuery.getOrders());
        } else {
            OrderItem orderItem = OrderItem.asc("qdl.now_sec_time");
            List<OrderItem> orders = Collections.singletonList(orderItem);
            page.setOrders(orders);
        }

        return getBaseMapper().pageQuery(page, dataLossQuery);
    }

    @Override
    public Long countLostMileage(DataLossQuery dataLossQuery) {
        Long lostMileage = getBaseMapper().countLostMileage(dataLossQuery);
        return lostMileage == null ? 0 : lostMileage;
    }

    @Override
    public Long countLostDevice(DataLossQuery dataLossQuery) {
        Long lostDevice = getBaseMapper().countLostDevice(dataLossQuery);
        return lostDevice == null ? 0 : lostDevice;
    }

    @Override
    public Long countLostEvent(DataLossQuery dataLossQuery) {
        Long lostEvent = getBaseMapper().countLostEvent(dataLossQuery);
        return lostEvent == null ? 0 : lostEvent;
    }

    @Override
    public DataLossVO detail(Long id) {
        if (id == null || id <= 0) {
            return null;
        }
        return getBaseMapper().detail(id);
    }

    @Override
    public void solve(BatchSolveRecordForm form) {
        if (CollectionUtils.isEmpty(form.getIdList())) {
            return;
        }

        LambdaUpdateWrapper<DataLoss> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(DataLoss::getReasonType, form.getReasonType());
        updateWrapper.set(DataLoss::getCauseAnalysis, form.getCauseAnalysis());
        updateWrapper.set(DataLoss::getSolveStatus, 1);
        updateWrapper.set(DataLoss::getHandlerId, UserUtils.getUserId());
        updateWrapper.set(DataLoss::getUpdateTime, new Date());
        updateWrapper.in(DataLoss::getId, form.getIdList());
        this.update(updateWrapper);
    }
}
