package com.bosch.rbcd.quality.pojo.vo;

import com.bosch.rbcd.common.base.BaseEntity;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * GPS数据质量事件记录(3、4)(QualityGpsLoss)视图对象
 *
 * @author wang bo
 * @since 2023-05-11 11:10:28
 */
@ApiModel("定位丢失")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GpsLossVO extends BaseEntity {

    @ApiModelProperty("主键id")
    private Long id;

    @ApiModelProperty("当时的项目id")
    private Long projectId;

    @ApiModelProperty("当时的项目名字")
    private String projectName;

    /**
     * 当时的车辆id
     */
    @ApiModelProperty("当时的车辆id")
    private Long vehicleId;

    @ApiModelProperty("当时的车辆VIN")
    private String vin;

    @ApiModelProperty("ccuId")
    private String ccuId;

    @ApiModelProperty("当时的软件版本")
    private String softwareVersion;

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("sn")
    private String sn;

    @ApiModelProperty("shortSn")
    private String shortSn;

    @ApiModelProperty(value = "类型，0:有GPS无数据；1：无GPS有数据", hidden = true)
    private Long type;

    @ApiModelProperty("检测窗口开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Shanghai")
    private Date startTime;

    @ApiModelProperty("检测窗口结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Shanghai")
    private Date endTime;

    @ApiModelProperty("处理人id")
    private Long handlerId;

    @ApiModelProperty("处理人名字")
    private String handlerName;

    /**
     * 问题分类，0-应用问题, 1-软件问题, 2-硬件问题
     */
    @ApiModelProperty("问题分类，0-应用问题, 1-软件问题, 2-硬件问题")
    private Integer reasonType;

    /**
     * 原因分析
     */
    @ApiModelProperty("原因分析")
    private String causeAnalysis;

    /**
     * 解决状态 0-待处理 1-已处理
     */
    @ApiModelProperty("解决状态 0-待处理 1-已处理")
    private Integer solveStatus;
}
