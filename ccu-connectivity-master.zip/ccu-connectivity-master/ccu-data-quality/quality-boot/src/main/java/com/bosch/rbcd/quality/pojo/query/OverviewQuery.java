package com.bosch.rbcd.quality.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class OverviewQuery extends BasePageQuery {

    @ApiParam("项目id，不传就查全部")
    private Long projectId;

    @ApiParam(hidden = true)
    private List<Long> projectIdList;

    @ApiParam("失效原因code，绘图的时候用，不填查全部，CAN问题：Can_Line_Expire，CCU软件问题：CCU_SW_Expire，Cloud链路问题：RBCD_CLOUD_EXPIRE")
    private String expireCode;
}
