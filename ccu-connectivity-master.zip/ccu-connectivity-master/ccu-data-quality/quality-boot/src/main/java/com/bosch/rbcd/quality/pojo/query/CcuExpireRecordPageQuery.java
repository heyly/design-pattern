package com.bosch.rbcd.quality.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * 数据质量-ccu失效记录(QualityCcuExpireRecord)分页查询对象
 *
 * @author wang bo
 * @since 2023-12-12 16:22:01
 */
@ApiModel("数据质量-ccu失效记录分页查询对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CcuExpireRecordPageQuery extends BasePageQuery {

    @ApiModelProperty("主键，唯一标识")
    private Long id;

    @ApiModelProperty("项目id列表")
    private List<Long> projectIdList;

    @ApiModelProperty("ccuId")
    private String ccuId;

//    @ApiModelProperty("ccu 标识")
//    private String ccuNo;

    @ApiModelProperty("长运行车辆标志，0_非常运行，1_常运行")
    private Integer regularFlag;

    @ApiModelProperty("失效日期")
    private String expireDate;

    @ApiModelProperty("失效流程节点")
    private String flowNode;

    @ApiModelProperty("失效等级 1_疑似失效 2_确认失效")
    private Integer expireType;

    @ApiModelProperty("失效类型code")
    private String expireCode;

    @ApiModelProperty("处理状态")
    private Integer solveStatus;

    @ApiModelProperty("车辆别名")
    private String vehicleName;

    @ApiModelProperty("车架号")
    private String vin;

    @ApiModelProperty("IMEI")
    private String imei;

    @ApiModelProperty("软件版本")
    private String softwareVersion;

    @ApiModelProperty("发动机编号")
    private String engineNo;

    @ApiModelProperty("ccu sn")
    private String sn;

    @ApiModelProperty("硬件类型id")
    private Long hardwareTypeId;

}
