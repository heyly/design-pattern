package com.bosch.rbcd.quality.pojo.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("数据丢失统计信息")
public class DataLossStatisticVO {

    @ApiModelProperty("数据丢失设备")
    private long lostDeviceCount;

    @ApiModelProperty("丢失总里程数（单位公里）")
    private long lostMileageCount;

    @ApiModelProperty("平均丢包率")
    private double lossRate;

    @ApiModelProperty("数据丢失事件")
    private long lostEventCount;
}
