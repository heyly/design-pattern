package com.bosch.rbcd.quality.pojo.form;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 数据质量-ccu失效记录(QualityCcuExpireRecord)实体类
 *
 * @author wang bo
 * @since 2023-12-12 16:22:01
 */
@ApiModel("数据质量-ccu失效记录提交表单")
@Data
@Accessors(chain = true)
public class CcuExpireRecordForm {

    @ApiModelProperty(value = "ccu失效记录id列表", required = true)
    @NotEmpty(message = "请选择失效记录")
    private List<Long> idList;

    @ApiModelProperty("问题分析")
    @NotBlank(message = "请填写问题分析")
    private String analysis;

    @ApiModelProperty("处理方式")
    @NotBlank(message = "请填写处理方式")
    private String solution;

}
