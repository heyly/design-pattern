package com.bosch.rbcd.quality.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.quality.pojo.entity.DataLoss;
import com.bosch.rbcd.quality.pojo.form.BatchSolveRecordForm;
import com.bosch.rbcd.quality.pojo.query.DataLossQuery;
import com.bosch.rbcd.quality.pojo.vo.DataLossVO;

public interface DataLossService extends IService<DataLoss> {

    IPage<DataLossVO> pageQuery(DataLossQuery dataLossQuery);

    Long countLostMileage(DataLossQuery dataLossQuery);

    Long countLostDevice(DataLossQuery dataLossQuery);

    Long countLostEvent(DataLossQuery dataLossQuery);

    DataLossVO detail(Long id);

    void solve(BatchSolveRecordForm batchSolveRecordForm);
}
