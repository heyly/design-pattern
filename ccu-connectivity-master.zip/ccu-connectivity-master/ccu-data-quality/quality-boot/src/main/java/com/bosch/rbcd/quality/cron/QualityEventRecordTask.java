//package com.bosch.rbcd.quality.cron;
//
//import cn.hutool.core.date.DateTime;
//import cn.hutool.core.date.DateUtil;
//import com.alibaba.fastjson.JSON;
//import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
//import com.bosch.rbcd.common.result.PageResult;
//import com.bosch.rbcd.common.result.Result;
//import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
//import com.bosch.rbcd.device2.api.DeviceLogFeignClient;
//import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
//import com.bosch.rbcd.device2.query.DeviceSelfCheckQuery;
//import com.bosch.rbcd.device2.vo.DeviceSelfCheckVO;
//import com.bosch.rbcd.quality.enums.ExpireCodeEnum;
//import com.bosch.rbcd.quality.pojo.entity.CcuSelfCheckConfig;
//import com.bosch.rbcd.quality.pojo.entity.DataLoss;
//import com.bosch.rbcd.quality.service.CcuSelfCheckConfigService;
//import com.bosch.rbcd.quality.service.DataLossService;
//import com.xxl.job.core.handler.annotation.XxlJob;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.collections4.CollectionUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.stereotype.Service;
//
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.List;
//
//@Service
//@Slf4j
//@RequiredArgsConstructor
//public class QualityEventRecordTask {
//
//    private final QualityEventRecordService qualityEventRecordService;
//    private final DeviceLogFeignClient ccuDeviceLogFeignClient;
//    private final DataLossService dataLossService;
//    private final DeviceInfoFeignClient deviceInfoFeignClient;
//    private final CcuSelfCheckConfigService ccuSelfCheckConfigService;
//
//    /**
//     * 读取 quality_event_record 表，查询前一天的异常事件，要求ccu，重发数据
//     * 每天 3:00 am 执行一次
//     */
//    public void requestDeviceLog() {
//        Calendar calendar = Calendar.getInstance();
//        calendar.set(Calendar.HOUR_OF_DAY, 0);
//        calendar.clear(Calendar.MINUTE);
//        calendar.clear(Calendar.SECOND);
//        calendar.clear(Calendar.MILLISECOND);
//        Date today = calendar.getTime();
//        calendar.add(Calendar.DAY_OF_MONTH, -1);
//        Date yesterday = calendar.getTime();
//
//        List<String> ccuIdList = qualityEventRecordService.queryDistinctCcuIdByTime(yesterday, today);
//        if (CollectionUtils.isEmpty(ccuIdList)) {
//            return;
//        }
//        List<String> failCcuList = new ArrayList<>();
//        for (String ccuId : ccuIdList) {
//            Result<?> feignResult = ccuDeviceLogFeignClient.requestDeviceLog(ccuId, "ccu-data-quality", yesterday.getTime());
//            if (!Result.isSuccess(feignResult)) {
//                failCcuList.add(ccuId);
//            }
//        }
//        if (CollectionUtils.isNotEmpty(failCcuList)) {
//            log.error("requestDeviceLog 执行部分失败！车辆列表：" + JSON.toJSONString(failCcuList));
//        }
//    }
//
//
//    @XxlJob("dailySelfCheckDateLoss")
//    public void dailySelfCheckDateLoss() {
//        DateTime yesterday = DateUtil.yesterday();
//
//        LambdaQueryWrapper<DataLoss> dataLossQuery = new LambdaQueryWrapper<>();
//        dataLossQuery.between(DataLoss::getNowSecTime, DateUtil.beginOfDay(yesterday), DateUtil.endOfDay(yesterday));
//
//        List<DataLoss> dataLossList = dataLossService.list(dataLossQuery);
//        if (CollectionUtils.isEmpty(dataLossList)) {
//            return;
//        }
//
//        for (DataLoss dataLoss : dataLossList) {
//            ProjectVehicleCcuDTO ccuDevice = deviceInfoFeignClient.findByCcuId(dataLoss.getCcuId()).getData();
//
//            // 获取自诊断错误码Tree
//            List<DeviceSelfCheckVO> deviceSelfCheckVOList = new ArrayList<>();
//            DeviceSelfCheckQuery deviceSelfCheckQuery = new DeviceSelfCheckQuery();
//            deviceSelfCheckQuery.setImei(ccuDevice.getImei());
//            deviceSelfCheckQuery.setStartTime(dataLoss.getLastSecTime());
//            deviceSelfCheckQuery.setEndTime(dataLoss.getNowSecTime());
//            deviceSelfCheckQuery.setPageSize(50);
//            for (int pageNum = 1; ; pageNum++) {
//                deviceSelfCheckQuery.setPageNum(pageNum);
//                PageResult<DeviceSelfCheckVO> pageResult = deviceInfoFeignClient.pageSelfCheckRecord(deviceSelfCheckQuery);
//                if (pageResult == null || pageResult.getData() == null || CollectionUtils.isEmpty(pageResult.getData().getList())) {
//                    break;
//                }
//                deviceSelfCheckVOList.addAll(pageResult.getData().getList());
//            }
//
//            if (CollectionUtils.isEmpty(deviceSelfCheckVOList)) {
//                continue;
//            }
//
//            List<String> errorTypeReasonCodes = new ArrayList<>();
//            for (DeviceSelfCheckVO deviceSelfCheckVO : deviceSelfCheckVOList) {
//                if (StringUtils.isNotBlank(deviceSelfCheckVO.getErrorType()) && StringUtils.isNotBlank(deviceSelfCheckVO.getErrorData())) {
//                    errorTypeReasonCodes.add(deviceSelfCheckVO.getErrorType() + deviceSelfCheckVO.getErrorData());
//
//                }
//            }
//
//            if (CollectionUtils.isEmpty(errorTypeReasonCodes)) {
//                continue;
//            }
//
//            // 获取错误级别最高的自诊断信息
//            CcuSelfCheckConfig ccuSelfCheckConfig = ccuSelfCheckConfigService.getErrorCheckInfo(errorTypeReasonCodes);
//            String errorType = ccuSelfCheckConfig != null ? ccuSelfCheckConfig.getPriority() : "";
//            boolean needUpdate = false;
//            switch (errorType) {
//                case "":
//                    break;
//                case "A":
//                    needUpdate = true;
//                    dataLoss.setReasonType(0);
//                    dataLoss.setCauseAnalysis(ExpireCodeEnum.CAN_LINE_EXPIRE.getLabel());
//                    break;
//                case "B":
//                    needUpdate = true;
//                    dataLoss.setReasonType(0);
//                    dataLoss.setCauseAnalysis(ExpireCodeEnum.CCU_CONFIG_EXPIRE.getLabel());
//                    break;
//                case "D":
//                    needUpdate = true;
//                    dataLoss.setReasonType(1);
//                    dataLoss.setCauseAnalysis(ExpireCodeEnum.RBCD_CLOUD_EXPIRE.getLabel());
//                    break;
//                default:
//                    // 默认CCU软件失效
//                    needUpdate = true;
//                    dataLoss.setReasonType(1);
//                    dataLoss.setCauseAnalysis(ExpireCodeEnum.CCU_SW_EXPIRE.getLabel());
//                    break;
//            }
//
//            if (needUpdate) {
//                dataLossService.updateById(dataLoss);
//            }
//        }
//
//    }
//
//}
