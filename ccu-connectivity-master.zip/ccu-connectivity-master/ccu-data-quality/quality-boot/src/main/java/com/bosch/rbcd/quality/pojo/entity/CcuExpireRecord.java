package com.bosch.rbcd.quality.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.bosch.rbcd.common.base.BaseEntity;
import com.bosch.rbcd.quality.enums.ExpireCodeEnum;
import com.bosch.rbcd.quality.enums.ExpireJudgeNodeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.ArrayList;
import java.util.List;

/**
 * 数据质量-ccu失效记录(QualityCcuExpireRecord)实体类
 *
 * @author wang bo
 * @since 2023-12-12 16:22:01
 */
@ApiModel("数据质量-ccu失效记录实体类")
@Data
@Accessors(chain=true)
@TableName("quality_ccu_expire_record")
public class CcuExpireRecord extends BaseEntity {

    @ApiModelProperty("主键，唯一标识")
    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("ccu 标识")
    private String ccuId;

    // todo
    private Long vehicleId;

    // todo
    private Long projectId;

    @ApiModelProperty("长运行车辆标志，0_非常运行，1_常运行")
    private Integer regularFlag;


    @ApiModelProperty("失效日期")
    private String expireDate;

    @ApiModelProperty("失效流程节点")
    private String flowNode;

    @TableField(exist = false)
    @ApiModelProperty("失效流程节点列表")
    private List<String> flowNodeList = new ArrayList<>();

    @ApiModelProperty("失效等级 1_CCU疑似失效 2_CCU确认失效 3_Cloud问题")
    private Integer expireType;

    @ApiModelProperty("失效类型code")
    private String expireCode;

    @ApiModelProperty("失效分析")
    private String analysis;

    @ApiModelProperty("解决方案")
    private String solution;

    @ApiModelProperty("解决人id")
    private Long userId;

    @ApiModelProperty("处理状态")
    private Integer solveStatus;

    @ApiModelProperty("软件版本")
    private String softwareVersion;

    /**
     * 添加失效判断节点
     * @param judgeNodeEnum
     */
    public void addFlowNode(ExpireJudgeNodeEnum judgeNodeEnum){
        flowNodeList.add(judgeNodeEnum.getValue());
    }

    public void setExpireCode(ExpireCodeEnum expireCodeEnum) {
        this.expireCode = expireCodeEnum.getValue();
    }
}
