package com.bosch.rbcd.quality.pojo.form;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname BatchSolveRecordVO
 * @description TODO
 * @date 2023/5/12 14:00
 */
@ApiModel("批处理视图层实体")
@Data
public class BatchSolveRecordForm {

    @ApiModelProperty("记录主键列表")
    @NotEmpty(message = "请选择待分析处理的记录")
    private List<Long> IdList;

    @ApiModelProperty("原因分析")
    @NotBlank(message = "请填写原因分析")
    private String causeAnalysis;

    @ApiModelProperty("问题分类，0-应用问题, 1-软件问题, 2-硬件问题")
    @NotNull(message = "请选择问题分类")
    private Integer reasonType;
}
