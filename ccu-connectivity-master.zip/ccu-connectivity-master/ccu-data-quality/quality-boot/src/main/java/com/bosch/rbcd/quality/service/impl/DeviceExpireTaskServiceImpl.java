package com.bosch.rbcd.quality.service.impl;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.bosch.rbcd.common.enums.CcuHardwareTypeEnum;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.data.api.CcuOnlineFeignClient;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import com.bosch.rbcd.device2.dto.SimStatusDTO;
import com.bosch.rbcd.device2.query.DevicePeriodUploadQuery;
import com.bosch.rbcd.device2.query.DeviceSelfCheckQuery;
import com.bosch.rbcd.device2.vo.DevicePeriodUploadVO;
import com.bosch.rbcd.device2.vo.DeviceSelfCheckVO;
import com.bosch.rbcd.fleet.api.VehicleFeignClient;
import com.bosch.rbcd.fleet.dto.ProjectVehicleDeviceDTO;
import com.bosch.rbcd.quality.enums.ExpireCodeEnum;
import com.bosch.rbcd.quality.enums.ExpireJudgeNodeEnum;
import com.bosch.rbcd.quality.pojo.entity.CcuExpireRecord;
import com.bosch.rbcd.quality.pojo.entity.CcuSelfCheckConfig;
import com.bosch.rbcd.quality.service.CcuExpireRecordService;
import com.bosch.rbcd.quality.service.CcuSelfCheckConfigService;
import com.bosch.rbcd.quality.service.DeviceExpireTaskService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.index.query.QueryBuilders;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Stream;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname DeviceExpireTaskServiceImpl
 * @description TODO
 * @date 23/12/11 11:28
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DeviceExpireTaskServiceImpl implements DeviceExpireTaskService {

    private final VehicleFeignClient vehicleFeignClient;

    private final DeviceInfoFeignClient deviceInfoFeignClient;

    private final CcuOnlineFeignClient ccuOnlineFeignClient;

    private final CcuExpireRecordService ccuExpireRecordService;

    private final ElasticsearchRestTemplate elasticsearchRestTemplate;

    private final RedisUtils redisUtils;

    private final CcuSelfCheckConfigService ccuSelfCheckConfigService;

    private static final String TCP_INDEX_NAME = "filebeat-7.10.2-{}";
    private static final String[] REAL_PROTOCOL_LIST = {"06a6", "06c6"};
    private static final String TCP_PROCESS_PHRASE = "IMEI: %s, Handler processor: process%s";

    @Override
    public void detectOneCcuExpire(ProjectVehicleCcuDTO ccuDevice, Date today) {
        // 新建失效记录，默认非失效状态
        CcuExpireRecord ccuExpireRecord = new CcuExpireRecord().setCcuId(ccuDevice.getCcuId())
                .setExpireDate(DateUtil.format(today, DatePattern.PURE_DATE_PATTERN))
                .setExpireType(0).setSoftwareVersion(ccuDevice.getSoftwareVersion());

        ProjectVehicleDeviceDTO projectVehicleDeviceDTO = vehicleFeignClient.queryProjectVehicleDeviceByCcuId(ccuDevice.getCcuId()).getData();
        if (projectVehicleDeviceDTO != null) {
            ccuExpireRecord.setProjectId(projectVehicleDeviceDTO.getProjectId());
            ccuExpireRecord.setVehicleId(projectVehicleDeviceDTO.getVehicleId());
        }

        setCcuRegularFlag(ccuExpireRecord, today);
        // 开始监测CCU失效
        try {
            detectCcuOffline(ccuExpireRecord, ccuDevice, today);
        } catch (Exception e) {
            log.error("发生异常", e);
        }
        // 监测结束，并判断是否为失效情况
        if (ccuExpireRecord.getExpireType() != 0) {
            ccuExpireRecord.setFlowNode(String.join(",", ccuExpireRecord.getFlowNodeList()));
            ccuExpireRecordService.save(ccuExpireRecord);
        }
    }

    /**
     * 监测CCU当天是否离线
     *
     * @param ccuExpireRecord
     * @param ccuDevice
     * @param today
     */
    private void detectCcuOffline(CcuExpireRecord ccuExpireRecord, ProjectVehicleCcuDTO ccuDevice, Date today) {
        // 查询当天CCU是否离线
        boolean ccuOfflineFlag = whetherCcuOffline(ccuDevice.getCcuId(), today, today);
        if (ccuOfflineFlag) {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CCU_ON_F);
            // 根据SIM卡状态路由监测链路
            detectPowerExpire(ccuExpireRecord, ccuDevice, today);
        }
    }

    /**
     * 检测供电失效问题
     *
     * @param ccuExpireRecord
     * @param ccuDevice
     * @param today
     */
    private void detectPowerExpire(CcuExpireRecord ccuExpireRecord, ProjectVehicleCcuDTO ccuDevice, Date today) {

        // 标识硬件类型CCU-S/E
        ExpireJudgeNodeEnum ccuHardwareType = Objects.equals(CcuHardwareTypeEnum.CCU_A.getValue(), ccuDevice.getHardwareTypeId()) ? ExpireJudgeNodeEnum.CCU_A_T :
                ExpireJudgeNodeEnum.CCU_A_F;
        ccuExpireRecord.addFlowNode(ccuHardwareType);

        // SIM卡在线判断电源是否供电
        boolean simOnlineFlag = whetherSimTodayOnline(ccuExpireRecord, today);
        ccuExpireRecord.addFlowNode(simOnlineFlag ? ExpireJudgeNodeEnum.SIM_ON_T : ExpireJudgeNodeEnum.SIM_ON_F);
        // TCP是否连接到Cloud
        boolean tcpConnectFlag = whetherHasTcpLog(ccuDevice.getImei(), today);
        ccuExpireRecord.addFlowNode(tcpConnectFlag ? ExpireJudgeNodeEnum.TCP_LOG_T : ExpireJudgeNodeEnum.TCP_LOG_F);
        // 是否有MQTT消息
        boolean mqttSendFlag = whetherHasMqtt(ccuDevice.getImei(), today);
        ccuExpireRecord.addFlowNode(mqttSendFlag ? ExpireJudgeNodeEnum.MQTT_ON_T : ExpireJudgeNodeEnum.MQTT_ON_F);

        // CCU供电标志，sim卡，tcp，mqtt任一在线
        boolean ccuPowerOnFlag = simOnlineFlag || tcpConnectFlag || mqttSendFlag;

        // 如果设备上电
        if (ccuPowerOnFlag) {
            if (mqttSendFlag) {
                detectMqttExpire(ccuExpireRecord, ccuDevice, today);
            } else if (tcpConnectFlag) {
                detectTcpExpire(ccuExpireRecord, ccuDevice, today);
            } else {
                // 如果是常运行CCU,并且近一周在线过且最近三天没在线，疑似软件问题
                if (whetherRegularDoubtExpire(ccuExpireRecord, today)) {
                    ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CCU_WEEK_ON_T);
                    ccuExpireRecord.setExpireType(1);
                    ccuExpireRecord.setExpireCode(ExpireCodeEnum.DOUBT_SW);
                }
            }
        } else {
            // 如果是常运行CCU,并且近一周在线过且最近三天没在线，疑似供电问题
            if (whetherRegularDoubtExpire(ccuExpireRecord, today)) {
                ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CCU_WEEK_ON_T);
                ccuExpireRecord.setExpireType(1);
                ccuExpireRecord.setExpireCode(ExpireCodeEnum.DOUBT_POWER);
            }
        }
    }


    /**
     * 监测TCP链路是否失效
     *
     * @param ccuExpireRecord
     * @param ccuDevice
     * @param today
     */
    private void detectTcpExpire(CcuExpireRecord ccuExpireRecord, ProjectVehicleCcuDTO ccuDevice, Date today) {
        boolean hasLoginFlag = whetherHasTcpLogin(ccuDevice.getImei(), today);
        // 当天有process0641登陆报文，则监测实时数据。否则判定为CCU软件失效
        if (hasLoginFlag) {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.TCP_LOGIN_T);
            detectRealDataExpire(ccuExpireRecord, ccuDevice, today);
        } else {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.TCP_LOGIN_F);
            ccuExpireRecord.setExpireType(2);
            ccuExpireRecord.setExpireCode(ExpireCodeEnum.CCU_SW_EXPIRE);
        }
    }


    /**
     * 监测CCU实时数据有无失效
     *
     * @param ccuExpireRecord
     * @param ccuDevice
     * @param today
     */
    private void detectRealDataExpire(CcuExpireRecord ccuExpireRecord, ProjectVehicleCcuDTO ccuDevice, Date today) {
        boolean hasRealDataFlag = whetherHasTcpData(ccuDevice.getImei(), today);
        // 有实时数据校验数据采集配置，
        if (hasRealDataFlag) {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.TCP_DATA_T);
            // 校验TCP报文，CCU数据配置与云端缓存的配置长度是否一致
            boolean sameConfigLength = whetherConfigSameLength(ccuDevice.getImei(), today);
            // 长度一致，则说明云端链路问题，否则为CCU侧问题
            if (sameConfigLength) {
                ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CONFIG_CHECK_T);
                ccuExpireRecord.setExpireType(3);
                ccuExpireRecord.setExpireCode(ExpireCodeEnum.RBCD_CLOUD_EXPIRE);
            } else {
                ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CONFIG_CHECK_F);
                ccuExpireRecord.setExpireType(2);
                ccuExpireRecord.setExpireCode(ExpireCodeEnum.CCU_CONFIG_EXPIRE);
            }
        } else {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.TCP_DATA_F);
            //若为CCU-S/E时,校验自诊断报文
            if (!Objects.equals(CcuHardwareTypeEnum.CCU_A.getValue(), ccuDevice.getHardwareTypeId())) {
                detectSelfCheckExpire(ccuExpireRecord, ccuDevice, today);
            }
        }

    }


    /**
     * 监测CCU实时数据有无失效
     *
     * @param ccuExpireRecord
     * @param ccuDevice
     * @param today
     */
    private void detectSelfCheckExpire(CcuExpireRecord ccuExpireRecord, ProjectVehicleCcuDTO ccuDevice, Date today) {

        // 获取自诊断错误码
        List<DeviceSelfCheckVO> deviceSelfCheckVOList = new ArrayList<>();

        DeviceSelfCheckQuery deviceSelfCheckQuery = new DeviceSelfCheckQuery();
        deviceSelfCheckQuery.setStartTime(DateUtil.beginOfDay(today));
        deviceSelfCheckQuery.setEndTime(DateUtil.endOfDay(today));

        for (int pageNum=1, pageSize=50; ; pageNum++) {
            deviceSelfCheckQuery.setPageNum(pageNum);
            deviceSelfCheckQuery.setPageSize(pageSize);
            PageResult<DeviceSelfCheckVO> pageResult = deviceInfoFeignClient.pageSelfCheckRecord(deviceSelfCheckQuery);
            if (pageResult == null || pageResult.getData() == null || CollectionUtils.isEmpty(pageResult.getData().getList())) {
                break;
            }
            deviceSelfCheckVOList.addAll(pageResult.getData().getList());
        }

        if (CollectionUtils.isEmpty(deviceSelfCheckVOList)) {
            return;
        }

        Set<String> errorTypeReasonCodes = new HashSet<>();
        for (DeviceSelfCheckVO deviceSelfCheckVO : deviceSelfCheckVOList) {
            if (StringUtils.isAnyBlank(deviceSelfCheckVO.getErrorType(), deviceSelfCheckVO.getErrorData())) {
                continue;
            }
            errorTypeReasonCodes.add(deviceSelfCheckVO.getErrorType() + deviceSelfCheckVO.getErrorData());
        }

        // 获取错误级别最高的自诊断信息
        CcuSelfCheckConfig ccuSelfCheckConfig = ccuSelfCheckConfigService.getErrorCheckInfo(new ArrayList<>(errorTypeReasonCodes));

//       // 添加自诊断节点
        ccuExpireRecord.addFlowNode(ccuSelfCheckConfig != null ? ExpireJudgeNodeEnum.CCU_CHECK_T : ExpireJudgeNodeEnum.CCU_CHECK_F);
        // 设置失效
        ccuExpireRecord.setExpireType(2);

        String errorType = ccuSelfCheckConfig != null ? ccuSelfCheckConfig.getPriority() : "";
        switch (errorType) {
            case "A":
                ccuExpireRecord.setExpireCode(ExpireCodeEnum.CAN_LINE_EXPIRE);
                break;
            case "B":
                ccuExpireRecord.setExpireCode(ExpireCodeEnum.CCU_CONFIG_EXPIRE);
                break;
            case "D":
                ccuExpireRecord.setExpireCode(ExpireCodeEnum.RBCD_CLOUD_EXPIRE);
                ccuExpireRecord.setExpireType(3);
                break;
            default:
                // 默认CCU软件失效
                ccuExpireRecord.setExpireCode(ExpireCodeEnum.CCU_SW_EXPIRE);
                break;
        }
    }

    /**
     * @Description: 十进制解析十六进制
     * @Param: [value]
     * @return: java.lang.String
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/10/30
     */
    private String getHexKey(String value) {
        String hexValue = "";
        String hexFlag = "0x";
        if (StrUtil.startWithIgnoreCase(value, hexFlag)) {
            hexValue = hexFlag + value.substring(2).toUpperCase();
        } else {
            hexValue = StrUtil.padPre(value.toUpperCase(), 4, hexFlag);
        }
        return hexValue;
    }


    /**
     * 监测CCU-S/E是否失效
     *
     * @param ccuExpireRecord
     * @param ccuDevice
     * @param today
     */
    private void detectMqttExpire(CcuExpireRecord ccuExpireRecord, ProjectVehicleCcuDTO ccuDevice, Date today) {
        // CCU V1.9.0及以上，若无周期状态报文上报，则为软件问题
//        if (StrUtil.compareVersion(ccuDevice.getSoftwareVersion(), CCU_V190_VERSION) > -1) {
//            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CCU_V190_T);
//            boolean hasCcuStatusUp = whetherHasStatusUp(ccuDevice.getCcuId(), today);
//            if (hasCcuStatusUp) {
//                ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CCU_STATUS_T);
//            } else {
//                ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CCU_STATUS_F);
//                ccuExpireRecord.setExpireType(2);
//                ccuExpireRecord.setExpireCode(ExpireCodeEnum.CCU_SW_EXPIRE);
//                return;
//            }
//        } else {
//            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.CCU_V190_F);
//        }

        // 有T15 ON(钥匙上电信号)，否则无法继续推测
        boolean hasT15Flag = whetherHasT15On(ccuDevice.getImei(), today);
        if (hasT15Flag) {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.T15_ON_T);
            // 根据CCU连接Cloud路由监测链路
            routeCloudExpire(ccuExpireRecord, ccuDevice, today);
        } else {
            log.warn("CCU No： {} IMEI: {} 当日无T15 ON消息", ccuDevice.getCcuNo(), ccuDevice.getImei());
        }
    }


    /**
     * 根据CCU连接Cloud路由监测链路
     *
     * @param ccuExpireRecord
     * @param ccuDevice
     * @param today
     */
    private void routeCloudExpire(CcuExpireRecord ccuExpireRecord, ProjectVehicleCcuDTO ccuDevice, Date today) {
        boolean cdCloudFlag = whetherRbcdCloud(ccuDevice.getImei());
        if (cdCloudFlag) {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.HP_CCU_F);
            detectTcpExpire(ccuExpireRecord, ccuDevice, today);
        } else {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.HP_CCU_T);
            detectHpCloudExpire(ccuExpireRecord, ccuDevice, today);
        }
    }

    /**
     * 监测HP链路
     *
     * @param ccuExpireRecord
     * @param ccuDevice
     * @param today
     */
    private void detectHpCloudExpire(CcuExpireRecord ccuExpireRecord, ProjectVehicleCcuDTO ccuDevice, Date today) {
        String hpDateCountHash = StrUtil.format("hp_date_count:{}", DateUtil.format(today, DatePattern.PURE_DATE_PATTERN));
        Map hpDateConutMap = redisUtils.hgetAll(hpDateCountHash);
        // 当天是否有HP数据，若没有则为HP关闭数据转发或者都没上电
        if (MapUtil.isNotEmpty(hpDateConutMap)) {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.HP_KAFKA_OFF_F);
            if (hpDateConutMap.containsKey(ccuDevice.getImei())) {
                ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.HP_DATA_T);
                ccuExpireRecord.setExpireType(2);
                ccuExpireRecord.setExpireCode(ExpireCodeEnum.RBCD_CLOUD_EXPIRE);
            }
        } else {
            ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.HP_KAFKA_OFF_T);
            ccuExpireRecord.setExpireType(1);
            ccuExpireRecord.setExpireCode(ExpireCodeEnum.HP_KAFKA_EXPIRE);
        }
    }

    /**
     * 设置常运行CCU标志
     *
     * @param ccuExpireRecord
     * @param today
     * @return
     */
    private void setCcuRegularFlag(CcuExpireRecord ccuExpireRecord, Date today) {
        ccuExpireRecord.setRegularFlag(0);
        String yearAgo = DateUtil.format(DateUtil.offsetMonth(today, -12), DatePattern.PURE_DATE_PATTERN);
        String monthAgo = DateUtil.format(DateUtil.offsetMonth(today, -1), DatePattern.PURE_DATE_PATTERN);
        String todayStr = DateUtil.format(today, DatePattern.PURE_DATE_PATTERN);
        Integer yearOnlineSum = ccuOnlineFeignClient.judgeOnlineDuringDays(ccuExpireRecord.getCcuId(), yearAgo, todayStr).getData();
        // 常运行CCU: 过去一年在线天数大于12，并且最近一月有上线
        if (yearOnlineSum != null && yearOnlineSum > 12) {
            Integer monthOnlineSum = ccuOnlineFeignClient.judgeOnlineDuringDays(ccuExpireRecord.getCcuId(), monthAgo, todayStr).getData();
            if (monthOnlineSum > 1) {
                ccuExpireRecord.setRegularFlag(1);
            }
        }
    }


    /**
     * 判断指定日期内是否离线
     *
     * @param ccuId
     * @param startDate
     * @param endDate
     * @return
     */
    private boolean whetherCcuOffline(String ccuId, Date startDate, Date endDate) {
        String startDateStr = DateUtil.format(startDate, DatePattern.PURE_DATE_PATTERN);
        String endDateStr = DateUtil.format(endDate, DatePattern.PURE_DATE_PATTERN);
        Integer onlineDays = ccuOnlineFeignClient.judgeOnlineDuringDays(ccuId, startDateStr, endDateStr).getData();
        return onlineDays != null && onlineDays == 0;
    }

    /**
     * 判断当天sim卡是否在线
     *
     * @param ccuExpireRecord
     * @param today
     * @return null时，非无锡移动4G卡，
     */
    private boolean whetherSimTodayOnline(CcuExpireRecord ccuExpireRecord, Date today) {
        boolean onlineFlag = false;
        try {
            SimStatusDTO lastOnlineInfo = deviceInfoFeignClient.simLastOnlineTime(ccuExpireRecord.getCcuId()).getData();
            // 如果Sim信息不为空，则为中国移动无锡4G卡
            if (lastOnlineInfo != null) {
                ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.SIM_4G_T);
                if (StrUtil.isNotBlank(lastOnlineInfo.getCreateDate())) {
                    onlineFlag = DateUtil.isSameDay(today, DateUtil.parse(lastOnlineInfo.getCreateDate()));
                }
            } else {
                ccuExpireRecord.addFlowNode(ExpireJudgeNodeEnum.SIM_4G_F);
            }
        } catch (Exception e) {
            log.error("中移动在线信息查询报错", e);
        }
        return onlineFlag;
    }

    /**
     * 判定常运行ccu是否需要确定为疑似失效
     * @param ccuExpireRecord
     * @param today
     * @return
     */
    private boolean whetherRegularDoubtExpire(CcuExpireRecord ccuExpireRecord, Date today) {
        boolean doubtFlag = false;
        // 常运行车辆
        if (ccuExpireRecord.getRegularFlag() != null && ccuExpireRecord.getRegularFlag() == 1) {
            // 近3天不在线
            boolean day3OfflineFlag = whetherCcuOffline(ccuExpireRecord.getCcuId(), DateUtil.offsetDay(today, -2), today);
            if (day3OfflineFlag) {
                // 过去一周 前四天在线过3次，并且每次数据量大于3600条
                String key = "kafka:vehicle:" + ccuExpireRecord.getCcuId();
                List<DateTime> fourDayList = DateUtil.rangeToList(DateUtil.offsetDay(today, -6), DateUtil.offsetDay(today, -3), DateField.DAY_OF_MONTH);
                long runDayCount = fourDayList.stream().filter(date -> {
                    Integer dateCount = (Integer) redisUtils.hget(key, DateUtil.format(date, DatePattern.NORM_DATE_PATTERN));
                    return dateCount != null && dateCount > 3600;
                }).count();
                doubtFlag = runDayCount > 2;
            }
        }
        return doubtFlag;
    }

    /**
     * TCP当天是否有数据报文
     *
     * @param imei
     * @param today
     * @return
     */
    private boolean whetherHasTcpLog(String imei, Date today) {
        String indexName = StrUtil.format(TCP_INDEX_NAME, DateUtil.format(today, "yyyy.MM.dd"));
        NativeSearchQuery query = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.matchPhraseQuery("message", String.format("IMEI: %s, Handler processor", imei))).build();
        return elasticsearchRestTemplate.count(query, JSONObject.class, IndexCoordinates.of(indexName)) > 0;
    }


    /**
     * TCP当天是否有登陆报文(0641)
     *
     * @param imei
     * @param today
     * @return
     */
    private boolean whetherHasTcpLogin(String imei, Date today) {
        String indexName = StrUtil.format(TCP_INDEX_NAME, DateUtil.format(today, "yyyy.MM.dd"));
        return Stream.of("0641","0643")
                .map(protocol -> String.format(TCP_PROCESS_PHRASE, imei, protocol))
                .map(queryPhrase -> new NativeSearchQueryBuilder()
                        .withQuery(QueryBuilders.matchPhraseQuery("message", queryPhrase)))
                .anyMatch(builder -> elasticsearchRestTemplate.count(builder.build(), JSONObject.class, IndexCoordinates.of(indexName)) > 0);
    }

    /**
     * TCP当天是否有实时数据报文("06a6", "06b6", "06c6", "06d6")
     *
     * @param imei
     * @param today
     * @return
     */
    private boolean whetherHasTcpData(String imei, Date today) {
        String indexName = StrUtil.format(TCP_INDEX_NAME, DateUtil.format(today, "yyyy.MM.dd"));
        return Arrays.stream(REAL_PROTOCOL_LIST)
                .map(protocol -> String.format(TCP_PROCESS_PHRASE, imei, protocol))
                .map(queryPhrase -> new NativeSearchQueryBuilder()
                        .withQuery(QueryBuilders.matchPhraseQuery("message", queryPhrase)))
                .anyMatch(builder -> elasticsearchRestTemplate.count(builder.build(), JSONObject.class, IndexCoordinates.of(indexName)) > 0);
    }

    /**
     * 校验实时数据TCP，配置长度是否与云端缓存一致
     *
     * @param imei
     * @param today
     * @return
     */
    private boolean whetherConfigSameLength(String imei, Date today) {
        String indexName = StrUtil.format(TCP_INDEX_NAME, DateUtil.format(today, "yyyy.MM.dd"));
        NativeSearchQuery query = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.matchPhraseQuery("message", StrUtil.format("\"{}数据长度不匹配\"", imei))).build();
        return elasticsearchRestTemplate.count(query, JSONObject.class, IndexCoordinates.of(indexName)) == 0;
    }

    /**
     * MQTT当天是否有记录
     *
     * @param imei
     * @param today
     * @return
     */
    public boolean whetherHasMqtt(String imei, Date today) {
        String indexName = StrUtil.format("mqtt-{}", DateUtil.format(today, "yyyy.MM.dd"));
        NativeSearchQuery query = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.boolQuery()
                        .must(QueryBuilders.matchPhraseQuery("message", "mqtt"))
                        .must(QueryBuilders.matchPhraseQuery("message", imei)))
                .build();
        return elasticsearchRestTemplate.count(query, JSONObject.class, IndexCoordinates.of(indexName)) > 0;
    }

    /**
     * MQTT当天是否有T15信号
     *
     * @param imei
     * @param today
     * @return
     */
    private boolean whetherHasT15On(String imei, Date today) {

        DeviceSelfCheckQuery deviceSelfCheckQuery = new DeviceSelfCheckQuery();
        deviceSelfCheckQuery.setImei(imei);
        deviceSelfCheckQuery.setStartTime(DateUtil.beginOfDay(today));
        deviceSelfCheckQuery.setEndTime(DateUtil.endOfDay(today));
        // 0x05 T15类型
        deviceSelfCheckQuery.setErrorType("0x05");
        // 0x01 ON
        deviceSelfCheckQuery.setErrorData("0x01");
        deviceSelfCheckQuery.setPageSize(1);
        PageResult<DeviceSelfCheckVO> pageResult = deviceInfoFeignClient.pageSelfCheckRecord(deviceSelfCheckQuery);

        return pageResult != null && pageResult.getData() != null && CollectionUtils.isNotEmpty(pageResult.getData().getList());
    }


    /**
     * MQTT当天是否有周期上报状态
     *
     * @param ccuId
     * @param today
     * @return
     */
    private boolean whetherHasStatusUp(String ccuId, Date today) {

        DevicePeriodUploadQuery devicePeriodUploadQuery = new DevicePeriodUploadQuery();
        devicePeriodUploadQuery.setCcuId(ccuId);
        devicePeriodUploadQuery.setStartTime(DateUtil.beginOfDay(today));
        devicePeriodUploadQuery.setEndTime(DateUtil.endOfDay(today));

        PageResult<DevicePeriodUploadVO> pageResult = deviceInfoFeignClient.pageCcuStatusUp(devicePeriodUploadQuery);
        return pageResult != null && pageResult.getData() != null && CollectionUtils.isNotEmpty(pageResult.getData().getList());

    }


    /**
     * 判断CCU是否连接RBCD Cloud
     *
     * @param imei
     * @return
     */
    private boolean whetherRbcdCloud(String imei) {
        String cloud = (String) redisUtils.hget("imei:" + imei, "cloud");
        return !StrUtil.equals("RBHP", cloud);
    }


}
