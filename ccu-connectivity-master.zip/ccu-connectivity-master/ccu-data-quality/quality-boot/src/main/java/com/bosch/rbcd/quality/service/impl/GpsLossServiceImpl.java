package com.bosch.rbcd.quality.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.quality.mapper.GpsLossMapper;
import com.bosch.rbcd.quality.pojo.entity.GpsLoss;
import com.bosch.rbcd.quality.pojo.form.BatchSolveRecordForm;
import com.bosch.rbcd.quality.pojo.query.GpsLossPageQuery;
import com.bosch.rbcd.quality.pojo.vo.GpsLossVO;
import com.bosch.rbcd.quality.service.GpsLossService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * GPS数据质量事件记录(3、4)(QualityGpsLoss)表服务实现类
 *
 * @author wang bo
 * @since 2023-05-11 11:10:28
 */
@Service("qualityGpsLossService")
@RequiredArgsConstructor
public class GpsLossServiceImpl extends ServiceImpl<GpsLossMapper, GpsLoss> implements GpsLossService {

    @Override
    public IPage<GpsLossVO> pageQuery(GpsLossPageQuery gpsLossPageQuery){
        Page<GpsLossVO> page = new Page<>(gpsLossPageQuery.getPageNum(), gpsLossPageQuery.getPageSize());
        if (CollectionUtils.isNotEmpty(gpsLossPageQuery.getOrders())) {
            page.setOrders(gpsLossPageQuery.getOrders());
        } else {
            OrderItem orderItem = OrderItem.asc("qdl.now_sec_time");
            List<OrderItem> orders = Collections.singletonList(orderItem);
            page.setOrders(orders);
        }

        return getBaseMapper().pageQuery(page, gpsLossPageQuery);
    }

    @Override
    public GpsLossVO detail(Long id) {
        if (id == null || id <= 0) {
            return null;
        }
        return getBaseMapper().detail(id);
    }

    @Override
    public void solve(BatchSolveRecordForm form) {
        if (CollectionUtils.isEmpty(form.getIdList())) {
            return;
        }

        LambdaUpdateWrapper<GpsLoss> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(GpsLoss::getReasonType, form.getReasonType());
        updateWrapper.set(GpsLoss::getCauseAnalysis, form.getCauseAnalysis());
        updateWrapper.set(GpsLoss::getSolveStatus, 1);
        updateWrapper.set(GpsLoss::getHandlerId, UserUtils.getUserId());
        updateWrapper.set(GpsLoss::getUpdateTime, new Date());
        updateWrapper.in(GpsLoss::getId, form.getIdList());
        this.update(updateWrapper);
    }
}

