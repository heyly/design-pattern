package com.bosch.rbcd.quality.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.web.vo.echarts.NameValueVO;
import com.bosch.rbcd.quality.pojo.entity.QualityEventRecord;
import com.bosch.rbcd.quality.pojo.form.BatchSolveRecordForm;
import com.bosch.rbcd.quality.pojo.query.QualityEventRecordPageQuery;
import com.bosch.rbcd.quality.pojo.vo.QualityEventRecordVO;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 数据质量事件记录信息表(QualityEventRecord)表数据库访问层
 *
 * @author wang bo
 * @since 2023-04-27 11:20:56
 */
@Mapper
public interface QualityEventRecordMapper extends BaseMapper<QualityEventRecord> {

    /**
     * 获取QualityEventRecord分页列表
     *
     * @param page
     * @param queryParams 查询参数
     * @return
     */
    List<QualityEventRecordVO> listQualityEventRecordPage(Page<QualityEventRecordVO> page, @Param("queryParams") QualityEventRecordPageQuery queryParams);


    List<NameValueVO> getTop10VehiclePieData(@Param("queryParams") QualityEventRecordPageQuery queryParams);

    Integer countQualityEventRecord(@Param("queryParams") QualityEventRecordPageQuery queryParams);

    List<Map<String,Object>> pageCountQualityEventRecord(Page<Map<String, Object>> page, @Param("queryParams") QualityEventRecordPageQuery queryParams);

    @MapKey("ccuNo")
    Map<String,Map<String,Object>> getEventVehicleCountMap(@Param("queryParams") QualityEventRecordPageQuery queryParams);

    Integer batchSolveRecord(BatchSolveRecordForm batchSolveRecordForm);

    List<String> queryDistinctCcuIdByTime(@Param("startTime") Date startTime, @Param("endTime") Date endTime);

    IPage<QualityEventRecord> getPersonInChargeEmpty(IPage<QualityEventRecord> page);
}

