package com.bosch.rbcd.quality.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.quality.mapper.DataLossRateMapper;
import com.bosch.rbcd.quality.pojo.entity.DataLossRate;
import com.bosch.rbcd.quality.pojo.query.DataLossRateQuery;
import com.bosch.rbcd.quality.service.DataLossRateService;
import org.springframework.stereotype.Service;

/**
 * 丢包率(Quality_loss_rate)表服务实现类
 *
 * @author cl
 * @since 2023-06-08 11:20:56
 */
@Service("dataLossRateService")
public class DataLossRateServiceImpl extends ServiceImpl<DataLossRateMapper, DataLossRate> implements DataLossRateService {

    @Override
    public Double getAverageRate(DataLossRateQuery queryParams) {
        Double averageRate = baseMapper.getAverageRate(queryParams);
        return averageRate == null ? 0 : averageRate;
    }

}

