package com.bosch.rbcd.quality.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.quality.mapper.CcuSelfCheckConfigMapper;
import com.bosch.rbcd.quality.pojo.entity.CcuSelfCheckConfig;
import com.bosch.rbcd.quality.service.CcuSelfCheckConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * ccu自诊断信息配置表(CcuSelfCheckConfig)表服务实现类
 *
 * @author wang bo
 * @since 2023-12-15 14:00:55
 */
@Service("ccuSelfCheckConfigService")
@RequiredArgsConstructor
public class CcuSelfCheckConfigServiceImpl extends ServiceImpl<CcuSelfCheckConfigMapper, CcuSelfCheckConfig> implements CcuSelfCheckConfigService {


    @Override
    public CcuSelfCheckConfig getErrorCheckInfo(List<String> codeList) {
        if (CollectionUtil.isEmpty(codeList)) {
            return null;
        }
        return this.baseMapper.getErrorCheckInfo(codeList);
    }
}

