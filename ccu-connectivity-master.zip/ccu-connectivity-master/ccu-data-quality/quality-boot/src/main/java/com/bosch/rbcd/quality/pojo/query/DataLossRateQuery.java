package com.bosch.rbcd.quality.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@ApiModel("数据丢失分页查询对象")
@Data
public class DataLossRateQuery extends BasePageQuery {

    @ApiModelProperty("项目id，如果同时传了projectId和ccuIdList, 那么以ccuIdList为准")
    private Long projectId;

    private List<Long> projectIdList;

    @ApiModelProperty("ccu_id列表")
    private List<String> ccuIdList;

    @ApiModelProperty("ccu编号")
    private String ccuNo;

    @ApiModelProperty("车辆别名")
    private String vehicleName;

    @ApiModelProperty("车架号")
    private String vin;

    @ApiModelProperty("IMEI")
    private String imei;

    @ApiModelProperty("发动机编号")
    private String engineNo;

    @ApiModelProperty("ccu sn")
    private String shortSn;
}
