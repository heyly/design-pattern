package com.bosch.rbcd.quality.pojo.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel("CCU状态记录")
public class CcuStatusStatisticVO {

    @ApiModelProperty("活跃CCU数量")
    private Integer onlineCcuCount;

    @ApiModelProperty("失效CCU数量")
    private Integer expireCcuCount;

    @ApiModelProperty("日期")
    @JsonFormat(pattern = "MM-dd", timezone = "Asia/Shanghai")
    private Date day;
}
