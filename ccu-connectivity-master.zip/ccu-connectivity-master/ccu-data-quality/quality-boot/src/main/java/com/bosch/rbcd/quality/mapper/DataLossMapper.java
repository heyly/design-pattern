package com.bosch.rbcd.quality.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.quality.pojo.entity.DataLoss;
import com.bosch.rbcd.quality.pojo.query.DataLossQuery;
import com.bosch.rbcd.quality.pojo.vo.DataLossVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface DataLossMapper extends BaseMapper<DataLoss> {

    Long countLostDevice(@Param("query") DataLossQuery query);

    Long countLostMileage(@Param("query") DataLossQuery query);

    Long countLostEvent(@Param("query") DataLossQuery query);

    Page<DataLossVO> pageQuery(@Param("page") Page<DataLossVO> page, @Param("query") DataLossQuery query);

    DataLossVO detail(@Param("id") Long id);
}
