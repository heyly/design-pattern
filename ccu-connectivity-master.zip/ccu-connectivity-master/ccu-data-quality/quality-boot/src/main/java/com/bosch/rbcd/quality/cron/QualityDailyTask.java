package com.bosch.rbcd.quality.cron;

import com.bosch.rbcd.common.utils.FreeMarkerUtil;
import com.bosch.rbcd.common.utils.communication.MailUtil;
import com.bosch.rbcd.data.api.DgcFeignClient;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.quality.mapper.CcuExpireRecordMapper;
import com.bosch.rbcd.quality.service.UserNoticeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname QualityDailyTask
 * @description 数据质量记录每日汇总任务
 * @date 2023/4/26 13:37
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class QualityDailyTask {

    private final FreeMarkerUtil freeMarkerUtil;
    private final MailUtil mailUtil;
    private final UserNoticeService userNoticeService;
    private final ProjectFeignClient projectFeignClient;
    private final CcuExpireRecordMapper ccuExpireRecordMapper;

    private final DeviceInfoFeignClient deviceInfoFeignClient;
    private final StringRedisTemplate stringRedisTemplate;
//    private final DataScoreService dataScoreService;
//    private final DataScoreDetailService dataScoreDetailService;
    private final DgcFeignClient dgcFeignClient;

    /**
     * 汇总邮件模板
     */
    String SUMMARY_DATA_QUALITY_FTL = "dataQualitySummary.ftl";

    /**
     * 数据质量时间汇总邮件主题
     */
    String SUMMARY_DATA_QUALITY_TOPIC = "Daily Data Quality Event Summary: ";

    // todo
//    @Scheduled(cron = "0 0 7 * * ?")
    public void sendDailySummaryTask() {
//        List<ProjectUserDTO> list = projectFeignClient.getProjectUserList(-1L).getData();
//        Date yesterday = DateUtil.yesterday();
//        list.forEach(item -> {
//            if (CollectionUtils.isEmpty(item.getUserIdList())) {
//                log.info("sendDailySummaryTask 当前项目projectId = {}，分组下没有用户，跳过！", item.getProjectId());
//                return;
//            }
//            String projectName = item.getProjectName();
//
//            // 查询用户邮件通知
//            UserNoticeQuery noticeQuery = new UserNoticeQuery();
//            noticeQuery.setProjectId(item.getProjectId());
//            noticeQuery.setSendEmail(1);
//            noticeQuery.setPageSize(-1);
//            IPage<UserNoticeVO> userNoticePage = userNoticeService.query(noticeQuery);
//            if (userNoticePage == null || CollectionUtils.isEmpty(userNoticePage.getRecords())) {
//                log.info("sendDailySummaryTask 当前分组projectId = {}, projectName = {}，没有配置邮件接收人", item.getProjectId(), projectName);
//                return;
//            }
//
//            // 查询设备失效
//            CcuExpireRecordPageQuery expireRecordQuery = new CcuExpireRecordPageQuery();
//            expireRecordQuery.setPageSize(-1);
//            expireRecordQuery.setStartTime(DateUtil.beginOfDay(yesterday));
//            expireRecordQuery.setEndTime(DateUtil.endOfDay(yesterday));
//            expireRecordQuery.setProjectIdList(Collections.singletonList(item.getProjectId()));
//            Page<CcuExpireRecordVO> expireRecordVOPage = new Page<>(expireRecordQuery.getPageNum(), expireRecordQuery.getPageSize());
//            List<CcuExpireRecordVO> expireRecordVOList = ccuExpireRecordMapper.listQualityCcuExpireRecordPage(expireRecordVOPage, expireRecordQuery);
//
//            // 查询其他事件
//            QualityEventRecordPageQuery query = new QualityEventRecordPageQuery().setProjectId(item.getProjectId());
//            // 关闭分页
//            query.setPageSize(-1);
//            query.setStartTime(DateUtil.beginOfDay(yesterday));
//            query.setEndTime(DateUtil.endOfDay(yesterday));
//            // 只查询指定类型的事件
//            Map<Integer, String> otherEventMap = DataEventTypeEnum.getOtherEventMap();
//            query.setEventTypeList(new ArrayList<>(otherEventMap.keySet()));
//            List<QualityEventRecordVO> dailyEvenetRecordList = qualityEventRecordService.listQualityEventRecordPage(query, false).getRecords();
//
//            // 数据评分
//            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//            LambdaQueryWrapper<DataScore> dataScoreQuery = new LambdaQueryWrapper<>();
//            dataScoreQuery.eq(DataScore::getCreateDay, simpleDateFormat.format(yesterday));
//            dataScoreQuery.eq(DataScore::getProjectId, item.getProjectId());
//            dataScoreQuery.lt(DataScore::getScore, 1);
//            List<DataScore> dataScoreList = dataScoreService.list(dataScoreQuery);
//
//            if (CollectionUtils.isEmpty(expireRecordVOList) && CollectionUtils.isEmpty(dailyEvenetRecordList) && CollectionUtils.isEmpty(dataScoreList)) {
//                log.info("sendDailySummaryTask 当前分组不存在数据异常事件！当前分组projectId = {}, projectName = {}", item.getProjectId(), projectName);
//                return;
//            }
//
//            Map<Integer, List<QualityEventRecordVO>> eventRecordMap = new HashMap<>();
//            for (QualityEventRecordVO qualityEventRecordVO : dailyEvenetRecordList) {
//                List<QualityEventRecordVO> voList = eventRecordMap.getOrDefault(qualityEventRecordVO.getEventType(), new ArrayList<>());
//                voList.add(qualityEventRecordVO);
//                eventRecordMap.put(qualityEventRecordVO.getEventType(), voList);
//            }
//
//            for (UserNoticeVO userNoticeVO : userNoticePage.getRecords()) {
//                if (CollectionUtils.isEmpty(userNoticeVO.getEventTypeList())) {
//                    continue;
//                }
//
//                Long userId = userNoticeVO.getUserId();
//                String email = userNoticeVO.getEmail();
//
//                boolean sendCcuExpireEmail = userNoticeVO.getEventTypeList().contains(DataEventTypeEnum.CCU_EXPIRE.getValue());
//                boolean sendDataScoreEmail = userNoticeVO.getEventTypeList().contains(DataEventTypeEnum.DATA_SCORE_TOO_LOW.getValue());
//
//                List<QualityEventRecordVO> userEventRecordList = new ArrayList<>();
//                for (Integer eventType : userNoticeVO.getEventTypeList()) {
//                    if (CollectionUtils.isNotEmpty(eventRecordMap.get(eventType))) {
//                        userEventRecordList.addAll(eventRecordMap.get(eventType));
//                    }
//                }
//
//                // 不发送空邮件
//                if ((!sendCcuExpireEmail || CollectionUtils.isEmpty(expireRecordVOList))
//                        && CollectionUtils.isEmpty(userEventRecordList)
//                        && (!sendDataScoreEmail || CollectionUtils.isEmpty(dataScoreList))) {
//                    continue;
//                }
//
//                // 定义邮件ftl数据节点
//                Map<String, Object> realMap = new HashMap<>();
//                realMap.put("expireRecordVOList", expireRecordVOList);
//                realMap.put("vehicleRecordList", userEventRecordList);
//                realMap.put("dataScoreList", dataScoreList);
//                String summaryContent = freeMarkerUtil.fillTemplate(SUMMARY_DATA_QUALITY_FTL, realMap);
//
//
//                // 根据搜索条件生成数据质量信息汇总表
//                String summaryExcel = FileUtils.getTempDirectoryPath() + userId + "_QualitySummary_" + System.currentTimeMillis() + ".xlsx";
//                try (ExcelWriter excelWriter = EasyExcel.write(summaryExcel).build()) {
//                    // 设备失效
//                    WriteSheet ccuExpireSheet = EasyExcel.writerSheet(0, "设备失效")
//                            .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
//                            .head(CcuExpireRecordVO.class).build();
//                    excelWriter.write(expireRecordVOList, ccuExpireSheet);
//
//                    // 其他事件
//                    WriteSheet eventSheet = EasyExcel.writerSheet(1, "其他事件")
//                            .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
//                            .head(QualityEventRecordVO.class).build();
//                    excelWriter.write(userEventRecordList, eventSheet);
//
//                    // 数据评分过低
//                    WriteSheet dataScoreSheet = EasyExcel.writerSheet(2, "数据评分过低")
//                            .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
//                            .head(DataScore.class).build();
//                    excelWriter.write(dataScoreList, dataScoreSheet);
//                }
//
//                mailUtil.sendAttachmentsMail(email, SUMMARY_DATA_QUALITY_TOPIC + projectName, null, summaryContent, summaryExcel, true);
//            }
//
//        });
    }

    /**
     * 计算数据评分
     * 每天凌晨2点执行，计算前一天的
     */
//    @Scheduled(cron = "0 0 2 * * ?")
//    public void calculateDataScore() {
//        log.info("计算数据评分 开始！");
//        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//        Calendar today = Calendar.getInstance();
//        today.add(Calendar.DATE, -1);
//        Date yesterday = today.getTime();
//        String creatDay = simpleDateFormat.format(yesterday);
//        try {
//            yesterday = simpleDateFormat.parse(creatDay);
//        } catch (ParseException e) {
//            log.error("时间转化出错！", e);
//            return;
//        }
//
//        int scoreNum = 0, detailNum = 0;
//
//        for (int pageNum=1, pageSize=20; ; pageNum++) {
//            DeviceInfoFeignQuery deviceInfoFeignQuery = new DeviceInfoFeignQuery();
//            deviceInfoFeignQuery.setPageNum(pageNum);
//            deviceInfoFeignQuery.setPageSize(pageSize);
//
//            PageResult<DeviceInfoDTO> pageResult = deviceInfoFeignClient.pageForFleetMonitor(deviceInfoFeignQuery);
//            if (pageResult == null || pageResult.getData() == null || CollectionUtils.isEmpty(pageResult.getData().getList())) {
//                break;
//            }
//
//            Map<Long, Map<String, DgcDataRangeVO>> projectDgcRuleMap = new HashMap<>();
//
//            for (DeviceInfoDTO deviceInfoDTO : pageResult.getData().getList()) {
//
////                log.info("当前ccu：" + JSON.toJSONString(ccuDeviceInfoDTO));
//
//                String redisCountKey = "dataError_" + deviceInfoDTO.getCcuId() + "_" + creatDay + "_count";
//                if (Boolean.FALSE.equals(stringRedisTemplate.hasKey(redisCountKey))) {
//                    continue;
//                }
//                int totalCount = 0, errorCount = 0;
//                try {
//                    totalCount = Integer.parseInt(String.valueOf(stringRedisTemplate.opsForHash().get(redisCountKey, "totalCount")));
//                    errorCount = Integer.parseInt(String.valueOf(stringRedisTemplate.opsForHash().get(redisCountKey, "errorCount")));
//                } catch (Exception e) {
////                    log.error("获取totalCount或errorCount出错！redis数据：" + JSON.toJSONString(stringRedisTemplate.opsForHash().entries(redisCountKey)), e);
//                }
//
//                if (totalCount <= 0 || errorCount < 0) {
////                    log.info("当前CCU（ccu_id = {}, ccu_no = {}）被跳过，totalCount = {}, errorCount = {}", ccuDeviceInfoDTO.getCcuId(), ccuDeviceInfoDTO.getCcuNo(), totalCount, errorCount);
//                    continue;
//                }
//
//                // 计算数据质量评分
//                Long dataScoreId = calculateScore(deviceInfoDTO, totalCount, errorCount, yesterday);
//                // 细节
//                detailNum = calculateScoreDetail(deviceInfoDTO, creatDay, totalCount, dataScoreId, detailNum, projectDgcRuleMap);
//
//                scoreNum ++;
//            }
//
//        }
//        log.info("计算数据评分 结束！插入data_score数量：{}, detail_num数量：{}", scoreNum, detailNum);
//    }
//
//    private int calculateScoreDetail(DeviceInfoDTO ccuDeviceInfoDTO, String creatDate, int total, Long dataScoreId, int detailNum, Map<Long, Map<String, DgcDataRangeVO>> projectDgcRuleMap) {
//        int res = detailNum;
//        // key: label, value: dataScoreDetail
//        Map<String, DataScoreDetail> detailMap = new HashMap<>();
//
//        // 空值
//        String redisEmptyKey = "dataError_" + ccuDeviceInfoDTO.getCcuId() + "_" + creatDate + "_empty";
//        Map<Object, Object> redisEmptyMap = stringRedisTemplate.opsForHash().entries(redisEmptyKey);
////        log.info("ccuId = {}, ccuNo = {}, redisEmptyMap = {}", ccuDeviceInfoDTO.getCcuId(), ccuDeviceInfoDTO.getCcuNo(), JSON.toJSONString(redisEmptyMap));
//        if (MapUtils.isNotEmpty(redisEmptyMap)) {
//            for (Map.Entry<Object, Object> entry : redisEmptyMap.entrySet()) {
//                String label = String.valueOf(entry.getKey());
//                int emptyCount = Integer.parseInt(String.valueOf(entry.getValue()));
//                DataScoreDetail dataScoreDetail = getDetailFromMap(detailMap, label, dataScoreId);
//                dataScoreDetail.setEmptyCount(emptyCount);
//                dataScoreDetail.setEmptyRate(1.0 * emptyCount / total);
//
//                detailMap.put(label, dataScoreDetail);
//            }
//        }
//
//        // 小于最小值
//        String redisLessKey = "dataError_" + ccuDeviceInfoDTO.getCcuId() + "_" + creatDate + "_less";
//        Map<Object, Object> redisLessMap = stringRedisTemplate.opsForHash().entries(redisLessKey);
////        log.info("ccuId = {}, ccuNo = {}, redisLessKey = {}", ccuDeviceInfoDTO.getCcuId(), ccuDeviceInfoDTO.getCcuNo(), JSON.toJSONString(redisLessKey));
//        if (MapUtils.isNotEmpty(redisLessMap)) {
//            for (Map.Entry<Object, Object> entry : redisLessMap.entrySet()) {
//                String label = String.valueOf(entry.getKey());
//                int lessCount = Integer.parseInt(String.valueOf(entry.getValue()));
//                DataScoreDetail dataScoreDetail = getDetailFromMap(detailMap, label, dataScoreId);
//                dataScoreDetail.setLessCount(lessCount);
//                dataScoreDetail.setLessRate(1.0 * lessCount / total);
//
//                detailMap.put(label, dataScoreDetail);
//            }
//        }
//
//        // 大于最大值
//        String redisGreaterKey = "dataError_" + ccuDeviceInfoDTO.getCcuId() + "_" + creatDate + "_greater";
//        Map<Object, Object> redisGreaterMap = stringRedisTemplate.opsForHash().entries(redisGreaterKey);
////        log.info("ccuId = {}, ccuNo = {}, redisGreaterMap = {}", ccuDeviceInfoDTO.getCcuId(), ccuDeviceInfoDTO.getCcuNo(), JSON.toJSONString(redisGreaterMap));
//        if (MapUtils.isNotEmpty(redisGreaterMap)) {
//            for (Map.Entry<Object, Object> entry : redisGreaterMap.entrySet()) {
//                String label = String.valueOf(entry.getKey());
//                int greaterCount = Integer.parseInt(String.valueOf(entry.getValue()));
//                DataScoreDetail dataScoreDetail = getDetailFromMap(detailMap, label, dataScoreId);
//                dataScoreDetail.setGreaterCount(greaterCount);
//                dataScoreDetail.setGreaterRate(1.0 * greaterCount / total);
//
//                detailMap.put(label, dataScoreDetail);
//            }
//        }
//
//        if (MapUtils.isNotEmpty(detailMap)) {
//            List<DataScoreDetail> dataScoreDetailList = new ArrayList<>();
//            for (Map.Entry<String, DataScoreDetail> entry : detailMap.entrySet()) {
//                String label = entry.getKey();
//                DataScoreDetail dataScoreDetail = entry.getValue();
//
//                Map<String, DgcDataRangeVO> dgcRuleMap = projectDgcRuleMap.get(ccuDeviceInfoDTO.getProjectId());
//                if (dgcRuleMap == null) {
//                    dgcRuleMap = dgcFeignClient.queryRules(ccuDeviceInfoDTO.getProjectId()).getData();
//                    if (MapUtils.isEmpty(dgcRuleMap)) {
//                        dgcRuleMap = new HashMap<>(1);
//                    }
//                    projectDgcRuleMap.put(ccuDeviceInfoDTO.getProjectId(), dgcRuleMap);
//                }
//
//                if (dgcRuleMap.get(label) != null) {
//                    dataScoreDetail.setMin(dgcRuleMap.get(label).getMin());
//                    dataScoreDetail.setMax(dgcRuleMap.get(label).getMax());
//                }
//
//                dataScoreDetailList.add(dataScoreDetail);
//            }
//            dataScoreDetailService.saveBatch(dataScoreDetailList);
//            detailNum += dataScoreDetailList.size();
//        }
//
//        return detailNum;
//    }
//
//    private Long calculateScore(DeviceInfoDTO ccuDeviceInfoDTO, int totalCount, int errorCount, Date yesterday) {
//
//        // 满分10分
//        double score = 10.0 * (totalCount - errorCount) / totalCount;
//        if (score < 0) {
//            score = 0;
//        }
//
//        DataScore dataScore = new DataScore();
//        dataScore.setProjectId(ccuDeviceInfoDTO.getProjectId());
//        dataScore.setCcuId(ccuDeviceInfoDTO.getCcuId());
//        dataScore.setCcuNo(ccuDeviceInfoDTO.getCcuNo());
//        dataScore.setTotal(totalCount);
//        dataScore.setErrorCount(errorCount);
//        dataScore.setScore(score);
//        dataScore.setCreateDay(yesterday);
//        dataScoreService.save(dataScore);
//
//        return dataScore.getId();
//    }

//    private DataScoreDetail getDetailFromMap(Map<String, DataScoreDetail> detailMap, String label, Long dataScoreId) {
//        DataScoreDetail dataScoreDetail = detailMap.get(label);
//        if (dataScoreDetail == null) {
//            dataScoreDetail = new DataScoreDetail();
//            dataScoreDetail.setDataScoreId(dataScoreId);
//            dataScoreDetail.setLabel(label);
//        }
//        return dataScoreDetail;
//    }
}
