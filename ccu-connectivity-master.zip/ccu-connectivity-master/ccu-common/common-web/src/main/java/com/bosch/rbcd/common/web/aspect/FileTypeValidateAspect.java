package com.bosch.rbcd.common.web.aspect;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.ReUtil;
import cn.hutool.core.util.StrUtil;
import com.bosch.rbcd.common.web.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.tika.Tika;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname FileTypeValidateAspect
 * @description TODO
 * @date 24/04/08 14:41
 */
@Slf4j
@Aspect
@Component
@RefreshScope
public class FileTypeValidateAspect {

    // 非法文件名内容
    @Value("${system.inValidFileName}")
    private String INVALID_FILE_NAME;

    /**
     * 允许上传的文件类型
     */
    @Value("${system.validFile}")
    private String ALLOWED_EXTENSIONS;

    @Before("execution(public * com.bosch.rbcd.*.controller.*.*(..)) && args(..,file)")
    public void validateFileExtension(MultipartFile file) {
        try {
            if (file != null) {
                if (!file.isEmpty() && file.getInputStream().available() > 0) {
                    String fileName = file.getOriginalFilename();
                    if (StrUtil.isBlank(fileName)) {
                        throw new BizException("文件名不能为空!");
                    }

                    Pattern invalidFileNamePattern = Pattern.compile(INVALID_FILE_NAME);
                    //验证文件名中是否含有空格或者“."等其他特殊字符
                    if (invalidFileNamePattern.matcher(FileUtil.mainName(fileName)).find()) {
                        Set<String> invalidCharSet = new HashSet<>(ReUtil.findAllGroup0(invalidFileNamePattern, FileUtil.mainName(fileName)));
                        String invalidCharTip = invalidCharSet.stream().map(s -> StrUtil.equals(" ", s) ? "空格" : s).collect(Collectors.joining(" "));
                        throw new BizException(StrUtil.format("文件名存在特殊字符:{}", invalidCharTip));
                    }

                    // 校验文件后缀名
                    String fileType = FileUtil.extName(fileName);
                    if (!StrUtil.equalsAnyIgnoreCase(fileType, ALLOWED_EXTENSIONS.split(StrUtil.COMMA))) {
                        throw new BizException(StrUtil.format("不支持上传{}文件类型", fileType));
                    }
                    // 校验文件内容，防止篡改文件后缀
                    Tika tika = new Tika();
                    String contentType = tika.detect(file.getInputStream());
                    if (!StrUtil.containsAnyIgnoreCase(contentType, ALLOWED_EXTENSIONS.split(StrUtil.COMMA))) {
                        throw new BizException(StrUtil.format("请勿篡改文件类型{}", contentType));
                    }
                } else {
                    throw new BizException("文件不能为空!");
                }
            }
        } catch (IOException e) {
            log.error("===============Aspect Valid File Type Occur Exception=================", e);
        }

    }

}
