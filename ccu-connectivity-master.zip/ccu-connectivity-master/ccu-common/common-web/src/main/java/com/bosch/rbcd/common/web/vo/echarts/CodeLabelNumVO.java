package com.bosch.rbcd.common.web.vo.echarts;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author
 * @version 1.0.0
 * @classname CodeLabelNumVO
 * @description 公用Code Label 总数  视图层
 * @date 2023/8/17 14:24
 */
@ApiModel("Code Label 总数  视图层")
@Data
public class CodeLabelNumVO {

    @ApiModelProperty("code")
    private Object code;

    @ApiModelProperty("label")
    private String label;

    @ApiModelProperty("总数")
    private Long num;
}
