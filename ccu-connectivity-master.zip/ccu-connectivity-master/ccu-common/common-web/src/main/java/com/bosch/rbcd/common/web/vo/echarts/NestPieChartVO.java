package com.bosch.rbcd.common.web.vo.echarts;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname PieChartVO
 * @description TODO
 * @date 2023/5/8 14:44
 */
@ApiModel("Echarts 嵌套饼状图视图层实体")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NestPieChartVO {
    @ApiModelProperty("绘图数据")
    List<NameValueVO> data;

    @ApiModelProperty("绘图数据")
    List<NameValueVO> nestData;

}
