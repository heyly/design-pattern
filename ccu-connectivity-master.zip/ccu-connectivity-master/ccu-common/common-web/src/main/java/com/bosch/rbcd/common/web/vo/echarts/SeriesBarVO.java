package com.bosch.rbcd.common.web.vo.echarts;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname DoubleBarVO
 * @description TODO
 * @date 2023/8/30 14:24
 */
@ApiModel("Series数据结构柱状图")
@Data
public class SeriesBarVO {
    @ApiModelProperty("横坐标")
    private List<String> xAxis;

    @ApiModelProperty("柱子值列表")
    private List<List<Object>> ySeries;
}
