package com.bosch.rbcd.common.web.huawei.pojo.auth;

public class DomainDTO {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
