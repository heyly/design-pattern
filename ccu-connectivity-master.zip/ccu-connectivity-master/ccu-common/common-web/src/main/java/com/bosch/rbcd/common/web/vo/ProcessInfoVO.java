package com.bosch.rbcd.common.web.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@ApiModel
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class ProcessInfoVO {

    @ApiModelProperty("流程节点id")
    private Long processNodeId;

    @ApiModelProperty("流程节点名称")
    private String processNodeName;

    @ApiModelProperty("流程节点状态 -1: 待审批 0: 审批中 1: 审批通过 2: 审批拒绝")
    private Integer processNodeStatus;

    @ApiModelProperty("审核用户信息")
    private List<CheckUserVO> checkUserList;

    @Data
    @ApiModel
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    public static class CheckUserVO {

        @ApiModelProperty("用户id")
        private Long userId;

        @ApiModelProperty("用户名")
        private String username;

        @ApiModelProperty("审核状态 0: 初始 1: 通过 2: 拒绝")
        private int checkResult;

        @ApiModelProperty("备注")
        private String remark;

        @ApiModelProperty("审核时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
        private LocalDateTime checkTime;
    }
}
