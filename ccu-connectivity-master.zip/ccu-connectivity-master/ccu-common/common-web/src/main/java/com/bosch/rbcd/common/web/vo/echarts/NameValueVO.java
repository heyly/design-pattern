package com.bosch.rbcd.common.web.vo.echarts;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Map;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname NameValueVO
 * @description TODO
 * @date 2023/5/8 14:55
 */
@Data
@ApiModel("Echarts名称-值视图层实体")
@Accessors(chain = true)
public class NameValueVO {

    @ApiModelProperty("名称")
    private String name;

    @ApiModelProperty("显示label")
    private String label;

    @ApiModelProperty("值")
    private Double value;

    @ApiModelProperty("子柱值")
    Map<Integer, Long> subMap;
}
