package com.bosch.rbcd.common.web.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProcessCheckResultVO {

    private Long processInstanceId;

    private Integer instanceCheckResult;

    private Integer processNodeCheckResult;
}
