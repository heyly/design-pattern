package com.bosch.rbcd.common.web.huawei.pojo.command;

import lombok.Data;

import java.util.List;

@Data
public class CalibrationCommand {

    private String device;

    private String taskId;

    private String messageType;

    private String timestamp;

    private List<Object> calibration;

}
