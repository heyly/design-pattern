package com.bosch.rbcd.common.web.vo.echarts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname SeriesLineVO
 * @description TODO
 * @date 24/04/02 11:23
 */
@Data
public class SeriesLineVO {

    @ApiModelProperty("line 名称")
    String name;

    @ApiModelProperty("数据值")
    List<Double> data;

}
