package com.bosch.rbcd.common.web.vo.echarts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname StackedLineVO
 * @description TODO
 * @date 24/04/02 10:59
 */
@Data
public class StackedLineVO {
    @ApiModelProperty("横坐标刻度名称")
    List<String> xAxisData;


    @ApiModelProperty("line列表")
    List<SeriesLineVO> series;

}
