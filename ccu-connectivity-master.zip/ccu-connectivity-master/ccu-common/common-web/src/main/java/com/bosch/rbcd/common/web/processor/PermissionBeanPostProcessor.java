package com.bosch.rbcd.common.web.processor;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson2.JSON;
import com.bosch.rbcd.common.web.vo.PermissionRedisVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class PermissionBeanPostProcessor implements BeanPostProcessor {

    private final RedisTemplate redisTemplate;

    @Value("${spring.application.name}")
    private String applicationName;

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return BeanPostProcessor.super.postProcessBeforeInitialization(bean, beanName);
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> beanClass = bean.getClass();
        RestController restController = AnnotationUtils.findAnnotation(beanClass, RestController.class);
        if (restController == null) {
            return bean;
        }
        Api api = AnnotationUtils.findAnnotation(beanClass, Api.class);
        if (api == null) {
            return bean;
        }
        ApiIgnore apiIgnore = AnnotationUtils.findAnnotation(beanClass, ApiIgnore.class);
        if (apiIgnore != null) {
            return bean;
        }
        RequestMapping requestMapping = AnnotationUtils.findAnnotation(beanClass, RequestMapping.class);
        if (requestMapping == null) {
            return bean;
        }
        log.info("开始处理Controller [{}] 里面所有的接口", beanName);
        String basePath = getBasePath(requestMapping);
        List<PermissionRedisVO> permissionList = getPermissionList(basePath, beanClass);
        redisTemplate.opsForHash().put("perm:" + applicationName, beanName, JSON.toJSONString(permissionList));
        return BeanPostProcessor.super.postProcessAfterInitialization(bean, beanName);
    }

    /**
     * 获取接口的基础path
     * @param requestMapping @RequestMapping注解信息
     * @return 基础path 如：/ccu-fleet/vehicle
     */
    private String getBasePath(RequestMapping requestMapping) {
        String[] pathArray = requestMapping.path();
        String basePath = "/" + applicationName;
        if (pathArray.length > 0) {
            String path = pathArray[0];
            if (path.startsWith("/")) {
                basePath = basePath + path;
            } else {
                basePath = basePath + "/" + path;
            }
        }
        return basePath;
    }

    /**
     * 根据当前Controller里面所有的方法封装成 PermissionList
     * @param beanClass Controller类
     * @return PermissionList
     */
    private List<PermissionRedisVO> getPermissionList(String basePath, Class<?> beanClass) {
        List<PermissionRedisVO> list = new ArrayList<>();
        for (Method classMethod : beanClass.getDeclaredMethods()) {
            ApiIgnore apiIgnore = AnnotationUtils.findAnnotation(classMethod, ApiIgnore.class);
            if (apiIgnore != null) {
                continue;
            }
            ApiOperation apiOperation = AnnotationUtils.findAnnotation(classMethod, ApiOperation.class);
            if (apiOperation == null) {
                continue;
            }
            RequestMapping requestMapping = AnnotatedElementUtils.findMergedAnnotation(classMethod, RequestMapping.class);
            if (requestMapping == null) {
                continue;
            }
            String url = getUrl(basePath, requestMapping);
            int traceEventFlag = 1;
            if ("GET:/ccu-fleet/vehicle/realtime".equals(url)) {
                traceEventFlag = 0;
            }
            String name = apiOperation.value();
            if (StrUtil.isBlank(name)) {
                name = classMethod.getName();
            }
            list.add(new PermissionRedisVO(name, url, traceEventFlag));
        }
        return list;
    }

    /**
     * 获取url权限
     * @param basePath 基础路径 /ccu-fleet/vehicle
     * @param requestMapping 方法上的@RequestMapping注解
     * @return 权限的路径 "GET:/ccu-system/users"
     */
    private String getUrl(String basePath, RequestMapping requestMapping) {
        RequestMethod[] requestMethods = requestMapping.method();
        String urlPerm = basePath;
        if (requestMethods.length > 0) {
            RequestMethod method = requestMethods[0];
            urlPerm = method.name().toUpperCase() + ":" + urlPerm;
        }
        String[] methodPaths = requestMapping.path();
        String methodPath = "";
        if (methodPaths.length > 0) {
            methodPath = methodPaths[0];
        }
        if (urlPerm.endsWith("/")) {
            urlPerm = urlPerm.substring(0, urlPerm.length() - 1);
        }
        if (StrUtil.isBlank(methodPath)) {
            return urlPerm;
        }
        if (!methodPath.startsWith("/")) {
            methodPath = "/" + methodPath;
        }
        methodPath = methodPath.replaceAll("\\{.*?}", "*");
        return urlPerm + methodPath;
    }
}
