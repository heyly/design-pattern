package com.bosch.rbcd.common.web.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class PermissionRedisVO implements Serializable {

    private static final long serialVersionUID = 4930443417335379830L;

    private String name;

    private String urlPerm;

    private int traceEventFlag = 1;
}
