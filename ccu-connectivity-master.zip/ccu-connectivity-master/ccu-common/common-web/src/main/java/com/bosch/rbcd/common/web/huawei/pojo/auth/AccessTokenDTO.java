package com.bosch.rbcd.common.web.huawei.pojo.auth;

public class AccessTokenDTO {
    private AuthDTO auth;

    public AuthDTO getAuth() {
        return auth;
    }

    public void setAuth(AuthDTO auth) {
        this.auth = auth;
    }
}
