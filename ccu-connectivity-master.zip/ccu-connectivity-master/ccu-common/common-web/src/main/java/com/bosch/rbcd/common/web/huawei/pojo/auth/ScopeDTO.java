package com.bosch.rbcd.common.web.huawei.pojo.auth;

public class ScopeDTO {

    private ProjectDTO project;

    public ProjectDTO getProject() {
        return project;
    }

    public void setProject(ProjectDTO project) {
        this.project = project;
    }
}
