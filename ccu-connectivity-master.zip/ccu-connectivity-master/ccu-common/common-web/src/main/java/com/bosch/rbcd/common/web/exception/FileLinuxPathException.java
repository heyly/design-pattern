package com.bosch.rbcd.common.web.exception;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;

/**
 * Created by admin on 2017/10/30.
 */
@Slf4j
public class FileLinuxPathException {

    public static void runTime(File file) {
        try {
            String OS = System.getProperty("os.name").toLowerCase();
            if (OS.contains("linux")) {
                Runtime.getRuntime().exec("chmod 777 " + file.getPath());
            }
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.web.exception.FileLinuxPathException.runTime error!", e);
        }

    }

    public static void runPathTime(File file) {
        try {
            String OS = System.getProperty("os.name").toLowerCase();
            if (OS.contains("linux")) {
                Runtime.getRuntime().exec(" chmod -R 777 " + file.getPath());
            }
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.web.exception.FileLinuxPathException.runPathTime error!", e);
        }
    }
}
