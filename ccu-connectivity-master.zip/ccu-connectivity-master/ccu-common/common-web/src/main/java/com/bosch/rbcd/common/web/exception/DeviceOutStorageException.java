package com.bosch.rbcd.common.web.exception;

import com.bosch.rbcd.common.result.IResultCode;
import lombok.Getter;

@Getter
public class DeviceOutStorageException extends RuntimeException{

    public IResultCode resultCode;

    public DeviceOutStorageException(IResultCode errorCode) {
        super(errorCode.getMsg());
        this.resultCode = errorCode;
    }

    public DeviceOutStorageException(String message){
        super(message);
    }

    public DeviceOutStorageException(String message, Throwable cause){
        super(message, cause);
    }

    public DeviceOutStorageException(Throwable cause){
        super(cause);
    }
}
