package com.bosch.rbcd.common.web.vo.echarts;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname LineChartVO
 * @description TODO
 * @date 2023/5/8 15:47
 */
@Data
@ApiModel("折线图")
@AllArgsConstructor
@NoArgsConstructor
public class LineChartVO {
    @ApiModelProperty("横坐标刻度名称")
    List<String> xAxisData;

    @ApiModelProperty("数据值")
    List<Double> data;

}
