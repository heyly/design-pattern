package com.bosch.rbcd.common.web.validate;

import javax.validation.groups.Default;

/**
 * 用户创建时的参数校验
 */
public interface Create extends Default {
}
