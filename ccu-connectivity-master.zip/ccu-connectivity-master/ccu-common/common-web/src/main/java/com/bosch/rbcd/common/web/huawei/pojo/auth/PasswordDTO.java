package com.bosch.rbcd.common.web.huawei.pojo.auth;

public class PasswordDTO {

    private UserDTO user;

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }
}
