package com.bosch.rbcd.common.web.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Select选择器默认Option属性
 * @author LUK3WX
 */
@Data
@NoArgsConstructor
public class OptionVO<T> {

    public OptionVO(T value, String label) {
        this.value = value;
        this.label = label;
    }

    private T value;

    private String label;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private List<OptionVO<T>> children;

}