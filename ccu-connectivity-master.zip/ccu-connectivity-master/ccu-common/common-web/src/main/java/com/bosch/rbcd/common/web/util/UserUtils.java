package com.bosch.rbcd.common.web.util;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.json.JSONObject;
import com.bosch.rbcd.common.constant.GlobalConstants;
import com.bosch.rbcd.common.constant.SecurityConstants;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

/**
 * JWT工具类
 * @author LUK3WX
 */
@Slf4j
public class UserUtils {

    /**
     * 解析JWT获取用户ID
     *
     * @return
     */
    public static Long getUserId() {
        Long userId = null;
        JSONObject jwtPayload = JwtUtils.getJwtPayload();
        if (jwtPayload != null) {
            userId = jwtPayload.getLong("userId");
        }
        return userId;
    }

    /**
     * 解析JWT获取获取用户名
     *
     * @return
     */
    public static String getUsername() {
        JSONObject jwt = JwtUtils.getJwtPayload();
        return Objects.nonNull(jwt) ? jwt.getStr(SecurityConstants.USER_NAME_KEY) : "";
    }

    /**
     * 解析JWT获取获取用户昵称
     *
     * @return
     */
    public static String getRealName() {
        JSONObject jwt = JwtUtils.getJwtPayload();
        return Objects.nonNull(jwt) ? jwt.getStr(SecurityConstants.REAL_NAME_KEY) : "";
    }

    /**
     * JWT获取用户角色列表
     *
     * @return 角色列表
     */
    public static List<String> getRoles() {
        List<String> roles;
        JSONObject payload =  JwtUtils.getJwtPayload();
        if (payload.containsKey(SecurityConstants.JWT_AUTHORITIES_KEY)) {
            roles = payload.getJSONArray(SecurityConstants.JWT_AUTHORITIES_KEY).toList(String.class);
        } else {
            roles = Collections.emptyList();
        }
        return roles;
    }

    /**
     * 是否「超级管理员」
     *
     * @return
     */
    public static boolean isRoot() {
        List<String> roles = getRoles();
        return CollectionUtil.isNotEmpty(roles) && roles.contains(GlobalConstants.ROOT_ROLE_CODE);
    }

    /**
     * 获取用户部门id
     * @return
     */
    public static Long getDeptId() {
        JSONObject payload = JwtUtils.getJwtPayload();
        Long deptId = null;
        if (Objects.nonNull(payload) && payload.containsKey(SecurityConstants.JWT_DEPT_KEY)) {
            deptId = payload.getLong(SecurityConstants.JWT_DEPT_KEY);
        }
        return deptId;
    }

    /**
     * 获取appId和角色的对应关系
     * @return
     */
    public static Map<Long, String> getAppRoleMap() {
        Map<Long, String> result = new HashMap<>();
        try {
            JSONObject payload = JwtUtils.getJwtPayload();
            if (payload!= null && payload.containsKey("appRoleMap")) {
                JSONObject appRoleObj = payload.getJSONObject("appRoleMap");
                for (Map.Entry<String, Object> next : appRoleObj) {
                    Long appId = Long.parseLong(next.getKey());
                    String roleCode = (String) next.getValue();
                    result.put(appId, roleCode);
                }
            }
        } catch (NumberFormatException e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    /**
     * 判断此app下用户是否是root
     * @param appId
     * @return
     */
    public static boolean isAppRoot(Long appId) {
        Map<Long, String> appRoleMap = getAppRoleMap();
        return appRoleMap.containsKey(appId) && appRoleMap.get(appId).equals(GlobalConstants.ROOT_ROLE_CODE);
    }
}
