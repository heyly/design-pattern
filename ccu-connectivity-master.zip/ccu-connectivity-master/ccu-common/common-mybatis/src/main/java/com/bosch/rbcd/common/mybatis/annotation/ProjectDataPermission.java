package com.bosch.rbcd.common.mybatis.annotation;

import java.lang.annotation.*;

/**
 * 项目数据权限注解
 * @author LUK3WX
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface ProjectDataPermission {

    /**
     * 数据权限 {@link com.baomidou.mybatisplus.extension.plugins.inner.DataPermissionInterceptor}
     * 项目相关表别名
     */
    String projectAlias() default "p";

    String projectIdField() default "id";
}

