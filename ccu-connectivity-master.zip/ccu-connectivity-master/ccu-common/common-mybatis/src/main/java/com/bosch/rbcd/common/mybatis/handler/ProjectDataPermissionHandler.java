package com.bosch.rbcd.common.mybatis.handler;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.baomidou.mybatisplus.extension.plugins.handler.DataPermissionHandler;
import com.bosch.rbcd.common.constant.GlobalConstants;
import com.bosch.rbcd.common.mybatis.annotation.ProjectDataPermission;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.common.web.util.UserUtils;
import lombok.extern.slf4j.Slf4j;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.expression.Parenthesis;
import net.sf.jsqlparser.expression.ValueListExpression;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.relational.ExpressionList;
import net.sf.jsqlparser.expression.operators.relational.InExpression;
import net.sf.jsqlparser.schema.Column;

import java.lang.reflect.Method;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 数据过滤处理器，目前只实现了根据组织过滤
 * 使用场景：查询语句中必须关联(left join)了organization或者vehicle_user表，而且起了别名
 * 不关联或者没有起别名就起不到数据过滤的效果
 *
 * @author LUK3WX
 */
@Slf4j
public class ProjectDataPermissionHandler implements DataPermissionHandler {

    private RedisUtils redisUtils;

    public ProjectDataPermissionHandler(RedisUtils redisUtils) {
        this.redisUtils = redisUtils;
    }

    @Override
    public Expression getSqlSegment(Expression where, String mappedStatementId) {
        try {
            Class<?> clazz = Class.forName(mappedStatementId.substring(0, mappedStatementId.lastIndexOf(".")));
            String methodName = mappedStatementId.substring(mappedStatementId.lastIndexOf(".") + 1);
            Method[] methods = clazz.getDeclaredMethods();
            for (Method method : methods) {
                ProjectDataPermission annotation = method.getAnnotation(ProjectDataPermission.class);
                if (ObjectUtils.isNotEmpty(annotation) && (method.getName().equals(methodName) || (method.getName() + "_COUNT").equals(methodName))) {
                    if (UserUtils.getUserId() == null) {
                        return where;
                    }
                    // 获取当前的用户角色
//                    Object appId = redisTemplate.opsForHash().get(GlobalConstants.APP_SERVICE_KEY, "ccu-fleet");
                    Object appId = redisUtils.hget(GlobalConstants.APP_SERVICE_KEY, "ccu-fleet");
                    boolean isRoot = UserUtils.isAppRoot(Long.parseLong(appId.toString()));
                    if (isRoot) {
                        // 如果是超级管理员则放行
                        return where;
                    } else {
                        List<Integer> projectIdSet = JSON.parseArray(redisUtils.hget(GlobalConstants.USER_PROJECT_KEY, UserUtils.getUserId().toString()).toString(), Integer.class);
                        return dataScopeFilter(annotation.projectAlias(), annotation.projectIdField(), where, projectIdSet);
                    }
                }
            }
        } catch (ClassNotFoundException e) {
            log.error("ProjectDataPermissionHandler.getSqlSegment error!", e);
        }
        return where;
    }

    private static Expression dataScopeFilter(String projectAlias, String projectIdField, Expression where, List<Integer> projectIdSet) {
        InExpression inExpression = new InExpression();
        ExpressionList expressionList = new ExpressionList();
        ValueListExpression result = new ValueListExpression();
        if (projectIdSet != null && !projectIdSet.isEmpty()) {
            List<LongValue> projectIdList = projectIdSet.stream().map(LongValue::new).collect(Collectors.toList());
            expressionList.addExpressions(projectIdList);
        } else {
            expressionList.addExpressions(CollectionUtil.newArrayList(new LongValue(-1)));
        }
        result.setExpressionList(expressionList);
        String column = StrUtil.isNotBlank(projectAlias) ? projectAlias + "." + projectIdField : projectIdField;
        inExpression.setLeftExpression(new Column(column));
        inExpression.setRightExpression(result);
        return ObjectUtils.isNotEmpty(where) ? new AndExpression(where, new Parenthesis(inExpression)) : inExpression;
    }
}
