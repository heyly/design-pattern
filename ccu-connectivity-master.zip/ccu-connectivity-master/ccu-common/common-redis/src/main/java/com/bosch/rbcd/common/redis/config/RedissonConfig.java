//package com.bosch.rbcd.common.redis.config;
//
//import cn.hutool.core.util.StrUtil;
//import org.redisson.Redisson;
//import org.redisson.api.RedissonClient;
//import org.redisson.config.Config;
//import org.redisson.config.SingleServerConfig;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
///**
// * 分布式锁 Redisson 配置
// *
// * @author LUK3WX
// */
//@Configuration
//public class RedissonConfig {
//
//    @Value("${spring.redis.host}")
//    private String host;
//
//    @Value("${spring.redis.port}")
//    private String port;
//
//    @Value("${spring.redis.password}")
//    private String password;
//
//    @Value("${spring.redis.database}")
//    private Integer database;
//
//
//    @Bean(destroyMethod = "shutdown")
//    public RedissonClient redissonClient() {
//        Config config = new Config();
//        SingleServerConfig singleServerConfig = config.useSingleServer();
//        singleServerConfig.setAddress(StrUtil.format("redis://{}:{}", host, port));
//        singleServerConfig.setDatabase(database);
//        if (StrUtil.isNotBlank(password)) {
//            singleServerConfig.setPassword(password);
//        }
//        return Redisson.create(config);
//    }
//
//}
