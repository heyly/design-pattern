package com.bosch.rbcd.common.redis.bo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.annotation.Id;

import java.util.List;
import java.util.Map;

/**
 * Redis key:RealTimeData 实体信息
 *
 * @author WBO3WX
 */
@ApiModel("Redis 车辆实时数据实体对象")
@Data
public class RealTimeData {
    @Id
    private String id;

    @ApiModelProperty("车辆标识")
    private String vehicleNo;


    @ApiModelProperty("车辆id")
    private String vehicleId;

    @ApiModelProperty("车辆名称")
    private String vehicleName;

    @ApiModelProperty("vin号")
    private String vin;

    @ApiModelProperty("设备编号")
    private String imei;

    @ApiModelProperty("状态")
    private Integer status;

    @ApiModelProperty("车牌号")
    private String plateNumber;

    @ApiModelProperty("车辆类型")
    private String vehicleType;

    @ApiModelProperty("排放")
    private String emissions;

    @ApiModelProperty("省份")
    private String province;

    @ApiModelProperty("城市")
    private String city;

    @ApiModelProperty("")
    private String prjId;

    @ApiModelProperty("配置标识")
    private String confId;

    @ApiModelProperty("配置编号")
    private String confNo;

    @ApiModelProperty("")
    private String samplingTime;

    @ApiModelProperty("原始数据")
    private String rawData;

    @ApiModelProperty("经度")
    private String longitude;

    @ApiModelProperty("纬度")
    private String latitude;

    @ApiModelProperty("行驶里程")
    private String  mileage;

    @ApiModelProperty("运行时间")
    private String runtime;

    @ApiModelProperty("车速")
    private String  speed;

    @ApiModelProperty("功率")
    private String power;

    @ApiModelProperty("soc")
    private String soc;

    @ApiModelProperty("")
    private String direction;

    @ApiModelProperty("创建时间")
    private String createAt;

    /**
     * Measurement 0
     * LCM 1
     */
    private String deviceType;

    @ApiModelProperty("实时数据")
    private Map<String, Object> data;

    List<Map<String, Object>> dataList;

    @Override
    public String toString() {
        return "RealTimeData{" + "id='" + id + '\'' + ", imei='" + imei + '\'' + ", ccuId='" + vehicleNo + '\'' + ", prjId='" + prjId + '\'' + ", confId='" + confId + '\'' + ", confNo='" + confNo + '\'' + ", samplingTime='" + samplingTime + '\'' + ", rawData='" + rawData + '\'' + ", longitude='" + longitude + '\'' + ", latitude='" + latitude + '\'' + ", direction='" + direction + '\'' + ", deviceType='" + deviceType + '\'' + ", data=" + data + '}';
    }
}
