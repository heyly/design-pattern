package com.bosch.rbcd.common.security.dto;

import cn.hutool.core.collection.CollectionUtil;
import com.bosch.rbcd.common.security.common.PasswordEncoderTypeEnum;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 系统管理用户认证信息
 * @author LUK3WX
 */
@Data
public class SysUserDetails implements UserDetails {

    /**
     * 扩展字段：用户ID
     */
    private Long userId;

    /**
     * 扩展字段：部门ID
     */
    private Long deptId;

    /**
     * 扩展字段：用户拥有的appId和role映射
     */
    private Map<Long, String> appRoleMap;

    private Boolean needChangePassword;

    /**
     * 扩展字段：认证身份标识，枚举值如下：
     *
     * @see com.bosch.rbcd.common.enums.AuthenticationIdentityEnum
     */
    private String authenticationIdentity;

    private String realName;

    private LocalDateTime updatePasswordTime;

    /**
     * 默认字段
     */
    private String username;
    private String password;
    private Boolean enabled;
    private Collection<SimpleGrantedAuthority> authorities;

    /**
     * 系统管理用户
     */
    public SysUserDetails(UserAuthDTO user) {
        this.setUserId(user.getUserId());
        this.setUsername(user.getUserName());
        this.setPassword(PasswordEncoderTypeEnum.BCRYPT.getPrefix() + user.getPassword());
        this.setEnabled(user.getStatus() == 1);
        this.setRealName(user.getRealName());
        this.appRoleMap = user.getUserAppRoles().stream().collect(Collectors.toMap(UserAuthDTO.UserAppRoleDTO::getAppId, UserAuthDTO.UserAppRoleDTO::getRole));
        this.setNeedChangePassword(user.getChangePasswordFlag() == 0);
        if (CollectionUtil.isNotEmpty(user.getRoles())) {
            authorities = new ArrayList<>();
            user.getRoles().forEach(role -> authorities.add(new SimpleGrantedAuthority(role)));
        }
        this.setDeptId(user.getDeptId());
        this.setUpdatePasswordTime(user.getUpdatePasswordTime());
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.authorities;
    }

    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public String getUsername() {
        return this.username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
}
