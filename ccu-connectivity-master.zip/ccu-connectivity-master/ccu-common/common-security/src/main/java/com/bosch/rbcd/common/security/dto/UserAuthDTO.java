package com.bosch.rbcd.common.security.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.List;

/**
 * OAuth2认证用户信息传输层对象
 * @author LUK3WX
 */
@Data
@Accessors(chain = true)
public class UserAuthDTO {

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 用户密码
     */
    private String password;

    private Integer status;

    /**
     * 用户角色编码集合 ["ROOT","ADMIN"]
     */
    private List<String> roles;

    private List<Long> roleIds;

    private Long deptId;

    private String email;

    private String realName;

    /**
     * 用户拥有的app和权限的映射
     * appId -> role
     */
    private List<UserAppRoleDTO> userAppRoles;

    private Integer changePasswordFlag;

    private LocalDateTime updatePasswordTime;

    @Data
    public static class UserAppRoleDTO {

        private Long appId;

        private Long roleId;

        private String role;
    }
}
