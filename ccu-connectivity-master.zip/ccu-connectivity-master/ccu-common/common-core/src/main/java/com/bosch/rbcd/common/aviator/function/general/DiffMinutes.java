package com.bosch.rbcd.common.aviator.function.general;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.googlecode.aviator.runtime.function.AbstractFunction;
import com.googlecode.aviator.runtime.type.AviatorLong;
import com.googlecode.aviator.runtime.type.AviatorObject;

import java.util.Map;

/**
 * @description: 两时间相差分钟数, 参数类型为String
 */
public class DiffMinutes extends AbstractFunction {

    @Override
    public AviatorObject call(Map<String, Object> env, AviatorObject arg1, AviatorObject arg2) {
        long diffMinutes = 0L;
        String time1Str = (String) arg1.getValue(env);
        String time2Str = (String) arg2.getValue(env);
        if (StrUtil.isNotBlank(time1Str) && StrUtil.isNotBlank(time2Str)) {
            DateTime time1 = DateUtil.parse(time1Str);
            DateTime time2 = DateUtil.parse(time2Str);
            diffMinutes = DateUtil.between(time1, time2, DateUnit.MINUTE);
        }
        return AviatorLong.valueOf(diffMinutes);
    }

    @Override
    public String getName() {
        return "minutes.diff";
    }
}
