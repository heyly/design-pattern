package com.bosch.rbcd.common.constant;

/**
 * 全局常量
 * @author LUK3WX
 */
public interface GlobalConstants {

    /**
     * 全局状态-是
     */
    Integer STATUS_YES = 1;

    /**
     * 超级管理员角色编码
     */
    String ROOT_ROLE_CODE = "SUPER_ADMIN";

    /**
     * 系统一般管理员编码, 这个角色不需要进行车辆权限过滤
     */
    String ADMIN_ROLE_CODE = "ADMIN";

    /**
     * [ {接口路径:[角色编码]},...]
     */
    String URL_PERM_ROLES_KEY = "system:perm_roles_rule:url";

    /**
     * [{按钮权限:[角色编码]},...]
     */
    String BTN_PERM_ROLES_KEY = "system:perm_roles_rule:btn";

    String ORGANIZATION_FIELD = "organization_id";

    String PERM_INFO_KEY = "PermInfo";

    String APP_SERVICE_KEY = "sys:app:service";

    String USER_PROJECT_KEY = "fleet:user:project";
}
