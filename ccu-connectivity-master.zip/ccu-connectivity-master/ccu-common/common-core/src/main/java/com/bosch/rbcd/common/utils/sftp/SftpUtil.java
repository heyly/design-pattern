package com.bosch.rbcd.common.utils.sftp;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Component
@RequiredArgsConstructor
public class SftpUtil {

    private final SshClient sshClient;

    private volatile AtomicInteger threadNum = new AtomicInteger(1);

    public ExecutorService threadPool = new ThreadPoolExecutor(
            3,
            3,
            60L, TimeUnit.SECONDS,
            new LinkedBlockingQueue<Runnable>(),
            (ThreadFactory) runnable -> {
                return new Thread(runnable, Integer.toString(threadNum.getAndIncrement()));
            });

    public ConcurrentHashMap<Integer, SshClient> sshClientConcurrentHashMap = new ConcurrentHashMap<>();

    public void uploadFile(String localSourcePath, String remoteDestinationPath) throws Exception {
        uploadFile(localSourcePath, remoteDestinationPath, 0);
    }

    public void uploadFile(String localSourcePath, String remoteDestinationPath, int retryTimes) throws Exception {
        try {
            checkAndCreateDirectory(remoteDestinationPath);
            upload(localSourcePath, remoteDestinationPath);
            sshClient.disconnect();
        } catch (IOException ioException) {
            if (retryTimes > 5) {
                throw ioException;
            }
            log.error(ioException.toString());
            uploadFile(localSourcePath, remoteDestinationPath, ++retryTimes);
        } catch (Exception e) {
            log.error(e.toString());
            throw e;
        }
    }

    public void upload(String localSourcePath, String remoteDestinationPath) throws IOException {
        File localFile = new File(localSourcePath);
        if (!localFile.exists()) {
            return;
        }

        if (localFile.isDirectory()) {
            File[] localChildFiles = localFile.listFiles();
            if (ArrayUtils.isEmpty(localChildFiles)) {
                return;
            }
            for (File localChildFile : localChildFiles) {
                String localChildFilePath = localChildFile.getAbsolutePath();
                String remoteChildDestinationPath = remoteDestinationPath + "/" + localChildFile.getName();
                if (localChildFile.isDirectory()) {
                    if (!isDirectoryExists(remoteChildDestinationPath)) {
                        sshClient.createDirectory(remoteChildDestinationPath);
                    }
                    upload(localChildFilePath, remoteChildDestinationPath);
                } else {
                    threadPool.submit(new UploadCsvTask(sshClientConcurrentHashMap, localChildFilePath, remoteChildDestinationPath));
                }
            }
        } else {
            threadPool.submit(new UploadCsvTask(sshClientConcurrentHashMap, localSourcePath, remoteDestinationPath));
        }
    }

    public void checkAndCreateDirectory(String path, ChannelSftp channelSftp) {
        boolean result = isDirectoryExists(path, channelSftp);
        if (!result) {
            try {
                channelSftp.mkdir(path);
            } catch (SftpException e) {
                log.error("SftpUtil.checkAndCreateDirectory error!", e);
            }
        }
    }

    public boolean isDirectoryExists(String path, ChannelSftp channelSftp) {
        boolean isExist = false;
        try {
            SftpATTRS sftpATTRS = channelSftp.lstat(path);
            isExist = true;
        } catch (Exception e) {
            if (e.getMessage().toLowerCase().equals("no such file")) {
                isExist = false;
            }
        }
        return isExist;
    }

    public void checkAndCreateDirectory(String path) throws IOException {
        boolean exist = isDirectoryExists(path);
        if (!exist) {
            sshClient.createDirectory(path);
        }
    }

    public boolean isDirectoryExists(String path) throws IOException {
        return sshClient.fileExists(path);
    }
}
