package com.bosch.rbcd.common.constant;

/**
 * Redis key Name 常量类
 *
 * @author WBO3WX
 */
public interface RedisKeyConstants {

    /**
     * 实时数据key name前缀
     */
    String REALTIME_DATA_KEY_SUFFIX = "RealTimeData:";

    /**
     * 实时数据Hash 数据体 data
     */
    String REALTIME_DATA_BODY = "data";
}
