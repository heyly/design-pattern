package com.bosch.rbcd.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname EcuMetaTypeEnum
 */
@ToString
@AllArgsConstructor
@Getter
public enum EcuMetaTypeEnum {
    /**
     * 软件版本
     */
    SOFTWARE("01", "Software Version", "软件版本"),

    /**
     * 硬件版本
     */
    HARDWARE("02", "Hardware Version", "硬件版本"),

    /**
     * 标定版本
     */
    CALIBRATE("03", "Calibrate Version", "标定版本");

    /**
     * code
     */
    private final String code;

    /**
     * 英文名称
     */
    private final String enLabel;

    /**
     * 中文名称
     */
    private final String cnLabel;

    /**
     * 获取中文解释
     */
    public static String getCnLabel(String code) {
        String cnLabel = "";
        for (EcuMetaTypeEnum status : values()) {
            if (code.equals(status.getCode())) {
                cnLabel = status.getCnLabel();
            }
        }
        return cnLabel;
    }
}
