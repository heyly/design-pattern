package com.bosch.rbcd.common.algorithm;

import cn.hutool.core.util.StrUtil;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

@Slf4j
public class OverThreadCheckAlgorithm extends AbsAlgorithm {

    public OverThreadCheckAlgorithm(String ruleName, String ruleDetails) {
        super(ruleName, ruleDetails);
    }

    public List<RuleDataEntity> extractorRule() {
        List<RuleDataEntity> ruleList = new LinkedList<>();
        String rules = this.ruleDetails;
        while (StrUtil.contains(rules, "${")) {
            RuleDataEntity entity = new RuleDataEntity();
            if (StrUtil.contains(rules, "||")) {
                entity.setPreAppendType(1);
            } else if (StrUtil.contains(rules, "&&")) {
                entity.setPreAppendType(2);
            }
            String label = rules.substring(rules.indexOf("${") + 2, rules.indexOf("}"));
            if (StrUtil.contains(label, ",")) {
                String fncName = label.split(",")[1];
                int fncWindow = Integer.parseInt(label.split(",")[2]);
                if (!RuleDataEntity.FUNCTION_LIST.contains(fncName) || fncWindow > 20) {
                    throw new RuntimeException();
                }
                entity.setFunctions(fncName);
                entity.setFunctionsWindows(fncWindow);
                label = label.split(",")[0];
            }
            entity.setLabel(label);
            rules = rules.substring(rules.indexOf("}") + 1);
            rules = rules.trim();
            if (rules.startsWith(">")) {
                rules = rules.substring(1);
                if (rules.startsWith("=")) {
                    rules = rules.substring(1);
                }
                entity.setType(new BigDecimal("1"));
            } else if (rules.startsWith("<")) {
                rules = rules.substring(1);
                if (rules.startsWith("=")) {
                    rules = rules.substring(1);
                }
                entity.setType(new BigDecimal("-1"));
            } else if (rules.startsWith("=")) {
                rules = rules.substring(1);
                if (rules.startsWith("=")) {
                    rules = rules.substring(1);
                }
                entity.setType(new BigDecimal("0"));
            }
            rules = rules.trim();
            String subtractor = rules.split(" ")[0];
            entity.setSubtractor(new BigDecimal(subtractor));
            rules = rules.trim();
            rules = rules.substring(subtractor.length());
            rules = rules.trim();
            if (rules.startsWith("for")) {
                rules = rules.substring(3);
                rules = rules.trim();
                String lastTimes = rules.split(" ")[0];
                rules = rules.substring(lastTimes.length());
                rules = rules.trim();
                int lastTimeValue = Integer.parseInt(lastTimes);
                if (lastTimeValue > 20) {
                    throw new RuntimeException();
                }
                entity.setLastTimes(lastTimeValue);
            }
            ruleList.add(entity);
        }
        return ruleList;
    }


    @Override
    public boolean validateRule() {
        boolean result = false;
        try {
            List<RuleDataEntity> ruleList = this.extractorRule();
            //判定规则集合是否满足以下两个条件：1.必须是同时是函数或者都不是函数；2.必须每个规则的窗口是一致的
            if (ruleList.size() > 1) {
                for (int i = 0; i < ruleList.size() - 1; i++) {
                    if (StrUtil.isBlank(ruleList.get(i).getFunctions()) != StrUtil.isBlank(ruleList.get(i + 1).getFunctions())) {
                        result = false;
                        break;
                    }
                    if (ruleList.get(i).getLastTimes() != ruleList.get(i + 1).getLastTimes()) {
                        result = false;
                        break;
                    }
                    result = true;
                }
            }
        } catch (Exception e) {
            log.error("数据规则验证失败，请检查：{}", e.getMessage(), e);
        }
        return result;
    }
}
