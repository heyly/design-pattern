package com.bosch.rbcd.common.utils;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 字节数 字节数据处理类
 * @author whan
 *
 */
public class ByteHexUtils {

    private static final char[] HexCharArr = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

    private static final String HexStr = "0123456789abcdef";


    static public String decodeHexString(String str) {
        str =HighLowHex(spaceHex(str));
        String value =new BigInteger(str, 16).toString(10);
        return value;
    }

    static private String spaceHex(String str){
        char[] array= str.toCharArray();
        if(str.length()<=2) return str;
        StringBuffer buffer =new StringBuffer();
        for(int i=0;i<array.length;i++){
            int start =i+1;
            if(start%2==0){
                buffer.append(array[i]).append(" ");
            }else{
                buffer.append(array[i]);
            }
        }
        return buffer.toString();
    }

    static private String HighLowHex(String str){

        if(str.trim().length()<=2) return str;
        List<String> list = Arrays.asList( str.split(" "));
        Collections.reverse(list);
        StringBuffer stringBuffer = new StringBuffer();
        for(String string:list){
            stringBuffer.append(string);
        }
        return stringBuffer.toString();
    }

    /**
     * LocalDateTime转为自定义的时间格式的字符串
     * @param localDateTime
     * @param format
     * @return
     */
    public static String getDateTimeAsString(LocalDateTime localDateTime, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return localDateTime.format(formatter);
    }

    /**
     * long类型的timestamp转为LocalDateTime
     * @param timestamp
     * @return
     */
    public static LocalDateTime getDateTimeOfTimestamp(long timestamp) {
        Instant instant = Instant.ofEpochMilli(timestamp * 1000);
        ZoneId zone = ZoneId.systemDefault();
        return LocalDateTime.ofInstant(instant, zone);
    }

    public static int Byte2_To_Int(byte [] content,int offset)
    {
        int v=0;

        v=		(int)((int)(content[offset+0] & 0xFF) |
                ((int)(content[offset+1] & 0xFF)<<8));

        return v;

    }

    /**
     * 4字节转换成整形
     * @param
     * @return
     */
    public static long Byte4_To_long(byte [] content,int offset)
    {
        long v=0;
        v=		(long)((long)(content[offset+0] & 0xFF) |
                ((long)(content[offset+1] & 0xFF)<<8)|
                ((long)(content[offset+2] & 0xFF)<<16)|
                ((long)(content[offset+3] & 0xFF)<<24));
        return v;
    }

    public static int Byte1_To_Int(byte[] content,int offset)
    {
        int v=0;

        v=		(int)((int)(content[offset+0] & 0xFF));

        return v;
    }

    /**
     *	BE,高字节在前的方式解析数据,有符号处理
     * @param n
     * @param content
     * @param offset
     * @return
     */
    public static long Byten_To_Long_BE_Signed(int n,byte [] content,int offset)
    {
        ByteBuffer buffer = ByteBuffer.wrap(content,offset,n);
        // ByteBuffer.order(ByteOrder) 方法指定字节序,即大小端模式(BIG_ENDIAN/LITTLE_ENDIAN)
        // ByteBuffer 默认为大端(BIG_ENDIAN)模式
        buffer.order(ByteOrder.BIG_ENDIAN);
        long value = 0;
        switch (n){
            case 1:
                value = buffer.get();break;
            case 2:
                value = buffer.getShort();break;
            case 4:
                value = buffer.getInt();break;
            case 8:
                value = buffer.getLong();break;
        }
        return value;
    }

    /**
     * LE,有符号类型值处理
     * @param n
     * @param content
     * @param offset
     * @return
     */
    public static long Byten_To_Long_Signed(int n,byte [] content,int offset)
    {
        ByteBuffer buffer = ByteBuffer.wrap(content,offset,n);
        // ByteBuffer.order(ByteOrder) 方法指定字节序,即大小端模式(BIG_ENDIAN/LITTLE_ENDIAN)
        // ByteBuffer 默认为大端(BIG_ENDIAN)模式
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        long value = 0;
        switch (n){
            case 1:
                value = buffer.get();break;
            case 2:
                value = buffer.getShort();break;
            case 4:
                value = buffer.getInt();break;
            case 8:
                value = buffer.getLong();break;
        }
        return value;
    }

    /**
     * BE,高字节在前的方式解析数据
     * @param n
     * @param content
     * @param offset
     * @return
     */
    public static long Byten_To_Long_BE(int n,byte [] content,int offset)
    {
        long v=0l;

        for(int i=0;i<n;i++)
        {
            v |= (long)(content[offset+i] & 0xFF)<<(8*(n-1-i));
        }
        return v;

    }

    /**
     * LE,低字节在前的方式解析数据
     * @param n
     * @param content
     * @param offset
     * @return
     */
    public static long Byten_To_Long(int n,byte [] content,int offset)
    {
        long v=0;
        for(int i=0;i<n;i++)
        {
            v |= (long)(content[offset+i] & 0xFF)<<(8*i);
        }
        return v;

    }

    /**
     * 字节数组转16进制字符串
     * @param btArr
     * @return
     */
    public static String byteArrToHex(byte[] btArr) {
        char[] strArr = new char[btArr.length * 2];
        int i = 0;
        for (byte bt : btArr) {
            strArr[i++] = HexCharArr[bt>>>4 & 0xf];
            strArr[i++] = HexCharArr[bt & 0xf];
        }
        return new String(strArr);
    }

    /**
     * 16机制字符串转字节数组
     * @param hexStr
     * @return
     */
    public static byte[] hexToByteArr(String hexStr) {
        char[] charArr = hexStr.toCharArray();
        byte[] btArr = new byte[charArr.length / 2];
        int index = 0;
        for (int i = 0; i < charArr.length; i++) {
            int highBit = HexStr.indexOf(charArr[i]);
            int lowBit = HexStr.indexOf(charArr[++i]);
            btArr[index] = (byte) (highBit << 4 | lowBit);
            index++;
        }
        return btArr;
    }

    public static void main(String[] args) {
        String s = "7e0501830538363736303530353333323937363700f4000080800102ff6b05c606f270c87280010000000000000000000001fdbaa705887cf6463e38a131e18da7168f9d02dc3de17f6da0621e3a077b372dad9883785e5d270ab2c913186c571a9bdec7872d9224b7b15fb54af9e7e8caaefb340f174addd8b316f61d14d15b687df02bf6a8755e7d6a214bc728d51fee0e16befacdabf3ce72298225022ff21445839e7df6743ea2f44612b23ac1e5c33d696629454a68f986653560360a54ceb7e3a651612529fcb04f5dfa110649f4ebababc5f91d12292e743c935925d8ef35f8cf8f3d32f41d1e8939521ac14a878709e2b25813e105cdeff1370b5c02a3e29d69df7a8ff91ce079ad43920bf5df94b23e65af883051d20b0937ed1616196b3e77eb429651348e799f3563fb182722d3b55e5d589539f35fc9b1746ea7efd1789f408ffab16642b178746f02f230d9658f0b7b56eb4f67764ed5aa1d1317041620f9f00af8317c2ad0a5f3dcd03f9a840e6cee0916863d188d8213346eb8c864dd9a366a2501cc60540938b6a2d9db140238eb97a460d7d8b24b43e214f2c9116cca909529db60d20d0f673c8cedcdccb30afb300b191fee1ac4e056e1f14564912db47fbe8a00365f900f7648909970192f1578e1b3a5f801dc40ef43f65497d6493dc53f71959d336dcdc1e3d800a250c2037ddf388e153bd50e4a94d34bf5d6aa5bccb9d6b12635e5aeb91c00cbb089c818c176b17708bc2db0e028671bbaa6448e21799f9236f2f266c842ed9c3b8928571dfe744b1e3874361722e39277c980d7f5bafa86ebf4183d56b2a0982f16735187289be9363814e6135a036d8d080428c9541abc1e28056d489ad0e7e0179638ae61a75660973e17226d357921fe7b2b5ab26364aba0c259cca84674840ba8290ffc99dc92143b0f29f72a493155a5da142bf99782984657a039a7551778f683349d08fbab0bba82893a804c1e766826437da6edfcef7a4b6fef8dc618fce4f42128e859b5bed65bf721c65e7d4706e6b13bb6e6d93dcba15004e6e4b30063f79940ad87eb981e8af79ae57344d6c01d2462f10ff247b63ede58b6898a0c64668fdb20949b1210099a272fec3dc0349c9f4db7a910ad4d30671abfe24862ae59451d9532b466f91a3386676105832b8f48ddd107945a6b4a665f532bdd48014b85317c085896a310b4fd3632ea62c1842e18bac08aa6283c6846536ae36f2c1eb95a5b68e64bf6940c52b60502fcb34f3b32cb07df9e54bfc6d380c58aed63ea629cb73e0fc5d00d1e0c6547c170ab5acf1d63181e614f1d09d4d1965607b0f032bbc011e404bf97741c6045c390439582502252d24d5955033a8c94feaa1335cac432db1de9616accd97264af410b0b17014614fa7ffc7abc5284be944b5afe885e5d5e7d3d0e3c95f011c18d4a4d72c59acfcf3687956b18cadde5c5b16c2d4da9ee5018bea89929f24bd18a0297bace639fc385d02f24e9e2c3c5cc442097a676defadfde08c0c9b067c8147b05c2cbe2fbe36754ead919a24ccf5da409fd2e5dd8cc0029b204605cca2d48ce634d35a1e5ce1b236e25be0e8b8822844f3296f02f7aad3fa6d2fbe1acda69cc8d93576c1c9d5e7dc3167d5b7b70ddb975e3b743c9ed9b903a74c8a4d2a371c70f7d8cf3fc02d63b47eb4148406217697c769dedcb22f1f64f370a10f26c1836ea204e002131b7de0da73e4ceb82240287417625deff7603d0d4e3311f5179395fbc04be4c7cc6df81e06864077b283787fe3d2691ab6d843ace1199202153b8a692ebf7daa8e5409b37e130f19137979ac6c5a4a1a364500dbc43fcba0f4e94adaf1d1b110b63068f8b3fd22b2908d240a2b9c6a0375a78053ec16c4a6758a3761ed75e7d507486013139c9ba3d2620a4838d0f688945fbc212ab60490f3ebdf64bdda090f7334d1756659b43fff9a0d959ed6d80a5f7bc0c82091698a2929ac78640cc5757e93e0ec2d058faf67e";
        System.out.println(s.length());
        byte[] bytes = hexToByteArr(s);
    }

}
