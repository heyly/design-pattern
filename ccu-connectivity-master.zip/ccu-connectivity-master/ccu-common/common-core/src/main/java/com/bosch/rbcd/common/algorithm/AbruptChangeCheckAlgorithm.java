package com.bosch.rbcd.common.algorithm;

import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class AbruptChangeCheckAlgorithm extends AbsAlgorithm {

    public AbruptChangeCheckAlgorithm(String ruleName, String ruleDetails) {
        super(ruleName, ruleDetails);
    }

    /**
     * Pattern:"Range ${Vehe_v} > 20 in 3"
     */
    @Override
    public List<RuleDataEntity> extractorRule() {
        List<RuleDataEntity> ruleList = new ArrayList<>();
        String rules = this.ruleDetails;
        while (rules.contains("Range")) {
            RuleDataEntity entity = new RuleDataEntity();
            if (rules.startsWith("||")) {
                entity.setPreAppendType(1);
            } else if (rules.startsWith("&&")) {
                entity.setPreAppendType(2);
            }
            rules = rules.substring(5);
            String label = rules.substring(rules.indexOf("${") + 2, rules.indexOf("}"));
            entity.setLabel(label);
            rules = rules.substring(rules.indexOf("}") + 1);
            rules = rules.trim();
            if (rules.startsWith(">")) {
                rules = rules.substring(1);
                if (rules.startsWith("=")) {
                    rules = rules.substring(1);
                }
                entity.setType(new BigDecimal("1"));
            } else if (rules.startsWith("<")) {
                rules = rules.substring(1);
                if (rules.startsWith("=")) {
                    rules = rules.substring(1);
                }
                entity.setType(new BigDecimal("-1"));
            }
            rules = rules.trim();
            String subtractor = rules.split(" ")[0];
            entity.setSubtractor(new BigDecimal(subtractor));
            rules = rules.trim();
            rules = rules.substring(subtractor.length());
            rules = rules.trim();
            if (rules.startsWith("in")) {
                rules = rules.substring(2);
                rules = rules.trim();
                String lastTimes = rules.split(" ")[0];
                int lastTimeValue = Integer.parseInt(lastTimes);
                if (lastTimeValue > 20 || lastTimeValue < 1) {
                    throw new RuntimeException();
                }
                entity.setLastTimes(lastTimeValue);
            }
            ruleList.add(entity);
        }
        return ruleList;
    }

    @Override
    public boolean validateRule() {
        boolean result = false;
        try {
            List<RuleDataEntity> ruleList = this.extractorRule();
            if (ruleList.size() > 0) {
                result = true;
            }
        } catch (Exception e) {
            log.error("数据规则验证失败，请检查：{}", e.getMessage(), e);
        }
        return result;
    }
}
