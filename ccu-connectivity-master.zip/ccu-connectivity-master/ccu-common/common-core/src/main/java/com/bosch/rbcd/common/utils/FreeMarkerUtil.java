package com.bosch.rbcd.common.utils;

import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.util.Map;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname FreeMarkerUtil
 * @description TODO
 * @date 2022/11/28 15:55
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class FreeMarkerUtil {

    private final Configuration configuration;

    /**
    * @Description: 获取填充后的模板内容
    * @Param: [templateName, maps]
    * @return: java.lang.String
    * @Author: Wang Bo (BCSC-EPA2)
    * @Date: 2022/11/28
    */
    public String fillTemplate(String templateName, Map<String,Object> maps){
        try {
            Template template = configuration.getTemplate(templateName);
            return FreeMarkerTemplateUtils.processTemplateIntoString(template, maps);
        }catch (Exception e){
            log.error("FreeMarkerUtil.fillTemplate error!", e);
        }
        return null;
    }

    public String fillTemplate(String templateName, Object object){
        try {
            Template template = configuration.getTemplate(templateName);
            return FreeMarkerTemplateUtils.processTemplateIntoString(template, object);
        }catch (Exception e){
            log.error("FreeMarkerUtil.fillTemplate error!", e);
        }
        return null;
    }
}
