package com.bosch.rbcd.common.utils;

/**
 * 字符串处理工具类
 * @author whan
 *
 */
public class StrTools {

	public static String bytes2HexString(byte[] bytes) {
		StringBuilder stringBuilder = new StringBuilder("");
    	if (bytes == null || bytes.length <= 0) {
            return null;
        }

    	for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv+" ");
        }
        return stringBuilder.toString();
	}

	public static byte[] hexString2Bytes(String str) {
		if(str == null){
			return null;
		}
		str = str.toUpperCase();//add by kee 转化为大写
		if(str.length()%2==1) {
			str = "0" + str;
		}
		int len = str.length()/2;
		byte[] bytes = new byte[len];
		char[] achar = str.toCharArray();
		for(int i=0;i<len;i++) {
			int pos =i*2;
			bytes[i] = (byte) (toByte(achar[pos])<<4|toByte(achar[pos+1]));
		}
		return bytes;
	}

	public static byte[] hexString2Bytes4(String str) {
		//add by kee bug，当str中存在小写的abcdef时存在错译为f
		str = str.toUpperCase();//bug
		if(str.length()%2==1) {
			str = "0" + str;
		}
		int len = str.length()/2;
		byte[] bytes = new byte[4];
		char[] achar = str.toCharArray();
		for(int i=0;i<len;i++) {
			int pos =i*2;
			bytes[len-i-1] = (byte) (toByte(achar[pos])<<4|toByte(achar[pos+1]));
		}
		return bytes;
	}

	private static byte toByte(char c) {
		//此处代码写的不严谨
		byte b = (byte)"0123456789ABCDEF".indexOf(c);

		return b;
	}
}
