package com.bosch.rbcd.common.aviator.function.collection;

import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import com.googlecode.aviator.runtime.function.AbstractFunction;
import com.googlecode.aviator.runtime.type.AviatorBoolean;
import com.googlecode.aviator.runtime.type.AviatorObject;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;

/**
 * @description: 判断一个字符串是否在一个字符串区间集合中,逗号分隔
 */
public class IsIn extends AbstractFunction {

    @Override
    public AviatorObject call(Map<String, Object> env, AviatorObject value, AviatorObject range) {
        boolean inResult = false;
        if (Objects.nonNull(value.getValue(env)) && Objects.nonNull(range.getValue(env))) {
            String target =  StrUtil.removeAll(value.getValue(env).toString()," ");
            String rangeStr = StrUtil.removeAll(range.getValue(env).toString()," ");
            if (StrUtil.isNotBlank(rangeStr)) {
                String targetStr = NumberUtil.isNumber(target) ? String.valueOf(NumberUtil.parseInt(target)) : target;
                inResult = Arrays.asList(rangeStr.split(",")).contains(targetStr);
            }
        }
        return AviatorBoolean.valueOf(inResult);
    }


    @Override
    public AviatorObject call(Map<String, Object> env, AviatorObject value, AviatorObject min, AviatorObject max) {
        boolean inResult = false;
        if (Objects.nonNull(value.getValue(env)) && Objects.nonNull(min.getValue(env)) && Objects.nonNull(max.getValue(env))) {
            BigDecimal target = NumberUtil.toBigDecimal(value.getValue(env).toString());
            BigDecimal minValue = NumberUtil.toBigDecimal(min.getValue(env).toString());
            BigDecimal maxValue = NumberUtil.toBigDecimal(max.getValue(env).toString());
            inResult = NumberUtil.isIn(target, minValue, maxValue);
        }
        return AviatorBoolean.valueOf(inResult);
    }

    @Override
    public String getName() {
        return "isIn";
    }
}
