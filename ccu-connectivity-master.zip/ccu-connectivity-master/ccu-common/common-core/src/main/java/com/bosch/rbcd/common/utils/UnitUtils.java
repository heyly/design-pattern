package com.bosch.rbcd.common.utils;

import cn.hutool.core.util.StrUtil;

/**
 * 单位转化工具类
 */
public class UnitUtils {

    /**
     * 数值转化
     * @param sourceData 源数据
     * @param sourceUnit 源单位
     * @param targetUnit 目标单位
     * @return 目标数据
     */
    public static String convert(String sourceData, String sourceUnit, String targetUnit) {
        String targetData = sourceData;
        if (StrUtil.isBlank(sourceUnit) || StrUtil.isBlank(targetUnit)) {
            return targetData;
        }
        if (StrUtil.isNotBlank(sourceData) && !sourceData.equals("-") && !sourceData.equals("--")){
            double sourceValue = Double.parseDouble(sourceData);
            double targetValue = 0;
            sourceUnit = sourceUnit.replaceAll(" ", "");
            targetUnit = targetUnit.replaceAll(" ", "");
            // 温度
            if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "degC", "℃", "[degC]", "[℃]")
                    && StrUtil.equalsAnyIgnoreCase(targetUnit, "K", "[K]")) {
                targetValue = sourceValue + 273.15;
            } else if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "K", "[K]")
                    && StrUtil.equalsAnyIgnoreCase(targetUnit, "degC", "℃", "[degC]", "[℃]")) {
                targetValue = sourceValue - 273.15;
            } else {
                targetValue = sourceValue * getFacter(sourceUnit, targetUnit);
            }
            targetData = String.valueOf(targetValue);
        }
        return targetData;
    }

    /**
     * 获得转化因子
     * 源单位 * 倍率 = 目标单位
     * @param sourceUnit 源单位
     * @param targetUnit 目标单位
     * @return 倍率
     */
    public static double getFacter(String sourceUnit, String targetUnit) {
        if (StrUtil.isBlank(sourceUnit) || StrUtil.isBlank(targetUnit)) {
            return 1;
        }
        sourceUnit = sourceUnit.trim();
        targetUnit = targetUnit.trim();
        if (sourceUnit.startsWith("[") && sourceUnit.endsWith("]")) {
            sourceUnit = sourceUnit.substring(1, sourceUnit.length()-1);
        }
        if (targetUnit.startsWith("[") && targetUnit.endsWith("]")) {
            targetUnit = targetUnit.substring(1, targetUnit.length()-1);
        }
        sourceUnit = sourceUnit.trim();
        targetUnit = targetUnit.trim();
        if (StrUtil.isBlank(sourceUnit) || StrUtil.isBlank(targetUnit)) {
            return 1;
        }
        if (sourceUnit.equalsIgnoreCase(targetUnit)) {
            return 1;
        }
        if (sourceUnit.equals("-") || targetUnit.equals("-")) {
            return 1;
        }

        // 长度
        if (sourceUnit.equalsIgnoreCase("nm")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "um", "µm")){
                return 0.001;
            } else if (targetUnit.equalsIgnoreCase("mm")) {
                return 0.000001;
            } else if (targetUnit.equalsIgnoreCase("cm")) {
                return 0.0000001;
            } else if (targetUnit.equalsIgnoreCase("dm")) {
                return 0.00000001;
            } else if (targetUnit.equalsIgnoreCase("m")) {
                return 0.000000001;
            } else if (targetUnit.equalsIgnoreCase("km")) {
                return 0.000000000001;
            }
        } else if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "um", "µm")) {
            if (targetUnit.equalsIgnoreCase("nm")) {
                return 1000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "um", "µm")) {
                return 1;
            } else if (targetUnit.equalsIgnoreCase("mm")) {
                return 0.001;
            } else if (targetUnit.equalsIgnoreCase("cm")) {
                return 0.0001;
            } else if (targetUnit.equalsIgnoreCase("dm")) {
                return 0.00001;
            } else if (targetUnit.equalsIgnoreCase("m")) {
                return 0.000001;
            } else if (targetUnit.equalsIgnoreCase("km")) {
                return 0.000000001;
            }
        } else if (sourceUnit.equalsIgnoreCase("mm")) {
            if (targetUnit.equalsIgnoreCase("nm")) {
                return 1000000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "um", "µm")) {
                return 1000;
            } else if (targetUnit.equalsIgnoreCase("cm")) {
                return 0.1;
            } else if (targetUnit.equalsIgnoreCase("dm")) {
                return 0.01;
            } else if (targetUnit.equalsIgnoreCase("m")) {
                return 0.001;
            } else if (targetUnit.equalsIgnoreCase("km")) {
                return 0.000001;
            }
        } else if (sourceUnit.equalsIgnoreCase("cm")) {
            if (targetUnit.equalsIgnoreCase("nm")) {
                return 10000000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "um", "µm")) {
                return 10000;
            } else if (targetUnit.equalsIgnoreCase("mm")) {
                return 10;
            } else if (targetUnit.equalsIgnoreCase("dm")) {
                return 0.1;
            } else if (targetUnit.equalsIgnoreCase("m")) {
                return 0.01;
            } else if (targetUnit.equalsIgnoreCase("km")) {
                return 0.00001;
            }
        } else if (sourceUnit.equalsIgnoreCase("dm")) {
            if (targetUnit.equalsIgnoreCase("nm")) {
                return 100000000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "um", "µm")) {
                return 100000;
            } else if (targetUnit.equalsIgnoreCase("mm")) {
                return 100;
            } else if (targetUnit.equalsIgnoreCase("cm")) {
                return 10;
            } else if (targetUnit.equalsIgnoreCase("m")) {
                return 0.1;
            } else if (targetUnit.equalsIgnoreCase("km")) {
                return 0.0001;
            }
        } else if (sourceUnit.equalsIgnoreCase("m")) {
            if (targetUnit.equalsIgnoreCase("nm")) {
                return 1000000000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "um", "µm")) {
                return 1000000;
            } else if (targetUnit.equalsIgnoreCase("mm")) {
                return 1000;
            } else if (targetUnit.equalsIgnoreCase("cm")) {
                return 100;
            } else if (targetUnit.equalsIgnoreCase("dm")) {
                return 10;
            } else if (targetUnit.equalsIgnoreCase("km")) {
                return 0.001;
            }
        } else if (sourceUnit.equalsIgnoreCase("km")) {
            if (targetUnit.equalsIgnoreCase("nm")) {
                return 1000000000000.0;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "um", "µm")) {
                return 1000000000;
            } else if (targetUnit.equalsIgnoreCase("mm")) {
                return 1000000;
            } else if (targetUnit.equalsIgnoreCase("cm")) {
                return 100000;
            } else if (targetUnit.equalsIgnoreCase("dm")) {
                return 10000;
            } else if (targetUnit.equalsIgnoreCase("m")) {
                return 1000;
            }
        }

        // 功率
        if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "W", "J/s", "Nm/s")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "W", "J/s", "Nm/s")) {
                return 1;
            } else if (targetUnit.equalsIgnoreCase("kW")) {
                return 0.001;
            }
        } else if (sourceUnit.equalsIgnoreCase("kW")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "W", "J/s", "Nm/s")) {
                return 1000;
            }
        }

        // 电压
        if (sourceUnit.equalsIgnoreCase("mV")) {
            if (targetUnit.equalsIgnoreCase("V") || targetUnit.equalsIgnoreCase("Vdc")) {
                return 0.001;
            }
        } else if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "V", "Vdc")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "V", "Vdc")) {
                return 1;
            } else if (targetUnit.equalsIgnoreCase("mV")) {
                return 1000;
            }
        }


        // 电流
        if (sourceUnit.equalsIgnoreCase("mA")) {
            if (targetUnit.equalsIgnoreCase("A")) {
                return 0.001;
            }
        } else if (sourceUnit.equalsIgnoreCase("A")) {
            if (targetUnit.equalsIgnoreCase("mA")) {
                return 1000;
            }
        }

        // 电阻
        if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "Ohm", "Ω")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "Ohm", "Ω")) {
                return 1;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "kOhm", "kΩ")) {
                return 0.001;
            }
        } else if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "kOhm", "kΩ")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "Ohm", "Ω")) {
                return 1000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "kOhm", "kΩ")) {
                return 1;
            }
        }

        // 压强
        if (sourceUnit.equalsIgnoreCase("Pa")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "hPa", "mbar")) {
                return 0.01;
            } else if (targetUnit.equalsIgnoreCase("kPa")) {
                return 0.001;
            } else if (targetUnit.equalsIgnoreCase("bar")) {
                return 0.00001;
            } else if (targetUnit.equalsIgnoreCase("MPa")) {
                return 0.000001;
            }
        } else if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "hPa", "mbar")) {
            if (targetUnit.equalsIgnoreCase("Pa")) {
                return 100;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "hPa", "mbar")) {
                return 1;
            } else if (targetUnit.equalsIgnoreCase("kPa")) {
                return 0.1;
            } else if (targetUnit.equalsIgnoreCase("bar")) {
                return 0.001;
            } else if (targetUnit.equalsIgnoreCase("MPa")) {
                return 0.0001;
            }
        } else if (sourceUnit.equalsIgnoreCase("kPa")) {
            if (targetUnit.equalsIgnoreCase("Pa")) {
                return 1000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "hPa", "mbar")) {
                return 10;
            } else if (targetUnit.equalsIgnoreCase("bar")) {
                return 0.01;
            } else if (targetUnit.equalsIgnoreCase("MPa")) {
                return 0.001;
            }
        } else if (sourceUnit.equalsIgnoreCase("bar")) {
            if (targetUnit.equalsIgnoreCase("Pa")) {
                return 100000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "hPa", "mbar")) {
                return 1000;
            }  else if (targetUnit.equalsIgnoreCase("kPa")){
                return 100;
            } else if (targetUnit.equalsIgnoreCase("MPa")) {
                return 0.01;
            }
        } else if (sourceUnit.equalsIgnoreCase("MPa")) {
            if (targetUnit.equalsIgnoreCase("Pa")) {
                return 1000000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "hPa", "mbar")) {
                return 10000;
            }  else if (targetUnit.equalsIgnoreCase("kPa")){
                return 1000;
            } else if (targetUnit.equalsIgnoreCase("bar")) {
                return 10;
            }
        }

        // 速度
        if (sourceUnit.equalsIgnoreCase("m/s")) {
            if (targetUnit.equalsIgnoreCase("km/s")) {
                return 0.001;
            } else if (targetUnit.equalsIgnoreCase("km/h")) {
                return 3.6;
            }
        } else if (sourceUnit.equalsIgnoreCase("km/s")) {
            if (targetUnit.equalsIgnoreCase("m/s")) {
                return 1000;
            } else if (targetUnit.equalsIgnoreCase("km/h")) {
                return 3600;
            }
        } else if (sourceUnit.equalsIgnoreCase("km/h")) {
            if (targetUnit.equalsIgnoreCase("m/s")) {
                return 1 / 3.6;
            } else if (targetUnit.equalsIgnoreCase("km/s")) {
                return 1 / 3600.0;
            }
        }

        // 温度
        if (sourceUnit.equals("degC") && targetUnit.equals("℃")) {
            return 1;
        }
        if (sourceUnit.equals("℃") && targetUnit.equals("degC")) {
            return 1;
        }

        // 百分比
        if ((sourceUnit.equals("percent") && targetUnit.equals("%"))
                || sourceUnit.equals("%") && targetUnit.equals("percent")) {
            return 1;
        }

        // 能量
        if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "Nm", "J")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "Nm", "J")) {
                return 1;
            } else if (targetUnit.equalsIgnoreCase("kJ")) {
                return 0.001;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "kWh", "deg", "°")) {
                return 1.0 / 3600000;
            }
        } else if (sourceUnit.equalsIgnoreCase("kJ")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "Nm", "J")) {
                return 1000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "kWh", "deg", "°")) {
                return 1.0 / 3600;
            }
        } else if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "kWh", "deg", "°")) {
            if (targetUnit.equalsIgnoreCase("J")) {
                return 3600000;
            } else if (targetUnit.equalsIgnoreCase("kJ")) {
                return 3600;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "kWh", "deg", "°")) {
                return 1;
            }
        }

        // 转速
        if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "rpm", "1/min")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "rpm", "1/min")) {
                return 1;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "deg/s", "°/s")) {
                return 6;
            } else if (targetUnit.equalsIgnoreCase("rad/s")) {
                return Math.PI / 30;
            }
        } else if (sourceUnit.equalsIgnoreCase("rad/s")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "rpm", "1/min")) {
                return 30.0 / Math.PI;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "deg/s", "°/s")) {
                return 180.0 / Math.PI;
            }
        } else if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "deg/s", "°/s")) {
            if (StrUtil.equalsAnyIgnoreCase(targetUnit, "rpm", "1/min")) {
                return 1.0 / 6;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "deg/s", "°/s")) {
                return 1;
            } else if (targetUnit.equalsIgnoreCase("rad/s")) {
                return Math.PI / 180;
            }
        }

        // 时间
        if (sourceUnit.equalsIgnoreCase("h")) {
            if (targetUnit.equalsIgnoreCase("min")) {
                return 60;
            } else if (targetUnit.equalsIgnoreCase("s")) {
                return 3600;
            } else if (targetUnit.equalsIgnoreCase("ms")) {
                return 3600000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "us", "μs")) {
                return 3600000000.0;
            } else if (targetUnit.equalsIgnoreCase("ns")) {
                return 3600000000000.0;
            }
        } else if (sourceUnit.equalsIgnoreCase("min")) {
            if (targetUnit.equalsIgnoreCase("h")) {
                return 1.0 / 60;
            } else if (targetUnit.equalsIgnoreCase("s")) {
                return 60.0;
            } else if (targetUnit.equalsIgnoreCase("ms")) {
                return 60.0 * 1000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "us", "μs")) {
                return 60.0 * 1000000;
            } else if (targetUnit.equalsIgnoreCase("ns")) {
                return 60.0 * 1000000000;
            }
        } else if (sourceUnit.equalsIgnoreCase("s")) {
            if (targetUnit.equalsIgnoreCase("h")) {
                return 1.0 / 3600;
            } else if (targetUnit.equalsIgnoreCase("min")) {
                return 1.0 / 60;
            } else if (targetUnit.equalsIgnoreCase("ms")) {
                return 1000;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "us", "μs")) {
                return 1000000;
            } else if (targetUnit.equalsIgnoreCase("ns")) {
                return 1000000000;
            }
        } else if (sourceUnit.equalsIgnoreCase("ms")) {
            if (targetUnit.equalsIgnoreCase("h")) {
                return 0.001 / 3600;
            } else if (targetUnit.equalsIgnoreCase("min")) {
                return 0.001 / 60;
            } else if (targetUnit.equalsIgnoreCase("s")) {
                return 0.001;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "us", "μs")) {
                return 1000;
            } else if (targetUnit.equalsIgnoreCase("ns")) {
                return 1000000;
            }
        } else if (StrUtil.equalsAnyIgnoreCase(sourceUnit, "us", "μs")) {
            if (targetUnit.equalsIgnoreCase("h")) {
                return 0.000001 / 3600;
            } else if (targetUnit.equalsIgnoreCase("min")) {
                return 0.000001 / 60;
            } else if (targetUnit.equalsIgnoreCase("s")) {
                return 0.000001;
            } else if (targetUnit.equalsIgnoreCase("ms")) {
                return 0.001;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "us", "μs")) {
                return 1;
            } else if (targetUnit.equalsIgnoreCase("ns")) {
                return 1000;
            }
        } else if (sourceUnit.equalsIgnoreCase("ns")) {
            if (targetUnit.equalsIgnoreCase("h")) {
                return 0.000000001 / 3600;
            } else if (targetUnit.equalsIgnoreCase("min")) {
                return 0.000000001 / 60;
            } else if (targetUnit.equalsIgnoreCase("s")) {
                return 0.000000001;
            } else if (targetUnit.equalsIgnoreCase("ms")) {
                return 0.000001;
            } else if (StrUtil.equalsAnyIgnoreCase(targetUnit, "us", "μs")) {
                return 0.001;
            }
        }

        // 质量
        if (sourceUnit.equalsIgnoreCase("mg")) {
            if (targetUnit.equalsIgnoreCase("g")) {
                return 0.001;
            } else if (targetUnit.equalsIgnoreCase("kg")) {
                return 0.000001;
            } else if (targetUnit.equalsIgnoreCase("t")) {
                return 0.000000001;
            }
        } else if (sourceUnit.equalsIgnoreCase("g")) {
            if (targetUnit.equalsIgnoreCase("mg")) {
                return 1000;
            } else if (targetUnit.equalsIgnoreCase("kg")) {
                return 0.001;
            } else if (targetUnit.equalsIgnoreCase("t")) {
                return 0.000001;
            }
        } else if (sourceUnit.equalsIgnoreCase("kg")) {
            if (targetUnit.equalsIgnoreCase("mg")) {
                return 1000000;
            } else if (targetUnit.equalsIgnoreCase("g")) {
                return 1000;
            } else if (targetUnit.equalsIgnoreCase("t")) {
                return 0.001;
            }
        } else if (sourceUnit.equalsIgnoreCase("t")) {
            if (targetUnit.equalsIgnoreCase("mg")) {
                return 1000000000;
            } else if (targetUnit.equalsIgnoreCase("g")) {
                return 1000000;
            } else if (targetUnit.equalsIgnoreCase("kg")) {
                return 1000;
            }
        }

        return 1;
    }
}
