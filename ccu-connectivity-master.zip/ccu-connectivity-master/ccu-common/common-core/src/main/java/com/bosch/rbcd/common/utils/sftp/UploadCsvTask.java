package com.bosch.rbcd.common.utils.sftp;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Component
@RequiredArgsConstructor
@Slf4j
public class UploadCsvTask implements Runnable {

    //因为取余结果会多个0，所以实际的数量为 taskNum + 1
    public static final Integer taskNum = 2;

    private ConcurrentHashMap<Integer, SshClient> sshClients;

    private String localPath;

    private String remotePath;

    @Autowired
    private SshClient sshClient;

    public UploadCsvTask(ConcurrentHashMap<Integer, SshClient> sshClients, String localPath, String remotePath) {
        Assert.isTrue(Objects.nonNull(sshClients), "ssh clients is empty");
        Assert.isTrue(StringUtils.isNotBlank(localPath), "loacl path is blank");
        Assert.isTrue(StringUtils.isNotBlank(remotePath), "remote path is blank");
        this.sshClients = sshClients;
        this.localPath = localPath;
        this.remotePath = remotePath;
    }


    @Override
    public void run() {
        //特定的线程会使用固定的sshClient
        Integer threadNumber = Integer.valueOf(Thread.currentThread().getName()) % taskNum;
        SshClient sshClient = this.sshClients.get(threadNumber);
        if (Objects.isNull(sshClient) || !sshClient.isConnected()) {
            this.sshClients.put(threadNumber, sshClient);
        }

        try {
            log.info("start upload file " + sshClient.toString());
            uploadeFile(sshClient, 0);
        } catch (IOException ioException) {
            log.error(ioException.toString());
            return;
        }

//        if (hashVerify(sshClient)) {
        deleteLocalFile(this.localPath);
//        } else {
////            deleteRemoteFile(this.remotePath, sshClient);
//        }
    }

    /**
     * 上传失败直接重建sshClient实例
     *
     * @param sshClient
     * @param retryTimes
     */
    private void uploadeFile(SshClient sshClient, int retryTimes) throws IOException {
        try {
            sshClient.upload(this.localPath, this.remotePath);
        } catch (IOException ioException) {
            if (retryTimes < 3) {
                log.error(ioException.toString());
                log.error("retry time is " + retryTimes);
                sshClient.disconnect();
                uploadeFile(sshClient, ++retryTimes);
            } else {
                log.error(ioException.toString());
                throw ioException;
            }
        }
    }

    private boolean hashVerify(SshClient sshClient) {
        String localVerifyMd5 = getLocalPathMd5(this.localPath);
        String remoteVerifyMd5 = getRemotePathMd5(this.remotePath, sshClient);
        if (StringUtils.isBlank(localVerifyMd5) || StringUtils.isBlank(remoteVerifyMd5)) {
            return false;
        } else {
            return localVerifyMd5.equals(remoteVerifyMd5);
        }
    }

    /**
     * 地址请使用绝对路径
     *
     * @param localPath
     * @return
     */
    private String getLocalPathMd5(String localPath) {
        FileInputStream fileInputStream = null;
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            fileInputStream = new FileInputStream(localPath);
            byte[] buffer = new byte[10240];
            int length;
            while ((length = fileInputStream.read(buffer)) != -1) {
                md5.update(buffer, 0, length);
            }
            //转为16进制表示
            return new BigInteger(1, md5.digest()).toString(16);
        } catch (Exception e) {
            log.error(e.toString());
            return "localError";
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
            } catch (IOException e) {
                log.error(e.toString());
            }
        }
    }

    /**
     * 地址请使用绝对路径
     *
     * @param remotePath
     * @param sshClient
     * @return
     */
    private String getRemotePathMd5(String remotePath, SshClient sshClient) {
        try {
            return sshClient.executeMd5(remotePath);
        } catch (IOException ioException) {
            log.error("com.bosch.rbcd.common.utils.sftp.UploadCsvTask.getRemotePathMd5 error!", ioException);
            return "remoteError";
        }
    }

    private void deleteLocalFile(String localPath) {
        File file = new File(localPath);
        File parentFile = file.getParentFile();
        if (file.delete()) {
            if (parentFile.isDirectory() && ArrayUtils.isEmpty(parentFile.list())) {
                parentFile.delete();
            }
        }
    }

    private void deleteRemoteFile(String remotePath, SshClient sshClient) {
        try {
            sshClient.execute("rm -f " + remotePath);
        } catch (IOException ioException) {
            log.error(ioException.toString());
        }
    }
}
