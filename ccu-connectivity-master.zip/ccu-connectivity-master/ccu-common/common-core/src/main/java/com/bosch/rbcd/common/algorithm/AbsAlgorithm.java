package com.bosch.rbcd.common.algorithm;

import java.util.List;

public abstract class AbsAlgorithm {

    protected String ruleName;
    protected String ruleDetails;

    public AbsAlgorithm(String ruleName, String ruleDetails) {
        this.ruleName = ruleName;
        this.ruleDetails = ruleDetails;
    }

    public abstract List<RuleDataEntity> extractorRule();

    public abstract boolean validateRule();
}
