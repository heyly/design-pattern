package com.bosch.rbcd.common.result;

import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 分页响应结构体
 * @author LUK3WX
 */
@Data
@ApiModel("分页响应结构体")
public class PageResult<T> implements Serializable {

    @ApiModelProperty("业务响应码：00000 ： 一切ok")
    private String code;

    @ApiModelProperty("响应实体T泛型")
    private Record<T> data;

    @ApiModelProperty("业务消息")
    private String msg;

    public static <T> PageResult<T> success(IPage<T> page) {
        PageResult<T> result = new PageResult<>();
        result.setCode(ResultCode.SUCCESS.getCode());

        Record<T> data = new Record<T>();
        if (page != null) {
            data.setList(page.getRecords());
            data.setTotal(page.getTotal());
        }

        result.setData(data);
        result.setMsg(ResultCode.SUCCESS.getMsg());
        return result;
    }

    public static <T> PageResult<T> failed(IResultCode resultCode) {
        PageResult<T> result = new PageResult<>();
        result.setCode(resultCode.getCode());
        result.setMsg(resultCode.getMsg());
        return result;
    }

    public static <T> PageResult<T> failed(String msg) {
        PageResult<T> result = new PageResult<>();
        result.setCode(ResultCode.SYSTEM_EXECUTION_ERROR.getCode());
        result.setMsg(msg);
        return result;
    }

    @Data
    public static class Record<T> {

        @ApiModelProperty("页面记录列表")
        private List<T> list;

        @ApiModelProperty("总数")
        private long total;

    }

}
