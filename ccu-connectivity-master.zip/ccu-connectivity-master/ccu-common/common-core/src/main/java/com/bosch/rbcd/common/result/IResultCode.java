package com.bosch.rbcd.common.result;

/**
 * 返回码接口
 * @author LUK3WX
 **/
public interface IResultCode {

    String getCode();

    String getMsg();

}
