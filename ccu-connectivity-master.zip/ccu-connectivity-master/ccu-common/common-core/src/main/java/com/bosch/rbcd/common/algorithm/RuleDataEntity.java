package com.bosch.rbcd.common.algorithm;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 规则实体
 */
@Data
public class RuleDataEntity {

    public static final String FUNCTION_LIST = "AVERAGE,MEDIAN";

    @ApiModelProperty("标签")
    String label;

    @ApiModelProperty("当前值")
    BigDecimal currentValue;

    @ApiModelProperty("函数")
    String functions;

    @ApiModelProperty("函数参数")
    Integer functionsWindows;

    @ApiModelProperty("被减数")
    BigDecimal minuend;

    @ApiModelProperty("减数")
    BigDecimal subtractor;

    @ApiModelProperty("1大于,-1小于")
    BigDecimal type;

    @ApiModelProperty("0代表前序无连接，1代表或连接，2代表与连接")
    int preAppendType;

    @ApiModelProperty("持续时间")
    int lastTimes;

    public int getResult() {
        int result = this.minuend.subtract(this.subtractor).multiply(this.type).intValue();
        if (result > 0) {
            return 0;
        } else {
            return 1;
        }
    }

}
