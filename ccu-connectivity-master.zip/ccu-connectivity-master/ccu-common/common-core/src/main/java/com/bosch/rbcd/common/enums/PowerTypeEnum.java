package com.bosch.rbcd.common.enums;

import com.bosch.rbcd.common.base.IBaseEnum;
import lombok.Getter;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname PowerTypeEnum
 * @description 动力总成类型与powertrain_code 关系枚举类
 * @date 2023/3/28 19:50
 */
public enum PowerTypeEnum implements IBaseEnum<String> {
    /**
     * 氢动
     */
    FUEL_CELL("Fuel Cell", "01"),

    /**
     * 电动
     */
    ELECTRIC("Electric", "02"),

    /**
     * 柴油
     */
    DIESEL("Diesel", "03"),

    /**
     * 汽油
     */
    GASOLINE("Gasoline", "04"),

    /**
     * 天然气
     */
    NATURAL_GAS("Natural Gas", "05");

    @Getter
    private final String label;

    @Getter
    private final String value;

    PowerTypeEnum(String label, String value) {
        this.label = label;
        this.value = value;
    }

}
