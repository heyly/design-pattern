package com.bosch.rbcd.common.base;

import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 基础分页请求对象
 *
 * @author LUK3WX
 */
@Data
@ApiModel
public class BasePageQuery implements Serializable {

    private static final long serialVersionUID = -8245939229252531782L;

    @ApiParam(value = "页码", example = "1")
    @ApiModelProperty(value = "页码", example = "1")
    private int pageNum = 1;

    @ApiParam(value = "每页记录数", example = "10")
    @ApiModelProperty(value = "每页记录数", example = "10")
    private int pageSize = 10;

    @ApiParam(value = "排序字段", example = "[{\"column\":\"id\",\"asc\":\"true\"}]")
    @ApiModelProperty(value = "排序字段", example = "[{\"column\":\"id\",\"asc\":\"true\"}]")
    List<OrderItem> orders;

    @ApiParam("开始时间")
    @ApiModelProperty("开始时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    private Date startTime;

    @ApiParam("结束时间")
    @ApiModelProperty("结束时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    private Date endTime;

}
