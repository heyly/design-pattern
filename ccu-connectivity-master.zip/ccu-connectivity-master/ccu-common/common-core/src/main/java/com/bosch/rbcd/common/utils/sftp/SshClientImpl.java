package com.bosch.rbcd.common.utils.sftp;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.connection.channel.direct.Session;
import net.schmizz.sshj.sftp.*;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import net.schmizz.sshj.xfer.FileSystemFile;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class SshClientImpl implements SshClient {

    private String user;
    private String password;
    private Path privateKey;

    private String remoteHostIp;

    private SSHClient sshClient;

    private SFTPClient sftpClient;

    public SshClientImpl(String user, String password, String remoteHostIp) throws IOException {
        this(user, password, null, null, remoteHostIp);
    }

    public SshClientImpl(String user, Path privateKey, String remoteHostIp) throws IOException {
        this(user, null, privateKey, null, remoteHostIp);

    }

    public SshClientImpl(String user, String password, Path privateKey, Path knownHosts, String remoteHostIp) throws IOException {
        this.sshClient = new SSHClient();
        if (Objects.isNull(knownHosts)) {
            sshClient.addHostKeyVerifier(new PromiscuousVerifier());
        } else {
            sshClient.loadKnownHosts(knownHosts.toFile());
        }
        this.authUserPassword(user, password);
        this.authUserPublicKey(user, privateKey);
        this.remoteHostIp = remoteHostIp;
    }


    @Override
    public void authUserPassword(String user, String password) {
        this.user = user;
        this.password = password;
    }

    @Override
    public void authUserPublicKey(String user, Path privateKey) {
        this.user = user;
        this.privateKey = privateKey;
    }

    @Override
    public void connect() throws IOException {
        Assert.isTrue(Objects.nonNull(this.sshClient), "ssh client is null");
        Assert.isTrue((StringUtils.isNotBlank(this.password) || Objects.nonNull(this.privateKey)) && StringUtils.isNotBlank(this.user) && StringUtils.isNotBlank(this.remoteHostIp), "some parameter is null");
        sshClient.connect(this.remoteHostIp);
        if (privateKey != null) {
            sshClient.authPublickey(user, privateKey.toString());
        } else if (password != null) {
            sshClient.authPassword(user, password);
        } else {
            throw new RuntimeException("Either privateKey nor password is set. Please call one of the auth method.");
        }
    }

    @Override
    public void disconnect() {
        try {
            close();
        } catch (Exception ex) {
            // Ignore because disconnection is quietly
        }
    }

    @Override
    public void download(String remotePath, String localPath) throws IOException {
        try (SFTPClient sftpClient = sshClient.newSFTPClient()) {
            sftpClient.get(remotePath, new FileSystemFile(localPath));
        }
    }

    @Override
    public void upload(String localPath, String remotePath) throws IOException {
        Assert.isTrue(Objects.nonNull(this.sshClient), "ssh client is null");
        if (!sshClient.isConnected()) {
            connect();
        }
        if (Objects.isNull(this.sftpClient)) {
            this.sftpClient = sshClient.newSFTPClient();
        }

        try {
            this.sftpClient.put(new FileSystemFile(localPath), remotePath);
        } catch (SFTPException sftpException) {
            if (!sftpException.getStatusCode().equals(Response.StatusCode.OP_UNSUPPORTED)) {
                log.error(sftpException.toString());
                throw sftpException;
            }
        }
    }

    /**
     * 请注意此处使用绝对路径
     *
     * @param remotePath
     * @return
     * @throws IOException
     */
    @Override
    public boolean fileExists(String remotePath) throws IOException {

        Assert.isTrue(Objects.nonNull(this.sshClient), "ssh client is null");
        if (!sshClient.isConnected()) {
            connect();
        }
        if (Objects.isNull(this.sftpClient)) {
            this.sftpClient = sshClient.newSFTPClient();
        }
        try {
            return sftpClient.statExistence(remotePath) != null;
        } catch (Exception e) {
            log.error(e.toString());
            throw e;
        }
    }

    /**
     * 请注意此处使用绝对路径
     *
     * @param path
     * @throws IOException
     */
    @Override
    public void createDirectory(String path) throws IOException {
        Assert.isTrue(Objects.nonNull(this.sshClient), "ssh client is null");
        if (!sshClient.isConnected()) {
            connect();
        }
        if (Objects.isNull(this.sftpClient)) {
            this.sftpClient = sshClient.newSFTPClient();
        }
        this.sftpClient.mkdirs(path);
    }

    @Override
    public void move(String oldRemotePath, String newRemotePath) throws IOException {
        try (SFTPClient sftpClient = sshClient.newSFTPClient()) {
            sftpClient.rename(oldRemotePath, newRemotePath);
        }
    }

    @Override
    public void copy(String oldRemotePath, String newRemotePath) throws IOException {
        try (SFTPClient sftpClient = sshClient.newSFTPClient()) {
            sftpClient.put(oldRemotePath, newRemotePath);
        }
    }

    @Override
    public void delete(String remotePath) throws IOException {
        try (SFTPClient sftpClient = sshClient.newSFTPClient()) {
            sftpClient.rm(remotePath);
        }
    }


    @Override
    public List<String> listChildrenNames(String remotePath) throws IOException {
        return listChildrenNamesByFilter(remotePath, null);
    }

    @Override
    public List<String> listChildrenFolderNames(String remotePath) throws IOException {
        return listChildrenNamesByFilter(remotePath, RemoteResourceInfo::isDirectory);
    }

    @Override
    public List<String> listChildrenFileNames(String remotePath) throws IOException {
        return listChildrenNamesByFilter(remotePath, RemoteResourceInfo::isRegularFile);
    }

    private List<String> listChildrenNamesByFilter(String remotePath, RemoteResourceFilter remoteFolderResourceFilter) throws IOException {
        try (SFTPClient sftpClient = sshClient.newSFTPClient()) {
            List<String> children = new ArrayList<>();
            List<RemoteResourceInfo> childrenInfos = sftpClient.ls(remotePath, remoteFolderResourceFilter);
            childrenInfos.stream().forEach((childInfo) -> {
                children.add(childInfo.getName());
            });
            return children;
        }
    }

    /**
     * 需要注意每个session只能执行一个command
     *
     * @param remotePath
     * @throws IOException
     */
    @Override
    public String executeMd5(String remotePath) throws IOException {
        try (Session session = sshClient.startSession()) {
            Session.Command cmd = session.exec("md5sum " + remotePath);
            byte[] content = new byte[100];
            cmd.getInputStream().read(content);
            String[] result = new String(content).split("\\s+");
            if (!ArrayUtils.isEmpty(result) && result.length >= 2) {
                return result[0];
            } else {
                return "remoteError";
            }
        }
    }

    @Override
    public void execute(String command) throws IOException {
        try (Session session = sshClient.startSession()) {
            session.exec(command);
        }
    }

    @Override
    public boolean isConnected() {
        if (Objects.isNull(this.sshClient)) {
            return false;
        }
        return this.sshClient.isConnected();
    }

    @Override
    public void close() throws IOException {
        if (Objects.nonNull(sftpClient)) {
            try {
                this.sftpClient.close();
            } catch (IOException e) {
                log.error(e.toString());
            } finally {
                if (Objects.nonNull(sshClient)) {
                    sshClient.close();
                }
            }
        }
    }
}
