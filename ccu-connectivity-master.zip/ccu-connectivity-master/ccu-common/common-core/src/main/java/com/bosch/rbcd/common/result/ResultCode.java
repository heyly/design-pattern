package com.bosch.rbcd.common.result;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 响应码
 * A - 系统通用报错状态码
 * B - 系统内部其他报错状态码
 * @author LUK3WX
 **/
@AllArgsConstructor
@NoArgsConstructor
public enum ResultCode implements IResultCode, Serializable {

    SUCCESS("00000", "一切ok"),

    // ========================================== 系统通用报错状态码 start =============================================
    USER_ERROR("A0001", "用户端错误"),
    USER_LOGIN_ERROR("A0200", "用户登录异常"),

    USER_NOT_EXIST("A0201", "用户不存在"),
    MOBILE_NOT_EXIST("A0203", "手机号不存在"),
    USER_ACCOUNT_LOCKED("A0202", "用户账户被禁用"),
    USERNAME_OR_PASSWORD_ERROR("A0210", "用户名或密码错误，请通过【Forget Password】修改密码"),
    PASSWORD_ENTER_EXCEED_LIMIT("A0211", "客户端认证失败"),
    CLIENT_AUTHENTICATION_FAILED("A0212", "客户端认证失败"),
    TOKEN_INVALID_OR_EXPIRED("A0230", "token无效或已过期"),
    TOKEN_ACCESS_FORBIDDEN("A0231", "token已被禁止访问"),
    TOKEN_ACCESS_INVALID("A0232", "token已失效"),
    REFRESH_TOKEN_ACCESS_INVALID("A0241", "refresh token已过期"),

    AUTHORIZED_ERROR("A0300", "访问权限异常"),
    ACCESS_UNAUTHORIZED("A0301", "访问未授权"),
    FORBIDDEN_OPERATION("A0302", "演示环境禁止修改、删除重要数据，请本地部署后测试"),

    PARAM_ERROR("A0400", "用户请求参数错误"),
    RESOURCE_NOT_FOUND("A0401", "请求资源不存在"),
    PARAM_IS_NULL("A0410", "请求必填参数为空"),

    USER_UPLOAD_FILE_ERROR("A0700", "用户上传文件异常"),
    USER_UPLOAD_FILE_TYPE_NOT_MATCH("A0701", "用户上传文件类型不匹配"),
    USER_UPLOAD_FILE_SIZE_EXCEEDS("A0702", "用户上传文件太大"),
    USER_UPLOAD_IMAGE_SIZE_EXCEEDS("A0703", "用户上传图片太大"),

    SYS_APP_EXISTED("A10001", "系统应用app已存在"),
    SYS_ORG_CODE_CONFLICT("A10001", "组织code不能重复"),
    DUPLICATE_USERNAME("A10002", "用户名或手机号重复，操作失败"),
    OLD_PASSWORD_INCORRECT("A10003", "原密码输入错误"),
    VALIDATE_CODE_ERROR("A10004", "验证码无效或已过期"),

    TRACE_EVENT_QUERY_SIZE_ERROR("A10500", "审计日志只支持查看前一万条数据, 请修改查询条件"),
    PASSWORD_EXPIRED("A10501", "密码已过期，请修改密码"),
    // ========================================== 系统通用报错状态码 end =============================================

    // ========================================== 系统内部其他报错状态码 start =============================================
    SYSTEM_EXECUTION_ERROR("B0001", "系统执行出错"),
    SYSTEM_EXECUTION_TIMEOUT("B0100", "系统执行超时"),
    SYSTEM_ORDER_PROCESSING_TIMEOUT("B0100", "系统订单处理超时"),

    SYSTEM_DISASTER_RECOVERY_TRIGGER("B0200", "系统容灾功能被出发"),
    FLOW_LIMITING("B0210", "系统限流"),
    DEGRADATION("B0220", "系统功能降级"),

    SYSTEM_RESOURCE_ERROR("B0300", "系统资源异常"),
    SYSTEM_RESOURCE_EXHAUSTION("B0310", "系统资源耗尽"),
    SYSTEM_RESOURCE_ACCESS_ERROR("B0320", "系统资源访问异常"),
    SYSTEM_READ_DISK_FILE_ERROR("B0321", "系统读取磁盘文件失败"),

    CALL_THIRD_PARTY_SERVICE_ERROR("C0001", "调用第三方服务出错"),
    MIDDLEWARE_SERVICE_ERROR("C0100", "中间件服务出错"),
    INTERFACE_NOT_EXIST("C0113", "接口不存在"),

    MESSAGE_SERVICE_ERROR("C0120", "消息服务出错"),
    MESSAGE_DELIVERY_ERROR("C0121", "消息投递出错"),
    MESSAGE_CONSUMPTION_ERROR("C0122", "消息消费出错"),
    MESSAGE_SUBSCRIPTION_ERROR("C0123", "消息订阅出错"),
    MESSAGE_GROUP_NOT_FOUND("C0124", "消息分组未查到"),

    DATABASE_ERROR("C0300", "数据库服务出错"),
    DATABASE_TABLE_NOT_EXIST("C0311", "表不存在"),
    DATABASE_COLUMN_NOT_EXIST("C0312", "列不存在"),
    DATABASE_DUPLICATE_COLUMN_NAME("C0321", "多表关联中存在多个相同名称的列"),
    DATABASE_DEADLOCK("C0331", "数据库死锁"),
    DATABASE_PRIMARY_KEY_CONFLICT("C0341", "主键冲突"),

    // ------------------------------ 以下是fcev平台自定义异常msg ------------------------------------

    FIND_NO_VEHICLE_IN_ES("A0404", "ES中未找到车辆信息"),
    FIND_NO_VEHICLE_IN_DB("A0404", "数据库中未找到车辆信息"),

    VEHICLE_FIELD_VALUE_BLANK("A0400", "请检查所有必填属性是否都已经填值！！"),
    CAN_INFO_LABEL_CONFLICT("A0400", "can info label 不能重复"),
    PARSE_CONFIG_DETAIL_FAILED("A0500", "解析config detail失败"),
    CONFIG_NAME_CONFLICT("A0400", "配置名称已存在"),
    VEHICLE_PERMISSION_FORBIDDEN("A0403", "没有权限操作车辆"),

    IOT_GET_TOKEN_FAILED("A0500", "获取移动api token失败"),
    IOT_GET_SIM_PLATFORM_FAILED("A0500", "获取移动api sim归属平台失败"),
    IOT_GET_SIM_DATA_FAILED("A0500", "实时查询物联卡本月套餐内流量使用量失败"),
    IOT_GET_OFFERING_DETAIL_FAILED("A0500", "查询指定资费的详细信息失败"),
    IOT_GET_SIM_STATUS_FAILED("A0500", "通过卡号查询物联卡的状态信息失败"),
    SIM_INFO_CONFLICT("A0409", "sim卡已存在"),

    DOWNLOAD_FILE_FAILED("A0500", "下载文件失败"),
    IMEI_DUPLICATE("A0500", "IMEI重复"),

    PARSE_SIM_EXCEL_FAILED("A0500", "解析sim excel失败"),

    QUERY_HBASE_GPS_FAILED("A0500", "查询hbase gps数据失败"),


    // ------------------------------ 以下是 FOTA 平台自定义异常msg ------------------------------------
    INVALID_TASK_ID("F0200", "无效的任务id"),
    DELETE_TASK_FAILED("F0201", "删除任务失败，有未完成的任务"),
    CANCEL_TASK_FAILED("F0202", "取消任务失败，有进行中的任务"),

    // ------------------------------ 以下是 CCU Device 平台自定义异常msg ------------------------------------
    NO_PERMISSION("D0403", "该用户无权限访问"),
    DATE_RANGE_ERROR("D0500", "请检查时间范围是否正确"),
    UPDATE_PROJECT_FORBIDDEN("D0403", "只有项目创建者才可以更新！！"),

    // ------------------------------ 以下是 Fleet monitor 平台自定义异常msg ------------------------------------
    GROUP_NAME_EMPTY("FM001", "未设置车辆分组名字"),
    GROUP_NAME_REPEAT("FM002", "车辆分组名字已存在"),
    GROUP_HAS_CHILD("FM003", "该分组下存在子分组，无法分配车辆"),
    GROUP_HAS_VEHICLE("FM004", "该分组下存在车辆，无法创建子分组")
    ;

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMsg() {
        return msg;
    }

    private String code;

    private String msg;

    @Override
    public String toString() {
        return "{" +
                "\"code\":\"" + code + '\"' +
                ", \"msg\":\"" + msg + '\"' +
                '}';
    }


    public static ResultCode getValue(String code){
        for (ResultCode value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return SYSTEM_EXECUTION_ERROR; // 默认系统执行错误
    }
}
