package com.bosch.rbcd.common.utils;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2017/10/29 0029.
 */
@Slf4j
public class DateUtils {
    public static int getWeek(String str) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(str);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        //第几周
        int week = calendar.get(Calendar.WEEK_OF_MONTH);
        //第几天，从周日开始
        int day = calendar.get(Calendar.DAY_OF_WEEK);
        return week;
    }

    /**
     * 时间区间间隔90天中的全部数据
     *
     * @param cal
     * @param date
     * @param day
     * @return
     */
    public static List<Date> temporalGroup(Calendar cal, Date date, int day, List<Date> list) {
        if (cal.getTime().getTime() <= date.getTime()) {
            day += 90;
            list.add(cal.getTime());
            cal.add(Calendar.DATE, +day);
            temporalGroup(cal, date, day, list);
        } else {
            list.add(date);
        }
        return list;
    }

    /**
     * 获取当前本周一日期
     *
     * @return
     */
    public static Date theNowWeekFirst() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        Date date = cal.getTime();
        return date;
    }


    /**
     * 获取当前本月第一天
     *
     * @return
     */
    public static Date theNowMonthFirst() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.MONTH, 0);
        c.set(Calendar.DAY_OF_MONTH, 1);//设置为1号,当前日期既为本月第一天
        Date date = c.getTime();
        return date;
    }


    /**
     * 时间区间相隔的天数
     *
     * @param start
     * @param end
     * @return
     */
    public static int daysBetween(Date start, Date end) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(start);
        long time1 = cal.getTimeInMillis();
        cal.setTime(end);
        cal.add(Calendar.DATE, +1);
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        return Integer.parseInt(String.valueOf(between_days));
    }

    /**
     * 判断时间是否为当天
     *
     * @param needDate
     * @return
     */
    public static boolean isToday(Date needDate) {
        Date nowDate = new Date();
        SimpleDateFormat sdfToDay = new SimpleDateFormat("yyyyMMdd");
        if (sdfToDay.format(nowDate).equals(sdfToDay.format(needDate))) {
            return true;
        }
        return false;
    }

    public static boolean checkIsToday(String time) {
        Date nowDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
        try {
            if (sdf.format(nowDate).equals(sdf.parse(time))) {
                return true;
            }
        } catch (ParseException e) {
            log.error("com.bosch.rbcd.common.utils.DateUtils.checkIsToday error!", e);
        }
        return false;
    }

    /**
     * 获取当前日期的前一天
     * @return
     */
    public static Date getPreviousDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH,-1);
        Date previousDate = calendar.getTime();
        return previousDate;
    }

    /**
     * 获取当前日期的后一天
     * @return
     */
    public static Date getNextDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH,1);
        Date previousDate = calendar.getTime();
        return previousDate;
    }

    /**
     * 解析日期字符串
     * @param str
     * @param pattern
     * @return
     */
    public static Date format(String str, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);

        LocalDateTime time = LocalDateTime.parse(str, formatter);

        return Date.from(time.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date localDateTimeToDate(LocalDateTime localDateTime) {
        //获取系统默认时区
        ZoneId zoneId = ZoneId.systemDefault();
        //时区的日期和时间
        ZonedDateTime zonedDateTime = localDateTime.atZone(zoneId);
        //获取时刻
        return Date.from(zonedDateTime.toInstant());
    }


    /**
    * @Description: 按指定单位和步值 对时间拆分
    * @Param: [startTime, endTime, unit, step]
    * @return: java.util.List<java.util.Date>
    * @Author: Wang Bo (BCSC-EPA2)
    * @Date: 2023/7/5
    */
    public static List<Date> rangeToList(Date startTime, Date endTime, DateField unit, int step) {
        List<Date> rangeList = new ArrayList<>();
        rangeList.add(startTime);
        DateTime nextDate = DateUtil.ceiling(startTime, unit);
        if (DateField.HOUR_OF_DAY == unit) {
            int hour = DateUtil.hour(startTime, true);
            nextDate = DateUtil.offsetHour(DateUtil.beginOfDay(startTime), (hour / step + 1) * step);
        }
        // 直到nextDate大于结束时间
        while (nextDate.before(endTime)) {
            rangeList.add(DateUtil.date(nextDate));
            nextDate = DateUtil.ceiling(DateUtil.offset(nextDate, unit, step), unit);
        }
        rangeList.add(endTime);
        return rangeList;
    }
}
