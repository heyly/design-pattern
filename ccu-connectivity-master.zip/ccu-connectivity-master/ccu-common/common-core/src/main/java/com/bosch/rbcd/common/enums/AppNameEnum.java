package com.bosch.rbcd.common.enums;

import com.bosch.rbcd.common.base.IBaseEnum;
import lombok.Getter;

/**
 * 认证身份标识枚举
 * 后续如果还有其他登录方式可以扩展
 * @author LUK3WX
 */
public enum AppNameEnum implements IBaseEnum<Long> {
    SYSTEM("Systems Management", 1L),
    CCU_Device("CCU Device", 4L),
    Ramp_Up_Support("Ramp up support", 5L),
    Fleet_Monitoring("Fleet Monitoring", 7L),
    Fleet_FOTA("FOTA", 9L);

    @Getter
    private final String label;

    @Getter
    private final Long value;

    AppNameEnum(String label, Long value) {
        this.label = label;
        this.value = value;
    }
}
