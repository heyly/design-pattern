package com.bosch.rbcd.common.annotation;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 校验枚举值有效性
 * @author LUK3WX
 */
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = EnumValue.Validator.class)
public @interface EnumValue {

    String message() default "{custom.value.invalid}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    Class<? extends Enum<?>> enumClass();

    boolean ignoreEmpty() default true;

    class Validator implements ConstraintValidator<EnumValue, Object> {

        private Class<? extends Enum<?>> enumClass;

        private boolean ignoreEmpty;

        @Override
        public void initialize(EnumValue enumValue) {
            enumClass = enumValue.enumClass();
            ignoreEmpty = enumValue.ignoreEmpty();
        }

        @Override
        public boolean isValid(Object value, ConstraintValidatorContext constraintValidatorContext) {
            if (enumClass.isEnum() && (value != null || !ignoreEmpty)) {
                for (Enum<?> constant : enumClass.getEnumConstants()) {
                    if (constant.toString().equals(String.valueOf(value))) {
                        return true;
                    }
                }
                return false;
            }
            return true;
        }
    }
}
