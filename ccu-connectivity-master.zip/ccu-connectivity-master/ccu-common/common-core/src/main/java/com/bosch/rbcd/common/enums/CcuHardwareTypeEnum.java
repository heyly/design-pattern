package com.bosch.rbcd.common.enums;

import com.bosch.rbcd.common.base.IBaseEnum;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname PowerTypeEnum
 * @description 动力总成类型与powertrain_code 关系枚举类
 * @date 2023/3/28 19:50
 */
public enum CcuHardwareTypeEnum implements IBaseEnum<Long> {
    /**
     * CCU_A
     */
    CCU_A("CCU-A", 2L),

    /**
     * CCU_S
     */
    CCU_S("CCU-S", 3L),

    /**
     * CCU_S
     */
    CCU_E("CCU-E", 4L),

    /**
     * CCU_S
     */
    CCU_E_L2("CCU-E-L2", 5L);

    private final String label;

    private final Long value;

    CcuHardwareTypeEnum(String label, Long value) {
        this.label = label;
        this.value = value;
    }

    @Override
    public Long getValue() {
        return value;
    }

    @Override
    public String getLabel() {
        return label;
    }
}
