package com.bosch.rbcd.common.utils.communication;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname MailUtil
 * @description TODO
 * @date 2022/9/12 13:46
 */
@Slf4j
@RefreshScope
@Component
@RequiredArgsConstructor
public class MailUtil {

    @Autowired(required = false)
    private JavaMailSender sender;

    @Value("${mail.username}")
    private String from;

    /**
     * 发送纯文本的简单邮件
     *
     * @param to      .
     * @param subject .
     * @param content .
     */
    public void sendSimpleMail(String to, String subject, String content) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(from);
        message.setTo(to);
        message.setSubject(subject);
        message.setText(content);
        try {
            sender.send(message);
        } catch (Exception e) {
            log.error("发送简单邮件时发生异常！", e);
        }
    }

    @Async
    public void asyncSendSimpleMail(String[] to, String[] cc, String subject, String content) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(from);
        message.setTo(to);
        message.setCc(cc);
        message.setSubject(subject);
        message.setText(content);
        try {
            sender.send(message);
        } catch (Exception e) {
            log.error("发送简单邮件时发生异常！", e);
        }
    }

    /**
     * 发送html格式的邮件
     *
     * @param to      .
     * @param subject .
     * @param content .
     */
    @Async
    public void sendHtmlMail(String to, String subject, String content) {
        MimeMessage message = sender.createMimeMessage();
        try {
            //true表示需要创建一个multipart message
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(content, true);
            sender.send(message);
        } catch (MessagingException e) {
            log.error("发送html邮件时发生异常！", e);
        }
    }

    @Async
    public void asyncSendHtmlMail(String[] to, String[] cc, Integer priority,  String subject, String content) {
        MimeMessage message = sender.createMimeMessage();
        try {
            //true表示需要创建一个multipart message
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            // 设置邮件优先级
            if (Objects.nonNull(priority)) {
                helper.setPriority(priority);
            }
            helper.setFrom(from);
            helper.setTo(to);
            if (cc != null && cc.length > 0) {
                helper.setCc(cc);
            }
            helper.setSubject(subject);
            helper.setText(content, true);
            sender.send(message);
        } catch (MessagingException e) {
            log.error("发送html邮件时发生异常！", e);
        }
    }

    /**
     * 发送带附件的邮件
     *
     * @param to       .
     * @param subject  .
     * @param content  .
     * @param filePath .
     */
    public Boolean sendAttachmentsMail(String to, String subject, String content, String filePath) {
        MimeMessage message = sender.createMimeMessage();
        boolean flag = false;
        try {
            //true表示需要创建一个multipart message
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(content, true);
            FileSystemResource file = new FileSystemResource(new File(filePath));
            String fileName = filePath.substring(filePath.lastIndexOf(File.separator));
            helper.addAttachment(fileName, file);
            sender.send(message);
            flag = true;
            // 邮件发送成功，删除生成的附件
            FileUtil.del(filePath);
        } catch (MessagingException e) {
            log.error("发送带附件的邮件时发生异常！", e);
        } finally {
            FileUtil.del(filePath);
        }
        return flag;
    }

    /**
     * 发送嵌入静态资源（一般是图片）的邮件
     *
     * @param to         .
     * @param subject    .
     * @param priority
     * @param content    邮件内容，需要包括一个静态资源的id，比如：<img src=\"cid:rscId01\" >
     * @param contentMap 静态资源路径和文件名
     */
    public void sendInlineResourceMail(String to, String subject, Integer priority, String content, Map<String, String> contentMap, File attachment) {
        MimeMessage message = sender.createMimeMessage();
        try {
            //true表示需要创建一个multipart message
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(content, true);
            // 设置邮件优先级
            if (Objects.nonNull(priority)) {
                helper.setPriority(priority);
            }
            // 发送附件
            if (FileUtil.exist(attachment)) {
                FileSystemResource file = new FileSystemResource(attachment);
                helper.addAttachment(attachment.getName(), file);
            }
            // 添加邮箱首尾bosch-logo
            if (MapUtil.isNotEmpty(contentMap)) {
                contentMap.forEach((eleId, path) -> {
                    try {
                        helper.addInline(eleId, new FileSystemResource(new File(path)));
                    } catch (MessagingException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
            sender.send(message);
        } catch (MessagingException e) {
            log.error("发送嵌入静态资源的邮件时发生异常！", e);
        }
    }

    /**
     * 发送带附件的邮件
     *
     * @param to       .
     * @param subject  .
     * @param content  .
     * @param filePath .
     */
    public Boolean sendAttachmentsMail(String to, String subject,Integer priority, String content, String filePath, boolean delFlag) {
        MimeMessage message = sender.createMimeMessage();

        Boolean flag = false;

        try {
            //true表示需要创建一个multipart message
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(from);
            helper.setTo(to.split(";"));
            helper.setSubject(subject);
            helper.setText(content, true);
            // 设置邮件优先级
            if (Objects.nonNull(priority)) {
                helper.setPriority(priority);
            }
            if (FileUtil.exist(filePath)) {
                if (FileUtil.isDirectory(filePath)) {
                    List<File> subList = FileUtil.loopFiles(filePath);
                    for (File file : subList) {
                        String fileName = StrUtil.subAfter(file.getAbsolutePath(), File.separator, true);
                        helper.addAttachment(fileName, new FileSystemResource(file));
                    }
                } else {
                    FileSystemResource file = new FileSystemResource(new File(filePath));
                    String fileName = filePath.substring(filePath.lastIndexOf(File.separator));
                    helper.addAttachment(fileName, file);
                }
            }
            sender.send(message);
            flag = true;
        } catch (MessagingException e) {
            log.error("发送带附件的邮件时发生异常！", e);
        }
        if (delFlag) {
            try {
                FileUtil.del(filePath);
            } catch (Exception e) {
                log.error("文件删除失败！文件路径：" + filePath);
            }

        }
        return flag;
    }

    /**
     * 发送带附件的邮件
     *
     * @param to       .
     * @param subject  .
     * @param content  .
     * @param filePath .
     */
    @Async
    public Boolean asyncSendAttachmentsMail(String[] to, String[] cc, String subject,Integer priority, String content, String filePath, boolean delFlag) {
        MimeMessage message = sender.createMimeMessage();

        Boolean flag = false;

        try {
            //true表示需要创建一个multipart message
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(from);
            helper.setTo(to);
            if (cc != null) {
                helper.setCc(cc);
            }
            helper.setSubject(subject);
            helper.setText(content, true);
            // 设置邮件优先级
            if (Objects.nonNull(priority)) {
                helper.setPriority(priority);
            }
            if (FileUtil.isDirectory(filePath)) {
                List<File> subList = FileUtil.loopFiles(filePath);
                for (File file : subList) {
                    String fileName = StrUtil.subAfter(file.getAbsolutePath(), File.separator, true);
                    helper.addAttachment(fileName, new FileSystemResource(file));
                }
            } else {
                FileSystemResource file = new FileSystemResource(new File(filePath));
                String fileName = filePath.substring(filePath.lastIndexOf(File.separator));
                helper.addAttachment(fileName, file);
            }

            sender.send(message);
            flag = true;
        } catch (MessagingException e) {
            log.error("发送带附件的邮件时发生异常！", e);
        }
        if (delFlag) {
            FileUtil.del(filePath);
        }
        return flag;
    }
}
