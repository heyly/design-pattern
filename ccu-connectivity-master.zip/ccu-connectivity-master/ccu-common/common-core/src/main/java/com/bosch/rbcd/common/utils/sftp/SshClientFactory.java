package com.bosch.rbcd.common.utils.sftp;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

@Configuration
@RefreshScope
public class SshClientFactory {

    //    private static final String remoteHostIp = "122.112.248.216";
    @Value("${relay.server.host}")
    private String remoteHostIp;

    //    public static final String userName = "root";
    @Value("${relay.server.user}")
    private String userName;

    //    public static final String passWord = "P@ssw0rd3!";
    @Value("${relay.server.pwd}")
    private String passWord;

    /**
     * 返回一个已经建立ssh链接的实例
     *
     * @return
     * @throws IOException
     */
//    @Bean
    public SshClient createSshClient() throws IOException {
        SshClient sshClient = new SshClientImpl(userName, passWord, remoteHostIp);
        sshClient.connect();
        return sshClient;
    }
}
