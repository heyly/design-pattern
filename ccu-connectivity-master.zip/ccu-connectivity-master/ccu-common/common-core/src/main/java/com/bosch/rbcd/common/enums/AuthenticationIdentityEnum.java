package com.bosch.rbcd.common.enums;

import com.bosch.rbcd.common.base.IBaseEnum;
import lombok.Getter;

/**
 * 认证身份标识枚举
 * 后续如果还有其他登录方式可以扩展
 * @author LUK3WX
 */
public enum AuthenticationIdentityEnum implements IBaseEnum<String> {

    USERNAME("username", "用户名")
    ;

    @Getter
    private final String value;

    @Getter
    private final String label;

    AuthenticationIdentityEnum(String value, String label) {
        this.value = value;
        this.label = label;
    }
}
