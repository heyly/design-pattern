package com.bosch.rbcd.common.utils.sftp;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public interface SshClient extends AutoCloseable {

    void authUserPassword(String user, String password);

    void authUserPublicKey(String user, Path privateKey);

//    void setKnownHosts(Path knownHosts);

    void connect() throws IOException;

    void disconnect();

    void download(String remotePath, String localPath) throws IOException;

    void upload(String localPath, String remotePath) throws IOException;

    void move(String oldRemotePath, String newRemotePath) throws IOException;

    void copy(String oldRemotePath, String newRemotePath) throws IOException;

    void delete(String remotePath) throws IOException;

    boolean fileExists(String remotePath) throws IOException;

    void createDirectory(String directoryName) throws IOException;

    List<String> listChildrenNames(String remotePath) throws IOException;

    List<String> listChildrenFolderNames(String remotePath) throws IOException;

    List<String> listChildrenFileNames(String remotePath) throws IOException;

    String executeMd5(String command) throws IOException;

    void execute(String command) throws IOException;

    boolean isConnected();

}
