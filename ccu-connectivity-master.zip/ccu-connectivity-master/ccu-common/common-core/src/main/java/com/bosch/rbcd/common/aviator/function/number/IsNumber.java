package com.bosch.rbcd.common.aviator.function.number;

import cn.hutool.core.util.NumberUtil;
import com.googlecode.aviator.runtime.function.AbstractFunction;
import com.googlecode.aviator.runtime.type.AviatorBoolean;
import com.googlecode.aviator.runtime.type.AviatorObject;

import java.util.Map;
import java.util.Objects;

/**
 * @description: 向上取整
 */
public class IsNumber extends AbstractFunction {
    @Override
    public AviatorObject call(Map<String, Object> env, AviatorObject arg) {
        boolean result = false;
        if(Objects.nonNull(arg.getValue(env))){
            result = NumberUtil.isNumber(arg.getValue(env).toString());
        }
        return AviatorBoolean.valueOf(result);
    }

    @Override
    public String getName() {
        return "isNumber";
    }
}
