package com.bosch.rbcd.common.utils;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname NioFileUtils
 * @description TODO
 * @date 2023/6/15 13:11
 */
@Slf4j
public class NioFileUtils {

    public static void deleteDirectory(String directoryPath) {
        try {
            if(Files.exists(Paths.get(directoryPath))){
                // 将中文路径字符串转换为Java的Path对象
                Path path = Paths.get(directoryPath);
                // 删除目录及其下的所有文件和子目录
                Files.walk(path)
                        .sorted(java.util.Comparator.reverseOrder())
                        .map(Path::toFile)
                        .forEach(File::delete);
//                log.info("{}目录删除成功！",directoryPath);
            }
        } catch (IOException e) {
            log.error("{}目录删除失败：" ,directoryPath,e.getMessage());
        }
    }
}
