package com.bosch.rbcd.common.aviator;

import com.bosch.rbcd.common.aviator.function.collection.IsIn;
import com.bosch.rbcd.common.aviator.function.collection.NotIn;
import com.bosch.rbcd.common.aviator.function.general.*;
import com.bosch.rbcd.common.aviator.function.number.*;
import com.bosch.rbcd.common.aviator.function.object.Nvl;
import com.bosch.rbcd.common.aviator.function.object.ToNumber;
import com.bosch.rbcd.common.aviator.function.object.ToString;
import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.Options;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.MathContext;

/**
 * @description: Aviator引擎执行器
 */
@Slf4j
public final class AviatorExecutor {
    static {
        AviatorEvaluator.setOption(Options.MATH_CONTEXT, MathContext.DECIMAL128);
        AviatorEvaluator.addFunction(new Nvl());
        AviatorEvaluator.addFunction(new Sum());
        AviatorEvaluator.addFunction(new Min());
        AviatorEvaluator.addFunction(new Max());
        AviatorEvaluator.addFunction(new Round());
        AviatorEvaluator.addFunction(new Ceil());
        AviatorEvaluator.addFunction(new Floor());
        AviatorEvaluator.addFunction(new Scale());
        AviatorEvaluator.addFunction(new IsIn());
        AviatorEvaluator.addFunction(new NotIn());
        AviatorEvaluator.addFunction(new IsNumber());
        AviatorEvaluator.addFunction(new DiffDays());
        AviatorEvaluator.addFunction(new DiffMinutes());
        AviatorEvaluator.addFunction(new Age());
        AviatorEvaluator.addFunction(new ChineseNumberUpper());
        AviatorEvaluator.addFunction(new StringNumbersSum());
        AviatorEvaluator.addFunction(new ToNumber());
        AviatorEvaluator.addFunction(new ToString());
    }

    private AviatorExecutor(){}
    /**
     * 执行结果
     * @param context 上下文对象
     * @return
     */
    public static Object execute(AviatorContext context){
        Object result = AviatorEvaluator.execute(context.getExpression(), context.getEnv(), context.isCached());
//        log.info("Aviator执行器context={},result={}", JSONObject.toJSON(context),result);
        return result;
    }

    /**
     * 执行结果，返回boolean类型
     * @param context 上下文对象
     * @return
     */
    public static boolean executeBoolean(AviatorContext context){
        return (Boolean) execute(context);
    }

    /**
     * 执行结果，返回double类型
     * @param context 上下文对象
     * @return
     */
    public static double executeDouble(AviatorContext context){
        return Double.valueOf(execute(context).toString());
    }

    /**
     * 执行结果，返回BigDecimal类型
     * @param context 上下文对象
     * @return
     */
    public static BigDecimal executeBigDecimal(AviatorContext context){
        return new BigDecimal(execute(context).toString());
    }

    /**
     * 执行结果，返回BigDecimal类型
     * @param context 上下文对象
     * @return
     */
    public static String executeString(AviatorContext context){
        return (String)execute(context);
    }
}
