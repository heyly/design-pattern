package com.bosch.rbcd.common.huawei.pojo.command;

import lombok.Data;

@Data
public class SyncCommand {

    private String service_id;

    private String command_name;

    private Object paras;

}
