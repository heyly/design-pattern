package com.bosch.rbcd.common.huawei.util;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.ZipUtil;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.common.web.exception.FileLinuxPathException;
import com.obs.services.ObsClient;
import com.obs.services.exception.ObsException;
import com.obs.services.model.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.*;

@Slf4j
@Component
public class ObsUtil {

    private static final String DEFAULT_ENCODING = "UTF-8";
    private static final String OBS_PREFIX = "x-obs-";
    private static final String SIGN_SEP = "\n";
    private static final List<String> SUB_RESOURCES = Collections.unmodifiableList(Arrays.asList("CDNNotifyConfiguration", "acl", "append", "attname", "backtosource", "cors",
            "customdomain", "delete", "deletebucket", "directcoldaccess", "encryption", "inventory", "length", "lifecycle", "location", "logging", "metadata",
            "mirrorBackToSource", "modify", "name", "notification", "obscompresspolicy", "orchestration", "partNumber", "policy", "position", "quota", "rename", "replication",
            "response-cache-control", "response-content-disposition", "response-content-encoding", "response-content-language", "response-content-type", "response-expires",
            "restore", "storageClass", "storagePolicy", "storageinfo", "tagging", "torrent", "truncate", "uploadId", "uploads", "versionId", "versioning", "versions", "website",
            "x-image-process", "x-image-save-bucket", "x-image-save-object", "x-obs-security-token"));

    @Value("${obs.endPoint}")
    private String endPoint;
    @Value("${obs.ak}")
    private String ak;
    @Value("${obs.sk}")
    private String sk;

    @Value("${obs.obsName}")
    private String defaultBucket;

    @Value("${system.filePath}")
    private String sysPath;
    @Value("${huawei.foldPath}")
    private String urlPrefix;
    final static Integer BATCH_DELETE_SIZE = 800;


    public String putFile(File file, String path, String fileName) {

        ObsClient obsClient = new ObsClient(ak, sk, endPoint);
        String url = "";
        try {
            //创建文件夹
            if (!path.isEmpty()) {
                obsClient.putObject(defaultBucket, path, new ByteArrayInputStream(new byte[0]));
            }
            // 使用访问OBS
            FileInputStream fis = new FileInputStream(file);  // 待上传的本地文件路径，需要指定到具体的文件名
            PutObjectResult putObjectResult = obsClient.putObject(defaultBucket, path + fileName, fis);
            url = URLDecoder.decode(putObjectResult.getObjectUrl(), "UTF-8");
            url = url.replace(urlPrefix, "");
            // 关闭obsClient
            obsClient.close();
        } catch (IOException e) {
            log.error("ObsUtil.putFile error!", e);
        }
        return url;
    }

    public String putBucketStream(String bucketName, String objectKey, InputStream is) {
        if (StrUtil.isBlank(bucketName)) {
            bucketName = defaultBucket;
        }
        ObsClient obsClient = new ObsClient(ak, sk, endPoint);
        String url = "";
        try {
            //创建文件夹
            if (!objectKey.isEmpty()) {
                obsClient.putObject(bucketName, objectKey, new ByteArrayInputStream(new byte[0]));
            }
            // 使用访问OBS
            PutObjectResult putObjectResult = obsClient.putObject(bucketName, objectKey, is);
            url = URLDecoder.decode(putObjectResult.getObjectUrl(), "UTF-8");
            url = url.replace(urlPrefix, "");
            // 关闭obsClient
            obsClient.close();
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.huawei.util.ObsUtil.putBucketStream error!", e);
        }
        return url;
    }

    public String putDiskFile(String filePath) {
        File file = new File(filePath);
        String fileName = file.getName();
        String path = "";
        String tmpSystemPath = sysPath;
        tmpSystemPath = tmpSystemPath.replace("\\", "/").replace("//", "/");
        path = filePath.substring(sysPath.length());
        path = path.substring(0, path.length() - fileName.length());
        path = path.replace("\\", "/");
        path = path.replace("//", "/");
        path = path.replace(tmpSystemPath, "");
        if (path.startsWith("/")) {
            path = path.substring(1);
        }
        return putFile(file, path, fileName);
    }

    /**
     * @Description: 上传file至OBS服务器
     * @Param: [file]
     * @return: java.lang.String
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/6
     */
    public String putFile(File file) {
        String url = "";
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            String absolutePath = file.getAbsolutePath();
            String tmpSystemPath = sysPath;
            tmpSystemPath = tmpSystemPath.replace("\\", "/").replace("//", "/");
            String objectKey = absolutePath.replace("\\", "/").replace("//", "/").replace(tmpSystemPath, "");

            if (objectKey.startsWith("/")) {
                objectKey = objectKey.substring(1);
            }
            PutObjectResult putObjectResult = obsClient.putObject(defaultBucket, objectKey, file);
            url = URLDecoder.decode(putObjectResult.getObjectUrl(), "UTF-8");
            url = url.replace(urlPrefix, "");
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        return url;
    }

    /**
     * 从obs下载文件，并将文件内容转换成string输出
     *
     * @param path
     * @return
     */
    public String download(String path) {
        ObsClient obsClient = new ObsClient(ak, sk, endPoint);

        //handle path, get bucket and objectName
        path = path.replaceAll("https://", "");
        String[] split = path.split("/");
        String bucketName = split[0].split("\\.")[0];

        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < split.length; i++) {
            sb.append(split[i]);
            if (i < split.length - 1) {
                sb.append("/");
            }
        }

        InputStream in = null;
        String content = "";
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            ObsObject object = obsClient.getObject(bucketName, sb.toString());
            in = object.getObjectContent();
            byte[] b = new byte[1024];
            int len;
            while ((len = in.read(b)) != -1) {
                bos.write(b, 0, len);
            }
            content = bos.toString();
        } catch (Exception e) {
            log.error("download file failed: {}", path, e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    log.error("close input stream failed");
                }
            }
        }

        return content;
    }


    /**
     * @Description: 判断OBS服务器是否含有指定对象
     * @Param: [objectKey]
     * @return: boolean
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/3
     */
    public boolean isExisted(String objectKey) {
        if (StrUtil.isBlank(objectKey)) {
            return false;
        }
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            return obsClient.doesObjectExist(defaultBucket, objectKey);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * @Description: 判断OBS服务器是否含有指定对象
     * @Param: [objectKey]
     * @return: boolean
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/3
     */
    public boolean isExisted(String bucketName, String objectKey) {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            return obsClient.doesObjectExist(bucketName, objectKey);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * @Description: 判断OBS服务器是否含有指定对象
     * @Param: [objectKey]
     * @return: boolean
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/3
     */
    public boolean isExistedOfBucket(String bucketName, String objectKey) {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            return obsClient.doesObjectExist(bucketName, objectKey);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * @Description: 根据路径获取OBS文件流
     * @Param: [objectKey]
     * @return: java.io.InputStream
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/3
     */
    public InputStream getFileInputStream(String bucketName, String objectKey) {
        if (StrUtil.isBlank(bucketName)) {
            bucketName = defaultBucket;
        }
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            if (isExisted(bucketName, objectKey)) {
                ObsObject object = obsClient.getObject(bucketName, objectKey);
                return object.getObjectContent();
            }
        } catch (Exception e) {
            log.error("com.bosch.rbcd.common.huawei.util.ObsUtil.getFileInputStream error!", e);
        }
        return null;
    }

    /**
     * @Description: 获取OBS文件
     * @Param: [objectKey, filePath]
     * @return: java.io.File
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/6
     */
    public File getFile(String objectKey, String filePath) {
        File file = new File(filePath);
        InputStream fileInputStream = getFileInputStream(null, objectKey);
        if (Objects.nonNull(fileInputStream)) {
            FileUtil.writeFromStream(fileInputStream, file);
        }
        FileLinuxPathException.runTime(file);
        return file;
    }

    public ObjectMetadata getFileInfo(String bucketName, String objectKey) {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            ObjectMetadata result = obsClient.getObjectMetadata(bucketName, objectKey);
            return result;
        } catch (Exception e) {
            log.info(e.getMessage());
            return null;
        }
    }

    /**
     * @Description: 获取OBS文件
     * @Param: [objectKey, filePath]
     * @return: java.io.File
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/6
     */
    public File getFile(String bucketName, String objectKey, String filePath) {
        File file = new File(filePath);
        InputStream fileInputStream = getFileInputStream(bucketName, objectKey);
        if (Objects.nonNull(fileInputStream)) {
            FileUtil.writeFromStream(fileInputStream, file);
        }
        FileLinuxPathException.runTime(file);
        return file;
    }

    /**
     * @Description: OBS删除文件
     * @Param: [objectKey]
     * @return: boolean
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/3
     */
    public boolean deleteFile(String objectKey) {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            DeleteObjectResult result = obsClient.deleteObject(defaultBucket, objectKey);
            if (Objects.nonNull(result)) {
                return result.isDeleteMarker();
            }
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        return false;
    }

    /**
     * @Description: 删除指定obs桶文件
     * @Param: [objectKey]
     * @return: boolean
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/3
     */
    public boolean deleteFile(String bucketName, String objectKey) {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            DeleteObjectResult result = obsClient.deleteObject(bucketName, objectKey);
            if (Objects.nonNull(result)) {
                return result.isDeleteMarker();
            }
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        return false;
    }

    /**
     * @Description: 删除多个文件
     * @Param: [objectKeyList]
     * @return: void
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/5/8
     */
    public void deleteFiles(List<String> objectKeyList) {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            List<List<String>> batchList = ListUtils.partition(objectKeyList, BATCH_DELETE_SIZE);
            batchList.forEach(list -> {
                KeyAndVersion[] keyList = list.stream().map(KeyAndVersion::new).toArray(KeyAndVersion[]::new);
                DeleteObjectsRequest deleteObjectsRequest = new DeleteObjectsRequest(defaultBucket, true, keyList);
                obsClient.deleteObjects(deleteObjectsRequest);
            });
        } catch (Exception e) {
            log.info(e.getMessage());
        }
    }


    public File retryDownloadFile(String bucketName, String obsKey, String targetPath, int count) {
        File targetFile = null;
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            DownloadFileRequest request = new DownloadFileRequest(bucketName, obsKey);
            // 设置下载对象的本地文件路径
            request.setDownloadFile(targetPath);
            // 设置分段下载时的最大并发数
            request.setTaskNum(5);
            // 设置分段大小为10MB
            request.setPartSize(10 * 1024 * 1024);
            // 开启断点续传模式
            request.setEnableCheckpoint(true);
            DownloadFileResult result = obsClient.downloadFile(request);
        } catch (Exception e) {
            if (FileUtil.exist(targetPath)) {
                FileUtil.del(targetPath);
            }
            count--;
            if (count > 0) {
                // 重试下载
                retryDownloadFile(bucketName, obsKey, targetPath, count);
            } else {
                log.warn("=====目标桶[{}],下载文件[{}],重试后仍失败======", bucketName, obsKey, e);
            }
        }
        return targetFile;
    }


    /**
     * @Description: 批量下载多个文件
     * @Param: [bucketName, folerName, downloadFiles]
     * @return:
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/9/18
     */
    public void batchDownload(String bucketName, String folerName, List<String> downloadFiles, boolean needUnzip, boolean needPureFolder) {
        for (String obsKey : downloadFiles) {
            if (isExistedInBucket(bucketName, obsKey)) {
                String rawFile = folerName + File.separator + StrUtil.subAfter(obsKey, "/", true);
                retryDownloadFile(bucketName, obsKey, rawFile, 5);
                if (needUnzip) {
                    if (FileUtil.exist(rawFile) && StrUtil.endWithIgnoreCase(obsKey, ".zip")) {
                        // 是否解压到target根目录
                        try {
                            if (needPureFolder) {
                                ZipUtil.unzip(rawFile, folerName);
                            } else {
                                ZipUtil.unzip(rawFile);
                            }
                        } catch (Exception e) {
                            log.error("解压失败");
                        } finally {
                            FileUtil.del(rawFile);
                        }
                    } else if (FileUtil.exist(rawFile) && StrUtil.endWithIgnoreCase(obsKey, ".gz")) {
                        // 是否解压到target根目录
                        try {
                            if (needPureFolder) {
                                byte[] fileByte = ZipUtil.unGzip(FileUtil.getInputStream(rawFile));
                                FileUtil.writeBytes(fileByte, rawFile.replace(".gz", ""));
                            } else {
                                byte[] fileByte = ZipUtil.unGzip(FileUtil.getInputStream(rawFile));
                                FileUtil.writeBytes(fileByte, rawFile.replace(".gz", ""));
                            }
                        } catch (Exception e) {
                            log.error("解压失败");
                        } finally {
                            FileUtil.del(rawFile);
                        }
                    }
                }

            }
        }
    }


    public boolean isExistedInBucket(String bucketName, String objectKey) {
        if (StrUtil.isBlank(bucketName)) {
            bucketName = endPoint;
        }
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            return obsClient.doesObjectExist(bucketName, objectKey);
        } catch (Exception e) {
            return false;
        }
    }

    public String upFileToBucket(String bucketName, File file, String obsKey) {
        String url = "";
        if (StrUtil.isBlank(bucketName)) {
            bucketName = defaultBucket;
        }
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            PutObjectResult putObjectResult = obsClient.putObject(bucketName, obsKey, file);
            url = URLDecoder.decode(putObjectResult.getObjectUrl(), "UTF-8");
            url = url.replace(urlPrefix, "");
        } catch (Exception e) {
            log.error("上送OBS发生异常：" + file.getName(), e);
        }
        return url;
    }

    public String getFileUrl(String bucketName, String objectName) throws Exception {
        if (StrUtil.isBlank(bucketName)) {
            bucketName = defaultBucket;
        }

        // 若直接使用URL在浏览器地址栏中访问，无法带上头域，此处headers加入头域会导致签名不匹配，使用headers需要客户端处理
        Map<String, String[]> headers = new HashMap<String, String[]>();
        Map<String, String> queries = new HashMap<String, String>();

        // 请求消息参数Expires，设置24小时后失效
        long expires = (System.currentTimeMillis() + 86400000L) / 1000;
        String signature = querySignature("GET", headers, queries, bucketName, objectName, expires);
        return getURL(endPoint, queries, bucketName, objectName, signature, expires);
    }

    public String getURL(String endpoint, Map<String, String> queries, String bucketName, String objectName, String signature, long expires) throws UnsupportedEncodingException {
        StringBuilder URL = new StringBuilder();
        URL.append("https://").append(bucketName).append(".").append(endpoint).append("/").append(encodeObjectName(objectName)).append("?");
        String key;
        for (Map.Entry<String, String> entry : queries.entrySet()) {
            key = entry.getKey();
            if (key == null) {
                continue;
            }
            if (SUB_RESOURCES.contains(key)) {
                String value = entry.getValue();
                URL.append(key);
                if (value != null) {
                    URL.append("=").append(value).append("&");
                } else {
                    URL.append("&");
                }
            }
        }
        URL.append("AccessKeyId=").append(ak).append("&Expires=").append(expires).append("&Signature=").append(signature);
        return URL.toString();
    }

    public static String encodeObjectName(String objectName) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        String[] tokens = objectName.split("/");
        for (int i = 0; i < tokens.length; i++) {
            result.append(encodeUrlString(tokens[i]));
            if (i < tokens.length - 1) {
                result.append("/");
            }
        }
        return result.toString();
    }

    public static String encodeUrlString(String path) throws UnsupportedEncodingException {
        return URLEncoder.encode(path, DEFAULT_ENCODING).replaceAll("\\+", "%20").replaceAll("\\*", "%2A").replaceAll("%7E", "~");
    }


    public String querySignature(String httpMethod, Map<String, String[]> headers, Map<String, String> queries, String bucketName, String objectName, long expires) throws Exception {
        if (headers.containsKey("x-obs-date")) {
            headers.put("x-obs-date", new String[]{String.valueOf(expires)});
        } else {
            headers.put("date", new String[]{String.valueOf(expires)});
        }
        //1. stringToSign
        String stringToSign = stringToSign(httpMethod, headers, queries, bucketName, objectName);

        //2. signature
        return urlEncode(hamcSha1(stringToSign));
    }

    public static String urlEncode(String input) throws UnsupportedEncodingException {
        return URLEncoder.encode(input, DEFAULT_ENCODING).replaceAll("%7E", "~") //for browser
                .replaceAll("%2F", "/");
    }

    public String hamcSha1(String input) throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        SecretKeySpec signingKey = new SecretKeySpec(sk.getBytes(DEFAULT_ENCODING), "HmacSHA1");
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(signingKey);
        return Base64.getEncoder().encodeToString(mac.doFinal(input.getBytes(DEFAULT_ENCODING)));
    }

    private static String stringToSign(String httpMethod, Map<String, String[]> headers, Map<String, String> queries, String bucketName, String objectName) throws Exception {
        String contentMd5 = "";
        String contentType = "";
        String date = "";

        TreeMap<String, String> canonicalizedHeaders = new TreeMap<String, String>();

        String key;
        List<String> temp = new ArrayList<String>();
        for (Map.Entry<String, String[]> entry : headers.entrySet()) {
            key = entry.getKey();
            if (key == null || entry.getValue() == null || entry.getValue().length == 0) {
                continue;
            }

            key = key.trim().toLowerCase(Locale.ENGLISH);
            if (key.equals("content-md5")) {
                contentMd5 = entry.getValue()[0];
                continue;
            }

            if (key.equals("content-type")) {
                contentType = entry.getValue()[0];
                continue;
            }

            if (key.equals("date")) {
                date = entry.getValue()[0];
                continue;
            }

            if (key.startsWith(OBS_PREFIX)) {

                for (String value : entry.getValue()) {
                    if (value != null) {
                        temp.add(value.trim());
                    }
                }
                canonicalizedHeaders.put(key, join(temp, ","));
                temp.clear();
            }
        }

        if (canonicalizedHeaders.containsKey("x-obs-date")) {
            date = "";
        }


        // handle method/content-md5/content-type/date
        StringBuilder stringToSign = new StringBuilder();
        stringToSign.append(httpMethod).append(SIGN_SEP).append(contentMd5).append(SIGN_SEP).append(contentType).append(SIGN_SEP).append(date).append(SIGN_SEP);

        // handle canonicalizedHeaders
        for (Map.Entry<String, String> entry : canonicalizedHeaders.entrySet()) {
            stringToSign.append(entry.getKey()).append(":").append(entry.getValue()).append(SIGN_SEP);
        }

        // handle CanonicalizedResource
        stringToSign.append("/");
        if (isValid(bucketName)) {
            stringToSign.append(bucketName).append("/");
            if (isValid(objectName)) {
                stringToSign.append(encodeObjectName(objectName));
            }
        }

        TreeMap<String, String> canonicalizedResource = new TreeMap<String, String>();
        for (Map.Entry<String, String> entry : queries.entrySet()) {
            key = entry.getKey();
            if (key == null) {
                continue;
            }

            if (SUB_RESOURCES.contains(key)) {
                canonicalizedResource.put(key, entry.getValue());
            }
        }

        if (canonicalizedResource.size() > 0) {
            stringToSign.append("?");
            for (Map.Entry<String, String> entry : canonicalizedResource.entrySet()) {
                stringToSign.append(entry.getKey());
                if (isValid(entry.getValue())) {
                    stringToSign.append("=").append(entry.getValue());
                }
                stringToSign.append("&");
            }
            stringToSign.deleteCharAt(stringToSign.length() - 1);
        }

//		System.out.println(String.format("StringToSign:%s%s", SIGN_SEP, stringToSign.toString()));

        return stringToSign.toString();
    }

    private static String join(List<?> items, String delimiter) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            String item = items.get(i).toString();
            sb.append(item);
            if (i < items.size() - 1) {
                sb.append(delimiter);
            }
        }
        return sb.toString();
    }

    private static boolean isValid(String input) {
        return input != null && !input.equals("");
    }

    public void moveFile(String oldName, String newName) {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            CopyObjectResult result = obsClient.copyObject(defaultBucket, oldName, defaultBucket, newName);
            obsClient.deleteObject(defaultBucket, oldName);
        } catch (ObsException | IOException e) {
            log.error("{}重命名为{}报错，{}", oldName, newName, e.getMessage());
        }
    }

    public void copyObject(String oldName, String newName) {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            obsClient.copyObject(defaultBucket, oldName, defaultBucket, newName);
        } catch (ObsException | IOException e) {
            log.error("{}重命名为{}报错，{}", oldName, newName, e.getMessage());
        }
    }

    public boolean renameObject(String bucket, String oldName, String newName) {
        if (StrUtil.isBlank(bucket)) {
            bucket = defaultBucket;
        }
        boolean success = true;
        if (!StrUtil.equals(oldName, newName)) {
            try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
                obsClient.copyObject(bucket, oldName, bucket, newName);
                obsClient.deleteObject(bucket, oldName);
            } catch (ObsException | IOException e) {
                log.error(oldName + "重命名为" + newName + "报错", e);
                success = false;
            }
        }
        return success;
    }

    public void batchRenameObject(String bucket, List<String> oldNameList, List<String> newNameList) {
        if (StrUtil.isBlank(bucket)) {
            bucket = defaultBucket;
        }
        if (CollectionUtils.isEmpty(oldNameList) || CollectionUtils.isEmpty(newNameList) || oldNameList.size() != newNameList.size()) {
            throw new BizException("原始路径或目标路径异常");
        }

        for (int i=0; i<oldNameList.size(); i++) {
            String oldName = oldNameList.get(i);
            String newName = newNameList.get(i);
            try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
                obsClient.copyObject(bucket, oldName, bucket, newName);
            } catch (ObsException | IOException e) {
                String errorInfo = oldName + "重命名为" + newName + "报错";
                log.error(errorInfo, e);
                throw new BizException(errorInfo);
            }
        }

        for (String oldName : oldNameList) {
            try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
                obsClient.deleteObject(bucket, oldName);
            } catch (ObsException | IOException e) {
                log.error("obs删除文件（" + oldName + "）异常", e);
            }
        }
    }

    public void setBucketQuota() {
        try (ObsClient obsClient = new ObsClient(ak, sk, endPoint)) {
            // 示例桶配额
            long exampleBucketQuota = 0L;
            // 设置桶配额为100MB
            BucketQuota quota = new BucketQuota(exampleBucketQuota);
            obsClient.setBucketQuota("rbcd-filestorage", quota);
        } catch (ObsException | IOException e) {
        }
    }
}
