package com.bosch.rbcd.common.huawei.util;

import cn.hutool.core.util.StrUtil;
import com.huaweicloud.sdk.core.auth.AbstractCredentials;
import com.huaweicloud.sdk.core.auth.BasicCredentials;
import com.huaweicloud.sdk.core.auth.ICredential;
import com.huaweicloud.sdk.core.exception.ConnectionException;
import com.huaweicloud.sdk.core.exception.RequestTimeoutException;
import com.huaweicloud.sdk.core.exception.ServiceResponseException;
import com.huaweicloud.sdk.core.region.Region;
import com.huaweicloud.sdk.iotda.v5.IoTDAClient;
import com.huaweicloud.sdk.iotda.v5.model.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

@Data
@Component
@ConfigurationProperties(prefix = "huawei")
@Slf4j
public class IotDaUtil {

    @Value("${obs.ak}")
    private String ak;
    @Value("${obs.sk}")
    private String sk;
    @Value("${huawei.region}")
    private String region;
    @Value("${huawei.IOTDAEndpoint}")
    private String IOTDAEndpoint;
    @Value("${huawei.projectId}")
    private String projectId;
    @Value("${huawei.productId}")
    private String productId;
    @Value("${huawei.deviceAuthType}")
    private String deviceAuthType;
    @Value("${huawei.deviceAuthSecret}")
    private String deviceAuthSecret;
    @Value("${huawei.deviceAuthSecureAccess}")
    private Boolean deviceAuthSecureAccess;

    /**
     * @Description: 初始化IoTDAClient
     * @Param: []
     * @return: com.huaweicloud.sdk.iotda.v5.IoTDAClient
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     */
    private IoTDAClient initClient() {
        ICredential auth = new BasicCredentials().withProjectId(projectId).withDerivedPredicate(AbstractCredentials.DEFAULT_DERIVED_PREDICATE) // Used in derivative ak/sk
                // authentication scenarios
                .withAk(ak).withSk(sk);
        return IoTDAClient.newBuilder().withCredential(auth).withRegion(new Region(region, IOTDAEndpoint)).build();
    }

    /**
     * @Description: 设备管理: 创建设备
     * @Param: [gatewayId, nodeId, deviceId, deviceName, description]
     * @return: com.alibaba.fastjson.JSONObject
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     */
    public AddDeviceResponse addDevice(String gatewayId, String nodeId, String deviceId, String deviceName, String description) {
        AddDeviceResponse response = null;
        AddDeviceRequest request = new AddDeviceRequest();
        AddDevice body = new AddDevice();
        AuthInfo authInfo = new AuthInfo();
        authInfo.withAuthType(deviceAuthType);
        authInfo.withSecret(deviceAuthSecret);
        authInfo.withSecureAccess(deviceAuthSecureAccess);
        body.withAuthInfo(authInfo);
        body.withDescription(description);
        body.withProductId(productId);
        body.withDeviceId(deviceId);
        body.withDeviceName(deviceName);
        body.withNodeId(nodeId);
        if (StrUtil.isNotBlank(gatewayId)) {
            body.withGatewayId(gatewayId);
        }
        request.withBody(body);
        try {
            IoTDAClient client = initClient();
            response = client.addDevice(request);
//            log.info("IotDA addDevice success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA addDevice ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA addDevice RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA addDevice ServiceResponseException error!", e);
        }
        return response;
    }

    /**
     * @Description: 设备管理: 创建设备
     * @Param: [gatewayId, nodeId, deviceId, deviceName, description]
     * @return: com.alibaba.fastjson.JSONObject
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     */
    @Async
    public void addDeviceAsync(String gatewayId, String nodeId, String deviceId, String deviceName, String description) {
        AddDeviceResponse response = null;
        AddDeviceRequest request = new AddDeviceRequest();
        AddDevice body = new AddDevice();
        AuthInfo authInfo = new AuthInfo();
        authInfo.withAuthType(deviceAuthType);
        authInfo.withSecret(deviceAuthSecret);
        authInfo.withSecureAccess(deviceAuthSecureAccess);
        body.withAuthInfo(authInfo);
        body.withDescription(description);
        body.withProductId(productId);
        body.withDeviceId(deviceId);
        body.withDeviceName(deviceName);
        body.withNodeId(nodeId);
        if (StrUtil.isNotBlank(gatewayId)) {
            body.withGatewayId(gatewayId);
        }
        request.withBody(body);
        try {
            IoTDAClient client = initClient();
            response = client.addDevice(request);
//            log.info("IotDA addDeviceAsync success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA addDeviceAsync ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA addDeviceAsync RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA addDeviceAsync ServiceResponseException error!", e);
        }
    }

    /**
     * 设备管理：查询
     *
     * @param marker 前页里的marker参数 初次使用空字符串
     * @return
     * @URL https://console-intl.huaweicloud.com/apiexplorer/#/openapi/IoTDA/sdk?api=ShowDevice
     */
    public ListDevicesResponse listDevices(String marker) {
        ListDevicesResponse response = null;
        ListDevicesRequest request = new ListDevicesRequest();
        try {
            IoTDAClient client = initClient();
            response = client.listDevices(request);
//            log.info("IotDA listDevices success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA listDevices ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA listDevices RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA listDevices ServiceResponseException error!", e);
        }
        return response;
    }


    /**
     * @Description: 设备管理：查询
     * @Param: [imei]
     * @return: com.huaweicloud.sdk.iotda.v5.model.ShowDeviceResponse
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     * @see <a href="https://console-intl.huaweicloud.com/apiexplorer/#/openapi/IoTDA/sdk?api=ShowDevice">设备管理：查询</a>
     */
    public ShowDeviceResponse showDevice(String imei) {
        ShowDeviceResponse response = null;
        ShowDeviceRequest request = new ShowDeviceRequest();
        request.withDeviceId(imei);
        try {
            IoTDAClient client = initClient();
            response = client.showDevice(request);
//            log.info("IotDA showDevice success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA showDevice ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA showDevice RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA showDevice ServiceResponseException error!", e);
        }
        return response;
    }

    /**
     * 删除设备
     *
     * @param deviceId
     * @return
     * @throws KeyManagementException
     * @throws NoSuchAlgorithmException
     * @throws IOException
     */
    public DeleteDeviceResponse deleteDevice(String deviceId) {
        DeleteDeviceResponse response = null;
        DeleteDeviceRequest request = new DeleteDeviceRequest();
        request.withDeviceId(deviceId);
        try {
            IoTDAClient client = initClient();
            response = client.deleteDevice(request);
//            log.info("IotDA deleteDevice success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA deleteDevice ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA deleteDevice RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA deleteDevice ServiceResponseException error!", e);
        }
        return response;
    }

    /**
    * @Description: 冻结设备
    * @Param: [deviceId]
    * @return: com.huaweicloud.sdk.iotda.v5.model.FreezeDeviceResponse
    * @Author: Wang Bo (BCSC-EPA2)
    * @Date: 2023/9/1
    */
    public FreezeDeviceResponse freezeDevice(String deviceId) {
        FreezeDeviceResponse response = null;
        FreezeDeviceRequest request = new FreezeDeviceRequest();
        request.withDeviceId(deviceId);
        try {
            IoTDAClient client = initClient();
            response = client.freezeDevice(request);
//            log.info("IotDA freezeDevice success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA freezeDevice ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA freezeDevice RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA freezeDevice ServiceResponseException error!", e);
        }
        return response;
    }


    /**
     * @Description: 解冻设备
     * @Param: [deviceId]
     * @return: com.huaweicloud.sdk.iotda.v5.model.FreezeDeviceResponse
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     */
    public UnfreezeDeviceResponse unfreezeDevice(String deviceId) {
        UnfreezeDeviceResponse response = null;
        UnfreezeDeviceRequest request = new UnfreezeDeviceRequest();
        request.withDeviceId(deviceId);
        try {
            IoTDAClient client = initClient();
            response = client.unfreezeDevice(request);
//            log.info("IotDA unfreezeDevice success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA unfreezeDevice ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA unfreezeDevice RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA unfreezeDevice ServiceResponseException error!", e);
        }
        return response;
    }

    /**
     * @Description: IOTDA: 批量任务
     * @Param: [targets, taskType, taskName, document]
     * @return: com.huaweicloud.sdk.iotda.v5.model.CreateBatchTaskResponse
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     */
    public CreateBatchTaskResponse createBatchTask(List<String> targets, String taskType, String taskName, Object document) {
        CreateBatchTaskResponse response = null;
        CreateBatchTaskRequest request = new CreateBatchTaskRequest();
        CreateBatchTask body = new CreateBatchTask();
        body.withTaskType(taskType);
        body.withTaskName(taskName);
        body.withTargets(targets);
        body.withDocument(document);
        request.withBody(body);
        try {
            IoTDAClient client = initClient();
            response = client.createBatchTask(request);
//            log.info("IotDA createBatchTask success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA createBatchTask ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA createBatchTask RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA createBatchTask ServiceResponseException error!", e);
        }
        return response;
    }

    /**
     * @Description: IOTDA: 批量任务查询
     * @Param: [taskId, marker]
     * @return: com.huaweicloud.sdk.iotda.v5.model.ShowBatchTaskResponse
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     */
    public ShowBatchTaskResponse showBatchTask(String taskId, String marker) {
        ShowBatchTaskResponse response = null;
        ShowBatchTaskRequest request = new ShowBatchTaskRequest();
        request.withTaskId(taskId);
        request.withMarker(marker);
        try {
            IoTDAClient client = initClient();
            response = client.showBatchTask(request);
//            log.info("IotDA showBatchTask success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA showBatchTask ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA showBatchTask RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA showBatchTask ServiceResponseException error!", e);
        }
        return response;
    }

    /**
    * @Description: 设备消息：下发
    * @Param: [imei, msg]
    * @return: com.huaweicloud.sdk.iotda.v5.model.CreateMessageResponse
    * @Author: Wang Bo (BCSC-EPA2)
    * @Date: 2023/9/1
    */
    public CreateMessageResponse createMessage(String imei, Object msg) {
        CreateMessageResponse response = null;
        CreateMessageRequest request = new CreateMessageRequest();
        request.withDeviceId(imei);
        DeviceMessageRequest body = new DeviceMessageRequest();
        body.withMessage(msg);
        request.withBody(body);
        try {
            IoTDAClient client = initClient();
            response = client.createMessage(request);
//            log.info("IotDA createMessage success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA createMessage ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA createMessage RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA createMessage ServiceResponseException error!", e);
        }
        return response;
    }

    /**
     * @Description: 设备命令（同步）
     * @Param: [imei, paras]
     * @return: com.alibaba.fastjson.JSONObject
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     */
    public CreateCommandResponse syncCommand(String imei, Object paras) {
        CreateCommandResponse response = null;
        CreateCommandRequest request = new CreateCommandRequest();
        request.withDeviceId(imei);
        DeviceCommandRequest body = new DeviceCommandRequest();
        body.withParas(paras);
        request.withBody(body);
        try {
            IoTDAClient client = initClient();
            response = client.createCommand(request);
//            log.info("IotDA syncCommand success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA syncCommand ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA syncCommand RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA syncCommand ServiceResponseException error!", e);
        }
        return response;
    }


    /**
     * @Description: 设备命令（异步）
     * @Param: [imei, paras]
     * @return: com.alibaba.fastjson.JSONObject
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/9/1
     */
    @Async
    public Future<CreateCommandResponse> asyncCommand(String imei, Map<String, Object> paras) {
        CreateCommandResponse response = null;
        CreateCommandRequest request = new CreateCommandRequest();
        request.withDeviceId(imei);
        DeviceCommandRequest body = new DeviceCommandRequest();
        body.withParas(paras);
        request.withBody(body);
        try {
            IoTDAClient client = initClient();
            response = client.createCommand(request);
//            log.info("IotDA asyncCommand success! request: {}, response:{}", JSON.toJSONString(request), JSON.toJSONString(response));
        } catch (ConnectionException e) {
            log.error("IotDA asyncCommand ConnectionException error!", e);
        } catch (RequestTimeoutException e) {
            log.error("IotDA asyncCommand RequestTimeoutException error!", e);
        } catch (ServiceResponseException e) {
            log.error("IotDA asyncCommand ServiceResponseException error!", e);
        }
        return new AsyncResult<>(response);
    }
}
