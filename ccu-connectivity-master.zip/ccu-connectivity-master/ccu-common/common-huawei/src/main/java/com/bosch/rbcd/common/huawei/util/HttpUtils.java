package com.bosch.rbcd.common.huawei.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.*;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.*;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;

@Slf4j
public class HttpUtils {

    private static final String CONTENT_LENGTH = "Content-Length";
    private static CloseableHttpClient httpClient;

    public void initClient() throws KeyManagementException, NoSuchAlgorithmException {
        SSLContext sslcontext = getSSLContent();
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
                .register("http", PlainConnectionSocketFactory.INSTANCE)
                .register("https", new SSLConnectionSocketFactory(sslcontext, NoopHostnameVerifier.INSTANCE))
                .build();
        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
        RequestConfig.Builder builder = RequestConfig.custom();
        RequestConfig requestConfig = builder.build();
        httpClient = HttpClients.custom().setConnectionManager(connManager).setDefaultRequestConfig(requestConfig).build();
    }

    public SSLContext getSSLContent() throws NoSuchAlgorithmException, KeyManagementException {
        SSLContext sc = SSLContext.getInstance("TLSv1.2");

        // 实现一个X509TrustManager接口，用于绕过验证，不用修改里面的方法
        X509TrustManager trustManager = new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
            }

            public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {

            }

            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        };
        sc.init(null, new TrustManager[]{trustManager}, null);
        return sc;
    }

    public StreamClosedHttpResponse doPost(String url, Map<String, String> headerMap, String body) {
        HttpPost httpPost = new HttpPost(url);
        addHeader(headerMap, httpPost);
        httpPost.setEntity(new StringEntity(body, ContentType.APPLICATION_JSON));
        return (StreamClosedHttpResponse) execute(httpPost);
    }

    public StreamClosedHttpResponse doGet(String url, Map<String, String> headerMap, Map<String, String> params) throws URISyntaxException {
        HttpGet httpGet = new HttpGet(url);
        addHeader(headerMap, httpGet);
        URIBuilder uriBuilder = null;
        try {
            uriBuilder = new URIBuilder(url);
        } catch (URISyntaxException e) {
            System.out.println(e);
        }
        if (params != null && !params.isEmpty()) {
            uriBuilder.setParameters(convertParams(params));
        }
        httpGet.setURI(uriBuilder.build());
        return (StreamClosedHttpResponse) execute(httpGet);

    }

    public CloseableHttpResponse doDelete(String url, Map<String, String> headerMap) {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpDelete httpDelete = new HttpDelete(url);
        addHeader(headerMap, httpDelete);
        CloseableHttpResponse httpResponse = null;
        try {
            httpResponse = httpClient.execute(httpDelete);
            return httpResponse;
        } catch (ClientProtocolException e) {
            log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.doDelete 1 error!", e);
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.doDelete 2 error!", e);
        } finally {
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.doDelete 3 error!", e);
                }
            }
            if (null != httpClient) {
                try {
                    httpClient.close();
                } catch (IOException e) {
                    log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.doDelete 4 error!", e);
                }
            }
        }
        return httpResponse;
    }

    public String constructUri(String url, Map<String, String> params) throws URISyntaxException {
        URIBuilder uriBuilder = null;
        try {
            uriBuilder = new URIBuilder(url);
        } catch (URISyntaxException e) {
            log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.constructUri error!", e);
        }
        if (params != null && !params.isEmpty()) {
            uriBuilder.setParameters(convertParams(params));
        }
        return uriBuilder.build().toString();

    }

    public List<NameValuePair> convertParams(Map<String, String> params) {
        List<NameValuePair> list = new ArrayList<NameValuePair>();
        for (String paramKey : params.keySet()) {
            list.add(new BasicNameValuePair(paramKey, params.get(paramKey)));
        }
        return list;
    }


    private void addHeader(Map<String, String> headerMap, HttpUriRequest request) {
        if (headerMap == null) {
            return;
        }

        for (String headerName : headerMap.keySet()) {
            if (CONTENT_LENGTH.equalsIgnoreCase(headerName)) {
                continue;
            }
            String headValue = headerMap.get(headerName);
            request.addHeader(headerName, headValue);
        }
    }

    public HttpResponse execute(HttpUriRequest request) {

        CloseableHttpResponse response;
        try {
            response = httpClient.execute(request);
            return new StreamClosedHttpResponse(response);
        } catch (IOException e) {
            System.out.println(e);
        }
        return null;
    }

    private static ObjectMapper mapper = new ObjectMapper();

    public static String get(String url) {
        HttpClientBuilder build = HttpClients.custom();
        HttpHost proxy = new HttpHost("10.4.103.69", 8080);
        CloseableHttpClient client = build.setProxy(proxy).build();
        HttpGet httpGet = new HttpGet(url);
        try (CloseableHttpResponse httpResponse = client.execute(httpGet)) {
            HttpEntity entity = httpResponse.getEntity();
            InputStream inputStream = entity.getContent();
            String result = IOUtils.toString(inputStream, "UTF-8");
            inputStream.close();
            return result;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     *
     * @param url
     * @param paramsMap
     * @return
     */
    public static String post(String url, Map<String,String> paramsMap) {

        CloseableHttpClient httpclient = HttpClients.createDefault();

        HttpPost httpPost = new HttpPost(url);
        String result = null;

        CloseableHttpResponse response = null;
        List<NameValuePair> nameValuePairList = new ArrayList<NameValuePair>();
        Set<String> it = paramsMap.keySet();
        Iterator<String> iterator = it.iterator();
        while(iterator.hasNext()){
            String key = iterator.next();
            String value = paramsMap.get(key);
            nameValuePairList.add(new BasicNameValuePair(key,value));
        }
        try {

            httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairList, "utf-8"));
            response = httpclient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            InputStream inputStream = entity.getContent();
            result = parse(inputStream);

            EntityUtils.consume(entity);
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.post 1 error!", e);
        } finally {
            assert response != null;
            try {
                response.close();
            } catch (IOException e) {
                log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.post 2 error!", e);
            }
        }
        return result;
    }
    /**
     * 将流转换为字符串
     *
     * @param inputStream
     * @return
     */
    private static String parse(InputStream inputStream) {
        String result = null;
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(inputStream,"utf-8"));
        } catch (UnsupportedEncodingException e) {
            log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.parse 1 error!", e);
        }
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.parse 2 error!", e);
        }
        result = sb.toString();
        return result;
    }

    public static String doGet(String url) {
        try {
            HttpClient client = new DefaultHttpClient();
            //发送get请求
            HttpGet request = new HttpGet(url);
            HttpResponse response = client.execute(request);

            /**请求发送成功，并得到响应**/
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                /**读取服务器返回过来的json字符串数据**/
                String strResult = EntityUtils.toString(response.getEntity());

                return strResult;
            }
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.huawei.util.HttpUtils.doGet(java.lang.String) error!", e);
        }

        return null;
    }

    public static String getNormal(String url) {
//        HttpClientBuilder build = HttpClients.custom();
//        HttpHost proxy = new HttpHost("10.4.103.69", 8080);
//        CloseableHttpClient client = build.setProxy(proxy).build();
        HttpGet httpGet = new HttpGet(url);
        try (CloseableHttpResponse httpResponse = httpClient.execute(httpGet)) {
            HttpEntity entity = httpResponse.getEntity();
            InputStream inputStream = entity.getContent();
            String result = IOUtils.toString(inputStream, "UTF-8");
            inputStream.close();
            return result;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static <T> T get(String url, Class<T> clazz) {
//        String result = get(url);
        String result = doGet(url);

        if (StringUtils.isNotBlank(result)) {
            try {
                return mapper.readValue(result, clazz);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return null;
    }
}
