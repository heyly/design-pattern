package com.bosch.rbcd.common.huawei.util;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.ZipUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname Mf4Util
 * @description TODO
 * @date 2023/4/7 14:14
 */
@RequiredArgsConstructor
@Component
@Slf4j
public class Mf4Util {

    private final ObsUtil obsUtil;

    @Value("${system.filePath}")
    private String baseFilePath;

    private static final String CSV_TO_MDF_TOOL_PY = "python_module/tool/csvToMF4.py";

    public void convertFolderToMf4(String sourceFolder, String mf4Folder) {
        String mf4Url = "";
        // 下载csv转MF4工具
        String csvToMf4PyFile =baseFilePath+ File.separator + StrUtil.replace(CSV_TO_MDF_TOOL_PY,"/", File.separator);
        obsUtil.getFile(CSV_TO_MDF_TOOL_PY, csvToMf4PyFile);
        FileUtil.mkdir(mf4Folder);
        List<File> csvFileList = new ArrayList<>(FileUtils.listFiles(new File(sourceFolder), new String[]{"csv"},
                true));
        if (CollectionUtil.isNotEmpty(csvFileList)) {
            for (File file : csvFileList) {
                excuteCsvToMF4(mf4Folder, file, csvToMf4PyFile);
            }
        }
        FileUtil.del(csvToMf4PyFile);
    }

    public void excuteCsvToMF4(String targetFolder, File sourceFile, String csvToMDFPythonFile) {
        String newMf4FilePath = targetFolder + File.separator + StrUtil.replace(sourceFile.getName(), ".csv",".mf4");
        String[] argss = new String[]{"python", csvToMDFPythonFile, sourceFile.getAbsolutePath(), newMf4FilePath};
        try {
            Process process = Runtime.getRuntime().exec(argss);
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String getMf4Obs(String sourceFolder, String mf4Folder) {
        String mf4Url = "";
        convertFolderToMf4(sourceFolder, mf4Folder);
        if (!FileUtil.isDirEmpty(new File(mf4Folder))) {
            File mf4Zip = ZipUtil.zip(mf4Folder);
            mf4Url = obsUtil.putFile(mf4Zip);
            FileUtil.del(mf4Folder);
            FileUtil.del(mf4Zip);
        }
        return mf4Url;
    }
}
