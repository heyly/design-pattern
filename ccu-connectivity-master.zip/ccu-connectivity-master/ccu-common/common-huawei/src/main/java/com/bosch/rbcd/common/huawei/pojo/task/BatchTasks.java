package com.bosch.rbcd.common.huawei.pojo.task;


import java.util.List;

public class BatchTasks {
    private String app_id;
    private String task_name;
    private String task_type;
    private List<String> targets;
    private Object targets_filter;
    private Object document;
    private String document_source;

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }

    public String getTask_name() {
        return task_name;
    }

    public void setTask_name(String task_name) {
        this.task_name = task_name;
    }

    public String getTask_type() {
        return task_type;
    }

    public void setTask_type(String task_type) {
        this.task_type = task_type;
    }

    public List<String> getTargets() {
        return targets;
    }

    public void setTargets(List<String> targets) {
        this.targets = targets;
    }

    public Object getTargets_filter() {
        return targets_filter;
    }

    public void setTargets_filter(Object targets_filter) {
        this.targets_filter = targets_filter;
    }

    public Object getDocument() {
        return document;
    }

    public void setDocument(Object document) {
        this.document = document;
    }

    public String getDocument_source() {
        return document_source;
    }

    public void setDocument_source(String document_source) {
        this.document_source = document_source;
    }
}
