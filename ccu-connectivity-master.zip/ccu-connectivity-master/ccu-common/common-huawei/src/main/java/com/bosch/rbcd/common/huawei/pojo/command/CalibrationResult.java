package com.bosch.rbcd.common.huawei.pojo.command;

import lombok.Data;

@Data
public class CalibrationResult {

    private String name;

    private String addr;

    private String datalen;

    private String lastvalue;

    private String setvalue;

    private String getvalue;
}
