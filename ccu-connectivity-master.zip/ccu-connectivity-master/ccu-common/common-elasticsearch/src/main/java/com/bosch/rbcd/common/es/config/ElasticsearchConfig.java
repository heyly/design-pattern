package com.bosch.rbcd.common.es.config;

import org.apache.http.HttpHost;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
public class ElasticsearchConfig {

    @Value("${spring.elasticsearch.rest.uris}")
    private String esUris;

    @Bean
    public RestHighLevelClient restHighLevelClient() {
        String[] uris = esUris.split(",");
        HttpHost[] esHosts = new HttpHost[uris.length];
        for (int i = 0; i < uris.length; i++) {
            String[] esHost = uris[i].split(":");
            String ip = esHost[0];
            int port = Integer.parseInt(esHost[1]);
            esHosts[i] = new HttpHost(ip, port, "http");
        }
        return new RestHighLevelClient(RestClient.builder(esHosts)
                        .setRequestConfigCallback(builder -> builder.setConnectTimeout(90000000)
                            .setSocketTimeout(90000000))
                        .setHttpClientConfigCallback(builder -> {
                            // 禁用身份验证缓存
                            builder.disableAuthCaching();
                            //显式设置keepAliveStrategy
                            builder.setKeepAliveStrategy((httpResponse,httpContext) -> TimeUnit.MINUTES.toMillis(3));
                            //显式开启tcp keepalive
                            builder.setDefaultIOReactorConfig(IOReactorConfig.custom().setSoKeepAlive(true).build());
                            return builder;
                        }));
    }
}
