package com.bosch.rbcd.common.es.trace;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.time.LocalDateTime;

@Data
@Document(indexName = "trace_event")
@Accessors(chain = true)
public class TraceEvent {
    private Long userId;

    private String username;

    private String realName;

    private String sourceIp;

    private String requestUrl;

    private String serviceName;

    private String permUrl;

    private String permName;

    @Field(type = FieldType.Date, format = DateFormat.custom, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime requestTime;

    @Field(type = FieldType.Date, format = DateFormat.custom, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime responseTime;

    private Long executeTime;

    private String responseCode;

    private String responseMessage;

    private String responseBody;

    private String userAgent;

    private String requestBody;

    @Field(type = FieldType.Date, format = DateFormat.custom, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime utcRequestTime;

    @Field(type = FieldType.Date, format = DateFormat.custom, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime utcResponseTime;

    private String tlsVersion;

    private String cipherSuite;
}
