package com.bosch.rbcd.common.hbase.filter;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.filter.FilterBase;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname MinimumPrefixFilter
 * @description TODO
 * @date 2023/6/1 14:35
 */
public class ManyColumnPrefixFilter  extends FilterBase {
    private byte[][] prefixArray;

    public ManyColumnPrefixFilter(byte[][] prefixArray) {
        this.prefixArray = prefixArray;
    }

    @Override
    public ReturnCode filterKeyValue(Cell cell) throws IOException {
        byte[] columnName = cell.getQualifierArray();
        for (byte[] prefix : prefixArray) {
            if (Bytes.startsWith(columnName, prefix)) {
                return ReturnCode.INCLUDE;
            }
        }
        return ReturnCode.SKIP;
    }
}
