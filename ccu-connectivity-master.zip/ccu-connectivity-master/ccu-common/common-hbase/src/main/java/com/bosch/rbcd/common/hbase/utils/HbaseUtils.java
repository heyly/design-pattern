package com.bosch.rbcd.common.hbase.utils;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.bosch.rbcd.common.hbase.constant.HBaseTableConstant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.security.User;
import org.apache.hadoop.hbase.util.Bytes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.*;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname HbaseUtils
 * @description TODO
 * @date 2022/7/19 15:16
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class HbaseUtils {
    private final Connection hbaseConnection;
    private final Admin admin;


    private byte[] getBytes(Object object) {
        byte[] bytes;
        if (object instanceof Boolean) {
            bytes = Bytes.toBytes((Boolean) object);
        } else if (object instanceof Integer) {
            bytes = Bytes.toBytes((Integer) object);
        } else if (object instanceof Short) {
            bytes = Bytes.toBytes((Short) object);
        } else if (object instanceof Long) {
            bytes = Bytes.toBytes((Long) object);
        } else if (object instanceof Float) {
            bytes = Bytes.toBytes((Float) object);
        } else if (object instanceof Double) {
            bytes = Bytes.toBytes((Double) object);
        } else if (object instanceof String) {
            bytes = Bytes.toBytes((String) object);
        } else if (object instanceof BigDecimal) {
            bytes = Bytes.toBytes((BigDecimal) object);
        } else if (object instanceof ByteBuffer) {
            bytes = Bytes.toBytes((ByteBuffer) object);
        } else {
            bytes = Bytes.toBytes(object.toString());
        }
        return bytes;
    }

    public Table getTable(String tableName) throws IOException {
        Table table = hbaseConnection.getTable(TableName.valueOf(tableName));
        return table;
    }


    /**
     * 判断表是否已经存在，这里使用间接的方式来实现
     * <p>
     * admin.tableExists() 会报NoSuchColumnFamilyException， 有人说是hbase-client版本问题
     *
     * @param tableName
     * @return
     * @throws IOException
     */
    public boolean tableExists(String tableName) throws IOException {
        TableName[] tableNames = admin.listTableNames();
        if (tableNames != null && tableNames.length > 0) {
            for (int i = 0; i < tableNames.length; i++) {
                if (tableName.equals(tableNames[i].getNameAsString())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * put <tableName>,<rowKey>,<family:column>,<value>,<timestamp>
     *
     * @param tableName
     * @param rowKey
     * @param columnFamily
     * @param columnDataMap
     */
    public boolean insertOrUpdate(String tableName, String rowKey, String columnFamily,
                                  Map<String, String> columnDataMap) {
        boolean successFlag = false;
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            Put put = new Put(getBytes(rowKey));
            columnDataMap.forEach((column, value) -> put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(column)
                    , getBytes(value)));
            table.put(put);
            successFlag = true;
        } catch (Exception e) {
            log.error("HbaseUtils.insertOrUpdate error!", e);
        }
        return successFlag;
    }

    /**
     * 批量插入数据
     *
     * @param tableName
     * @param columnFamily
     * @param batchRowDataMap
     */
    public void batchInsert(String tableName, String columnFamily, Map<String, Map<String, Object>> batchRowDataMap) {
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            List<Put> putList = new ArrayList<>();
            batchRowDataMap.forEach((rowKey, columnDataMap) -> {
                Put put = new Put(getBytes(rowKey));
                columnDataMap.forEach((column, value) -> put.addColumn(Bytes.toBytes(columnFamily),
                        Bytes.toBytes(column), getBytes(value)));
                putList.add(put);
            });
            table.put(putList);
        } catch (Exception e) {
            log.error("HbaseUtils.batchInsert error!", e);
        }
    }

    public void createTable(String tableName, String... columnFamilies) throws IOException {
        TableName name = TableName.valueOf(tableName);
        boolean isExists = this.tableExists(tableName);
        if (isExists) {
            throw new TableExistsException(tableName + "is exists!");
        }
        TableDescriptorBuilder descriptorBuilder = TableDescriptorBuilder.newBuilder(name);
        List<ColumnFamilyDescriptor> columnFamilyList = new ArrayList<>();
        for (String columnFamily : columnFamilies) {
            ColumnFamilyDescriptor columnFamilyDescriptor = ColumnFamilyDescriptorBuilder
                    .newBuilder(columnFamily.getBytes()).build();
            columnFamilyList.add(columnFamilyDescriptor);
        }
        descriptorBuilder.setColumnFamilies(columnFamilyList);
        TableDescriptor tableDescriptor = descriptorBuilder.build();
        admin.createTable(tableDescriptor);
    }

    /**
     * 批量插入数据
     *
     * @param tableName
     * @param columnFamily
     * @param data         key: rowKey value: (key: columns value: values)
     */
    public void batchSave(String tableName, String columnFamily, Map<String, Map<String[], String[]>> data) throws IOException {
        Table table = hbaseConnection.getTable(TableName.valueOf(tableName));
        List<Put> list = new ArrayList<>();
        data.forEach((rowKey, v) -> {
            Put put = new Put(Bytes.toBytes(rowKey));
            v.forEach((columns, values) -> {
                for (int i = 0; i < columns.length; i++) {
                    put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(columns[i]), Bytes.toBytes(values[i]));
                }
            });

            list.add(put);
        });
        table.put(list);
    }

    /**
     * @Description: scan方式获取Table数据
     * @Param: [table, scan]
     * @return: java.util.List<java.util.Map < java.lang.String, java.lang.String>>
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/7/20
     */
    private List<Map<String, String>> getDataByScan(Table table, Scan scan) {
        List<Map<String, String>> results = new ArrayList<>();
        try (ResultScanner resultScanner = table.getScanner(scan)) {
            for (Result result : resultScanner) {
                Map<String, String> map = new HashMap<>();
                Cell[] cells = result.rawCells();
                for (Cell cell : cells) {
                    String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
                    String cellValue = Bytes.toString(CellUtil.cloneValue(cell));
                    map.put(qualifier, cellValue);
                }
                results.add(map);
            }
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.getDataByScan error!", e);
        }
        return results;
    }

    /**
     * @Description: 查找指定区间原始数据
     * @Param: [tableName, startRow, endRow]
     * @return: java.util.List<java.util.Map < java.lang.String, java.lang.String>>
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/7/20
     */
    public List<Map<String, String>> findDurationRawData(String tableName, String startRow, String endRow) {
        List<Map<String, String>> results = new ArrayList<>();
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(startRow));
            scan.withStopRow(Bytes.toBytes(endRow), true);

            FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);
            // 过滤掉confid为null的记录行
            SingleColumnValueFilter singleColumnValueFilter = new SingleColumnValueFilter(
                    HBaseTableConstant.RAW_BASE_COLUMAN_FAMILY.getBytes(),
                    HBaseTableConstant.RAW_BASE_COLUMAN_COFIG.getBytes(),
                    CompareOperator.NOT_EQUAL,
                    new NullComparator());
            // 默认值为 false，即如果该行数据不包含参考列，其依然被包含在最后的结果中；设置为 true 时，则不包含；
            singleColumnValueFilter.setFilterIfMissing(true);
            filterList.addFilter(singleColumnValueFilter);

            // 过滤rawData原始数据列，减少内存占用
            QualifierFilter excludeRawDataFilter = new QualifierFilter(CompareOperator.NOT_EQUAL,
                    new BinaryComparator(Bytes.toBytes("rawData")));
            filterList.addFilter(excludeRawDataFilter);
            scan.setFilter(filterList);

            results = getDataByScan(table, scan);
        } catch (Exception e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.findDurationRawData error!", e);
        }
        return results;
    }

    /**
     * @Description: 通过列名前缀查找指定区间数据
     * @Param: [ccuId, startTime, endTime, columnPrfixList, tableName]
     * @return: java.util.List<java.util.Map < java.lang.String, java.lang.Object>>
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/7/12
     */
    public List<Map<String, String>> findDataByColumnPrefix(String tableName, String startRow, String endRow,
                                                            List<String> columnPrfixList) {
        List<Map<String, String>> results = new ArrayList<>();
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(startRow));
            scan.withStopRow(Bytes.toBytes(endRow));
            // 创建列名前缀过滤器
            byte[][] columnPrfixByte = columnPrfixList.stream().map(Bytes::toBytes).toArray(byte[][]::new);
            Filter filter = new MultipleColumnPrefixFilter(columnPrfixByte);
            scan.setFilter(filter);
            results = getDataByScan(table, scan);
        } catch (Exception e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.findDataByColumnPrefix error!", e);
        }
        return results;
    }

    /**
     * @Description: 通过列名查找指定区间数据
     * @Param: [tableName, startRow, endRow, columnPrfixList]
     * @return: java.util.List<java.util.Map < java.lang.String, java.lang.String>>
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/7/20
     */
    public List<Map<String, String>> findDataByColumnName(String tableName, String startRow, String endRow,
                                                          List<String> labelNameList, List<String> labelPrefixList) {
        List<Map<String, String>> results = new ArrayList<>();
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(startRow));
            scan.withStopRow(Bytes.toBytes(endRow));
            // 多条件过滤： MUST_PASS_ONE-> || ,MUST_PASS_ALL -> &&
            FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ONE);

            if (CollectionUtil.isNotEmpty(labelNameList)) {
                labelNameList.forEach(columnName -> {
                    filterList.addFilter(new QualifierFilter(CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(columnName))));
                });
            }

            if (CollectionUtil.isNotEmpty(labelPrefixList)) {
                // 创建列名前缀过滤器
                byte[][] columnPrefixByte = labelPrefixList.stream().map(Bytes::toBytes).toArray(byte[][]::new);
                Filter multiColumnNameFilter = new MultipleColumnPrefixFilter(columnPrefixByte);
                filterList.addFilter(multiColumnNameFilter);
            }

            scan.setFilter(filterList);
            results = getDataByScan(table, scan);
        } catch (Exception e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.findDataByColumnName error!", e);
        }
        return results;
    }

    /**
     * 从baseRow查找前后count包数据，支持精确/模糊匹配列名
     *
     * @param tableName
     * @param baseRow
     * @param count
     * @param labelNameList
     * @param labelPrefixList
     * @return
     */
    public List<Map<String, String>> findBaseRowAroundCountData(String tableName, String baseRow, Integer count,
                                                                List<String> labelNameList, List<String> labelPrefixList) {
        List<Map<String, String>> results = new ArrayList<>();
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(baseRow));
            // 多条件过滤： MUST_PASS_ONE-> || ,MUST_PASS_ALL -> &&
            FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ONE);

            if (CollectionUtil.isNotEmpty(labelNameList)) {
                labelNameList.forEach(columnName -> {
                    filterList.addFilter(new QualifierFilter(CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(columnName))));
                });
            }

            if (CollectionUtil.isNotEmpty(labelPrefixList)) {
                // 创建列名前缀过滤器
                byte[][] columnPrefixByte = labelPrefixList.stream().map(Bytes::toBytes).toArray(byte[][]::new);
                Filter multiColumnNameFilter = new MultipleColumnPrefixFilter(columnPrefixByte);
                filterList.addFilter(multiColumnNameFilter);
            }
            scan.setFilter(filterList);

            // baseRow查询前count个包数据
            scanData(results, table, scan, true, count);
            // baseRow查询后count个包数据
            scanData(results, table, scan, false, count);

        } catch (Exception e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.findDataByColumnName error!", e);
        }
        return results;
    }

    public Map<String, String> findOneDataBeforeBase(String tableName, String baseRow, Set<String> labelPrefixList, String[] validLabelList) {
        Map<String, String> oneData = new HashMap<>();
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(baseRow));

            if (CollectionUtil.isNotEmpty(labelPrefixList)) {
                // 创建列名前缀过滤器
                byte[][] columnPrefixByte = labelPrefixList.stream().map(Bytes::toBytes).toArray(byte[][]::new);
                Filter multiColumnNameFilter = new MultipleColumnPrefixFilter(columnPrefixByte);
                scan.setFilter(multiColumnNameFilter);

                scan.setReversed(true);

                try (ResultScanner resultScanner = table.getScanner(scan)) {
                    boolean hasDfcColumnFlag = false;
                    boolean validFlag = false;
                    for (Result result : resultScanner) {
                        Map<String, String> map = new HashMap<>();
                        Cell[] cells = result.rawCells();
                        for (Cell cell : cells) {
                            String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
                            String cellValue = Bytes.toString(CellUtil.cloneValue(cell));
                            map.put(qualifier, cellValue);

                            if (StrUtil.startWithAny(qualifier, validLabelList)) {
                                hasDfcColumnFlag = true;
                                if (!validFlag) {
                                    validFlag = NumberUtil.isNumber(cellValue);

                                }
                            }
                        }
                        if (validFlag) {
                            oneData = map;
                            break;
                        }
                        // 如果第一包数据未含有dfc label列，则条数循环
                        if (!hasDfcColumnFlag) {
                            break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.findOneValidData error!", e);
        }
        return oneData;
    }

    public Map<String, String> findFirstDataDuration(String tableName, String startRow, String endRow, List<String> columnPrfixList) {
        Map<String, String> oneData = null;
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(startRow));
            scan.withStopRow(Bytes.toBytes(endRow));
            // 创建列名前缀过滤器
            byte[][] columnPrfixByte = columnPrfixList.stream().map(Bytes::toBytes).toArray(byte[][]::new);
            Filter filter = new MultipleColumnPrefixFilter(columnPrfixByte);
            scan.setFilter(filter);

            // 查询第一个数据
            List<Map<String, String>> results = new ArrayList<>();
            scanData(results, table, scan, false, 1);
            if (CollectionUtil.isNotEmpty(results)) {
                oneData = results.get(0);
            }
        } catch (Exception e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.findOneValidData error!", e);
        }
        return oneData;
    }


    /**
     * @Description: 遍历baseRow前/后 指定包数
     * @Param: [results, table, scan, reverseFlag, count]
     * @return: void
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2024/3/21
     */
    private void scanData(List<Map<String, String>> results, Table table, Scan scan, boolean reverseFlag, Integer count) {
        scan.setReversed(reverseFlag);
        try (ResultScanner resultScanner = table.getScanner(scan)) {
            int scanCount = 0;
            for (Result result : resultScanner) {
                scanCount++;
                Map<String, String> map = new HashMap<>();
                Cell[] cells = result.rawCells();
                for (Cell cell : cells) {
                    String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
                    String cellValue = Bytes.toString(CellUtil.cloneValue(cell));
                    map.put(qualifier, cellValue);
                }
                if (reverseFlag) {
                    results.add(0, map);
                } else {
                    results.add(map);
                }
                if (scanCount >= Math.abs(count)) {
                    break;
                }
            }
        } catch (IOException e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.getDataByScan error!", e);
        }
    }


    /**
     * 获取Raw表行name
     *
     * @param vehicleId
     * @param dateTime
     * @return
     */
    public String getRawTableRow(Long vehicleId, Date dateTime) {
        String md5code = SecureUtil.md5(String.valueOf(vehicleId));
        return md5code + "_" + DateUtil.format(dateTime, DatePattern.PURE_DATETIME_PATTERN);
    }

    public String getRawTableRow(String ccuId, Date dateTime) {
        String md5code = SecureUtil.md5(ccuId);
        return md5code + "_" + DateUtil.format(dateTime, DatePattern.PURE_DATETIME_PATTERN);
    }

    /**
     * 获取Result表行name
     *
     * @param vehicleId
     * @param date
     * @return
     */
    public String getResultTableRow(Long vehicleId, Date date) {
        String md5code = SecureUtil.md5(String.valueOf(vehicleId));
        return md5code + "_" + DateUtil.format(date, DatePattern.PURE_DATE_PATTERN);
    }

    /**
     * @Description: 判断车辆在指定时间段内是否在线
     * @Param: [ccuId, startTime, endTime]
     * @return: boolean
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/3/16
     */
    public String getOnlineCcuNo(String vehicleId, String startTime, String endTime) {
        String onlineCcuNo = "";
        try (Table table = hbaseConnection.getTable(TableName.valueOf("rbcd_iov_data_ccu_raw1"))) {
            String md5code = SecureUtil.md5(vehicleId);
            Scan scan = new Scan();
            scan.setCaching(1);
            scan.setStartRow(Bytes.toBytes(md5code + "_" + startTime));
            scan.setStopRow(Bytes.toBytes(md5code + "_" + endTime));
            scan.setFilter(new QualifierFilter(CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes("name"))));
            ResultScanner resultScanner = table.getScanner(scan);
            Result firstData = resultScanner.next();
            if (Objects.nonNull(firstData) && !firstData.isEmpty()) {
                onlineCcuNo = Bytes.toString(CellUtil.cloneValue(firstData.rawCells()[0]));
            }
        } catch (Exception e) {
            log.error("判断车辆[{}]是否在线出错：{}", vehicleId, e);
        }
        return onlineCcuNo;
    }

    public boolean hasData(String vehicleId, String startTime, String endTime) {
        boolean hasDataFlag = false;
        try (Table table = hbaseConnection.getTable(TableName.valueOf("rbcd_iov_data_ccu_raw1"))) {
            String md5code = SecureUtil.md5(vehicleId);
            Scan scan = new Scan();
            scan.setCaching(1);
            scan.setStartRow(Bytes.toBytes(md5code + "_" + startTime));
            scan.setStopRow(Bytes.toBytes(md5code + "_" + endTime));
            ResultScanner resultScanner = table.getScanner(scan);
            Result firstData = resultScanner.next();
            if (Objects.nonNull(firstData) && !firstData.isEmpty()) {
                hasDataFlag = true;
            }
        } catch (Exception e) {
            log.error("判断车辆[{}]是否在线出错：{}", vehicleId);
        }
        return hasDataFlag;
    }

    /**
     * 统计总数
     *
     * @param vehicleId
     * @param startTime
     * @param endTime
     * @return
     */
    public Long countRawData(String vehicleId, String startTime, String endTime) {
        long rawCount = 0L;
        try (Table table = hbaseConnection.getTable(TableName.valueOf("rbcd_iov_data_ccu_raw1"))) {
            String md5code = SecureUtil.md5(vehicleId);
            Scan scan = new Scan();
            scan.setCaching(1000);
            scan.setStartRow(Bytes.toBytes(md5code + "_" + startTime));
            scan.setStopRow(Bytes.toBytes(md5code + "_" + endTime));
            ResultScanner resultScanner = table.getScanner(scan);
            for (Result result : resultScanner) {
                rawCount++;
            }
        } catch (Exception e) {
            log.error("判断车辆[{}]是否在线出错：{}", vehicleId, e);
        }
        return rawCount;
    }

    /**
     * 查询某个列名第一次不是'-'的数值
     *
     * @param tableName 表名
     * @param startRow  开始扫描的行
     * @param reverse   是否逆序
     * @param labelName 过滤的label列表
     * @return value
     */
    public String filterByLabelAndValue(String tableName, String startRow, boolean reverse, String labelName) {
        try (Table table = hbaseConnection.getTable(TableName.valueOf(tableName))) {
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(startRow));
            scan.setReversed(reverse);

            FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);
            filterList.addFilter(new QualifierFilter(CompareFilter.CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes(labelName))));
            filterList.addFilter(new SingleColumnValueFilter(Bytes.toBytes(HBaseTableConstant.RAW_BASE_COLUMAN_FAMILY),
                    Bytes.toBytes(labelName), CompareFilter.CompareOp.NOT_EQUAL, Bytes.toBytes("-")));
            scan.setFilter(filterList);
            Result result = table.getScanner(scan).next();
            return Bytes.toString(CellUtil.cloneValue(result.rawCells()[0]));
        } catch (Exception e) {
            log.error("com.bosch.rbcd.common.hbase.utils.HbaseUtils.filterByLabelAndValue error!", e);
        }
        return null;
    }
}

