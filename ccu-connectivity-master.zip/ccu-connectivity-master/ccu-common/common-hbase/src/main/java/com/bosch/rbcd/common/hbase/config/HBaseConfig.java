package com.bosch.rbcd.common.hbase.config;

import com.bosch.rbcd.common.hbase.utils.LoginUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.security.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @author wangbo
 * @version 1.0.0
 * @Classname HBaseConfig
 * @description: Hbase连接配置类
 * @date 2022/7/19 14:58
 */
@Slf4j
@Component
public class HBaseConfig {

    @Value("${hbase.zookeeper.quorum}")
    private String hbaseQuorum;

    @Value("${hbase.zookeeper.clientPort}")
    private String clientPort;


    @Value("${hbase.confPath}")
    private String hbaseConfPath;

//    @Bean
//    public org.apache.hadoop.conf.Configuration configuration() {
//        org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();
//        conf.set("hbase.zookeeper.quorum", hbaseQuorum);
//        conf.set("hbase.zookeeper.property.clientPort", clientPort);
//        return conf;
//    }

    @Bean
    public Admin admin() {
        Admin admin = null;
        try {
            Configuration conf = init();
            login(conf);
            handlZkSslEnabled(conf);
            return ConnectionFactory.createConnection(conf).getAdmin();
        } catch (Exception e) {
            log.error("Failed to login because ", e);
        }
        return admin;
    }

    @Bean
    public Connection getConnection() throws IOException {
        try {
            Configuration conf = init();
            login(conf);
            handlZkSslEnabled(conf);
            return ConnectionFactory.createConnection(conf);
        } catch (Exception e) {
            log.error("Failed to login because ", e);
            return null;
        }
    }


    private Configuration init() throws IOException {
        // Default load from conf directory
        Configuration conf = HBaseConfiguration.create();
        conf.addResource(new Path(hbaseConfPath + "core-site.xml"), false);
        conf.addResource(new Path(hbaseConfPath + "hdfs-site.xml"), false);
        conf.addResource(new Path(hbaseConfPath + "hbase-site.xml"), false);
        return conf;
    }

    private void login(Configuration conf) throws IOException {
        if (User.isHBaseSecurityEnabled(conf)) {
            String userName = "rbcd_cloud_user";

            String userKeytabFile = hbaseConfPath + "user.keytab";
            String krb5File = hbaseConfPath + "krb5.conf";
            /*
             * if need to connect zk, please provide jaas info about zk. of course,
             * you can do it as below:
             * System.setProperty("java.security.auth.login.config", confDirPath +
             * "jaas.conf"); but the demo can help you more : Note: if this process
             * will connect more than one zk cluster, the demo may be not proper. you
             * can contact us for more help
             */
            LoginUtil.setJaasConf("Client", userName, userKeytabFile);
            LoginUtil.login(userName, userKeytabFile, krb5File, conf);
        }
    }

    private void handlZkSslEnabled(org.apache.hadoop.conf.Configuration conf) {
        String ZK_CLIENT_CNXN_SOCKET = "zookeeper.clientCnxnSocket";
        String ZK_CLIENT_SECURE = "zookeeper.client.secure";
        String ZK_SSL_SOCKET_CLASS = "org.apache.zookeeper.ClientCnxnSocketNetty";
        boolean zkSslEnabled = conf.getBoolean("HBASE_ZK_SSL_ENABLED", false);
        if (zkSslEnabled) {
            System.setProperty(ZK_CLIENT_CNXN_SOCKET, ZK_SSL_SOCKET_CLASS);
            System.setProperty(ZK_CLIENT_SECURE, "true");
        } else {
            if (System.getProperty(ZK_CLIENT_CNXN_SOCKET) != null) {
                System.clearProperty(ZK_CLIENT_CNXN_SOCKET);
            }
            if (System.getProperty(ZK_CLIENT_SECURE) != null) {
                System.clearProperty(ZK_CLIENT_SECURE);
            }
        }
    }
}
