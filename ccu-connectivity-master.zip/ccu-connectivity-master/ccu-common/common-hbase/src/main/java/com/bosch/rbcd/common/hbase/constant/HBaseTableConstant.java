package com.bosch.rbcd.common.hbase.constant;

import java.util.Arrays;
import java.util.List;

/**
 * @author WBO3WX
 * @description Fcev系统 Hbase表常量类
 */
public class HBaseTableConstant {

    /**
     * 原始数据表名
     */
    public final static String RAW_DATA_TABLE_NAME = "rbcd_iov_data_ccu_raw1";

    /**
     * 结果数据表名
     */
    public final static String RESULT_DATA_TABLE_NAME = "rbcd_iov_data_ccu_result";

    /**
     * 历史按天汇总数据表名(ccuCount任务定时汇总昨日原始数据)
     */
    public final static String DAY_SUMMARY_DATA_TABLE_NAME = "";

    /**
     * 创建时间数据时间列名
     */
    public final static String CREAT_TIME_COLUMN = "createAt";

    /**
     * 到达时间数据时间列名
     */
    public final static String ARRIVE_TIME_COLUMN = "arriveAt";

    /**
     * 原始数据表基础列族
     */
    public final static String RAW_BASE_COLUMAN_FAMILY = "base_info";

    /**
     * 原始数据表基础列-配置列
     */
    public final static String RAW_BASE_COLUMAN_COFIG = "confId";

    /**
     * 原始表基础列族列名列表
     */
    public final static String[] RAW_BASE_COLUMN_ARRAY = new String[]{"name", "createAt", "arriveAt", "imei", "taskId"
            , "confId", "deviceType", "longitude", "latitude"};


    /**
     * DFC 相关标签名列表
     */
    public static final List<String> DFC_BASIC_COLUMNLIST = Arrays.asList("name", "createAt", "longitude", "latitude", "confId");

    /**
     * BEV 相关标签名列表
     */
    public static final List<String> BEV_DFC_COLUMN_PREFIX_LIST = Arrays.asList("name", "createAt", "PDU_FailCode", "DCDC_FailCode",
            "APCM_FailCode", "MCU_FailCode");

    /**
     * BEV——JP360 相关标签名列表
     */
    public static final List<String> BEV_JP360_DFC_COLUMN_PREFIX_LIST = Arrays.asList("name", "createAt", "MCU_FailCode");

}
