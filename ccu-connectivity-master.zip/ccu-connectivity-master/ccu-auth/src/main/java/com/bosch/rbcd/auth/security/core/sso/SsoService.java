package com.bosch.rbcd.auth.security.core.sso;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.bosch.rbcd.auth.common.exception.BoschSsoException;
import com.bosch.rbcd.system.api.UserFeignClient;
import com.bosch.rbcd.system.dto.UpdateLoginInfoDTO;
import com.nimbusds.jose.JWSObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class SsoService {

    private final RestTemplate restTemplate;
    private final UserFeignClient userFeignClient;

    @Value("${adfs.token-url}")
    private String tokenUrl;

    @Value("${adfs.client-id}")
    private String clientId;

    @Value("${adfs.client-secret}")
    private String clientSecret;

    @Value("${adfs.jwks-uri}")
    private String jwksUri;

    @Value("${adfs.issuer}")
    private String issuer;

    @Value("${adfs.redirect-url}")
    private String redirectUrl;

    /**
     * 由code获取博世内部NT账号
     * @param code
     * @return
     */
    public String getNtAccount(String code) {
        MultiValueMap<String,Object> params = new LinkedMultiValueMap<>();
        params.add("client_id",clientId);
        params.add("client_secret",clientSecret);
        params.add("redirect_uri",redirectUrl);
        params.add("grant_type","authorization_code");
        params.add("code",code);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        ResponseEntity<JSONObject> httpEntity = restTemplate.postForEntity(tokenUrl, new HttpEntity<>(params, headers), JSONObject.class);
        log.info("bosch sso request result entity: {}", httpEntity);
        JSONObject object = httpEntity.getBody();
        if (Objects.isNull(object)) {
            log.error("请求博世SSO链接失败");
            throw new BoschSsoException("请求博世SSO链接失败");
        }
        log.info("bosch sso request result object: {}", object);
        String token = object.getString("id_token");
        String payload = null;
        try {
            payload = StrUtil.toString(JWSObject.parse(token).getPayload());
        } catch (ParseException e) {
            log.error("parse bosch id token failed: {}", e.getMessage(), e);
            throw new BoschSsoException("解析Bosch SSO id Token失败");
        }
        JSONObject payloadObject = JSON.parseObject(payload);
        String nt = payloadObject.getString("upn").split("@")[0];
        String realName = payloadObject.getString("name");
        userFeignClient.updateLoginInfo(nt, new UpdateLoginInfoDTO(null, realName));
        return nt;
    }
}
