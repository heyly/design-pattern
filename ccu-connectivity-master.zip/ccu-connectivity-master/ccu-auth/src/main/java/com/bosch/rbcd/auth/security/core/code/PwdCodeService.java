package com.bosch.rbcd.auth.security.core.code;

import cn.hutool.core.util.StrUtil;
import com.bosch.rbcd.auth.common.exception.PwdCodeException;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname PwdCodeService
 * @description TODO
 * @date 24.12.24 16:30
 */
@Service
@RequiredArgsConstructor
public class PwdCodeService {

    private final RedisUtils redisUtils;

    public void checkEmailCode(String username, String code) {

        String userEmailCodeKey = "emailCode:" + username;

        if (StrUtil.isBlank(code)) {
            throw new PwdCodeException("验证码为空，请输入！");
        }

        if (!redisUtils.hasKey(userEmailCodeKey)) {
            throw new PwdCodeException("验证码已失效，请重新发送验证码！");
        }

        String cacheCode = (String) redisUtils.get(userEmailCodeKey);
        if (!StrUtil.equals(cacheCode, code)) {
            throw new PwdCodeException("验证码错误，请检查！");
        }
    }


}
