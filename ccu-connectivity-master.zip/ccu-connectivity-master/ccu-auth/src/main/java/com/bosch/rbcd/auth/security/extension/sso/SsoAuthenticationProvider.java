package com.bosch.rbcd.auth.security.extension.sso;

import com.bosch.rbcd.auth.security.core.sso.SsoService;
import com.bosch.rbcd.common.security.extension.SsoAuthenticationToken;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Objects;

/**
 * 博世SSO认证提供者
 */
@Data
@Slf4j
public class SsoAuthenticationProvider implements AuthenticationProvider {

    private UserDetailsService sysUserDetailsService;
    private SsoService ssoService;

    /**
     * 博世SSO认证
     *
     * @param authentication
     * @return
     * @throws AuthenticationException
     */
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        SsoAuthenticationToken authenticationToken = (SsoAuthenticationToken) authentication;
        String code = (String) authenticationToken.getPrincipal();

        String ntAccount = ssoService.getNtAccount(code);
        UserDetails user = sysUserDetailsService.loadUserByUsername(ntAccount.toUpperCase());
        if (Objects.isNull(user)) {
            throw new UsernameNotFoundException("用户不存在，请先联系管理员注册");
        }

        SsoAuthenticationToken result = new SsoAuthenticationToken(user, user.getAuthorities());
        result.setDetails(authentication.getDetails());
        return result;
    }


    @Override
    public boolean supports(Class<?> authentication) {
        return SsoAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
