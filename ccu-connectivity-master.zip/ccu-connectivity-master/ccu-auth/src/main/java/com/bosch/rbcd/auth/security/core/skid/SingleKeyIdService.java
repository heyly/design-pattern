package com.bosch.rbcd.auth.security.core.skid;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.bosch.rbcd.auth.common.constants.SingleKeyIdConstants;
import com.bosch.rbcd.auth.common.exception.SingleKeyIdException;
import com.nimbusds.jose.JWSObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
@Slf4j
public class SingleKeyIdService {

    private final RedisTemplate redisTemplate;
    private final RestTemplate restTemplate;

    @Value("${skid.client-id}")
    private String clientId;

    @Value("${skid.client-secret}")
    private String clientSecret;

    @Value("${skid.redirect-url}")
    private String redirectUrl;

    @Value("${skid.endpoint-uri}")
    private String endpointUri;

    /**
     * 获取用户手机号
     * @param code 由前端请求SingleKey ID服务获取
     * @return 手机号
     */
    public String getMobile(String code) {
        // 获取jwks和token的endpoint
        Map<String, Object> endpointMap = redisTemplate.opsForHash().entries(SingleKeyIdConstants.ENDPOINT_REDIS_KEY);
        if (CollectionUtil.isEmpty(endpointMap)) {
            endpointMap = new HashMap<>();
            JSONObject endpointObject = restTemplate.getForObject(endpointUri, JSONObject.class);
            if (endpointObject == null) {
                throw new SingleKeyIdException("从SingleKey ID服务获取endpoint失败, 登录失败");
            }
            endpointMap.put(SingleKeyIdConstants.JWKS_URI_KEY, endpointObject.getString(SingleKeyIdConstants.JWKS_URI_KEY));
            endpointMap.put(SingleKeyIdConstants.TOKEN_URI_KEY, endpointObject.getString(SingleKeyIdConstants.TOKEN_URI_KEY));
            redisTemplate.opsForHash().putAll(SingleKeyIdConstants.ENDPOINT_REDIS_KEY, endpointMap);
            redisTemplate.expire(SingleKeyIdConstants.ENDPOINT_REDIS_KEY, 1, TimeUnit.DAYS);
        }
        String tokenEndpoint = endpointMap.get(SingleKeyIdConstants.TOKEN_URI_KEY).toString();
        MultiValueMap<String,Object> params = new LinkedMultiValueMap<>();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setBasicAuth(clientId, clientSecret);
        params.add("client_id",clientId);
        params.add("client_secret",clientSecret);
        params.add("redirect_uri",redirectUrl);
        params.add("grant_type","authorization_code");
        params.add("code",code);
        ResponseEntity<JSONObject> httpEntity = restTemplate.postForEntity(tokenEndpoint, new HttpEntity<>(params, headers), JSONObject.class);
        JSONObject singleKeyIdTokenObject = httpEntity.getBody();
        if (singleKeyIdTokenObject == null) {
            throw new SingleKeyIdException("从SingleKey ID服务获取token失败, 登录失败");
        }
        log.info("SingleKey ID idToken object: {}", singleKeyIdTokenObject.toJSONString());
        String idToken = singleKeyIdTokenObject.getString("id_token");

        // TODO 校验token合法性

        String payload = null;
        try {
            payload = StrUtil.toString(JWSObject.parse(idToken).getPayload());
        } catch (ParseException e) {
            log.error("parse bosch id idToken failed: {}", e.getMessage(), e);
            throw new SingleKeyIdException("解析SingleKey ID的Token失败, 登录失败");
        }
        JSONObject payloadObject = JSON.parseObject(payload);
        String mobile = payloadObject.getString(SingleKeyIdConstants.MOBILE_KEY);
        redisTemplate.opsForHash().put(SingleKeyIdConstants.SINGLE_KEY_ID_TOKEN_KEY, mobile, idToken);
        redisTemplate.expire(SingleKeyIdConstants.SINGLE_KEY_ID_TOKEN_KEY, 30, TimeUnit.DAYS);
        return mobile;
    }
}
