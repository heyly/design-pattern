package com.bosch.rbcd.auth.security.extension.code;

import com.bosch.rbcd.auth.security.core.code.PwdCodeService;
import com.bosch.rbcd.common.security.extension.PwdCodeAuthenticationToken;
import com.bosch.rbcd.common.web.exception.BizException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Map;
import java.util.Objects;

/**
 * PWD+email code认证提供者
 */
@Data
@Slf4j
public class PwdCodeAuthenticationProvider implements AuthenticationProvider {
    private PasswordEncoder passwordEncoder;
    private UserDetailsService sysUserDetailsService;
    private PwdCodeService pwdCodeService;
    protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();

    /**
     * PWD+email code认证
     *
     * @param authentication
     * @return
     * @throws AuthenticationException
     */
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        PwdCodeAuthenticationToken authenticationToken = (PwdCodeAuthenticationToken) authentication;
        Map<String, String> map = (Map) authenticationToken.getPrincipal();
        String username = map.get("username");
        String password = map.get("password");
        String code = map.remove("code");

        UserDetails user = sysUserDetailsService.loadUserByUsername(username.toUpperCase());

        if (Objects.isNull(user)) {
            throw new UsernameNotFoundException("用户不存在，请先联系管理员注册");
        }

        pwdCodeService.checkEmailCode(username, code);

        if (!this.passwordEncoder.matches(password, user.getPassword())) {
            log.debug("Authentication failed: password does not match stored value");
            throw new BadCredentialsException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
        }

        PwdCodeAuthenticationToken result = new PwdCodeAuthenticationToken(user, user.getAuthorities());
        result.setDetails(authentication.getDetails());
        return result;
    }


    @Override
    public boolean supports(Class<?> authentication) {
        return PwdCodeAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
