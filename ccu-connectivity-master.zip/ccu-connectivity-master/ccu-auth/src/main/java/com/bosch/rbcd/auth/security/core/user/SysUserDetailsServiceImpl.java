package com.bosch.rbcd.auth.security.core.user;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.StrUtil;
import com.bosch.rbcd.auth.common.exception.MobileNotFoundException;
import com.bosch.rbcd.auth.common.exception.PasswordExpiredException;
import com.bosch.rbcd.common.constant.SecurityConstants;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.result.ResultCode;
import com.bosch.rbcd.common.security.dto.SysUserDetails;
import com.bosch.rbcd.common.security.dto.UserAuthDTO;
import com.bosch.rbcd.system.api.UserFeignClient;
import com.bosch.rbcd.system.dto.AuthUserDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 系统用户体系业务类
 * @author LUK3WX
 */
@Service("sysUserDetailsService")
@Slf4j
@RequiredArgsConstructor
public class SysUserDetailsServiceImpl implements UserDetailsService {

    private final UserFeignClient userFeignClient;

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        Result<AuthUserDTO> result = userFeignClient.getUserByUsername(s);
        return getUserDetails(result, 0);
    }

    public UserDetails loadUserByMobile(String mobile) throws UsernameNotFoundException {
        Result<AuthUserDTO> result = userFeignClient.getAuthInfoByMobile(mobile);
        return getUserDetails(result, 1);
    }

    @NotNull
    private static SysUserDetails getUserDetails(Result<AuthUserDTO> result, Integer type) {
        SysUserDetails userDetails = null;
        if (Result.isSuccess(result)) {
            AuthUserDTO user = result.getData();
            if (user == null) {
                if (type == 0) {
                    throw new UsernameNotFoundException(ResultCode.USER_NOT_EXIST.getMsg());
                }
                throw new MobileNotFoundException(ResultCode.MOBILE_NOT_EXIST.getMsg());
            }
            String grantType = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest().getParameter(SecurityConstants.GRANT_TYPE_KEY);
            if (StrUtil.equals(grantType, "password") && Math.abs(user.getUpdatePasswordTime().until(LocalDateTime.now(), ChronoUnit.DAYS)) > 365) {
                throw new PasswordExpiredException(ResultCode.PASSWORD_EXPIRED);
            }
            UserAuthDTO convertUser = Convert.convert(UserAuthDTO.class, user);
            convertUser.setRoles(user.getRoles());
            convertUser.setRoleIds(user.getRoleIds());
            List<UserAuthDTO.UserAppRoleDTO> list = user.getUserAppRoles().stream().map(item -> Convert.convert(UserAuthDTO.UserAppRoleDTO.class, item)).collect(Collectors.toList());
            convertUser.setUserAppRoles(list);
            userDetails = new SysUserDetails(convertUser);
        }
        if (userDetails == null) {
            throw new UsernameNotFoundException(ResultCode.USER_NOT_EXIST.getMsg());
        } else if (!userDetails.isEnabled()) {
            throw new DisabledException("该账户已被禁用!");
        }
        return userDetails;
    }
}
