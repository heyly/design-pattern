package com.bosch.rbcd.auth.security.extension.code;

import com.bosch.rbcd.common.security.extension.PwdCodeAuthenticationToken;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.exceptions.InvalidGrantException;
import org.springframework.security.oauth2.provider.*;
import org.springframework.security.oauth2.provider.token.AbstractTokenGranter;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 *  PWD+email code授权者
 */
public class PwdCodeTokenGranter extends AbstractTokenGranter {

    /**
     * 声明授权者 PwdCodeTokenGranter 支持授权模式 pwd_code
     * 根据接口传值 grant_type = pwd_code 的值匹配到此授权者
     * 匹配逻辑详见下面的两个方法
     *
     * @see CompositeTokenGranter#grant(String, TokenRequest)
     * @see AbstractTokenGranter#grant(String, TokenRequest)
     */
    private static final String GRANT_TYPE = "pwd_code";
    private final AuthenticationManager authenticationManager;

    public PwdCodeTokenGranter(AuthorizationServerTokenServices tokenServices, ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory, AuthenticationManager authenticationManager) {
        super(tokenServices, clientDetailsService, requestFactory, GRANT_TYPE);
        this.authenticationManager = authenticationManager;
    }

    @Override
    protected OAuth2Authentication getOAuth2Authentication(ClientDetails client, TokenRequest tokenRequest) {

        Map<String, String> parameters = new LinkedHashMap<>(tokenRequest.getRequestParameters());

        Authentication userAuth = new PwdCodeAuthenticationToken(parameters); // 未认证状态
        ((AbstractAuthenticationToken) userAuth).setDetails(parameters);

        userAuth = this.authenticationManager.authenticate(userAuth); // 认证中

        if (userAuth != null && userAuth.isAuthenticated()) { // 认证成功
            OAuth2Request storedOAuth2Request = this.getRequestFactory().createOAuth2Request(client, tokenRequest);
            return new OAuth2Authentication(storedOAuth2Request, userAuth);
        } else { // 认证失败
            throw new InvalidGrantException("Could not authenticate Password or Email Code: " + parameters.get("username"));
        }
    }
}
