package com.bosch.rbcd.auth.security.extension.skid;

import com.bosch.rbcd.auth.security.core.skid.SingleKeyIdService;
import com.bosch.rbcd.auth.security.core.user.SysUserDetailsServiceImpl;
import com.bosch.rbcd.common.security.extension.SingleKeyIdAuthenticationToken;
import com.bosch.rbcd.common.web.exception.BizException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Objects;

/**
 * 博世SSO认证提供者
 */
@Data
@Slf4j
public class SingleKeyIdAuthenticationProvider implements AuthenticationProvider {

    private SysUserDetailsServiceImpl sysUserDetailsService;
    private SingleKeyIdService singleKeyIdService;

    /**
     * 博世SSO认证
     *
     * @param authentication
     * @return
     * @throws AuthenticationException
     */
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        SingleKeyIdAuthenticationToken authenticationToken = (SingleKeyIdAuthenticationToken) authentication;
        String code = (String) authenticationToken.getPrincipal();

        String mobile = singleKeyIdService.getMobile(code);
        UserDetails user = sysUserDetailsService.loadUserByMobile(mobile);
        if (Objects.isNull(user)) {
            throw new UsernameNotFoundException("用户不存在，申请账号");
        }
        SingleKeyIdAuthenticationToken result = new SingleKeyIdAuthenticationToken(user, user.getAuthorities());
        result.setDetails(authentication.getDetails());
        return result;
    }


    @Override
    public boolean supports(Class<?> authentication) {
        return SingleKeyIdAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
