package com.bosch.rbcd.data.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.DataCompositeSchemeDetail;

/**
 * (CompositeSchemeDetail)表服务接口
 */
public interface DataCompositeSchemeDetailService extends IService<DataCompositeSchemeDetail> {

}