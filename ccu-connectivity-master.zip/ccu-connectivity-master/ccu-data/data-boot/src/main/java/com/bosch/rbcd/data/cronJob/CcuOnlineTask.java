package com.bosch.rbcd.data.cronJob;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bosch.rbcd.common.hbase.utils.HbaseUtils;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.service.CcuOnlineRecordService;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.fleet.api.VehicleFeignClient;
import com.bosch.rbcd.fleet.dto.ProjectDTO;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

;

@Slf4j
@Component
@RequiredArgsConstructor
public class CcuOnlineTask {

    private final StringRedisTemplate stringRedisTemplate;
    private final HbaseUtils hbaseUtils;
    private final CcuOnlineRecordService ccuOnlineRecordService;
    private final ProjectFeignClient projectFeignClient;
    private final DeviceInfoFeignClient deviceInfoFeignClient;
    private final VehicleFeignClient vehicleFeignClient;

    /**
     * 每5min实时统计当天在线
     * 0 0/5 * * * ?
     */
    @XxlJob("realTimeRecordOnlineVehicle")
    public void realTimeRecordOnlineVehicle() {
        Date today = new Date();
        executeOnlineRecord(today, null);
    }

    /**
     * 0/23点统计昨天在线
     * 0 0 0,23 * * ?
     */
    @XxlJob("recordYesterdayOnlineVehicle")
    public void recordYesterdayOnlineVehicle() {
        Date yesterday = DateUtil.yesterday();
        log.info(StrUtil.format("====计算昨日在线情况开始====="));
        executeOnlineRecord(yesterday, null);
    }

    /**
     * 每周一复核过去一周在线情况
     * 0 0 5 ? * MON
     */
    @XxlJob("checkWeekOnlineRecords")
    public void checkWeekOnlineRecords() {
        Date yesterday = DateUtil.yesterday();
        Date weekAgo = DateUtil.offsetWeek(yesterday, -1);
        log.info(StrUtil.format("====兜底计算过去一周在线情况开始====="));
        List<DateTime> dateList = DateUtil.rangeToList(weekAgo, yesterday, DateField.DAY_OF_MONTH);
        for (DateTime date : dateList) {
            executeOnlineRecord(date, null);
        }
    }

    public void executeOnlineRecord(Date date, List<Long> projectIds) {
        String dayStr = DateUtil.format(date, DatePattern.PURE_DATE_PATTERN);
        DateTime dayBegin = DateUtil.beginOfDay(date);
        String dayBeginStr = DateUtil.format(dayBegin, DatePattern.PURE_DATETIME_PATTERN);
        DateTime dayEnd = DateUtil.endOfDay(date);
        String dayEndStr = DateUtil.format(dayEnd, DatePattern.PURE_DATETIME_PATTERN);

        List<CcuOnlineRecord> existedOnlineRecordList = ccuOnlineRecordService.list(new LambdaQueryWrapper<CcuOnlineRecord>().eq(CcuOnlineRecord::getOnlineDate, dayStr));
        List<String> onlineCcuIdList = existedOnlineRecordList.stream().map(CcuOnlineRecord::getCcuId).collect(Collectors.toList());

        List<ProjectDTO> activePojectList = projectFeignClient.listActiveProject().getData();
        // 过滤目标项目
        if (CollectionUtil.isNotEmpty(projectIds)) {
            activePojectList = activePojectList.stream().filter(p -> CollectionUtil.contains(projectIds, p.getId())).collect(Collectors.toList());
        }

        for (ProjectDTO ProjectDTO : activePojectList) {
            List<ProjectVehicleCcuDTO> ccuList = deviceInfoFeignClient.listProjectCcu(ProjectDTO.getId()).getData();
            // 过滤已经在线的CCU
            ccuList = ccuList.stream().filter(v -> !onlineCcuIdList.contains(v.getCcuId())).collect(Collectors.toList());
            // 获取昨日在线CCU
            ccuList.forEach(ccu -> recordOnlineVehicle(ccu, dayStr, dayBegin, dayBeginStr, dayEnd, dayEndStr));
        }
    }

    /**
     * @Description: 判断CCU昨日是否在线
     * @Param: [ccuId, yesterdayBegin, yesterdayBeginStr, yesterdayEnd, yesterdayEndStr]
     * @return: boolean
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/3/16
     */
    private void recordOnlineVehicle(ProjectVehicleCcuDTO ccuInfo, String dayStr, DateTime yesterdayBegin, String yesterdayBeginStr, DateTime yesterdayEnd, String yesterdayEndStr) {
        String onlineCcuNo = "";
        String realTimeKey = "RealTimeData:" + ccuInfo.getCcuId();
        String dataStr = (String) stringRedisTemplate.opsForHash().get(realTimeKey, "data");
        try {
            // 查询redis实时判断
            if (StrUtil.isNotBlank(dataStr)) {
                String createAt = JSON.parseObject(dataStr).getString("createAt");
                // 处理yyyy-MM-dd HH:mm:ss:sss脏数据
                if (createAt.length() > 19) {
                    createAt = createAt.substring(0, 19);
                }
                DateTime createTime = DateUtil.parse(createAt);
                if (createTime.isAfterOrEquals(yesterdayBegin)) {
                    if (createTime.isBeforeOrEquals(yesterdayEnd)) {
                        onlineCcuNo = ccuInfo.getCcuNo();
                    }
                }
            }
            // 补算数据查询Hbase
            if (StrUtil.isBlank(onlineCcuNo)) {
                onlineCcuNo = hbaseUtils.getOnlineCcuNo(ccuInfo.getCcuId(), yesterdayBeginStr, yesterdayEndStr);
            }
        } catch (Exception e) {
            log.error("判断CCU[{}]是否在线出错", ccuInfo.getCcuId(), e);
        }
        // 若在线ccu编号非空，则新增记录
        if (StrUtil.isNotBlank(onlineCcuNo)) {
            CcuOnlineRecord ccuOnline = new CcuOnlineRecord()
                    .setProjectId(ccuInfo.getProjectId())
                    .setCcuId(ccuInfo.getCcuId())
                    .setCcuNo(onlineCcuNo)
                    .setOnlineDate(dayStr).setVehicleId(ccuInfo.getVehicleId());
            CcuOnlineRecord existedRecord = ccuOnlineRecordService.getOne(new QueryWrapper<>(ccuOnline));
            if (Objects.isNull(existedRecord)) {
                ccuOnlineRecordService.save(ccuOnline);
            }
        }
    }
}
