package com.bosch.rbcd.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.mybatis.annotation.ProjectDataPermission;
import com.bosch.rbcd.data.pojo.entity.CcuEventDataRecord;
import com.bosch.rbcd.data.pojo.query.CcuEventDataRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuEventDataRecordVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * ccu事件触发高频数据记录(CcuEventDataRecord)表数据库访问层
 *
 * @author wang bo
 * @since 2023-09-23 09:46:01
 */
@Mapper
public interface CcuEventDataRecordMapper extends BaseMapper<CcuEventDataRecord> {

    /**
     * 获取CcuEventDataRecord分页列表
     *
     * @param page
     * @param queryParams 查询参数
     * @return
     */
    @ProjectDataPermission(projectAlias = "cdi",projectIdField = "project_id")
    List<CcuEventDataRecordVO> listCcuEventDataRecordPage(Page<CcuEventDataRecordVO> page, @Param("queryParams") CcuEventDataRecordPageQuery queryParams);
}

