package com.bosch.rbcd.data.service;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname GaoDeMapService
 * @description TODO
 * @date 2023/7/19 11:24
 */
public interface GaoDeMapService {
    String getCityByGps(String longitude, String latitude);
}
