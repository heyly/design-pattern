package com.bosch.rbcd.data.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.DataCompositeScheme;
import com.bosch.rbcd.data.pojo.vo.DataCompositeSchemeVO;
import com.bosch.rbcd.data.pojo.vo.SchemeInFuelTypeVO;

import java.util.List;

/**
 * (CompositeScheme)表服务接口
 */
public interface DataCompositeSchemeService extends IService<DataCompositeScheme> {

    List<SchemeInFuelTypeVO> listAllDetails();

    DataCompositeSchemeVO saveOrUpdateCompositeScheme(DataCompositeSchemeVO compositeSchemeVO);

    Boolean deleteCompositeScheme(Long id);
}

