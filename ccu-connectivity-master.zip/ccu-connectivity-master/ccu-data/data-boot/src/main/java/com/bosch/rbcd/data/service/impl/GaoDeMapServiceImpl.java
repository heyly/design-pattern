package com.bosch.rbcd.data.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.bosch.rbcd.data.constant.GaoDeMapConstant;
import com.bosch.rbcd.data.service.GaoDeMapService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname GaoDeMapServiceImpl
 * @description TODO
 * @date 2023/7/19 11:25
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class GaoDeMapServiceImpl implements GaoDeMapService {

    private final RestTemplate restTemplate;

    @Value("${map.gaode.key}")
    private String gaodeKey;

    @Override
    public String getCityByGps(String longitude, String latitude) {
        String mapUrl = String.format(GaoDeMapConstant.REGEO_URL, longitude + "," + latitude, gaodeKey);
        JSONObject mapObj = restTemplate.getForObject(mapUrl, JSONObject.class);
        if (mapObj != null && mapObj.getJSONObject("regeocode")!= null) {
            JSONObject regionInfo = mapObj.getJSONObject("regeocode").getJSONObject("addressComponent");
            String province = regionInfo.getString("province");
            String city = regionInfo.getString("city");
            return province + city;
        }
        return "";
    }
}
