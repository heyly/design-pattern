package com.bosch.rbcd.data.constant;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname GaoDeMapConstant
 * @description TODO
 * @date 2023/7/19 11:38
 */
public class GaoDeMapConstant {
    /**
     * 逆地理编码 GET
     */
    public final static String REGEO_URL = "https://restapi.amap.com/v3/geocode/regeo?output=JSON&location=%s&key=%s&radius=1000";


}
