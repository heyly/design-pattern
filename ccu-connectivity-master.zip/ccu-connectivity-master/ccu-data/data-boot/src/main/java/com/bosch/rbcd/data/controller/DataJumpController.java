package com.bosch.rbcd.data.controller;

import cn.hutool.core.util.StrUtil;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.result.ResultCode;
import com.bosch.rbcd.data.pojo.entity.DataJumpDetail;
import com.bosch.rbcd.data.pojo.entity.DataJumpRequest;
import com.bosch.rbcd.data.pojo.entity.form.DataJumpRequestForm;
import com.bosch.rbcd.data.pojo.query.DataJumpDetailPageQuery;
import com.bosch.rbcd.data.pojo.query.DataJumpRequestPageQuery;
import com.bosch.rbcd.data.service.DataJumpDetailService;
import com.bosch.rbcd.data.service.DataJumpRequestService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(tags = "数据跳变", hidden = true)
@RestController
@RequestMapping("/dataJump")
public class DataJumpController {

    @Autowired
    private DataJumpRequestService dataJumpRequestService;

    @Autowired
    private DataJumpDetailService dataJumpDetailService;

    @ApiOperation("新建跳变请求")
    @PostMapping("/request/create")
    public Result<Long> createRequest(@RequestBody DataJumpRequestForm form) {
        if (StrUtil.isBlank(form.getCcuId()) || form.getStartTime() == null || form.getEndTime() == null) {
            return Result.failed(ResultCode.PARAM_IS_NULL);
        }
        if (form.getEndTime().before(form.getEndTime())) {
            return Result.failed("起止时间错误！");
        }
        if (form.getEndTime().getTime() - form.getStartTime().getTime() > 60 * 60 * 1000L) {
            return Result.failed("请将搜索范围设置在1小时内");
        }
        return Result.success(dataJumpRequestService.create(form));
    }

    @ApiOperation("查询请求历史")
    @GetMapping("/request/history")
    public PageResult<DataJumpRequest> requestHistory (DataJumpRequestPageQuery query) {
        if (query.getProjectId() == null || StrUtil.isBlank(query.getCcuId())) {
            return PageResult.failed(ResultCode.PARAM_IS_NULL);
        }
        return PageResult.success(dataJumpRequestService.pageQuery(query));
    }

    @ApiOperation("查询指定跳变请求的分析结果")
    @GetMapping("/detail")
    public PageResult<DataJumpDetail> detail(DataJumpDetailPageQuery query) {
        if (query.getRequestId() == null) {
            return PageResult.failed(ResultCode.PARAM_IS_NULL);
        }
        return PageResult.success(dataJumpDetailService.pageQuery(query));
    }


}
