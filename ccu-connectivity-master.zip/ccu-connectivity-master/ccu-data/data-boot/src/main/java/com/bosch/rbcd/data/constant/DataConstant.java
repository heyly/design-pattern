package com.bosch.rbcd.data.constant;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname DataDownLoadConstant
 * @description TODO
 * @date 2023/5/24 10:29
 */
public class DataConstant {

    /**
     * 车辆日期下载进度 download:vehicleIdxxx:20230516
     */
    public static final String VEHICLE_DATE_DOWNLOAD_RATE_REDIS = "download:{}:{}";
}
