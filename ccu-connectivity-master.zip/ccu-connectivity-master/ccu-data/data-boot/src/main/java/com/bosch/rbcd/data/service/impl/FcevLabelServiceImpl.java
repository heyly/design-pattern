package com.bosch.rbcd.data.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.data.mapper.FcevLabelMapper;
import com.bosch.rbcd.data.pojo.entity.VehicleFcevLabel;
import com.bosch.rbcd.data.service.VehicleFcevLabelService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @description 针对表【fcev_label】的数据库操作Service实现
 */
@Service
@Transactional
@RequiredArgsConstructor
public class FcevLabelServiceImpl extends ServiceImpl<FcevLabelMapper, VehicleFcevLabel>
        implements VehicleFcevLabelService {

    private final FcevLabelMapper fcevLabelMapper;

    @Override
    public List<String> listSystem() {
        return fcevLabelMapper.listSystem();
    }
}
