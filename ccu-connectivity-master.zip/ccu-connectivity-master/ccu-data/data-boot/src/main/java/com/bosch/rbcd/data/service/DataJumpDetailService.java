package com.bosch.rbcd.data.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.DataJumpDetail;
import com.bosch.rbcd.data.pojo.query.DataJumpDetailPageQuery;

import java.util.Date;

public interface DataJumpDetailService extends IService<DataJumpDetail> {

    IPage<DataJumpDetail> pageQuery(DataJumpDetailPageQuery dataJumpDetailPageQuery);

    void asyncCheckDetail(Long requestId, String ccuId, Date startTime, Date endTime);
}
