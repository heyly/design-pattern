//package com.bosch.rbcd.data.service.impl;
//
//import cn.hutool.core.bean.BeanUtil;
//import cn.hutool.core.convert.Convert;
//import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
//import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
//import com.bosch.rbcd.data.mapper.CompositeSchemeMapper;
//import com.bosch.rbcd.data.pojo.entity.DataCompositeScheme;
//import com.bosch.rbcd.data.pojo.entity.DataCompositeSchemeDetail;
//import com.bosch.rbcd.data.pojo.vo.DataCompositeSchemeVO;
//import com.bosch.rbcd.data.pojo.vo.SchemeInFuelTypeVO;
//import com.bosch.rbcd.data.service.DataCompositeSchemeDetailService;
//import com.bosch.rbcd.data.service.DataCompositeSchemeService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Service;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * (CompositeScheme)表服务实现类
// */
//@Service
//@RequiredArgsConstructor
//public class CompositeSchemeServiceImpl extends ServiceImpl<CompositeSchemeMapper, DataCompositeScheme> implements DataCompositeSchemeService {
//
//    private final DataCompositeSchemeDetailService dataCompositeSchemeDetailService;
//
//    private final CompositeSchemeMapper compositeSchemeMapper;
//
//    @Override
//    public List<SchemeInFuelTypeVO> listAllDetails() {
//        List<SchemeInFuelTypeVO> schemeInFuelTypeVOList = new ArrayList<>();
//        List<String> fuelTypes = compositeSchemeMapper.listFuelTypes();
//        for (String fuelType : fuelTypes) {
//            SchemeInFuelTypeVO vo = new SchemeInFuelTypeVO();
//            vo.setFuelType(fuelType);
//            vo.setDataCompositeSchemeVOList(listCompositeSchemeVOByFuelType(fuelType));
//            schemeInFuelTypeVOList.add(vo);
//        }
//        return schemeInFuelTypeVOList;
//    }
//
//    private List<DataCompositeSchemeVO> listCompositeSchemeVOByFuelType(String fuelType) {
//        List<DataCompositeScheme> list = this.list(new LambdaQueryWrapper<DataCompositeScheme>()
//                .eq(DataCompositeScheme::getFuelType, fuelType));
//        List<DataCompositeSchemeVO> dataCompositeSchemeVOList = Convert.toList(DataCompositeSchemeVO.class, list);
//        dataCompositeSchemeVOList.forEach(dataCompositeSchemeVO -> {
//            List<DataCompositeSchemeDetail> detailList = dataCompositeSchemeDetailService.list(new LambdaQueryWrapper<DataCompositeSchemeDetail>()
//                    .eq(DataCompositeSchemeDetail::getSchemeId, dataCompositeSchemeVO.getId()));
//            dataCompositeSchemeVO.setDetailList(detailList);
//        });
//        return dataCompositeSchemeVOList;
//    }
//
//    @Override
//    public DataCompositeSchemeVO saveOrUpdateCompositeScheme(DataCompositeSchemeVO dataCompositeSchemeVO) {
//        DataCompositeScheme dataCompositeScheme = new DataCompositeScheme();
//        BeanUtil.copyProperties(dataCompositeSchemeVO, dataCompositeScheme);
//        this.saveOrUpdate(dataCompositeScheme);
//        // 删除detail
//        dataCompositeSchemeDetailService.remove(new LambdaQueryWrapper<DataCompositeSchemeDetail>().eq(DataCompositeSchemeDetail::getSchemeId, dataCompositeSchemeVO.getId()));
//        // 新增detail
//        dataCompositeSchemeVO.getDetailList().forEach(dataCompositeSchemeDetail -> {
//            dataCompositeSchemeDetail.setSchemeId((dataCompositeSchemeVO.getId()));
//            dataCompositeSchemeDetailService.save(dataCompositeSchemeDetail);
//        });
//        return dataCompositeSchemeVO;
//    }
//
//    @Override
//    public Boolean deleteCompositeScheme(Long id) {
//        // 删除compositeScheme
//        this.removeById(id);
//        // 删除detail
//        return dataCompositeSchemeDetailService.remove(new LambdaQueryWrapper<DataCompositeSchemeDetail>().eq(DataCompositeSchemeDetail::getSchemeId, id));
//    }
//}
//
