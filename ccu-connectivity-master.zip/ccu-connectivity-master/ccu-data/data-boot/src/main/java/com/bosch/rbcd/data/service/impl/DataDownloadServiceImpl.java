package com.bosch.rbcd.data.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.ZipUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.bosch.rbcd.common.hbase.constant.HBaseTableConstant;
import com.bosch.rbcd.common.hbase.utils.HbaseUtils;
import com.bosch.rbcd.common.huawei.util.Mf4Util;
import com.bosch.rbcd.common.huawei.util.ObsUtil;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.common.utils.NioFileUtils;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.data.constant.DataConstant;
import com.bosch.rbcd.data.mapper.CcuDownloadRecordMapper;
import com.bosch.rbcd.data.mapper.CcuOnlineRecordMapper;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.service.DataDownloadService;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import com.bosch.rbcd.fleet.api.DataConfigFeignClient;
import com.bosch.rbcd.fleet.api.VehicleFeignClient;
import com.bosch.rbcd.fleet.dto.ConfigRemoteRecordDTO;
import com.bosch.rbcd.fleet.dto.VehicleDTO;
import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname DataDownloadServiceimpl
 * @description TODO
 * @date 2023/5/24 14:35
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DataDownloadServiceImpl implements DataDownloadService {
    @Value("${system.filePath}")
    private String sysPath;
    @Value("${obs.cluster-bucket}")
    private String clusterBucket;

    @Value("${autoMf4.projectId}")
    private String[] mf4projectIds;

    private final RedisUtils redisUtils;
    private final HbaseUtils hbaseUtils;
    private final ObsUtil obsUtil;
    private final CcuOnlineRecordMapper ccuOnlineRecordMapper;
    private final Mf4Util mf4Util;
    private final CcuDownloadRecordMapper ccuDownloadRecordMapper;
    private final VehicleFeignClient vehicleFeignClient;
    private final DeviceInfoFeignClient deviceInfoFeignClient;
    private final DataConfigFeignClient configFeignClient;

    @Async
    @Override
    public Future<String> asyncClusterCsv(CcuOnlineRecord ccuOnlineRecord) {
        String clusterKey = "";
        String vehicleRedisKey = StrUtil.format(DataConstant.VEHICLE_DATE_DOWNLOAD_RATE_REDIS, ccuOnlineRecord.getCcuId(), ccuOnlineRecord.getOnlineDate());
        redisUtils.set(vehicleRedisKey, 1, 3600);
        String csvFolder = null;
        File csvZipFile = null;
        try {
            csvFolder = getCsvFolder(vehicleRedisKey, ccuOnlineRecord);
            if (FileUtil.isNotEmpty(new File(csvFolder))) {
                csvZipFile = ZipUtil.zip(csvFolder, StandardCharsets.UTF_8);
                redisUtils.set(vehicleRedisKey, 90);
                clusterKey = ccuOnlineRecord.getCcuNo() + "/" + FileUtil.getName(csvZipFile);
                obsUtil.upFileToBucket(clusterBucket, csvZipFile, clusterKey);
                if (obsUtil.isExistedInBucket(clusterBucket, clusterKey)) {
                    ccuOnlineRecord.setCsvPath(clusterKey);
                    if (!DateUtil.format(new Date(), DatePattern.PURE_DATE_PATTERN).equals(ccuOnlineRecord.getOnlineDate())) {
                        ccuOnlineRecord.setClusterFlag(1);
                    }
                }
                redisUtils.set(vehicleRedisKey, 100);
                // 更新用户车辆下载记录为待下载状态
                ccuDownloadRecordMapper.updateDownRecordStatus(ccuOnlineRecord.getId(), "csv");

                ProjectVehicleCcuDTO ccuDevice = deviceInfoFeignClient.findByCcuId(ccuOnlineRecord.getCcuId()).getData();
                if (ccuDevice != null && ArrayUtil.contains(mf4projectIds, ccuDevice.getProjectId())) {
                    String mf4Folder = csvFolder + "_mf4";
                    File mf4ZipFile = null;
                    try {
                        mf4Util.convertFolderToMf4(csvFolder, mf4Folder);
                        redisUtils.set(vehicleRedisKey, 90);
                        if (FileUtil.loopFiles(mf4Folder).size() == FileUtil.loopFiles(csvFolder).size()) {
                            mf4ZipFile = ZipUtil.zip(mf4Folder, StandardCharsets.UTF_8);
                            String mf4Key = ccuOnlineRecord.getCcuNo() + "/" + FileUtil.getName(mf4ZipFile);
                            obsUtil.upFileToBucket(clusterBucket, mf4ZipFile, mf4Key);
                            if (obsUtil.isExistedInBucket(clusterBucket, mf4Key)) {
                                ccuOnlineRecord.setMf4Path(mf4Key);
                            }
                            ccuOnlineRecordMapper.updateById(ccuOnlineRecord);
                        }
                    } finally {
                        FileUtil.del(mf4Folder);
                        FileUtil.del(mf4ZipFile);
                    }
                }
            }
        } catch (Exception e) {
            // 标记为无法生成状态
            ccuOnlineRecord.setClusterFlag(-2);
            log.error("{}_{}聚合csv失败，请检查报错信息:", ccuOnlineRecord.getCcuNo(), ccuOnlineRecord.getOnlineDate(), e);
        } finally {
            ccuOnlineRecordMapper.updateById(ccuOnlineRecord);
            NioFileUtils.deleteDirectory(FileUtil.getParent(csvFolder, 1));
        }
        return new AsyncResult<>(clusterKey);
    }

    @Async
    @Override
    public Future<String> asyncClusterMf4(CcuOnlineRecord ccuOnlineRecord) {
        String clusterKey = "";
        String vehicleRedisKey = StrUtil.format(DataConstant.VEHICLE_DATE_DOWNLOAD_RATE_REDIS, ccuOnlineRecord.getCcuId(), ccuOnlineRecord.getOnlineDate());
        redisUtils.set(vehicleRedisKey, 1, 3600);

        // 如果csv已聚合至OBS,则下载csv转换mf4；否则实时生成csv
        String mainFolder = null;
        String csvFolder = null;
        String mf4Folder = null;
        File mf4ZipFile = null;
        try {
            if (ccuOnlineRecord.getClusterFlag() == 1 && StrUtil.isNotBlank(ccuOnlineRecord.getCsvPath())) {
                // 获取车辆车架号
                String vin = "";
                if (Objects.nonNull(ccuOnlineRecord.getVehicleId())) {
                    VehicleDTO vehicle = vehicleFeignClient.getById(ccuOnlineRecord.getVehicleId()).getData();
                    vin = vehicle != null ? StrUtil.nullToEmpty(vehicle.getVin()) : "";
                    vin = vin.replaceAll("[^a-zA-Z0-9]", "");
                }
                String mainCsvFolderName = StrUtil.format("{}_{}_{}", ccuOnlineRecord.getCcuNo(), vin, ccuOnlineRecord.getOnlineDate());
                mainFolder = sysPath + File.separator + ccuOnlineRecord.getCcuNo() + DateUtil.format(new Date(), DatePattern.PURE_DATETIME_FORMAT);
                csvFolder = mainFolder + File.separator + mainCsvFolderName;
                obsUtil.batchDownload(clusterBucket, csvFolder, Collections.singletonList(ccuOnlineRecord.getCsvPath()), true, true);
                redisUtils.set(vehicleRedisKey, 50);
            } else {
                // 实时生成csv
                csvFolder = getCsvFolder(vehicleRedisKey, ccuOnlineRecord);
                mainFolder = FileUtil.getParent(csvFolder, 1);
            }

            // csv转换为mf4
            if (FileUtil.isNotEmpty(new File(csvFolder))) {
                mf4Folder = csvFolder + "_mf4";
                mf4Util.convertFolderToMf4(csvFolder, mf4Folder);
                redisUtils.set(vehicleRedisKey, 90);
                // 校验csv与mf4文件数量
                if (FileUtil.loopFiles(mf4Folder).size() == FileUtil.loopFiles(csvFolder).size()) {
                    mf4ZipFile = ZipUtil.zip(mf4Folder, StandardCharsets.UTF_8);
                    redisUtils.set(vehicleRedisKey, 95);
                    clusterKey = ccuOnlineRecord.getCcuNo() + "/" + FileUtil.getName(mf4ZipFile);
                    obsUtil.upFileToBucket(clusterBucket, mf4ZipFile, clusterKey);
                    if (obsUtil.isExistedInBucket(clusterBucket, clusterKey)) {
                        ccuOnlineRecord.setMf4Path(clusterKey);
                    }
                    ccuOnlineRecordMapper.updateById(ccuOnlineRecord);
                    redisUtils.set(vehicleRedisKey, 100);
                    // 更新用户车辆下载记录为待下载状态
                    ccuDownloadRecordMapper.updateDownRecordStatus(ccuOnlineRecord.getId(), "mf4");
                } else {
                    redisUtils.set(vehicleRedisKey, -1);
                    String warnMsg = StrUtil.format("{}_{}csv转换mf4异常，csv[{}],mf4[{}]", ccuOnlineRecord.getCcuNo(), ccuOnlineRecord.getOnlineDate(), FileUtil.loopFiles(csvFolder).size(), FileUtil.loopFiles(mf4Folder).size());
                    log.warn(warnMsg);
                    throw new BizException(warnMsg);
                }
                // 非当日数据则为聚合数据
                if (!DateUtil.format(new Date(), DatePattern.PURE_DATE_PATTERN).equals(ccuOnlineRecord.getOnlineDate())) {
                    // 如果csv未聚合至OBS，则上传csv
                    if (StrUtil.isBlank(ccuOnlineRecord.getCsvPath())) {
                        ccuOnlineRecord.setClusterFlag(1);
                        // csv文件压缩上传OBS
                        File csvZipFile = ZipUtil.zip(csvFolder, StandardCharsets.UTF_8);
                        String clusterCsvKey = ccuOnlineRecord.getCcuNo() + "/" + FileUtil.getName(csvZipFile);
                        obsUtil.upFileToBucket(clusterBucket, csvZipFile, clusterCsvKey);
                        if (obsUtil.isExistedOfBucket(clusterBucket, clusterCsvKey)) {
                            ccuOnlineRecord.setCsvPath(clusterCsvKey);
                            ccuOnlineRecordMapper.updateById(ccuOnlineRecord);
                        }
                        FileUtil.del(csvZipFile);
                    }
                }

            }
        } catch (Exception e) {
            log.error("{}_{}聚合mf4失败，请检查报错信息:", ccuOnlineRecord.getCcuNo(), ccuOnlineRecord.getOnlineDate(), e);
            throw e;
        } finally {
            NioFileUtils.deleteDirectory(mainFolder);
        }
        return new AsyncResult<>(clusterKey);
    }


    /**
     * @Description: 生成车辆指定日期Csv文件夹
     * @Param: [ccuId, ccuNo, vin, onlineDate, targetFolder]
     * @return: java.util.List<java.lang.String>
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/5/24
     */
    private String getCsvFolder(String vehicleRedisKey, CcuOnlineRecord ccuOnlineRecord) {
        // 获取车辆车架号
        String vin = "";
        if (Objects.nonNull(ccuOnlineRecord.getVehicleId())) {
            VehicleDTO vehicle = vehicleFeignClient.getById(ccuOnlineRecord.getVehicleId()).getData();
            vin = vehicle != null ? StrUtil.nullToEmpty(vehicle.getVin()) : "";
            vin = vin.replaceAll("[^a-zA-Z0-9]", "");
        }
        String mainCsvFolderName = StrUtil.format("{}_{}_{}", ccuOnlineRecord.getCcuNo(), vin, ccuOnlineRecord.getOnlineDate());
        String targetCsvFolder =
                sysPath + File.separator + ccuOnlineRecord.getCcuNo() + DateUtil.format(new Date(), DatePattern.PURE_DATETIME_FORMAT) + File.separator + mainCsvFolderName;
        // 在线日期
        DateTime onlineDate = DateUtil.parse(ccuOnlineRecord.getOnlineDate(), DatePattern.PURE_DATE_PATTERN);

        Map<String, String> configCsvFileMap = new HashMap<>();
        Map<String, String> csvFileTimeRangeMap = new HashMap<>();
        ccuOnlineRecord.setDataCount(0);
        // 按小时增量生成csv内容
        List<String> rowNameList = getRowNameList(Long.valueOf(ccuOnlineRecord.getCcuId()), DateUtil.beginOfDay(onlineDate), DateUtil.endOfDay(onlineDate));
        for (int i = 0; i < rowNameList.size(); i++) {
            String startEndRowName = rowNameList.get(i);
            String startRow = startEndRowName.split("-")[0];
            String endRow = startEndRowName.split("-")[1];

            // 获取指定1h内原始数据
            List<Map<String, String>> rawDataList = hbaseUtils.findDurationRawData(HBaseTableConstant.RAW_DATA_TABLE_NAME, startRow, endRow);
            // 根绝configNo分组原始数据
            Map<String, List<Map<String, String>>> configIdDataMap = rawDataList.stream().collect(Collectors.groupingBy(map -> map.get(HBaseTableConstant.RAW_BASE_COLUMAN_COFIG)));

            configIdDataMap.forEach((configId, dataList) -> {
                // 记录当天数据总数
                ccuOnlineRecord.setDataCount(ccuOnlineRecord.getDataCount() + dataList.size());
                String key = "configId:" + configId;
                Object configDetail = redisUtils.hget(key, "config_detail");
                if (Objects.isNull(configDetail)) {
                    log.warn("Redis缺失config缓存信息：" + configId);
                    return;
                }

                String detailContent = "";
                if (configDetail instanceof String) {
                    detailContent = (String) configDetail;
                } else {
                    detailContent = JSON.toJSONString(configDetail);
                }
                // 解析配置文件中采集label详细列表
                List<JSONObject> configDetailList = JSON.parseArray(detailContent, JSONObject.class);
                String fileName = StrUtil.format("{}_{}.csv", mainCsvFolderName, configId);
                File csvFile = new File(targetCsvFolder + File.separator + fileName);

                // 判断是否为需要创建新的config csv文件
                if (StrUtil.isBlank(configCsvFileMap.get(configId))) {
                    // 遍历configDetailList，添加csv表头
                    String headerContent = getHeaderContent(configDetailList);
                    try {
                        FileUtils.write(csvFile, headerContent, Charset.defaultCharset());
                        // 记录初次生成的config csv文件
                        configCsvFileMap.put(configId, csvFile.getAbsolutePath());
                    } catch (IOException e) {
                        log.error("csv文件写入标题异常", e);
                    }
                }

                // 首次创建文件，默认开始-结束时间，否则只更新结束时间
                if (!csvFileTimeRangeMap.containsKey(fileName)) {
                    DateTime startTime = DateUtil.parse(CollectionUtil.getFirst(dataList).get("createAt"));
                    DateTime endTime = DateUtil.parse(CollectionUtil.getLast(dataList).get("createAt"));
                    String rangeTime = DateUtil.format(startTime, DatePattern.PURE_TIME_PATTERN) + "-" + DateUtil.format(endTime, DatePattern.PURE_TIME_PATTERN);
                    csvFileTimeRangeMap.put(fileName, rangeTime);
                } else {
                    String rangeTime = csvFileTimeRangeMap.get(fileName);
                    DateTime endTime = DateUtil.parse(CollectionUtil.getLast(dataList).get("createAt"));
                    rangeTime = StrUtil.subBefore(rangeTime, "-", true) + "-" + DateUtil.format(endTime, DatePattern.PURE_TIME_PATTERN);
                    csvFileTimeRangeMap.put(fileName, rangeTime);
                }

                // 写入数据内容
                String dataContent = getDataContent(configDetailList, dataList);
                try {
                    FileUtils.write(csvFile, dataContent, Charset.defaultCharset(), true);
                } catch (IOException e) {
                    log.error("csv文件写入数据异常", e);
                }
            });
            redisUtils.set(vehicleRedisKey, (int) i * 80 / rowNameList.size(), 0);
        }
        // csv文件添加时间后缀
        FileUtil.loopFiles(targetCsvFolder).forEach(csv -> {
            String newCsvFileName = FileUtil.mainName(csv) + "_" + csvFileTimeRangeMap.get(csv.getName());
            FileUtil.rename(csv, newCsvFileName, true, true);
        });
        // 记录当天数据配置id
        ccuOnlineRecord.setConfigId(StrUtil.join(",", configCsvFileMap.keySet()));
        // csv重新生成时，置空mf4
        if (StrUtil.isNotBlank(ccuOnlineRecord.getMf4Path())) {
            obsUtil.deleteFile(clusterBucket, ccuOnlineRecord.getMf4Path());
            ccuOnlineRecord.setMf4Path(null);
        }
        return targetCsvFolder;
    }


    /**
     * @Description: 获取 startRow-endRow 起止rowName列表
     * @Param: [vehiceId, beginTime, endTime]
     * @return: java.util.List<java.lang.String>
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/11/29
     */
    private List<String> getRowNameList(Long vehicleId, Date beginTime, Date endTime) {
        List<String> rowNameList = new ArrayList<>();

        // 默认按小时划分数据
        List<DateTime> hourSplitList = DateUtil.rangeToList(beginTime, endTime, DateField.HOUR_OF_DAY);

        // 若是高频优化时间间隔,100ms->10min, 10ms->1min
        ConfigRemoteRecordDTO configInfo = configFeignClient.getCcuConfigInfo(String.valueOf(vehicleId)).getData();
        if (configInfo != null && configInfo.getUploadPeriod() != null && configInfo.getUploadPeriod() < 1000) {
            if (configInfo.getUploadPeriod() == 100) {
                hourSplitList = DateUtil.rangeToList(beginTime, endTime, DateField.MINUTE, 10);
            } else if (configInfo.getUploadPeriod() == 10) {
                hourSplitList = DateUtil.rangeToList(beginTime, endTime, DateField.MINUTE, 1);
            }
        }

        for (int i = 0; i < hourSplitList.size(); i++) {
            DateTime beginPeriod = hourSplitList.get(i);
            String startRow = hbaseUtils.getRawTableRow(vehicleId, beginPeriod);
            String endRow = "";
            if (i < hourSplitList.size() - 1) {
                DateTime nextPeriod = hourSplitList.get(i + 1);
                endRow = hbaseUtils.getRawTableRow(vehicleId, nextPeriod);
            } else {
                endRow = hbaseUtils.getRawTableRow(vehicleId, DateUtil.offsetSecond(endTime, 1));
            }
            rowNameList.add(startRow + "-" + endRow);
        }
        return rowNameList;
    }

    /**
     * @Description: 获取CSV文件标题内容
     * @Param: [headerList]
     * @return: java.lang.String
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/11/27
     */
    private String getHeaderContent(List<JSONObject> configDetailList) {
        List<String> headerList = Lists.newArrayList(HBaseTableConstant.RAW_BASE_COLUMN_ARRAY);
        configDetailList.forEach(detail -> headerList.add(StrUtil.nullToEmpty(detail.getString("labelName"))));
        return StrUtil.join(",", headerList) + "\r\n";
    }

    /**
     * @Description: 获取CSV文件数据内容
     * @Param: [headerList, configRawDataList]
     * @return: java.lang.String
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2022/11/27
     */
    private String getDataContent(List<JSONObject> configDetailList, List<Map<String, String>> configRawDataList) {
        StringBuilder csvBuilder = new StringBuilder();
        // 遍历原始数据，按行写入csv文件
        configRawDataList.forEach(rawData -> {
            // base列族值
            List<String> rowCellValues = Arrays.stream(HBaseTableConstant.RAW_BASE_COLUMN_ARRAY).map(baseColumn -> {
                String baseValue = rawData.get(baseColumn);
                // 如果是createAt||arriveAt,则添加"\t"，保留2022-09-08 11:03:10格式
                if (StrUtil.equalsAny(baseColumn, HBaseTableConstant.CREAT_TIME_COLUMN, HBaseTableConstant.ARRIVE_TIME_COLUMN)) {
                    baseValue += "\t";
                }
                if (NumberUtil.isNumber(baseValue)) {
                    baseValue += "\t";
                }
                return StringEscapeUtils.escapeCsv(baseValue);
            }).collect(Collectors.toList());

            // 采集标签值
            List<String> labelCellValues = configDetailList.stream().map(configDetail -> {
                String label = configDetail.getString("labelName");
                String cellValue = "";
                if (StrUtil.isNotBlank(label)) {
                    String rawValue = rawData.get(label);
                    BigDecimal value = BigDecimal.ZERO;
                    // 若值为null,则考虑是否存在别名
                    if (StrUtil.isBlank(rawValue)) {
                        rawValue = rawData.get(configDetail.getString("displayName"));
                    }
                    if (StrUtil.isNotBlank(rawValue)) {
                        // 如果label和value是数组类型
                        if (StrUtil.contains(rawValue, "]")) {
                            JSONArray rawValueArray = JSON.parseArray(rawValue);
                            int labelIndex = 0;
                            if (StrUtil.contains(label, "]")) {
                                // 提取label下标
                                labelIndex = Integer.parseInt(label.substring(label.lastIndexOf("["), label.lastIndexOf("]")));
                            }
                            value = BigDecimal.valueOf(rawValueArray.getDoubleValue(labelIndex));
                        } else if (NumberUtil.isNumber(rawValue)) {
                            value = new BigDecimal(rawValue);
                        }
                        cellValue = value.setScale(10, RoundingMode.HALF_UP).toPlainString();
                    }
                }
                return StringEscapeUtils.escapeCsv(cellValue);
            }).collect(Collectors.toList());

            if (CollectionUtils.isNotEmpty(labelCellValues)) {
                rowCellValues.addAll(labelCellValues);
            }
            csvBuilder.append(StrUtil.join(",", rowCellValues)).append("\r\n");
        });
        return csvBuilder.toString();
    }

}
