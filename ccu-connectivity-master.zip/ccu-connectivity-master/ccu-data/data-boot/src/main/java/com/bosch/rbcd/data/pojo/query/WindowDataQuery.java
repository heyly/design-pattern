package com.bosch.rbcd.data.pojo.query;

import lombok.Data;

@Data
public class WindowDataQuery {

    private String ccuId;

    private String imei;

    private String fuelType;

    private Integer minutes;
}
