//package com.bosch.rbcd.data.cache;
//
//import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
//import com.bosch.rbcd.data.pojo.entity.DgcMappingTable;
//import com.bosch.rbcd.data.service.DgcMappingTableService;
//import com.bosch.rbcd.fleet.dto.ProjectDTO;
//import com.google.common.cache.Cache;
//import com.google.common.cache.CacheBuilder;
//import com.google.common.cache.RemovalListener;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.concurrent.TimeUnit;
//
//@Slf4j
//@Component
//public class DgcMappingTableCache extends BaseLocalCache<Long, DgcMappingTable> {
//
//    @Autowired
//    private DgcMappingTableService dgcMappingTableService;
//
//    @Autowired
//    private ProjectInfoCache projectInfoCache;
//
//    @Autowired
//    private ProjectPowerTrainCache projectPowerTrainCache;
//
//    /**
//     * 使用google guava缓存处理
//     * key: projectId
//     * value: dgcMappingTable
//     */
//    private static final Cache<Long, DgcMappingTable> cache;
//    static {
//        cache = CacheBuilder.newBuilder()
//                .maximumSize(1000)
//                .expireAfterWrite(10, TimeUnit.MINUTES) // 10分钟过期
//                .initialCapacity(20)
//                .removalListener((RemovalListener<Long, DgcMappingTable>) rn -> {
//                    if (log.isDebugEnabled()) {
//                        log.debug("DgcMappingTableCache 被移除缓存 projectId = {}, dgcMappingTable = {}", rn.getKey(), rn.getValue());
//                    }
//                }).build();
//    }
//
//    @Override
//    public Cache<Long, DgcMappingTable> getCache() {
//        return cache;
//    }
//
//    @Override
//    public DgcMappingTable get(Long projectId) {
//        if (projectId == null || projectId <= 0) {
//            return null;
//        }
//
//        DgcMappingTable dgcMappingTable = getCache().getIfPresent(projectId);
//
//        if (dgcMappingTable == null) {
//            LambdaQueryWrapper<DgcMappingTable> queryWrapper = new LambdaQueryWrapper<>();
//            queryWrapper.eq(DgcMappingTable::getProjectId, projectId);
//            queryWrapper.last("limit 1");
//            dgcMappingTable = dgcMappingTableService.getOne(queryWrapper);
//
//            // 没有为当前项目单独配置规则，则需要查询动力总成的通用规则
//            if (dgcMappingTable == null) {
//                // 查询项目信息
//                ProjectDTO projectInfo = projectInfoCache.get(projectId);
//                if (projectInfo != null && projectInfo.getId() > 0) {
//                    // 查询项目动力总成
//                    ProjectPowerTrainDTO projectPowerTrain = projectPowerTrainCache.get(projectId);
//                    if (projectPowerTrain != null && projectPowerTrain.getPowerTrainId() > 0) {
//                        queryWrapper = new LambdaQueryWrapper<>();
//                        queryWrapper.eq(DgcMappingTable::getPowerTrainId, projectPowerTrain.getPowerTrainId());
//                        queryWrapper.last("limit 1");
//                        // 查询规则
//                        dgcMappingTable = dgcMappingTableService.getOne(queryWrapper);
//                    }
//                }
//            }
//
//
//        }
//
//        // 防止缓存穿透，本地缓存保留一份明显错误的数据
//        if (dgcMappingTable == null) {
//            dgcMappingTable = new DgcMappingTable();
//            dgcMappingTable.setId(Long.MIN_VALUE);// 表示没有为当前项目单独配置规则
//        }
//
//
//        getCache().put(projectId, dgcMappingTable);
//
//        return dgcMappingTable;
//    }
//
//}
