package com.bosch.rbcd.data.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.pojo.entity.CcuEventDataRecord;
import com.bosch.rbcd.data.pojo.query.CcuEventDataRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuEventDataRecordVO;
import com.bosch.rbcd.data.service.CcuEventDataRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ccu事件触发高频数据记录(CcuEventDataRecord)表控制层
 *
 * @author wang bo
 * @since 2023-09-23 09:46:01
 */
@Api(tags = "ccu事件触发高频数据记录API")
@RestController
@RequestMapping("/ccuEventDataRecord")
@RequiredArgsConstructor
public class CcuEventDataRecordController {

    private final CcuEventDataRecordService ccuEventDataRecordService;

    @ApiOperation(value = "事件数据-分页查询")
    @PostMapping("/page")
    public PageResult<CcuEventDataRecordVO> page(@RequestBody CcuEventDataRecordPageQuery query) {
        IPage<CcuEventDataRecordVO> result = ccuEventDataRecordService.listCcuEventDataRecordPage(query);
        return PageResult.success(result);
    }

    @ApiIgnore(value = "事件数据-通过主键查询单条数据")
    @GetMapping("/getById/{id}")
    public Result<Object> getById(@PathVariable Serializable id) {
        return Result.success(ccuEventDataRecordService.getById(id));
    }

    @ApiIgnore(value = "事件数据-新增数据")
    @PostMapping("/insert")
    public Result<Object> insert(@RequestBody CcuEventDataRecord ccuEventDataRecord) {
        return Result.success(ccuEventDataRecordService.saveOrUpdate(ccuEventDataRecord));
    }

    @ApiIgnore(value = "事件数据-修改数据")
    @PutMapping("/update")
    public Result<Object> update(@RequestBody CcuEventDataRecord ccuEventDataRecord) {
        return Result.success(ccuEventDataRecordService.updateById(ccuEventDataRecord));
    }

    @ApiIgnore(value = "事件数据-删除数据")
    @DeleteMapping("/delete/{ids}")
    public Result<Object> delete(@ApiParam("主键id，多个以英文逗号(,)分割")  @PathVariable String ids) {
        List<Long> idList = Arrays.stream(ids.split(",")).map(Long::parseLong).collect(Collectors.toList());
        return Result.success(ccuEventDataRecordService.removeByIds(idList));
    }

    @ApiIgnore(value = "事件数据-新增事件触发数据")
    @PostMapping("/recordEventData")
    public Result<Object> recordEventData(@RequestBody JSONObject ccuEventDataJson) {
        ccuEventDataRecordService.recordEventData(ccuEventDataJson);
        return Result.success();
    }

}

