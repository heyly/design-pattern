package com.bosch.rbcd.data.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.data.mapper.VehicleMileageRunningTimeMapper;
import com.bosch.rbcd.data.pojo.entity.VehicleMileageRunningTime;
import com.bosch.rbcd.data.service.VehicleMileageRunningTimeService;
import org.springframework.stereotype.Service;

@Service
public class VehicleMileageRunningTimeServiceImpl extends ServiceImpl<VehicleMileageRunningTimeMapper, VehicleMileageRunningTime> implements VehicleMileageRunningTimeService  {

//    @Autowired
//    private DeviceVehicleFeignClient deviceVehicleFeignClient;
//
//    @Override
//    public Integer getAllVehicleRunTime(DeviceInfoWebQuery query) {
//
//        PageResult<DeviceVehicleDTO> result = deviceVehicleFeignClient.pageQuery(query);
//        if (result == null || result.getData() == null || CollectionUtils.isEmpty(result.getData().getList())) {
//            return 0;
//        }
//        List<String> ccuIdList = result.getData().getList().stream().map(DeviceVehicleDTO::getCcuId).collect(Collectors.toList());
//
//        LambdaQueryWrapper<VehicleMileageRunningTime> queryWrapper = new LambdaQueryWrapper<>();
//        queryWrapper.in(VehicleMileageRunningTime::getCcuId, ccuIdList);
//        queryWrapper.le(VehicleMileageRunningTime::getRunningDate, new Date());
//        queryWrapper.orderByDesc(VehicleMileageRunningTime::getRunningDate);
//        queryWrapper.last("limit 1");
//
//        VehicleMileageRunningTime vehicleMileageRunningTime = this.getOne(queryWrapper);
//        if (vehicleMileageRunningTime != null) {
//            double totalRuntime = vehicleMileageRunningTime.getTotalRuntime();
//            return (int)totalRuntime;
//        } else {
//            return 0;
//        }
//
//    }
//
//    @Override
//    public Integer getAllVehicleMileage(DeviceInfoWebQuery query) {
//        PageResult<DeviceVehicleDTO> result = deviceVehicleFeignClient.pageQuery(query);
//        if (result == null || result.getData() == null || CollectionUtils.isEmpty(result.getData().getList())) {
//            return 0;
//        }
//        List<String> ccuIdList = result.getData().getList().stream().map(DeviceVehicleDTO::getCcuId).collect(Collectors.toList());
//
//        LambdaQueryWrapper<VehicleMileageRunningTime> queryWrapper = new LambdaQueryWrapper<>();
//        queryWrapper.in(VehicleMileageRunningTime::getCcuId, ccuIdList);
//        queryWrapper.le(VehicleMileageRunningTime::getRunningDate, new Date());
//        queryWrapper.orderByDesc(VehicleMileageRunningTime::getRunningDate);
//        queryWrapper.last("limit 1");
//
//        VehicleMileageRunningTime vehicleMileageRunningTime = this.getOne(queryWrapper);
//        if (vehicleMileageRunningTime != null) {
//            double totalMileage = vehicleMileageRunningTime.getTotalMileage();
//            return (int)totalMileage;
//        } else {
//            return 0;
//        }
//    }
}
