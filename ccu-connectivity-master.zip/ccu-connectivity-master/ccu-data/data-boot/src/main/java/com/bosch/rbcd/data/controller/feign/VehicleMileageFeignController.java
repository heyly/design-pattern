package com.bosch.rbcd.data.controller.feign;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.convert.Convert;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.dto.VehicleMileageRunningTimeDTO;
import com.bosch.rbcd.data.dto.VehicleMileageRunningTimeQuery;
import com.bosch.rbcd.data.pojo.entity.VehicleMileageRunningTime;
import com.bosch.rbcd.data.service.VehicleMileageRunningTimeService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RequestMapping("/feign/vehicle/mileage")
@RestController
@RequiredArgsConstructor
public class VehicleMileageFeignController {

    private final VehicleMileageRunningTimeService vehicleMileageRunningTimeService;

    @GetMapping("/getByCcuId")
    public Result<VehicleMileageRunningTimeDTO> getByCcuId(@RequestParam String ccuId) {
        VehicleMileageRunningTime one = vehicleMileageRunningTimeService.getOne(new LambdaQueryWrapper<VehicleMileageRunningTime>()
                .eq(VehicleMileageRunningTime::getCcuId, ccuId)
                .orderByDesc(VehicleMileageRunningTime::getId)
                .last("LIMIT 1"));
        return Result.success(Convert.convert(VehicleMileageRunningTimeDTO.class, one));
    }

    @GetMapping("/listRunTime")
    public Result<List<VehicleMileageRunningTimeDTO>> listRunTime(@RequestBody VehicleMileageRunningTimeQuery query) {
        List<VehicleMileageRunningTime> list = vehicleMileageRunningTimeService
                .list(new LambdaQueryWrapper<VehicleMileageRunningTime>()
                        .between(VehicleMileageRunningTime::getRunningDate, query.getStartDate(), query.getEndDate())
                        .in(CollectionUtil.isNotEmpty(query.getCcuIdList()), VehicleMileageRunningTime::getCcuId, query.getCcuIdList()));
        List<VehicleMileageRunningTimeDTO> result = list.stream().map(item -> Convert.convert(VehicleMileageRunningTimeDTO.class, item)).collect(Collectors.toList());
        return Result.success(result);
    }

    @GetMapping("/getByCcuIdAndDate")
    public Result<VehicleMileageRunningTimeDTO> getByCcuIdAndDate(@RequestParam String ccuId, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localDate) {
        VehicleMileageRunningTime one = vehicleMileageRunningTimeService.getOne(new LambdaQueryWrapper<VehicleMileageRunningTime>()
                .eq(VehicleMileageRunningTime::getCcuId, ccuId)
                .eq(VehicleMileageRunningTime::getRunningDate, localDate));
        return Result.success(Convert.convert(VehicleMileageRunningTimeDTO.class, one));
    }

    @GetMapping("/getTotalAddMileage")
    public Result<Double> getTotalAddMileage(@RequestParam String ccuId, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") LocalDateTime updateMileageTime) {
        double sum = vehicleMileageRunningTimeService.list(new LambdaQueryWrapper<VehicleMileageRunningTime>()
                        .eq(VehicleMileageRunningTime::getCcuId, ccuId)
                        .ge(VehicleMileageRunningTime::getRunningDate, updateMileageTime))
                .stream()
                .filter(item -> item.getTodayMileage() != null)
                .mapToDouble(VehicleMileageRunningTime::getTodayMileage)
                .sum();
        return Result.success(sum);
    }
}
