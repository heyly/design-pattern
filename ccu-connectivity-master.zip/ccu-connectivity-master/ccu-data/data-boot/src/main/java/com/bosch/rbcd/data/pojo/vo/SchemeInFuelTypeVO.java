package com.bosch.rbcd.data.pojo.vo;

import lombok.Data;

import java.util.List;

@Data
public class SchemeInFuelTypeVO {

    private String fuelType;

    private List<DataCompositeSchemeVO> dataCompositeSchemeVOList;
}
