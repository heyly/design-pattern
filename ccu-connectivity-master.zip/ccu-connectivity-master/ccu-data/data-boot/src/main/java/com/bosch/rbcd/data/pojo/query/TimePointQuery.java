package com.bosch.rbcd.data.pojo.query;

import lombok.Data;

@Data
public class TimePointQuery {

    private String label;

    private String max;

    private String min;

    private String logic;

    public String getLabel() {
        if(label == null || label.isEmpty()){
            return  null;
        }
        return label;
    }

    public String getMax() {
        if(max == null || max.isEmpty()){
            return  null;
        }
        return max;
    }

    public String getMin() {
        if(min == null || min.isEmpty()){
            return  null;
        }
        return min;
    }

    public String getLogic() {
        if(logic == null || logic.isEmpty()){
            return  null;
        }
        return logic;
    }
}
