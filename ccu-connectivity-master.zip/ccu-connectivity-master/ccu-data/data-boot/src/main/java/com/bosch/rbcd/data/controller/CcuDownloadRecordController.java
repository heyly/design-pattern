package com.bosch.rbcd.data.controller;



import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.pojo.entity.CcuDownloadRecord;
import com.bosch.rbcd.data.pojo.query.CcuDownloadRecordPageQuery;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuDownloadRecordVO;
import com.bosch.rbcd.data.service.CcuDownloadRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * CCU数据下载记录表表控制层
 *
 * @author wang bo
 * @since 2023-05-23 14:28:41
 */
@Api(tags = "CCU数据下载记录表")
@RestController
@RequestMapping("/ccuDownloadRecordController")
@RequiredArgsConstructor
public class CcuDownloadRecordController {

    private final CcuDownloadRecordService ccuDownloadRecordService;

    @ApiOperation(value = "数据下载-分页")
    @PostMapping("/page")
    public PageResult<CcuDownloadRecordVO> page(@RequestBody CcuDownloadRecordPageQuery query) {
        IPage<CcuDownloadRecordVO> result = ccuDownloadRecordService.listCcuDownloadRecordPage(query);
        return PageResult.success(result);
    }

    @ApiOperation(value = "数据下载-通过主键查询单条数据")
    @GetMapping("/getById/{id}")
    public Result<CcuDownloadRecord> getById(@PathVariable Serializable id) {
        return Result.success(ccuDownloadRecordService.getById(id));
    }

    @ApiOperation(value = "数据下载-单天csv/mf4数据下载")
    @GetMapping("/downOneVehicleDay")
    public Result<String> downOneVehicleDay(@ApiParam("车辆主键") @RequestParam Long ccuId,
                                                                 @ApiParam("在线日期") @RequestParam String onlineDate,
                                                                 @ApiParam("文件类型 csv/mf4") @RequestParam String fileType){
        return Result.success(ccuDownloadRecordService.downOneCcuDay(ccuId, onlineDate, fileType));
    }

    @ApiOperation(value = "数据下载-批量csv/mf4数据下载")
    @PostMapping("/batchDownload")
    public Result<List<CcuDownloadRecordVO>> batchDownload(@RequestBody CcuOnlineRecordPageQuery query) throws Exception {
        return Result.success(ccuDownloadRecordService.batchDownload(query));
    }

    @ApiOperation(value = "数据下载-修改数据")
    @PutMapping("/update")
    public Result<Object> update(@RequestBody CcuDownloadRecord ccuDownloadRecord) {
        return Result.success(ccuDownloadRecordService.updateById(ccuDownloadRecord));
    }

    @ApiIgnore(value = "数据下载-删除数据")
    @DeleteMapping("/delete/{ids}")
    public Result<Object> delete(@ApiParam("主键id，多个以英文逗号(,)分割")  @PathVariable String ids) {
        List<Long> idList = Arrays.stream(ids.split(",")).map(Long::parseLong).collect(Collectors.toList());
        return Result.success(ccuDownloadRecordService.removeByIds(idList));
    }
}

