package com.bosch.rbcd.data.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.DataJumpRequest;
import com.bosch.rbcd.data.pojo.entity.form.DataJumpRequestForm;
import com.bosch.rbcd.data.pojo.query.DataJumpRequestPageQuery;

public interface DataJumpRequestService extends IService<DataJumpRequest> {

    Long create(DataJumpRequestForm dataJumpRequestForm);

    IPage<DataJumpRequest> pageQuery(DataJumpRequestPageQuery dataJumpRequestPageQuery);
}
