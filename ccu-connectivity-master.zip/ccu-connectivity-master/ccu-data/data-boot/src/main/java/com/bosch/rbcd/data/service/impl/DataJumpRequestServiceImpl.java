package com.bosch.rbcd.data.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.data.mapper.DataJumpRequestMapper;
import com.bosch.rbcd.data.pojo.entity.DataJumpRequest;
import com.bosch.rbcd.data.pojo.entity.form.DataJumpRequestForm;
import com.bosch.rbcd.data.pojo.query.DataJumpRequestPageQuery;
import com.bosch.rbcd.data.service.DataJumpDetailService;
import com.bosch.rbcd.data.service.DataJumpRequestService;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataJumpRequestServiceImpl extends ServiceImpl<DataJumpRequestMapper, DataJumpRequest> implements DataJumpRequestService {

    @Autowired
    private DataJumpDetailService dataJumpDetailService;

    @Autowired
    private DeviceInfoFeignClient deviceFeignClient;

    @Override
    public Long create(DataJumpRequestForm dataJumpRequestForm) {
        Result<ProjectVehicleCcuDTO> deviceInfoDTOResult = deviceFeignClient.findByCcuId(dataJumpRequestForm.getCcuId());
        if (deviceInfoDTOResult == null || deviceInfoDTOResult.getData() == null) {
            throw new BizException("指定CCU不存在！");
        }

        LambdaQueryWrapper<DataJumpRequest> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(DataJumpRequest::getStatus, 0);
        if (this.count(queryWrapper) > 2) {
            throw new BizException("系统繁忙，已有多个跳变分析在进行中，请稍后重试！");
        }

        DataJumpRequest dataJumpRequest = new DataJumpRequest();
        BeanUtils.copyProperties(dataJumpRequestForm, dataJumpRequest);
        dataJumpRequest.setProjectId(deviceInfoDTOResult.getData().getProjectId());
        dataJumpRequest.setCcuNo(deviceInfoDTOResult.getData().getCcuNo());
        dataJumpRequest.setStatus(0);
        dataJumpRequest.setCreator(UserUtils.getUserId());
        save(dataJumpRequest);
        // 查询hbase数据，搜索数据跳变
        dataJumpDetailService.asyncCheckDetail(dataJumpRequest.getId(), dataJumpRequestForm.getCcuId(), dataJumpRequestForm.getStartTime(), dataJumpRequestForm.getEndTime());
        return dataJumpRequest.getId();
    }

    @Override
    public IPage<DataJumpRequest> pageQuery(DataJumpRequestPageQuery query) {
        IPage<DataJumpRequest> iPage = new Page<>(query.getPageNum(), query.getPageSize());
        LambdaQueryWrapper<DataJumpRequest> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(query.getProjectId() != null, DataJumpRequest::getProjectId, query.getProjectId());
        queryWrapper.eq(StrUtil.isNotBlank(query.getCcuId()), DataJumpRequest::getCcuId, query.getCcuId());
        return page(iPage, queryWrapper);
    }
}
