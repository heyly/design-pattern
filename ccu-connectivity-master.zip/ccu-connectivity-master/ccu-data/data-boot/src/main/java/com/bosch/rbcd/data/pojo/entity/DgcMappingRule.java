package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("dgc_mapping_rule_1031")
public class DgcMappingRule {

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField("system")
    private String system;

    @TableField("signalName")
    private String signalName;

    @TableField("descENG")
    private String descEng;

    @TableField("descCHN")
    private String descChn;

    @TableField("unit")
    private String unit;

    @TableField("phyMin")
    private String phyMin;

    @TableField("phyMax")
    private String phyMax;

    @TableField("createBy")
    private String createBy;

    @TableField("uploadBy")
    private String uploadBy;

    @TableField("modifyBy")
    private String modifyBy;

    @TableField("table_id")
    private String tableId;

    @TableField("must")
    private Integer must;
}
