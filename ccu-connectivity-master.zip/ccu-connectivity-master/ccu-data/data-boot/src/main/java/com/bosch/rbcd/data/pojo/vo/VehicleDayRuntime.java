package com.bosch.rbcd.data.pojo.vo;

import lombok.Data;

@Data
public class VehicleDayRuntime {

    private String name;

    private Double runTime;

    private String day;
}
