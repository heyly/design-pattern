package com.bosch.rbcd.data.kafka;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.data.pojo.dto.MessageDTO;
import com.bosch.rbcd.data.pojo.entity.MonitorFcpmSttoplvlRecord;
import com.bosch.rbcd.data.service.MonitorFcpmSttoplvlRecordService;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@ConditionalOnProperty(prefix = "custom.kafka", name = {"createBean"}, havingValue = "true", matchIfMissing = false)
@Component
@EnableKafka
@RequiredArgsConstructor
public class DataMonitorConsumer implements InitializingBean {

    private final DeviceInfoFeignClient deviceInfoFeignClient;

    private final ProjectFeignClient projectFeignClient;

    private final MonitorFcpmSttoplvlRecordService fcpmSttoplvlRecordService;

    private final RedisUtils redisUtils;

    private final StringRedisTemplate stringRedisTemplate;


    @KafkaListener(topics = "ccu_data", containerFactory = "dataMonitorGroupFactory")
    public void analysisDataError(ConsumerRecords<String, String> records) {
        if (records == null) {
            return;
        }
        for (ConsumerRecord<String, String> record : records) {
            String json = record.value();
            if (json.length() < 10) {
                continue;
            }
            MessageDTO curMessage = JSONObject.parseObject(json, MessageDTO.class);
            try {
                fcpmMonitorFuCellStck_stTopLvlReq(curMessage);
            } catch (Exception e) {
                log.error("监控Fcpm 启停出错: {}", curMessage, e);
            }
        }
    }

    private void fcpmMonitorFuCellStck_stTopLvlReq(MessageDTO message) {
        String fcpmCcuSetKey = "monitor:fcpm:ccuSet";
        String stTopLvlRedisKey = "monitor:fcpm:stTopLvl:" + message.getVehicleId();

        if (redisUtils.noHasKey(fcpmCcuSetKey)) {
            projectFeignClient.initMonitorFcpmSet(fcpmCcuSetKey).getData();
        }

        if (!redisUtils.sHasKey(fcpmCcuSetKey, message.getVehicleId())) {
            return;
        }

        Map<String, Object> rawData = message.getData();
        String fuCellStck_stTopLvlReq = (String) rawData.get("FuCellStck_stTopLvlReq");

        // 如果车辆未采集此label或者为空 或者-，则跳过监控
        if (StrUtil.isBlank(fuCellStck_stTopLvlReq) || StrUtil.equals("-", fuCellStck_stTopLvlReq)) {
            return;
        }

        String dataTimeStr = message.getCreateAt();
        DateTime dataTime = DateUtil.parse(dataTimeStr);

        // 新增车辆初始化缓存
        if (redisUtils.noHasKey(stTopLvlRedisKey)) {
            // 缓存当前时间和发动机启停状态
            redisUtils.hset(stTopLvlRedisKey, "FuCellStck_stTopLvlReq", fuCellStck_stTopLvlReq);
            redisUtils.hset(stTopLvlRedisKey, "createAt", dataTimeStr);
            return;
        }


        Map stTopLvlMap = redisUtils.hgetAll(stTopLvlRedisKey);
        String lastDataTimeStr = (String) stTopLvlMap.get("createAt");
        DateTime lastDataTime = DateUtil.parse(lastDataTimeStr);
        String cacheStTopLvlReq = (String) stTopLvlMap.get("FuCellStck_stTopLvlReq");


        // 当前数据时间领先缓存时间，则进入监控逻辑 并且发生变化
        if (dataTime.isAfter(lastDataTime)) {
            // 缓存当前时间和发动机启停状态
            redisUtils.hset(stTopLvlRedisKey, "FuCellStck_stTopLvlReq", fuCellStck_stTopLvlReq);
            redisUtils.hset(stTopLvlRedisKey, "createAt", dataTimeStr);

            // FuCellStck_stTopLvlReq发生变化
            String stTopWaitKey = "monitor:fcpm:stTopLvlWait:" + message.getVehicleId();

            if (!StrUtil.equals(fuCellStck_stTopLvlReq, cacheStTopLvlReq)) {
                DateTime fcpmStartTime = DateUtil.parse((String) redisUtils.hget(stTopLvlRedisKey, "fcpmStartTime"));
                // FuCellStck_stTopLvlReq发生变化为0->发动机熄火
                if (StrUtil.equals("0", fuCellStck_stTopLvlReq) && DateUtil.compare(dataTime, fcpmStartTime) > 0 && redisUtils.noHasKey(stTopWaitKey)) {
                    redisUtils.set(stTopWaitKey, dataTimeStr, 5);
                    // FuCellStck_stTopLvlReq发生变化

                    Date today = new Date();
                    long dayCount = fcpmSttoplvlRecordService.count(new LambdaQueryWrapper<MonitorFcpmSttoplvlRecord>()
                            .eq(MonitorFcpmSttoplvlRecord::getCcuId, message.getVehicleId())
                            .gt(MonitorFcpmSttoplvlRecord::getCreateTime, DateUtil.beginOfDay(today))
                            .lt(MonitorFcpmSttoplvlRecord::getCreateTime, DateUtil.endOfDay(today))
                    );

                    // 获取分布式锁对象实例
                    String redissLock = "monitor:fcpm:stTopLvlRedissLock:" + message.getVehicleId();
                    Boolean locked = stringRedisTemplate.opsForValue().setIfAbsent(redissLock, "1", 30L, TimeUnit.SECONDS);
                    try {
                        if (locked != null && locked) {
                            // 设置发动机启停次数，跨天置1
                            if (dayCount == 0) {
                                dayCount++;
                                redisUtils.hset(stTopLvlRedisKey, "dayCount", dayCount);
                            } else {
                                dayCount = (int) redisUtils.hincr(stTopLvlRedisKey, "dayCount", 1);
                            }
                            MonitorFcpmSttoplvlRecord fcpmStTopLvlRecord = new MonitorFcpmSttoplvlRecord().setCcuId(message.getVehicleId())
                                    .setStartTime(DateUtil.parse((String) redisUtils.hget(stTopLvlRedisKey, "fcpmStartTime")))
                                    .setStopTime(dataTime).setOccurDate(dataTime).setDayCount((int) dayCount);
                            fcpmSttoplvlRecordService.save(fcpmStTopLvlRecord);
                        }
                    } catch (Exception e) {
                        log.error("Exception try to lock {}", redissLock, e);
                    } finally {
                        if (locked != null && locked) {
                            stringRedisTemplate.delete(redissLock);
                        }
                    }
                    // 发送邮件
                    if (locked && dayCount == 15) {
                        fcpmSttoplvlRecordService.sendFcpmStTopLvMail(message.getVehicleId(), dataTime);
                    }
                }
                // 0->其他值: 发动机开始工作
                else if (StrUtil.equals("0", cacheStTopLvlReq)) {
                    if (DateUtil.compare(dataTime, fcpmStartTime) > 0) {
                        redisUtils.hset(stTopLvlRedisKey, "fcpmStartTime", dataTimeStr);
                    }
                }
            }

        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("customCreateBean DataErrorConsumer success!");
    }
}
