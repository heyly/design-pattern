package com.bosch.rbcd.data.pojo.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class FuelTypeLabelDTO {

    private Long id;

    @ApiModelProperty("燃料类型")
    private String fuelType;

    @ApiModelProperty("")
    private String monitorLabel;

    @ApiModelProperty("")
    private String realtimeLabel;
}
