package com.bosch.rbcd.data.pojo.entity.presto;

import lombok.Data;

@Data
public class FcevData {

    private String vinCreateAt;

    private String vin;

    private String createAt;

    private String arriveAt;

    private String day;
}
