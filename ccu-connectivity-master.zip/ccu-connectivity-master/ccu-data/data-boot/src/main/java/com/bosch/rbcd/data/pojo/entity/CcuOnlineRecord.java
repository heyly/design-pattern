package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.bosch.rbcd.common.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 车辆在线统计表(VehicleOnlineRecord)实体类
 *
 * @author wang bo
 * @since 2023-05-23 14:25:04
 */
@ApiModel("车辆在线统计表实体类")
@Data
@Accessors(chain=true)
public class CcuOnlineRecord extends BaseEntity {

    @ApiModelProperty("主键，唯一标识")
    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("projectId")
    private Long projectId;

    @ApiModelProperty("ccu id")
    private String ccuId;

    @ApiModelProperty("车辆名称")
    private String ccuNo;

    @ApiModelProperty("vehicleId")
    private Long vehicleId;

    @ApiModelProperty("在线日期yyyymmdd")
    private String onlineDate;

    @ApiModelProperty("0:当天数据,1:历史数据")
    private Integer clusterFlag;

    @ApiModelProperty("csv文件路径")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String csvPath;

    @ApiModelProperty("数据采集配置,逗号分隔")
    private String configId;

    @ApiModelProperty("mf4文件路径")
    @TableField(updateStrategy = FieldStrategy.IGNORED)
    private String mf4Path;

    @ApiModelProperty("数据总数")
    private int dataCount;

    @ApiModelProperty("0:当天数据,1:历史数据")
    private Integer hiveClusterFlag;

}
