//package com.bosch.rbcd.data.controller.feign;
//
//import com.bosch.rbcd.common.result.Result;
//import com.bosch.rbcd.common.result.ResultCode;
//import com.bosch.rbcd.data.cache.DgcMappingRuleCache;
//import com.bosch.rbcd.data.pojo.entity.DgcMappingTable;
//import com.bosch.rbcd.data.vo.DgcDataRangeVO;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.Map;
//
//
//@RequestMapping("/feign/dgc")
//@RestController
//public class DgcFeignClientController {
////
////    @Autowired
////    private DgcMappingTableCache dgcMappingTableCache;
//
//    @Autowired
//    private DgcMappingRuleCache dgcMappingRuleCache;
//
//    @RequestMapping("/queryRules")
//    Result<Map<String, DgcDataRangeVO>> queryRules(@RequestParam Long projectId) {
//        if (projectId == null) {
//            return Result.failed(ResultCode.PARAM_IS_NULL);
//        }
//
////        DgcMappingTable dgcMappingTable = dgcMappingTableCache.get(projectId);
////
////        if (dgcMappingTable == null || dgcMappingTable.getId() == null || dgcMappingTable.getId() <= 0) {
////            return Result.success(null);
////        }
//
//        return Result.success(dgcMappingRuleCache.get(dgcMappingTable.getId()));
//    }
//}
