package com.bosch.rbcd.data.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.common.huawei.util.ObsUtil;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.common.web.util.UserUtils;
import com.bosch.rbcd.data.constant.DataConstant;
import com.bosch.rbcd.data.enums.DownLoadStatusEnum;
import com.bosch.rbcd.data.mapper.CcuDownloadRecordMapper;
import com.bosch.rbcd.data.pojo.entity.CcuDownloadRecord;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.pojo.query.CcuDownloadRecordPageQuery;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuDownloadRecordVO;
import com.bosch.rbcd.data.pojo.vo.CcuOnlineRecordVO;
import com.bosch.rbcd.data.service.CcuDownloadRecordService;
import com.bosch.rbcd.data.service.CcuOnlineRecordService;
import com.bosch.rbcd.data.service.DataDownloadService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * 车辆数据下载用户记录表(VehicleDownloadUserRecord)表服务实现类
 *
 * @author wang bo
 * @since 2023-05-23 14:28:42
 */
@Slf4j
@Service("vehicleDownloadUserRecordService")
@RequiredArgsConstructor
public class CcuDownloadRecordServiceImpl extends ServiceImpl<CcuDownloadRecordMapper, CcuDownloadRecord> implements CcuDownloadRecordService {
    @Value("${obs.cluster-bucket}")
    private String clusterBucket;
    private final CcuOnlineRecordService ccuOnlineRecordService;
    private final DataDownloadService dataDownloadService;
    private final ObsUtil obsUtil;
    private final RedisUtils redisUtils;

    @Override
    public IPage<CcuDownloadRecordVO> listCcuDownloadRecordPage(CcuDownloadRecordPageQuery queryParams) {
        // 如果前端未传入userId
        if (queryParams.getUserId() == null) {
            queryParams.setUserId(UserUtils.getUserId());
        }
        Page<CcuDownloadRecordVO> page = new Page<>(queryParams.getPageNum(), queryParams.getPageSize());
        List<CcuDownloadRecordVO> list = this.baseMapper.listCcuDownloadRecordPage(page, queryParams);
        if (CollectionUtil.isNotEmpty(list)) {
            list.forEach(downloadRecord -> {
                if (downloadRecord.getStatus() == DownLoadStatusEnum.CREATING.getValue()) {
                    String vehicleRedisKey = StrUtil.format(DataConstant.VEHICLE_DATE_DOWNLOAD_RATE_REDIS, downloadRecord.getCcuId(), downloadRecord.getOnlineDate());
                    downloadRecord.setClusterPercent((int) redisUtils.get(vehicleRedisKey));
                } else {
                    downloadRecord.setClusterPercent(100);
                }
            });
        }
        page.setRecords(list);
        return page;
    }

    @Override
    public String downOneCcuDay(Long vehicleId, String onlineDate, String fileType) {
        LambdaQueryWrapper<CcuOnlineRecord> query =
                new LambdaQueryWrapper<CcuOnlineRecord>().eq(CcuOnlineRecord::getCcuId, vehicleId).eq(CcuOnlineRecord::getOnlineDate, onlineDate);
        CcuOnlineRecord ccuOnlineRecord = ccuOnlineRecordService.getOne(query);
        if (Objects.nonNull(ccuOnlineRecord)) {
            CcuDownloadRecordVO record = recordOneCcuDayUserDown(fileType, ccuOnlineRecord, false);
            return StrUtil.equalsIgnoreCase("csv", fileType) ? record.getCsvPath() : record.getMf4Path();
        } else {
            return "";
        }
    }

    @Override
    public CcuDownloadRecordVO recordOneCcuDayUserDown(String fileType, CcuOnlineRecord ccuOnlineRecord, boolean asyncFlag) {
        CcuDownloadRecord ccuDownloadRecord = new CcuDownloadRecord();
        ccuDownloadRecord.setUserId(UserUtils.getUserId());
        ccuDownloadRecord.setUserName(UserUtils.getUsername());
        ccuDownloadRecord.setStatus(DownLoadStatusEnum.CREATING.getValue());
        ccuDownloadRecord.setOnlineRecordId(ccuOnlineRecord.getId());
        ccuDownloadRecord.setFileType(fileType);
        this.save(ccuDownloadRecord);
        // csv类型
        if ("csv".equals(fileType)) {
            // 如果是历史数据并且csv文件已聚合，则直接下载文件
            if (ccuOnlineRecord.getClusterFlag() == 1 && StrUtil.isNotBlank(ccuOnlineRecord.getCsvPath()) && obsUtil.isExisted(clusterBucket, ccuOnlineRecord.getCsvPath())) {
                ccuDownloadRecord.setStatus(DownLoadStatusEnum.TO_DOWNLOAD.getValue());
                this.updateById(ccuDownloadRecord);
            } else {
                Future<String> csvTask = dataDownloadService.asyncClusterCsv(ccuOnlineRecord);
                // 如果为同步实时任务
                if (!asyncFlag) {
                    try {
                        ccuOnlineRecord.setCsvPath(csvTask.get(1, TimeUnit.HOURS));
                    } catch (Exception e) {
                        log.error("====同步实时聚合csv{}_{}失败====", ccuOnlineRecord.getCcuNo(), ccuOnlineRecord.getOnlineDate(), e);
                    }
                }
            }
        }
        // mf4类型
        if ("mf4".equals(fileType)) {
            // 如果是历史数据并且mf4文件已聚合，则直接下载文件
            if (ccuOnlineRecord.getClusterFlag() == 1 && StrUtil.isNotBlank(ccuOnlineRecord.getMf4Path()) && obsUtil.isExisted(clusterBucket, ccuOnlineRecord.getMf4Path())) {
                ccuDownloadRecord.setStatus(DownLoadStatusEnum.TO_DOWNLOAD.getValue());
                this.updateById(ccuDownloadRecord);
            } else {
                Future<String> mf4Task = dataDownloadService.asyncClusterMf4(ccuOnlineRecord);
                // 如果为同步实时任务
                if (!asyncFlag) {
                    try {
                        ccuOnlineRecord.setMf4Path(mf4Task.get(1, TimeUnit.HOURS));
                    } catch (Exception e) {
                        log.error("====同步实时聚合mf4{}_{}失败====", ccuOnlineRecord.getCcuNo(), ccuOnlineRecord.getOnlineDate(), e);
                    }
                }
            }
        }
        CcuDownloadRecordVO ccuDownloadRecordVO = Convert.convert(CcuDownloadRecordVO.class, ccuOnlineRecord);
        ccuDownloadRecordVO.setId(ccuDownloadRecord.getId());
        return ccuDownloadRecordVO;
    }

    @Override
    public List<CcuDownloadRecordVO> batchDownload(CcuOnlineRecordPageQuery query) {
        List<CcuDownloadRecordVO> downloadUserRecordVOs = new ArrayList<>();
        // 关闭分页
        query.setPageSize(-1);
        List<CcuOnlineRecordVO> onlineRecordList = ccuOnlineRecordService.listVehicleOnlineRecordPage(query).getRecords();
        if (onlineRecordList.size() > 100) {
            throw new BizException("超过100车日限制,请减少下载数量重试！");
        }
        if (CollectionUtil.isNotEmpty(onlineRecordList)) {
            onlineRecordList.forEach(CcuOnlineRecordVO ->
                    downloadUserRecordVOs.add(recordOneCcuDayUserDown(query.getFileType(), Convert.convert(CcuOnlineRecord.class, CcuOnlineRecordVO), true))
            );
        }
        return downloadUserRecordVOs;
    }

}

