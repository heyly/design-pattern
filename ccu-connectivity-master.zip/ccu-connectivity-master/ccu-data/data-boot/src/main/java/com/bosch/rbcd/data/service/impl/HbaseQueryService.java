package com.bosch.rbcd.data.service.impl;


import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.bosch.rbcd.common.web.exception.BizException;
import com.bosch.rbcd.data.dto.DataFlowDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.util.MD5Hash;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class HbaseQueryService {

    private final Connection hbaseConnection;
    private final StringRedisTemplate redisTemplate;

    private static final Logger logger = LoggerFactory.getLogger(HbaseQueryService.class);


    public List<DataFlowDto> findDataFlow(String label, String ccuId, String imei, String startTime, String endTime) {
        List<DataFlowDto> resultDtos = new ArrayList<>();
        try {
            Table table = hbaseConnection.getTable(TableName.valueOf("rbcd_iov_data_ccu_raw1"));
            String md5code = SecureUtil.md5(ccuId);
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(md5code + "_" + startTime));
            scan.withStopRow(Bytes.toBytes(md5code + "_" + endTime));
            ResultScanner resultScanner = table.getScanner(scan);
            HashOperations<String, Object, Object> forHash = redisTemplate.opsForHash();
            String imeiKey = "imei:" + imei;
            String configDetailJson = Objects.requireNonNull(forHash.get(imeiKey, "config_detail")).toString();
            List<JSONObject> configDetailList = JSON.parseArray(configDetailJson, JSONObject.class);
            Map<String, String> label2DisplayNameMap = new HashMap<>();
            for (JSONObject configCanDetail : configDetailList) {
                String labelName = configCanDetail.getString("labelName");
                String displayName = configCanDetail.getString("displayName");
                if (StrUtil.isAllNotBlank(labelName, displayName)) {
                    label2DisplayNameMap.put(labelName, displayName);
                }
            }
            if (label2DisplayNameMap.get(label) != null) {
                label = label2DisplayNameMap.get(label);
            }
            for (Result result : resultScanner) {
                Cell[] cells = result.rawCells();
                String value;
                DataFlowDto resultDto = new DataFlowDto();
                for (Cell cell : cells) {
//                    String row = Bytes.toString(CellUtil.cloneRow(cell));
                    //取到修饰名
                    String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
                    if (label.equals(qualifier)) {
                        //label如果有别名的话，选择使用别名的方式获取数据
                        value = Bytes.toString(CellUtil.cloneValue(cell));
                        resultDto.setYValue(value);
                    }
                    if ("createAt".equals(qualifier)) {
                        value = Bytes.toString(CellUtil.cloneValue(cell));
                        resultDto.setXValue(value);
                    }
                }
                resultDtos.add(resultDto);
            }
            return resultDtos;

        } catch (Exception e) {
            throw new BizException("查询HBase失败");
        }
    }

    public List<Map<String, String>> findDataFlows(String[] labels, String ccuId, String imei, String startTime, String endTime) {
        List<Map<String, String>> resultDtos = new ArrayList<>();
        try {
            Table table = hbaseConnection.getTable(TableName.valueOf("rbcd_iov_data_ccu_raw1"));
            String md5code = SecureUtil.md5(ccuId);
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(Bytes.toBytes(md5code + "_" + startTime));
            scan.withStopRow(Bytes.toBytes(md5code + "_" + endTime));
            ResultScanner resultScanner = table.getScanner(scan);
            HashOperations<String, Object, Object> forHash = redisTemplate.opsForHash();
            String imeiKey = "imei:" + imei;
            String configDetailJson = Objects.requireNonNull(forHash.get(imeiKey, "config_detail")).toString();
            List<JSONObject> configDetailList = JSON.parseArray(configDetailJson, JSONObject.class);
            Map<String, String> label2DisplayNameMap = new HashMap<>();
            for (JSONObject configCanDetail : configDetailList) {
                String labelName = configCanDetail.getString("labelName");
                String displayName = configCanDetail.getString("displayName");
                if (StrUtil.isAllNotBlank(labelName, displayName)) {
                    label2DisplayNameMap.put(labelName, displayName);
                }
            }
            for (Result result : resultScanner) {
                Cell[] cells = result.rawCells();
                Map<String, String> datas = new HashMap<>();
                // 标签设置初值，防止出图时间轴紊乱
                for (String label : labels) {
                    datas.put(label, "");
                }
                for (Cell cell : cells) {
                    //取到修饰名
                    String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
                    for (String label : labels) {
                        if (label2DisplayNameMap.get(label) != null) {
                            String label1 = label2DisplayNameMap.get(label);
                            if (label1.equals(qualifier)) {
                                String value = Bytes.toString(CellUtil.cloneValue(cell));
                                datas.put(label, value);
                            }
                        } else {
                            if (label.equals(qualifier)) {
                                String value = Bytes.toString(CellUtil.cloneValue(cell));
                                datas.put(label, value);
                            }
                        }
                    }
                    if ("createAt".equals(qualifier)) {
                        String value = Bytes.toString(CellUtil.cloneValue(cell));
                        datas.put("createAt", value);
                    }
                }
                resultDtos.add(datas);
            }
            return resultDtos;
        } catch (Exception e) {
            log.error("查询HBase失败", e);
            return null;
        }
    }

    public List<String[]> searchGpsByTime(String vehicleId, String dateRange, String timeRange) {
        List<String[]> list = new ArrayList<>();
        String[] dateRangeArray = dateRange.split(",");
        if (timeRange == null) {
//            Connection connection;
            Table table;
            ResultScanner rs;
            try {
//                connection = HbaseQuery.getConnection();
                table = hbaseConnection.getTable(TableName.valueOf("rbcd_iov_data_ccu_gps1"));
                String startTime = dateRangeArray[0];
                String endTime = dateRangeArray[1];
                String startRowKey = MD5Hash.getMD5AsHex(Bytes.toBytes(vehicleId)) + "_" + startTime;
                String endRowKey = MD5Hash.getMD5AsHex(Bytes.toBytes(vehicleId)) + "_" + endTime;
                Scan scan = new Scan();
                scan.setCaching(500);
                scan.withStartRow(startRowKey.getBytes());
                scan.withStopRow(endRowKey.getBytes());
                rs = table.getScanner(scan);
                for (Result r : rs) {
                    Cell[] cells = r.rawCells();
                    for (Cell cell : cells) {
                        String[] arr;
                        arr = new String(CellUtil.cloneValue(cell)).split(",");
                        list.add(arr);
                        table.close();
//                        connection.close();
                    }
                }
            } catch (Exception e) {
                logger.error("com.bosch.rbcd.data.service.impl.HbaseQueryService.searchGpsByTime 1 error!", e);
            }
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            SimpleDateFormat sdfTime = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
            String[] timeRangeArray = timeRange.split(",");
            Long dateBgAt = 0L;
            Long dateEdAt = 0L;
            Long timeBgAt = 0L;
            Long timeEdAt = 0L;
            try {
                dateBgAt = sdf.parse(dateRangeArray[0]).getTime();
                dateEdAt = sdf.parse(dateRangeArray[1]).getTime();
                System.out.println("a" + sdfTime.parse(dateRangeArray[0] + " " + timeRangeArray[0]));
                timeBgAt = sdfTime.parse(dateRangeArray[0] + " " + timeRangeArray[0]).getTime();
//                System.out.println("a:" + timeBgAt+"timeRangeArray[0]).getTime()");
                timeEdAt = sdfTime.parse(dateRangeArray[1] + " " + timeRangeArray[1]).getTime();
            } catch (ParseException e) {
                logger.error("com.bosch.rbcd.data.service.impl.HbaseQueryService.searchGpsByTime 2 error!", e);
            }
//            Filter filter1 = new RowFilter(CompareFilter.CompareOp.EQUAL, new BinaryPrefixComparator((MD5Hash.getMD5AsHex(Bytes.toBytes(ccuId))).getBytes()));
//            Scan scan = new Scan();
//            scan.setFilter(filter1);
            String startTime = dateRangeArray[0];
            String endTimeTmp = dateRangeArray[1];
            String endTime = "";
            Calendar c = Calendar.getInstance();
            Date date = null;
            try {
                date = new SimpleDateFormat("yyyyMMdd").parse(endTimeTmp);
                c.setTime(date);
                int day = c.get(Calendar.DATE);
                c.set(Calendar.DATE, day + 1);
                endTime = new SimpleDateFormat("yyyyMMdd").format(c.getTime());
            } catch (ParseException e) {
                logger.error("com.bosch.rbcd.data.service.impl.HbaseQueryService.searchGpsByTime 3 error!", e);
            }
            String startRowKey = MD5Hash.getMD5AsHex(Bytes.toBytes(vehicleId)) + "_" + startTime;
            String endRowKey = MD5Hash.getMD5AsHex(Bytes.toBytes(vehicleId)) + "_" + endTime;
            Scan scan = new Scan();
            scan.setCaching(500);
            scan.withStartRow(startRowKey.getBytes());
            scan.withStopRow(endRowKey.getBytes());
            try {
                Table table = hbaseConnection.getTable(TableName.valueOf("rbcd_iov_data_ccu_gps1"));
                ResultScanner rs = table.getScanner(scan);
                for (Result r : rs) {
                    Cell[] cells = r.rawCells();
                    String rowKey = Bytes.toString(r.getRow());
                    String time = rowKey.substring(rowKey.length() - 8);
                    Long time_temp = 0L;
                    time_temp = sdf.parse(time).getTime();
                    if (time_temp < dateBgAt || time_temp > dateEdAt) {
                        continue;
                    }
                    for (Cell cell : cells) {
                        String[] arr;
                        String[] arr1 = new String[3];
                        if (Long.parseLong(new String(CellUtil.cloneQualifier(cell))) >= timeBgAt && Long.parseLong(new String(CellUtil.cloneQualifier(cell))) <= timeEdAt) {
                            arr = new String(CellUtil.cloneValue(cell)).split(",");
                            if (arr[0].equals("0")) {
                                continue;
                            }
                            arr1[0] = arr[0];
                            arr1[1] = arr[1];
                            SimpleDateFormat sdfTime1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            Date time1 = new Date(Long.parseLong(new String(CellUtil.cloneQualifier(cell))));
                            arr1[2] = sdfTime1.format(time1);
                            list.add(arr1);
                            table.close();
//                            connection.close();
                        }
                    }
                }
            } catch (ParseException e) {
                logger.error("com.bosch.rbcd.data.service.impl.HbaseQueryService.searchGpsByTime 4 error!", e);
            } catch (IOException e) {
                logger.error("com.bosch.rbcd.data.service.impl.HbaseQueryService.searchGpsByTime 5 error!", e);
            } catch (Exception e) {
                logger.error("com.bosch.rbcd.data.service.impl.HbaseQueryService.searchGpsByTime 6 error!", e);
            }
        }
        return list;
    }

}
