package com.bosch.rbcd.data.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.bosch.rbcd.common.hbase.constant.HBaseTableConstant;
import com.bosch.rbcd.common.hbase.utils.HbaseUtils;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.data.dto.DataFlowQuery;
import com.bosch.rbcd.data.service.DataFlowService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname DataFlowServiceImpl
 * @description TODO
 * @date 2023/7/10 13:10
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DataFlowServiceImpl implements DataFlowService {
    private final HbaseUtils hbaseUtils;
    private final RedisUtils redisUtils;

    private static final String LABEL_ALIAS_REDIS_KEY = "label:alias";

    @Override
    public Map<String, List<String>> labelsFlow(DataFlowQuery dataFlowQuery) {
        Map<String, List<String>> labelValuesMap = new HashMap<String, List<String>>();
        String startRowKey = hbaseUtils.getRawTableRow(Long.valueOf(dataFlowQuery.getCcuId()), dataFlowQuery.getStartTime());
        Date nextSecondEndTime = DateUtil.offsetSecond(dataFlowQuery.getEndTime(), 1);
        String endRowKey = hbaseUtils.getRawTableRow(Long.valueOf(dataFlowQuery.getCcuId()), nextSecondEndTime);

        List<String> labelAndAliasList = new ArrayList<>(dataFlowQuery.getLabelList());
        labelAndAliasList.add(HBaseTableConstant.CREAT_TIME_COLUMN);
        // 页面显示的label列表
        Set<String> showLabelList = new HashSet<>(labelAndAliasList);
        // 添加别名列
        dataFlowQuery.getLabelList().forEach(label -> {
            if (redisUtils.hHasKey(LABEL_ALIAS_REDIS_KEY, label)) {
                labelAndAliasList.add((String) (redisUtils.hget(LABEL_ALIAS_REDIS_KEY, label)));
            }
        });

        // 查询Hbase原始数据
        List<Map<String, String>> rawLabelList = dataFlowQuery.isReversFlag() ?
                hbaseUtils.findBaseRowAroundCountData(HBaseTableConstant.RAW_DATA_TABLE_NAME, startRowKey, dataFlowQuery.getCount(), labelAndAliasList, dataFlowQuery.getLabelPrefixList()) :
                hbaseUtils.findDataByColumnName(HBaseTableConstant.RAW_DATA_TABLE_NAME, startRowKey, endRowKey, labelAndAliasList, dataFlowQuery.getLabelPrefixList());

        rawLabelList.forEach(rawMap -> {
            showLabelList.forEach(label->{
                if (!labelValuesMap.containsKey(label)) {
                    labelValuesMap.put(label, new ArrayList<>());
                }
                String value = rawMap.get(label);
                // 值为null时，考虑是否存在别名
                if (value == null) {
                    String aliasLabel = (String) redisUtils.hget(LABEL_ALIAS_REDIS_KEY, label);
                    if (StrUtil.isNotBlank(aliasLabel) && rawMap.get(aliasLabel) != null) {
                        value = rawMap.get(aliasLabel);
                    } else {
                        value = "";
                    }
                }
                List<String> labelValueList = labelValuesMap.get(label);
                labelValueList.add(StrUtil.nullToEmpty(value));
            });
        });
        return labelValuesMap;
    }
}
