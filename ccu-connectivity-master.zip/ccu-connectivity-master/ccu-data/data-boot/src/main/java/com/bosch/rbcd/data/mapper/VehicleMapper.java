package com.bosch.rbcd.data.mapper;

import com.bosch.rbcd.data.pojo.dto.VehicleDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface VehicleMapper {

    List<VehicleDTO> listAllVehicle();

    String[] listFuelTypeLabel(@Param("fuelType")String fuelType);
}
