package com.bosch.rbcd.data.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.common.mybatis.annotation.ProjectDataPermission;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuOnlineRecordVO;

import java.util.List;

/**
 * 车辆在线统计表(VehicleOnlineRecord)表服务接口
 *
 * @author wang bo
 * @since 2023-05-23 14:25:04
 */
public interface CcuOnlineRecordService extends IService<CcuOnlineRecord> {

    /**
     * CcuOnlineRecord 分页列表
     *
     * @param: queryParams 分页查询条件
     * @return: IPage<CcuOnlineRecordVO>
     * @author: wang bo
     * @date: 2023-05-23 14:25:04
     */
    @ProjectDataPermission(projectAlias = "cor", projectIdField = "project_id")
    IPage<CcuOnlineRecordVO> listVehicleOnlineRecordPage(CcuOnlineRecordPageQuery queryParams);

    CcuOnlineRecordPageQuery getQueryParam(CcuOnlineRecordPageQuery query);

    List<String> listOnlineDate(CcuOnlineRecordPageQuery queryParams);
}

