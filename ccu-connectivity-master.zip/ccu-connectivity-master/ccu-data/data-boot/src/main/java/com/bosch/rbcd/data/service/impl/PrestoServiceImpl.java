//package com.bosch.rbcd.data.service.impl;
//
//import com.bosch.rbcd.common.result.PageResult;
//import com.bosch.rbcd.common.result.Result;
//import com.bosch.rbcd.data.dto.AverageDayMileageDTO;
//import com.bosch.rbcd.data.dto.VehicleMileageDTO;
//import com.bosch.rbcd.data.mapper.FcevDataMapper;
//import com.bosch.rbcd.data.pojo.dto.VehicleMileageAndRuntimeDTO;
//import com.bosch.rbcd.data.service.PrestoService;
//import com.bosch.rbcd.monitor.api.DeviceVehicleFeignClient;
//import com.bosch.rbcd.monitor.pojo.query.DeviceInfoWebQuery;
//import com.bosch.rbcd.monitor.dto.DeviceVehicleDTO;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Collectors;
//
//@Service
//@RequiredArgsConstructor
//public class PrestoServiceImpl implements PrestoService {
//
//    private final FcevDataMapper fcevDataMapper;
//
//    private final DeviceVehicleFeignClient deviceVehicleFeignClient;
//
//
//    @Override
//    public Result<Map<String,Integer>> getVehicleInfo(DeviceInfoWebQuery deviceInfoWebQuery) {
//        return deviceVehicleFeignClient.getVehicleInfo(deviceInfoWebQuery);
//    }
//
//    @Override
//    public List<VehicleMileageAndRuntimeDTO> listVehicleMileageAndRuntime(String day) {
//        StringBuilder sql = new StringBuilder("select" +
//                " name," +
//                " total_mileage as distance," +
//                " day," +
//                " total_runtime as runTime" +
//                " from" +
//                " hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime " +
//                " where day = '" + day + "'");
//        List<VehicleMileageAndRuntimeDTO> vehicleMileageAndRuntimeList = fcevDataMapper.listVehicleMileageAndRuntime(sql.toString());
//        return vehicleMileageAndRuntimeList;
//    }
//
//
//    @Override
//    public Integer getAllVehicleRunTime(DeviceInfoWebQuery query) {
//        String dayQuery="select day from hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime where day is not null limit 1";
//        String day = fcevDataMapper.getLastDay(dayQuery).toString();
//        query.setPageNum( 1 );
//        query.setPageSize( 9999999 );
//        PageResult<DeviceVehicleDTO> result = deviceVehicleFeignClient.pageQuery(query);
//        String names=result.getData().getList().stream().map(DeviceVehicleDTO::getCcuNo).collect( Collectors.joining("','"));
//        StringBuilder sql = new StringBuilder("" +
//                "SELECT " +
//                "    sum(total_runtime)" +
//                "    FROM " +
//                "     hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime " +
//                "    WHERE " +
//                "     total_runtime IS NOT NULL " );
//        sql.append(" and day = '" + day + "'");
//        sql.append(" and name in ('" + names + "')");
//        Double allVehicleRuntime = fcevDataMapper.getAllVehicleRunTime(sql.toString());
//        if(allVehicleRuntime!=null){
//            return  allVehicleRuntime.intValue();
//        }else{
//            return  0;
//        }
//    }
//
//    @Override
//    public Integer getAllVehicleMileage(DeviceInfoWebQuery query) {
//        String dayQuery="select day from hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime where day is not null limit 1";
//        String day = fcevDataMapper.getLastDay(dayQuery).toString();
//        query.setPageNum( 1 );
//        query.setPageSize( 9999999 );
//        PageResult<DeviceVehicleDTO> result =  deviceVehicleFeignClient.pageQuery(query);
//        String names=result.getData().getList().stream().map(DeviceVehicleDTO::getCcuNo).collect( Collectors.joining("','"));
//        StringBuilder sql = new StringBuilder("" +
//                " SELECT " +
//                "     sum(total_mileage) " +
//                "    FROM " +
//                "     hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime " +
//                "    WHERE " +
//                "     total_mileage IS NOT NULL " );
//        sql.append(" and day = '" + day + "'");
//        sql.append(" and name in ('" + names + "')");
//        Double allVehicleMileage=fcevDataMapper.getAllVehicleMileage(sql.toString());
//        if(allVehicleMileage!=null){
//            allVehicleMileage = allVehicleMileage/10000;
//        }else{
//            allVehicleMileage = 0d;
//        }
//
//        return allVehicleMileage.intValue();
//    }
//
//    @Override
//    public List<VehicleMileageDTO> getTop10MileageVehicles(DeviceInfoWebQuery query) {
//        String dayQuery="select day from hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime where day is not null limit 1";
//        String day = fcevDataMapper.getLastDay(dayQuery).toString();
//        query.setPageNum( 1 );
//        query.setPageSize( 9999999 );
//        PageResult<DeviceVehicleDTO> result =  deviceVehicleFeignClient.pageQuery(query);
//        String names=result.getData().getList().stream().map(DeviceVehicleDTO::getCcuNo).collect( Collectors.joining("','"));
//        StringBuilder sql = new StringBuilder();
//        sql.append("select sum(today_mileage) as mileage,name from hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime where 1 = 1");
//        sql.append(" and day = '" + day + "'");
//        sql.append(" and name in ('" + names + "')");
//        sql.append(" GROUP BY name");
//        sql.append(" ORDER BY mileage desc");
//        sql.append(" LIMIT 10");
//        List<VehicleMileageDTO> top10MileageVehicles = fcevDataMapper.getTop10MileageVehicles(sql.toString());
//        return top10MileageVehicles;
//    }
//
//    @Override
//    public List<AverageDayMileageDTO> getVehicle10DaysAverageMileage(DeviceInfoWebQuery query) {
//        String dayQuery="select day from hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime where day is not null limit 1";
//        String day = fcevDataMapper.getLastDay(dayQuery).toString();
//        query.setPageNum( 1 );
//        query.setPageSize( 9999999 );
//        PageResult<DeviceVehicleDTO> result =  deviceVehicleFeignClient.pageQuery(query);
//        String names=result.getData().getList().stream().map(DeviceVehicleDTO::getCcuNo).collect( Collectors.joining("','"));
//        StringBuilder sql = new StringBuilder();
//        sql.append("select avg(today_mileage) as mileage,day as date from hive.dwi_platform_iov.dwi_vehicle_mileage_runningtime where 1 = 1 ");
//        sql.append(" and day <= '" + day + "'");
//        sql.append(" and name in ('" + names + "')");
//        sql.append(" and today_mileage>0 ");
//        sql.append(" group by day");
//        sql.append(" order by day desc limit 10");
//
//        List<AverageDayMileageDTO> vehicle10DaysAverageMileage = fcevDataMapper.getVehicle10DaysAverageMileage(sql.toString());
//        return vehicle10DaysAverageMileage;
//    }
//
//
//
//}
