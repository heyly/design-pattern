package com.bosch.rbcd.data.enums;

import com.bosch.rbcd.common.base.IBaseEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * OTA状态枚举类
 * @author WBO3WX
 */
public enum DownLoadStatusEnum implements IBaseEnum {
    CREATING(1,"生成中"),
    TO_DOWNLOAD(2,"待下载"),
    FINISHED(3,"已完成");

    private final Integer value;

    private final String label;

    DownLoadStatusEnum(Integer value, String label) {
        this.value = value;
        this.label = label;
    }

    public Integer getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    private static final Map<Integer, String> map = new HashMap<>();

    static {
        for (DownLoadStatusEnum e : DownLoadStatusEnum.values()) {
            map.put(e.getValue(), e.getLabel());
        }
    }

    public static Map<Integer, String> getMap() {
        return map;
    }
}
