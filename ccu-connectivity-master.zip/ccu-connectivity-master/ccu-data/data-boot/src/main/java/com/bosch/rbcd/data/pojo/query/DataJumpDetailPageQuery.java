package com.bosch.rbcd.data.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class DataJumpDetailPageQuery extends BasePageQuery {

    private Long requestId;
}
