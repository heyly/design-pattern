package com.bosch.rbcd.data.controller;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuOnlineRecordVO;
import com.bosch.rbcd.data.service.CcuOnlineRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * ccu在线统计表(ccuOnlineRecord)表控制层
 *
 * @author wang bo
 * @since 2023-05-23 14:25:04
 */
@Api(tags = "ccu在线记录表API")
@RestController
@RequestMapping("/ccuOnlineRecord")
@RequiredArgsConstructor
public class CcuOnlineRecordController {

    private final CcuOnlineRecordService ccuOnlineRecordService;

    @ApiOperation(value = "ccu online-分页查询")
    @PostMapping("/page")
    public PageResult<CcuOnlineRecordVO> page(@RequestBody CcuOnlineRecordPageQuery query) {
        IPage<CcuOnlineRecordVO> result = ccuOnlineRecordService.listVehicleOnlineRecordPage(query);
        return PageResult.success(result);
    }

    @ApiOperation(value = "ccu online-获取车辆与vin列表")
    @PostMapping("/getQueryParam")
    public Result<CcuOnlineRecordPageQuery> getQueryParam(@RequestBody CcuOnlineRecordPageQuery query) {
        return Result.success(ccuOnlineRecordService.getQueryParam(query));
    }

    @ApiOperation(value = "ccu online-获取在线日期列表")
    @PostMapping("/listOnlineDate")
    public Result<List<String>> listOnlineDate(@RequestBody CcuOnlineRecordPageQuery query) {
        return Result.success(ccuOnlineRecordService.listOnlineDate(query));
    }

    @ApiIgnore(value = "ccu online-通过主键查询单条数据")
    @GetMapping("/getById/{id}")
    public Result<Object> getById(@PathVariable Serializable id) {
        return Result.success(ccuOnlineRecordService.getById(id));
    }

    @ApiIgnore(value = "ccu online-新增数据")
    @PostMapping("/insert")
    public Result<Object> insert(@RequestBody CcuOnlineRecord ccuOnlineRecord) {
        return Result.success(ccuOnlineRecordService.save(ccuOnlineRecord));
    }

    @ApiIgnore(value = "ccu online-修改数据")
    @PutMapping("/update")
    public Result<Object> update(@RequestBody CcuOnlineRecord ccuOnlineRecord) {
        return Result.success(ccuOnlineRecordService.updateById(ccuOnlineRecord));
    }

    @ApiIgnore(value = "ccu online-删除数据")
    @DeleteMapping("/delete/{ids}")
    public Result<Object> delete(@ApiParam("主键id，多个以英文逗号(,)分割") @PathVariable String ids) {
        List<Long> idList = Arrays.stream(ids.split(",")).map(Long::parseLong).collect(Collectors.toList());
        return Result.success(ccuOnlineRecordService.removeByIds(idList));
    }

    @ApiIgnore(value = "ccu online-重置在线记录聚合标志")
    @GetMapping("/resetCluster")
    public void resetCluster(@RequestParam String ccuId, @RequestParam String onlineDate) {
        ccuOnlineRecordService.update(new LambdaUpdateWrapper<CcuOnlineRecord>()
                .set(CcuOnlineRecord::getClusterFlag, 2)
                .set(CcuOnlineRecord::getHiveClusterFlag, 2)
                .eq(CcuOnlineRecord::getCcuId, ccuId).eq(CcuOnlineRecord::getOnlineDate, onlineDate));
    }

}

