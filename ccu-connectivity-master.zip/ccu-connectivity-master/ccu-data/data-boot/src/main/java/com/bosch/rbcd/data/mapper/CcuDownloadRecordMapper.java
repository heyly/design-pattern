package com.bosch.rbcd.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.data.pojo.entity.CcuDownloadRecord;
import com.bosch.rbcd.data.pojo.query.CcuDownloadRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuDownloadRecordVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 车辆数据下载用户记录表(VehicleDownloadUserRecord)表数据库访问层
 *
 * @author wang bo
 * @since 2023-05-23 14:28:42
 */
@Mapper
public interface CcuDownloadRecordMapper extends BaseMapper<CcuDownloadRecord> {

    /**
     * 获取VehicleDownloadUserRecord分页列表
     *
     * @param page
     * @param queryParams 查询参数
     * @return
     */
    List<CcuDownloadRecordVO> listCcuDownloadRecordPage(Page<CcuDownloadRecordVO> page, @Param("queryParams") CcuDownloadRecordPageQuery queryParams);

    void updateDownRecordStatus(@Param("onlineRecordId") long onlineRecordId, @Param("fileType") String fileType);

}

