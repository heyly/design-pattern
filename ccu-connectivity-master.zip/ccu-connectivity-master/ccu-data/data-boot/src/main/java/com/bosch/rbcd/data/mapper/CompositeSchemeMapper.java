package com.bosch.rbcd.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.data.pojo.entity.DataCompositeScheme;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * (CompositeScheme)表数据库访问层
 */
@Component
@Mapper
public interface CompositeSchemeMapper extends BaseMapper<DataCompositeScheme> {
    @Select("select DISTINCT(fuel_type) from data_composite_scheme")
    List<String> listFuelTypes();

}

