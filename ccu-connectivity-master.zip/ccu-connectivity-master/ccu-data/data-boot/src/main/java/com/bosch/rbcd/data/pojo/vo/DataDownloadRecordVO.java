package com.bosch.rbcd.data.pojo.vo;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * (DataDownloadRecord)视图对象
 *
 * @author makejava
 * @since 2022-09-01 13:02:37
 */
@ApiModel("")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataDownloadRecordVO {

    @ApiModelProperty("")
    private Long id;

    @ApiModelProperty("")
    private Long userId;

    @ApiModelProperty("")
    private String path;

    @ApiModelProperty("")
    private String name;

    @ApiModelProperty("1.单车 2.多车")
    private Integer type;

    @ApiModelProperty("")
    private Long organizationId;

    @ApiModelProperty("车辆id，逗号分隔")
    private String vehicleId;

    @ApiModelProperty("车辆名称，逗号分隔")
    private String vehicleName;

    @ApiModelProperty("")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date beginAt;

    @ApiModelProperty("")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date endAt;

    @ApiModelProperty("")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date createAt;

    @ApiModelProperty("")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date updateAt;

}
