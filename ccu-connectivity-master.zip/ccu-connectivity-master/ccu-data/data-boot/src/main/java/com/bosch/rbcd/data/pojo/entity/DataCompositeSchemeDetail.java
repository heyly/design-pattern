package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

/**
 * (CompositeSchemeDetail)表实体类
 */
@Data
public class DataCompositeSchemeDetail {

    @TableId(type = IdType.AUTO)
    private Long id;

    // 方案id
    private Long schemeId;

    private String label;

    private String labelDisplay;

    // 最大值
    private String max;

    // 最小值
    private String min;

    // 函数名 (sum,avg)
    private String functionName;

    // 逻辑运算符：&,||
    private String logic;
}