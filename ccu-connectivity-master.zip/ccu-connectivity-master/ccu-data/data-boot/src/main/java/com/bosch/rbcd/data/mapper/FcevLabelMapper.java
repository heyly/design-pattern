package com.bosch.rbcd.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.data.pojo.entity.VehicleFcevLabel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @description 针对表【fcev_label】的数据库操作Mapper
 */
@Component
@Mapper
public interface FcevLabelMapper extends BaseMapper<VehicleFcevLabel> {

    @Select( "select distinct(`system`) from vehicle_fcev_label" )
    List<String> listSystem();

}
