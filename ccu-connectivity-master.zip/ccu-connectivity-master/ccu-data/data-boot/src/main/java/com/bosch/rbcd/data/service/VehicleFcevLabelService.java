package com.bosch.rbcd.data.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.VehicleFcevLabel;

import java.util.List;

/**
 * @description 针对表【fcev_label】的数据库操作Service
 */
public interface VehicleFcevLabelService extends IService<VehicleFcevLabel> {

    List<String> listSystem();

}