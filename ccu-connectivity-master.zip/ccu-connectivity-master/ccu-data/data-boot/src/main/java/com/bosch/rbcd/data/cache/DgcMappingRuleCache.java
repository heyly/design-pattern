package com.bosch.rbcd.data.cache;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.data.pojo.entity.DgcMappingRule;
import com.bosch.rbcd.data.service.DgcMappingRuleService;
import com.bosch.rbcd.data.vo.DgcDataRangeVO;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalListener;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class DgcMappingRuleCache extends BaseLocalCache<Long, Map<String, DgcDataRangeVO>> {

    @Autowired
    private DgcMappingRuleService dgcMappingRuleService;

    public static final String PLACEHOLDER = "Invalid data";

    /**
     * 使用google guava缓存处理
     * key: DgcMappingRuleTable的id
     * value: 每个采集量的最大最小值
     */
    private static final Cache<Long, Map<String, DgcDataRangeVO>> cache;
    static {
        cache = CacheBuilder.newBuilder()
                .expireAfterWrite(10, TimeUnit.MINUTES) // 10分钟过期
                .removalListener((RemovalListener<Long, Map<String, DgcDataRangeVO>>) rn -> {
                    if (log.isDebugEnabled()) {
                        log.debug("DgcMappingRuleCache 被移除缓存 tableId = {}, 规则数量 = {}", rn.getKey(), rn.getValue().size());
                    }
                }).build();
    }

    @Override
    public Cache<Long, Map<String, DgcDataRangeVO>> getCache() {
        return cache;
    }

    @Override
    public Map<String, DgcDataRangeVO> get(Long tableId) {
        if (tableId == null || tableId <= 0) {
            return null;
        }

        Map<String, DgcDataRangeVO> ruleMap = getCache().getIfPresent(tableId);

        if (MapUtils.isEmpty(ruleMap)) {
            ruleMap = new HashMap<>();

            LambdaQueryWrapper<DgcMappingRule> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(DgcMappingRule::getTableId, tableId);
            List<DgcMappingRule> ruleList = dgcMappingRuleService.list(queryWrapper);

            if (CollectionUtils.isNotEmpty(ruleList)) {
                for (DgcMappingRule dgcMappingRule : ruleList) {
                    Integer must = dgcMappingRule.getMust();
                    if (must == null || must != 1) {
                        must = 0;
                    }
                    Double min = null, max = null;
                    try {
                        if (StringUtils.isNotBlank(dgcMappingRule.getPhyMin())) {
                            min = Double.parseDouble(dgcMappingRule.getPhyMin());
                        }
                        if (StringUtils.isNotBlank(dgcMappingRule.getPhyMax())) {
                            max = Double.parseDouble(dgcMappingRule.getPhyMax());
                        }
                    } catch (Exception e) {
                        log.error("最大最小值转化出错！", e);
                    }

                    if (min == null && max == null && must == 0) {
                        continue;
                    }

                    DgcDataRangeVO dataRange = new DgcDataRangeVO(min, max, must);
                    String[] signalNameList = dgcMappingRule.getSignalName().split(",");
                    for (String signalName : signalNameList) {
                        ruleMap.put(signalName, dataRange);
                    }
                }
            }

            // 防止缓存穿透
            if (MapUtils.isEmpty(ruleMap)) {
                ruleMap.put(PLACEHOLDER, null);
            }

            getCache().put(tableId, ruleMap);
        }

        return ruleMap;
    }
}
