package com.bosch.rbcd.data.pojo.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.bosch.rbcd.data.pojo.entity.DataCompositeSchemeDetail;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class DataCompositeSchemeVO {

    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("方案名称")
    private String name;

    @ApiModelProperty("1:瞬时 2:窗口")
    private Integer type;

    @ApiModelProperty("动力类型")
    private String fuelType;

    @ApiModelProperty("窗口大小")
    private Integer windowSize;

    @ApiModelProperty("创建人")
    private String createBy;

    List<DataCompositeSchemeDetail> detailList;

}
