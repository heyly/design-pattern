package com.bosch.rbcd.data.controller;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.dto.DataFlowDto;
import com.bosch.rbcd.data.dto.DataFlowQuery;
import com.bosch.rbcd.data.pojo.dto.JsonAddressDTO;
import com.bosch.rbcd.data.pojo.query.HistoryLocationQuery;
import com.bosch.rbcd.data.pojo.vo.GroupLocation;
import com.bosch.rbcd.data.service.DataFlowService;
import com.bosch.rbcd.data.service.impl.HbaseQueryService;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
@Api(tags = "数据流相关接口")
@RequestMapping("/data")
@RestController
@RequiredArgsConstructor
public class DataFlowController {

    private final HbaseQueryService hbaseQueryService;
    private final DataFlowService dataFlowService;
    private final DeviceInfoFeignClient deviceFeignClient;

    private final String url = "https://restapi.amap.com/v3/geocode/regeo?output=JSON&location=%s&key=%s&radius=1000";
    private final String mapKey = "4e2ab804a44ab77b8d93ee209bba57a5";

    @Value("${huawei.foldPath}")
    private String defaultBucketUrlPrfix;

    @ApiOperation("公共label数据流")
    @PostMapping("/labelsFlow")
    public Result<Map<String, List<String>>> labelsFlow(@RequestBody DataFlowQuery dataFlowQuery) {
        if (StrUtil.isBlank(dataFlowQuery.getCcuId())) {
            return Result.failed("请选择需要查看数据的CCU!");
        }
        if (dataFlowQuery.getStartTime() == null || dataFlowQuery.getEndTime() == null) {
            return Result.failed("请选择开始和结束时间!");
        }

        if (dataFlowQuery.getStartTime().before(DateUtil.parse("2025-01-13"))) {
            return Result.failed("请选择2025-01-13以后的时间!");
        }

        DateTime threeMonthAgo = DateUtil.offsetMonth(new Date(), -3);
        if(dataFlowQuery.getStartTime().before(threeMonthAgo)){
            return Result.failed("请选择近3个月内的时间，查看数据流！");
        }

        return Result.success(dataFlowService.labelsFlow(dataFlowQuery));
    }



    @ApiOperation("查询label图表")
    @GetMapping("/dataFlow")
    @ApiIgnore
    public Result<List<DataFlowDto>> dataFlow(@RequestParam String ccuId,
                                              @RequestParam String label,
                                              @RequestParam String imei,
                                              @RequestParam String startTime,
                                              @RequestParam String endTime) {

        DateTime startDate = DateUtil.parse(startTime, DatePattern.NORM_DATETIME_FORMAT);
        DateTime endDate = DateUtil.parse(endTime, DatePattern.NORM_DATETIME_FORMAT);
        long period = endDate.getTime() - startDate.getTime();
        if (period > 3600 * 24 * 1000) {
            return Result.failed("Please select data within one days");
        }
        String start = DateUtil.format(startDate, "yyyyMMddHHmmss");
        String end = DateUtil.format(endDate, "yyyyMMddHHmmss");
        List<DataFlowDto> resultVOs = hbaseQueryService.findDataFlow(label, ccuId, imei, start, end);
        return Result.success(resultVOs);
    }

    @ApiOperation("查询多个label图表")
    @GetMapping("/dataFlowByLabels")
    @ApiIgnore
    public Result<List<Map<String, String>>> dataFlowByLabels(@RequestParam String ccuId,
                                                              @RequestParam String labels,
                                                              @RequestParam String imei,
                                                              @RequestParam String startTime,
                                                              @RequestParam String endTime) {

        DateTime startDate = DateUtil.parse(startTime, DatePattern.NORM_DATETIME_FORMAT);
        DateTime endDate = DateUtil.parse(endTime, DatePattern.NORM_DATETIME_FORMAT);
        long period = endDate.getTime() - startDate.getTime();
        if (period > 3600 * 24 * 1000) {
            return Result.failed("Please select data within one days");
        }
        String start = DateUtil.format(startDate, "yyyyMMddHHmmss");
        String end = DateUtil.format(endDate, "yyyyMMddHHmmss");
        String[] labelArr = labels.split(",");
        List<Map<String, String>> resultVOs = hbaseQueryService.findDataFlows(labelArr, ccuId, imei, start, end);
        return Result.success(resultVOs);
    }

    @PostMapping("/findHistoryLocation")
    @ApiOperation("获取车辆分组历史定位")
    public Result findHistoryLocation(@RequestBody HistoryLocationQuery historyLocationQuery) {
        List<String[]> list = hbaseQueryService.searchGpsByTime(historyLocationQuery.getCcuId(),
                historyLocationQuery.getDateRange(),
                historyLocationQuery.getTimeRange());
        //将数据进行分段，发现车辆大于10分钟的距离差就把路径分离
        List<Integer> breakList = new ArrayList<>();
        if (list.size() > 0) {
            breakList.add(0);
        }
        SimpleDateFormat sdfTime1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for (int i = 1; i < list.size() && list.size() > 1; i++) {
            String[] currentData = list.get(i);
            String[] lastData = list.get(i - 1);
            if (currentData.length == 3 && lastData.length == 3) {
                String currentTimeStamp = currentData[2];
                String lastTimeStamp = lastData[2];
                try {
                    Date currentDate = sdfTime1.parse(currentTimeStamp);
                    Date lastDate = sdfTime1.parse(lastTimeStamp);
                    if (currentDate.getTime() - lastDate.getTime() > 300000) {
                        breakList.add(i - 1);
                        breakList.add(i);
                    }
                } catch (ParseException e) {
                    log.error("DataController.findHistoryLocation error!", e);
                }
            }
        }
        if (list.size() > 0) {
            breakList.add(list.size() - 1);
        }

        //生成分组信息
        List<GroupLocation> groupLocationList = new ArrayList<>();
        for (int i = 0; i < breakList.size(); i += 2) {
            GroupLocation groupLocation = new GroupLocation();
            Integer startIndex = breakList.get(i);
            Integer endIndex = breakList.get(i + 1);
            String[] startLocation = list.get(startIndex);
            String[] endLocation = list.get(endIndex);
            groupLocation.setLocationList(list.subList(startIndex, endIndex));
            groupLocation.setStartTime(startLocation[2]);
            groupLocation.setEndTime(endLocation[2]);
            //根据经纬度查询地址
            String location = startLocation[0] + "," + startLocation[1];
            String urlReplace = String.format(url, location, mapKey);
            String getAddress = HttpUtil.get(urlReplace);
            JSONObject jsonObject = JSONUtil.parseObj(getAddress);
            if ("1".equalsIgnoreCase(jsonObject.get("status").toString())) {
                JsonAddressDTO addressDTO = jsonObject.get("regeocode", JsonAddressDTO.class);
                groupLocation.setStartLocationInfo(addressDTO.getFormatted_address());
            }

            groupLocationList.add(groupLocation);
        }
        Map<String, Object> resMap = new HashMap<>();
        resMap.put("originalData", list);
        resMap.put("groupData", groupLocationList);
        return Result.success(resMap);
    }

    // 里程（km），车速（km/h），功率（W）
//    private static final String[] BEV_LABELS = {"IC_OdometerMasterValue", "ABS_VehSpdLgt", "MCU_MotorPwr_MEAS"};
//    private static final String[] FCEV_LABELS = {"GlbDa_lTotDst_VCU", "VehV_v_VCU", "FuCellElec_pwrStckAct"};
//    @PostMapping("/getLatestWindowData")
//    @ApiOperation("获取最新的窗口数据")
//    public Result getLatestWindowData(@RequestBody WindowDataQuery windowDataQuery) {
//        String[] labelArr;
//        ProjectVehicleCcuDTO device = deviceFeignClient.findByCcuId(windowDataQuery.getCcuId()).getData();
//        if (Objects.isNull(device.getProjectId())) {
//            return Result.failed("feign调用异常，或当前车辆不在任何项目中");
//        }
//        String powerTrainCode = device.getPowerTrainCode();
//        if (powerTrainCode.equalsIgnoreCase("BEV")) {
//
//            labelArr = BEV_LABELS;
//        } else if (powerTrainCode.equalsIgnoreCase("FCEV")) {
//            labelArr = FCEV_LABELS;
//        } else {
//            return Result.failed("当前车辆既不是FCEV也不是BEV");
//        }
//
//        if (windowDataQuery.getMinutes() == null) {
//            //默认查询5分钟
//            windowDataQuery.setMinutes(5);
//        }
//        //获取窗口开始和结束时间
//        String end = DateUtil.format(new Date(), "yyyyMMddHHmmss");
//        String start = DateUtil.format(DateUtil.offsetMinute(new Date(), -windowDataQuery.getMinutes()), "yyyyMMddHHmmss");
//
//        List<Map<String, String>> resultVOs = hbaseQueryService.findDataFlows(labelArr,
//                windowDataQuery.getCcuId(),
//                windowDataQuery.getImei(), start, end);
//        return Result.success(resultVOs);
//    }

}
