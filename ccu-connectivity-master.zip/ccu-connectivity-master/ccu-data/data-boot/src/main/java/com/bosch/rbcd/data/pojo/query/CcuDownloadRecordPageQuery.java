package com.bosch.rbcd.data.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;
import java.util.Set;

/**
 * 车辆数据下载用户记录表(VehicleDownloadUserRecord)分页查询对象
 *
 * @author wang bo
 * @since 2023-05-23 14:28:42
 */
@ApiModel("车辆数据下载用户记录表分页查询对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CcuDownloadRecordPageQuery extends BasePageQuery {

    @ApiModelProperty("下载记录id列表")
    private List<Long> idList;

    @ApiModelProperty("车辆id列表")
    private Set<Long> fleetIdList;

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("用户名称")
    private String userName;

    @ApiModelProperty("csv/mf4")
    private String fileType;

    @ApiModelProperty("0-已创建，1-生成中 ，2-下载中，3-已完成")
    private Integer status;

    @ApiModelProperty("车辆id列表")
    private List<Long> vehicleIdList;
}
