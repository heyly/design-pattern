package com.bosch.rbcd.data.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.VehicleMileageRunningTime;

public interface VehicleMileageRunningTimeService extends IService<VehicleMileageRunningTime> {

//    Integer getAllVehicleRunTime(DeviceInfoWebQuery query);
//
//
//    Integer getAllVehicleMileage(DeviceInfoWebQuery query);

}
