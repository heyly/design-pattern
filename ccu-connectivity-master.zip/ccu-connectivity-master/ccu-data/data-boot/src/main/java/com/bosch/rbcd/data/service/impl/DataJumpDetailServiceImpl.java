package com.bosch.rbcd.data.service.impl;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.common.hbase.constant.HBaseTableConstant;
import com.bosch.rbcd.common.hbase.utils.HbaseUtils;
import com.bosch.rbcd.data.mapper.DataJumpDetailMapper;
import com.bosch.rbcd.data.mapper.DataJumpRequestMapper;
import com.bosch.rbcd.data.pojo.entity.DataJumpDetail;
import com.bosch.rbcd.data.pojo.entity.DataJumpRequest;
import com.bosch.rbcd.data.pojo.query.DataJumpDetailPageQuery;
import com.bosch.rbcd.data.service.DataJumpDetailService;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DataJumpDetailServiceImpl extends ServiceImpl<DataJumpDetailMapper, DataJumpDetail> implements DataJumpDetailService {

    @Autowired
    private DataJumpRequestMapper dataJumpRequestMapper;

    @Autowired
    private HbaseUtils hbaseUtils;

    private static final String[] SEARCH_LABELS = {"createAt", "DFES_numDFC_[7]_TCU_S", "DFES_numDFC_[8]_TCU_S",
            "DFES_numDFC_[9]_TCU_S", "DFES_stChk_[0]_TCU_S", "DFES_stChk_[10]_TCU_S", "DFES_stChk_[11]_TCU_S",
            "DFES_stChk_[12]_TCU_S", "DFES_stChk_[13]_TCU_S", "DFES_stChk_[14]_TCU_S", "DFES_stChk_[15]_TCU_S"};

    @Override
    public IPage<DataJumpDetail> pageQuery(DataJumpDetailPageQuery query) {
        IPage<DataJumpDetail> iPage = new Page<>(query.getPageNum(), query.getPageSize());
        LambdaQueryWrapper<DataJumpDetail> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(query.getRequestId() != null, DataJumpDetail::getRequestId, query.getRequestId());
        return page(iPage, queryWrapper);
    }

    /**
     * 查询是否存在数据跳变
     * 以10min的时间窗口查询hbase，防止数据量过大，造成内存不足
     * 暂时关闭事务，运行时间可能偏长
     * @param requestId
     * @param ccuId
     * @param startTime
     * @param endTime
     */
    @Async
//    @Transactional
    public void asyncCheckDetail(Long requestId, String ccuId, Date startTime, Date endTime) {
        List<String> rowRangeList = getRowRangeList(ccuId, startTime, endTime);

        if (CollectionUtils.isNotEmpty(rowRangeList)) {

            Map<String, String> pre = null, current = null, next = null;
            List<String> labelList = Arrays.asList(SEARCH_LABELS);

            Queue<Map<String, String>> rawDataQueue = new LinkedList<>();
            for (String rowRange : rowRangeList) {
                String[] row = rowRange.split("-");
                String startRow = row[0];
                String endRow = row[1];
                // 获取指定10min内原始数据
//                List<Map<String, String>> rawDataList = hbaseUtils.findDataByColumnName(HBaseTableConstant.RAW_DATA_TABLE_NAME, startRow, endRow, labelList, null);
                List<Map<String, String>> rawDataList = hbaseUtils.findDurationRawData(HBaseTableConstant.RAW_DATA_TABLE_NAME, startRow, endRow);
                if (CollectionUtils.isEmpty(rawDataList)) {
                    continue;
                }
                rawDataQueue.addAll(rawDataList);

                // 初始值
                if (MapUtils.isEmpty(pre)) {
                    pre = rawDataQueue.poll();
                    current = rawDataQueue.poll();
                }

                List<DataJumpDetail> dataJumpDetailList = new ArrayList<>();
                while (!rawDataQueue.isEmpty()) {
                    next = rawDataQueue.poll();
                    if (MapUtils.isEmpty(pre) || MapUtils.isEmpty(current) || MapUtils.isEmpty(next)) {
                        pre = current;
                        current = next;
                        continue;
                    }


                    for (Map.Entry<String, String> entry : current.entrySet()) {
                        String key = entry.getKey();
                        String value = entry.getValue();
                        // 前后一样，当前不一样，则识别为跳变
                        if (StrUtil.equals(pre.get(key), next.get(key)) && !StrUtil.equals(pre.get(key), value)) {
                            DataJumpDetail dataJumpDetail = new DataJumpDetail();
                            dataJumpDetail.setRequestId(requestId);
                            dataJumpDetail.setLabel(key);
                            dataJumpDetail.setCorrectValue(pre.get(key));
                            dataJumpDetail.setJumpValue(value);
                            dataJumpDetail.setPreTime(pre.get("createAt"));
                            dataJumpDetail.setCurTime(current.get("createAt"));
                            dataJumpDetail.setNextTime(next.get("createAt"));
                            dataJumpDetailList.add(dataJumpDetail);
                        }
                    }

                    pre = current;
                    current = next;
                }

                if (CollectionUtils.isNotEmpty(dataJumpDetailList)) {
                    saveBatch(dataJumpDetailList,50);
                }

            }

        }


        // 更新请求表的状态
        LambdaUpdateWrapper<DataJumpRequest> requestLambdaUpdateWrapper = new LambdaUpdateWrapper<>();
        requestLambdaUpdateWrapper.set(DataJumpRequest::getStatus, 1);
        requestLambdaUpdateWrapper.eq(DataJumpRequest::getId, requestId);
        dataJumpRequestMapper.update(null, requestLambdaUpdateWrapper);
    }

    /**
     * 以10分钟的时间窗口进行拆分
     *
     * @param ccuId
     * @param beginTime
     * @param endTime
     * @return
     */
    private List<String> getRowRangeList(String ccuId, Date beginTime, Date endTime) {
        List<String> rowNameList = new ArrayList<>();
        List<DateTime> hourSplitList = DateUtil.rangeToList(beginTime, endTime, DateField.MINUTE);
        for (int i = 0; i < hourSplitList.size(); i += 10) {
            DateTime beginMinute = hourSplitList.get(i);
            String startRow = hbaseUtils.getRawTableRow(ccuId, beginMinute);
            String endRow = "";
            if (i < hourSplitList.size() - 10) {
                DateTime next10Minute = hourSplitList.get(i + 10);
                endRow = hbaseUtils.getRawTableRow(ccuId, next10Minute);
            } else {
                endRow = hbaseUtils.getRawTableRow(ccuId, DateUtil.offsetSecond(endTime, 1));
            }
            rowNameList.add(startRow + "-" + endRow);
        }
        return rowNameList;
    }
}
