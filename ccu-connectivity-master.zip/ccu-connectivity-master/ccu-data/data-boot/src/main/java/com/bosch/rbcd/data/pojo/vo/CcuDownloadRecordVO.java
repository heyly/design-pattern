package com.bosch.rbcd.data.pojo.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 车辆数据下载用户记录表(VehicleDownloadUserRecord)视图对象
 *
 * @author wang bo
 * @since 2023-05-23 14:28:42
 */
@ApiModel("车辆数据下载用户记录表视图对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CcuDownloadRecordVO {

    @ApiModelProperty("下载记录主键")
    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty(value = "车辆在线记录",required = true)
    private Long onlineRecordId;

    @ApiModelProperty("1-生成中 ，2-待下载，3-已完成")
    private Integer status;

    @ApiModelProperty(value ="csv/mf4",required = true)
    private String fileType;

    @ApiModelProperty("车辆名称")
    private String userName;

    @ApiModelProperty("ccuId")
    private String ccuId;

    @ApiModelProperty("ccu名称")
    private String ccuNo;

    @ApiModelProperty("车架号")
    private String vin;

    @ApiModelProperty("在线日期yyyymmdd")
    private String onlineDate;

    @ApiModelProperty("0:当天数据,1:历史数据")
    private Integer clusterFlag;

    @ApiModelProperty("csv文件路径")
    private String csvPath;

    @ApiModelProperty("mf4文件路径")
    private String mf4Path;

    @ApiModelProperty("生成进度")
    private Integer clusterPercent;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    private Date createTime;
}
