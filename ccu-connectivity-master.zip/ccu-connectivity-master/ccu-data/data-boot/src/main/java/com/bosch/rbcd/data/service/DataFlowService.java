package com.bosch.rbcd.data.service;

import com.bosch.rbcd.data.dto.DataFlowQuery;

import java.util.List;
import java.util.Map;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname DataFlowService
 * @description TODO
 * @date 2023/7/10 13:10
 */
public interface DataFlowService {
    Map<String, List<String>> labelsFlow(DataFlowQuery dataFlowQuery);
}
