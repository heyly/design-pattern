//package com.bosch.rbcd.data.kafka;
//
//import cn.hutool.core.collection.CollectionUtil;
//import cn.hutool.core.date.DateUtil;
//import cn.hutool.core.util.NumberUtil;
//import cn.hutool.core.util.StrUtil;
//import com.alibaba.fastjson.JSONObject;
//import com.bosch.rbcd.common.huawei.util.HWSmsUtil;
//import com.bosch.rbcd.common.redis.utils.RedisUtils;
//import com.bosch.rbcd.data.cache.DeviceInfoCache;
//import com.bosch.rbcd.data.cache.DgcMappingRuleCache;
//import com.bosch.rbcd.data.cache.DgcMappingTableCache;
//import com.bosch.rbcd.data.pojo.dto.MessageDTO;
//import com.bosch.rbcd.data.pojo.entity.DgcMappingTable;
//import com.bosch.rbcd.data.vo.DgcDataRangeVO;
//import com.bosch.rbcd.device.pojo.dto.CcuDeviceInfoDTO;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.collections.MapUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.apache.kafka.clients.consumer.ConsumerRecords;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.kafka.annotation.EnableKafka;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Component;
//
//import java.math.BigDecimal;
//import java.util.*;
//import java.util.concurrent.TimeUnit;
//import java.util.stream.Collectors;
//
//@Slf4j
////@ConditionalOnProperty(prefix = "custom.kafka", name = {"createBean"}, havingValue = "true", matchIfMissing = false)
////@Component
////@EnableKafka
//public class DataErrorConsumer implements InitializingBean {
//
//    @Autowired
//    private DeviceInfoCache deviceInfoCache;
//
//    @Autowired
//    private DgcMappingTableCache dgcMappingTableCache;
//
//    @Autowired
//    private DgcMappingRuleCache dgcMappingRuleCache;
//
//    @Autowired
//    private StringRedisTemplate stringRedisTemplate;
//
//    @Autowired
//    private HWSmsUtil hwSmsUtil;
//
//    @Autowired
//    private RedisUtils redisUtils;
//
//    @KafkaListener(topics = "ccu_data", containerFactory = "dataErrorGroupFactory")
//    public void analysisDataError(ConsumerRecords<String, String> records) {
//        if (records == null) {
//            return;
//        }
//        for (ConsumerRecord<String, String> record : records) {
//            String json = record.value();
//            if (json.length() < 10) {
//                continue;
//            }
//
//
//            MessageDTO curMessage = null;
//            // 校验数据质量
//            try {
//                curMessage = JSONObject.parseObject(json, MessageDTO.class);
////                log.info("来消息了：" + json);
////                checkDataQuality(curMessage);
//                monitorFanTemp(curMessage);
//            } catch (Exception e) {
//                log.error("校验数据质量出错！", e);
//            }
//        }
//
//    }
//
//    /**
//     * 监测DCAC风扇温度是否超限
//     *
//     * @param messageDTO
//     */
//    private void monitorFanTemp(MessageDTO messageDTO) {
//        String ccuNo = (String) stringRedisTemplate.opsForHash().get("imei:" + messageDTO.getImei(), "name");
//        // 获取待监控的ccu清单
//        Set<Object> monitorCcuSet = redisUtils.sGet("fccu_fan_warn:ccu_set");
//        if (CollectionUtil.contains(monitorCcuSet, ccuNo)) {
//            Map<String, Object> data = messageDTO.getData();
//
//            // 温差绝对值
//            int temSubAbs = 0;
//            //  实际值
//            String TCooltStckin_t_f = ((String) data.get("TCooltStckIn_t_f"));
//            // 设定值-开尔文
//            String FucellStck_tCooltStckSp = ((String) data.get("FuCellStck_tCooltStckSp"));
//            if (StrUtil.isAllNotBlank(TCooltStckin_t_f, FucellStck_tCooltStckSp)) {
//                // 设定值-华氏温度
//                BigDecimal targetTemp = NumberUtil.sub(FucellStck_tCooltStckSp, "273.15");
//                temSubAbs = NumberUtil.sub(NumberUtil.toBigDecimal(TCooltStckin_t_f), targetTemp).intValue();
//            }
//
//            //风扇转速
//            double Com_nFCCUFanSpdReq = NumberUtil.parseDouble((String) data.get("Com_nFCCUFanSpdReq"));
//            // FCCU电流
//            double Com_iInpFan2FCCU = NumberUtil.parseDouble((String) data.get("Com_iInpFan2FCCU"));
//
//            // 实际值   TCooltStckin_t_f   和  设定值 (FucellStck_tCooltStckSp - 273.15 ) 之间 温差大于3 度
//            //或者 风扇转速Com_nFCCUFanSpdReq   大于2000rpm 时，Com_iInpFan2FCCU  < 0.5A
//            if (temSubAbs > 3 || (Com_nFCCUFanSpdReq > 2000 && Com_iInpFan2FCCU < 0.5)) {
//                String warnMsg = StrUtil.format("[{}]DCAC风扇温度过高预警，实际温度值：{}，设定温度：{}， 风扇转速：{}， 风扇电流：{}", DateUtil.now(), TCooltStckin_t_f, FucellStck_tCooltStckSp,
//                        Com_nFCCUFanSpdReq,
//                        Com_iInpFan2FCCU);
//                log.info(warnMsg);
//                List<String> receiverSet = redisUtils.sGet("fccu_fan_warn:mobile_set").stream().map(String::valueOf).collect(Collectors.toList());
//                try {
//                    String tempWarnKey = "fccu_fan_warn:" + ccuNo;
//                    // 10min内只发送一封
//                    if (!redisUtils.hasKey(tempWarnKey)) {
//                        hwSmsUtil.send("113e0b64822a42f98083b9f74b6358a7", null, receiverSet);
//                        redisUtils.set(tempWarnKey, warnMsg, 600);
//                    }
//                } catch (Exception e) {
//                    log.error("DCAC温度预警短信发送失败，详情：", e);
//                }
//            }
//        }
//    }
//
//    private void checkDataQuality(MessageDTO messageDTO) {
//        if (messageDTO == null || MapUtils.isEmpty(messageDTO.getData())) {
//            return;
//        }
//
//        String ccuId = messageDTO.getVehicleId();
//        if (StringUtils.isBlank(ccuId)) {
//            return;
//        }
//
//        // 原始数据日期
//        String createDay = messageDTO.getCreateAt().split(" ")[0];
//        // 过期时间，单位：秒（加入随机数，防止集中过期）
//        long timeout = 36L * 60 * 60 + (long) (2 * 60 * 60 * Math.random());
//
//        // 记录数据总量
//        String redisCountKey = "dataError_" + ccuId + "_" + createDay + "_count";
//        boolean hasKey = Boolean.TRUE.equals(stringRedisTemplate.hasKey(redisCountKey));
//        // 原子操作
//        stringRedisTemplate.opsForHash().increment(redisCountKey, "totalCount", 1L);
//
//        if (!hasKey) {
//            stringRedisTemplate.expire(redisCountKey, timeout, TimeUnit.SECONDS);
//        }
//
//        CcuDeviceInfoDTO deviceInfo = deviceInfoCache.get(ccuId);
//        if (deviceInfo == null || deviceInfo.getProjectId() == null || deviceInfo.getId().equals(Long.MIN_VALUE)) {
//            return;
//        }
//
//        Long projectId = deviceInfo.getProjectId();
//        DgcMappingTable dgcMappingTable = dgcMappingTableCache.get(projectId);
//
//        if (dgcMappingTable == null || dgcMappingTable.getId() == null || dgcMappingTable.getId() <= 0) {
//            return;
//        }
//
//        // 查询具体规则
//        Map<String, DgcDataRangeVO> ruleMap = dgcMappingRuleCache.get(dgcMappingTable.getId());
//        if (MapUtils.isEmpty(ruleMap) || ruleMap.containsKey(DgcMappingRuleCache.PLACEHOLDER)) {
//            return;
//        }
//
//        boolean dataError = false;
//        // 用于记录must=1但是实际没有值的label
//        List<String> emptyList = new ArrayList<>();
//        // 用于记录小于最小值的label
//        List<String> lessList = new ArrayList<>();
//        // 用于记录大于最大值的label
//        List<String> greaterList = new ArrayList<>();
//        for (Map.Entry<String, Object> entry : messageDTO.getData().entrySet()) {
//            String signalName = entry.getKey();
//            if (!ruleMap.containsKey(signalName)) {
//                continue;
//            }
//            DgcDataRangeVO dataRange = ruleMap.get(signalName);
//
//            if (entry.getValue() == null) {
//                if (dataRange.getMust() == 1) {
//                    dataError = true;
//                    emptyList.add(signalName);
//                }
//            } else {
//                try {
//                    double value = Double.parseDouble(String.valueOf(entry.getValue()));
//
//                    if (dataRange.getMin() != null && value < dataRange.getMin()) {
//                        dataError = true;
//                        lessList.add(signalName);
//                    }
//                    if (dataRange.getMax() != null && value > dataRange.getMax()) {
//                        dataError = true;
//                        greaterList.add(signalName);
//                    }
//                } catch (Exception e) {
//                    // 数值转化出错，数据可能是“-”，满偏值，是CCU填充的，当成正常数据处理
////                    if (dataRange.getMust() == 1) {
////                        dataError = true;
////                        emptyList.add(signalName);
////                    }
//                }
//            }
//        }
//
//        if (dataError) {
//            // 数据异常总量
//            // 使用原子操作 INCR 来自增键的值
//            stringRedisTemplate.opsForHash().increment(redisCountKey, "errorCount", 1L);
//
//            // 空值
//            String redisEmptyKey = "dataError_" + ccuId + "_" + createDay + "_empty";
//            hasKey = Boolean.TRUE.equals(stringRedisTemplate.hasKey(redisEmptyKey));
//            for (String signalName : emptyList) {
//                stringRedisTemplate.opsForHash().increment(redisEmptyKey, signalName, 1L);
//            }
//            if (!hasKey) {
//                stringRedisTemplate.expire(redisEmptyKey, timeout, TimeUnit.SECONDS);
//            }
//
//            // 小于最小值
//            String redisLessKey = "dataError_" + ccuId + "_" + createDay + "_less";
//            hasKey = Boolean.TRUE.equals(stringRedisTemplate.hasKey(redisLessKey));
//            for (String signalName : lessList) {
//                stringRedisTemplate.opsForHash().increment(redisLessKey, signalName, 1L);
//            }
//            if (!hasKey) {
//                stringRedisTemplate.expire(redisLessKey, timeout, TimeUnit.SECONDS);
//            }
//
//            // 大于最大值
//            String redisGreaterKey = "dataError_" + ccuId + "_" + createDay + "_greater";
//            hasKey = Boolean.TRUE.equals(stringRedisTemplate.hasKey(redisGreaterKey));
//            for (String signalName : greaterList) {
//                stringRedisTemplate.opsForHash().increment(redisGreaterKey, signalName, 1L);
//            }
//            if (!hasKey) {
//                stringRedisTemplate.expire(redisGreaterKey, timeout, TimeUnit.SECONDS);
//            }
//        }
//    }
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//        log.info("customCreateBean DataErrorConsumer success!");
//    }
//}
