package com.bosch.rbcd.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.data.pojo.entity.DataJumpRequest;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DataJumpRequestMapper extends BaseMapper<DataJumpRequest> {
}
