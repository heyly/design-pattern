package com.bosch.rbcd.data.pojo.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class VehicleDTO {

    private Long id;

    private String plateNumber;

    private Long deviceId;

    private LocalDateTime commissionTime;

    private String authorizationPath;

    private String name;

    private String vin;

    private String reportPath;

    private Integer deleted;

    private String fcpmCNumber;

    private String fuelType;

    private Long organizationId;

    private String model;

    private String vehicleNo;

    private String imei;
}
