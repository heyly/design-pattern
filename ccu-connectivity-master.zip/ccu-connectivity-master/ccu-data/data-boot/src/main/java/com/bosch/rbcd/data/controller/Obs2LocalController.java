package com.bosch.rbcd.data.controller;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.cronJob.ObsData2LocalTask;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname Obs2LocalController
 * @description TODO
 * @date 2023/6/9 12:43
 */
@RestController
@RequestMapping("/obs2Local")
@RequiredArgsConstructor
public class Obs2LocalController {

    private final ObsData2LocalTask obsData2LocalTask;

    @Value("${tableau.manualFolder:D:\\CCU_Data}")
    private String manualFolder;

    @Value("${eventData.manualFolder:D:\\CCU_Data}")
    private String manualEventFolder;

    @GetMapping("/manual/{dateRange}")
    Result<Object> manual(@PathVariable String dateRange,@RequestParam(required = false) String fleetName) {
        if (!dateRange.contains(",")) {
            return Result.failed("请传入正确的日期范围，例如20230601,20230608");
        }
        String[] dateArray = dateRange.split(",");
        Date startDay = DateUtil.parse(dateArray[0], DatePattern.PURE_DATE_PATTERN);
        Date endDay = DateUtil.parse(dateArray[1], DatePattern.PURE_DATE_PATTERN);
        List<DateTime> dateList = DateUtil.rangeToList(startDay, endDay, DateField.DAY_OF_MONTH);
        dateList.forEach(date -> {
            obsData2LocalTask.moveDayData(DateUtil.format(date, DatePattern.PURE_DATE_PATTERN), fleetName, manualFolder);
        });
        return Result.success();
    }

    @GetMapping("/someVehicle")
    Result<Object> someVehicle(@RequestParam("vehicles") String vehicles, @RequestParam("dateRange") String dateRange) {
        if (!dateRange.contains(",")) {
            return Result.failed("请传入正确的日期范围，例如20230601,20230608");
        }
        obsData2LocalTask.someVehicle(vehicles, dateRange, manualFolder);
        return Result.success();
    }

    @GetMapping("/manualEvent/{dateRange}")
    Result<Object> manualEvent(@PathVariable String dateRange, @RequestParam(required = false) String fleetName) {
        if (!dateRange.contains(",")) {
            return Result.failed("请传入正确的日期范围，例如20230601,20230608");
        }
        String[] dateArray = dateRange.split(",");
        Date startDay = DateUtil.parse(dateArray[0], DatePattern.PURE_DATE_PATTERN);
        Date endDay = DateUtil.parse(dateArray[1], DatePattern.PURE_DATE_PATTERN);
        List<DateTime> dateList = DateUtil.rangeToList(startDay, endDay, DateField.DAY_OF_MONTH);
        dateList.forEach(date -> {
            obsData2LocalTask.moveEventData(date, fleetName!=null?fleetName.split(","):null,manualEventFolder);
        });
        return Result.success();
    }

}
