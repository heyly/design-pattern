package com.bosch.rbcd.data.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.data.mapper.DgcMappingTableMapper;
import com.bosch.rbcd.data.pojo.entity.DgcMappingTable;
import com.bosch.rbcd.data.service.DgcMappingTableService;
import org.springframework.stereotype.Service;

@Service
public class DgcMappingTableServiceImpl extends ServiceImpl<DgcMappingTableMapper, DgcMappingTable> implements DgcMappingTableService {

}
