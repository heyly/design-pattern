//package com.bosch.rbcd.data.service;
//
//import com.bosch.rbcd.common.result.Result;
//import com.bosch.rbcd.data.dto.AverageDayMileageDTO;
//import com.bosch.rbcd.data.dto.VehicleMileageDTO;
//import com.bosch.rbcd.data.pojo.dto.VehicleMileageAndRuntimeDTO;
//import com.bosch.rbcd.monitor.pojo.query.DeviceInfoWebQuery;
//
//import java.util.List;
//import java.util.Map;
//
//public interface PrestoService {
//
//    List<VehicleMileageAndRuntimeDTO> listVehicleMileageAndRuntime(String day);
//
//    Integer getAllVehicleRunTime(DeviceInfoWebQuery query);
//
//
//    Integer getAllVehicleMileage(DeviceInfoWebQuery query);
//
//    List<VehicleMileageDTO> getTop10MileageVehicles(DeviceInfoWebQuery query);
//
//    List<AverageDayMileageDTO> getVehicle10DaysAverageMileage(DeviceInfoWebQuery query);
//
//    Result<Map<String,Integer>> getVehicleInfo(DeviceInfoWebQuery deviceInfoWebQuery);
//}
