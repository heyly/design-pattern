package com.bosch.rbcd.data.cache;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.fleet.api.ProjectFeignClient;
import com.bosch.rbcd.fleet.dto.ProjectDTO;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class ProjectInfoCache extends BaseLocalCache<Long, ProjectDTO> {

    @Autowired
    private ProjectFeignClient projectFeignClient;

    /**
     * 使用google guava缓存处理
     * key: projectId
     * value: projectInfo
     */
    private static final Cache<Long, ProjectDTO> cache;
    static {
        cache = CacheBuilder.newBuilder()
                .maximumSize(500)
                .expireAfterWrite(24, TimeUnit.HOURS) // 24小时过期
                .initialCapacity(100)
                .removalListener((RemovalListener<Long, ProjectDTO>) rn -> {
                    if (log.isDebugEnabled()) {
                        log.debug("ProjectInfoCache 被移除缓存 projectId = {}, projectInfo = {}", rn.getKey(), rn.getValue());
                    }
                }).build();
    }

    @Override
    public Cache<Long, ProjectDTO> getCache() {
        return cache;
    }

    @Override
    public ProjectDTO get(Long projectId) {
        if (projectId == null || projectId <= 0) {
            return null;
        }

        ProjectDTO projectInfo = getCache().getIfPresent(projectId);

        if (projectInfo == null) {
            Result<ProjectDTO> feignResult = projectFeignClient.queryById(projectId);
            if (feignResult != null && feignResult.getData() != null) {
                projectInfo = feignResult.getData();
            }

            // 防止缓存穿透
            if (projectInfo == null) {
                projectInfo = new ProjectDTO();
                projectInfo.setId(Long.MIN_VALUE);
            }

            getCache().put(projectId, projectInfo);
        }

        return projectInfo;
    }
}
