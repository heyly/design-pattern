package com.bosch.rbcd.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.mybatis.annotation.ProjectDataPermission;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuOnlineRecordVO;
import com.bosch.rbcd.data.query.CcuOnlineRecordFeignQuery;
import com.bosch.rbcd.data.vo.CcuOnlineRecordStatisticVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 车辆在线统计表(VehicleOnlineRecord)表数据库访问层
 *
 * @author wang bo
 * @since 2023-05-23 14:25:04
 */
@Mapper
public interface CcuOnlineRecordMapper extends BaseMapper<CcuOnlineRecord> {

    /**
     * 获取VehicleOnlineRecord分页列表
     *
     * @param page
     * @param queryParams 查询参数
     * @return
     */
    @ProjectDataPermission(projectAlias = "cor",projectIdField = "project_id")
    List<CcuOnlineRecordVO> listVehicleOnlineRecordPage(Page<CcuOnlineRecordVO> page, @Param("queryParams") CcuOnlineRecordPageQuery queryParams);

    List<Map<String, String>> listCcuAndVin(@Param("queryParams") CcuOnlineRecordPageQuery queryParams);

    List<Map<String, Object>> listDayOnlineCcu(@Param("queryParams") CcuOnlineRecordPageQuery queryParams);

    CcuOnlineRecord getOneAutoMf4Record(@Param("mf4projectIds") String[] mf4projectIds, @Param("creatingIdSet") Set<Object> creatingIdSet);

    List<String> listOnlineDate(@Param("queryParams") CcuOnlineRecordPageQuery queryParams);

    Long countVehicleOnlineDate(@Param("powertrainId") Long powertrainId);

    List<CcuOnlineRecordStatisticVO> statistics(@Param("projectIdList") List<Long> projectIdList, @Param("startTime") Date startTime, @Param("endTime") Date endTime);

    Long dataCount(CcuOnlineRecordFeignQuery query);
}

