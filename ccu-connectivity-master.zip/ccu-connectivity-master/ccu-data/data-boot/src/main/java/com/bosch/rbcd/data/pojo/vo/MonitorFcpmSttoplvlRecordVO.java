package com.bosch.rbcd.data.pojo.vo;

import cn.afterturn.easypoi.excel.annotation.Excel;
import cn.afterturn.easypoi.excel.annotation.ExcelIgnore;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 实时监控-FCPM: 监控发动机启停次数(MonitorFcpmSttoplvlRecord)视图对象
 *
 * @author wang bo
 * @since 2024-09-20 09:42:57
 */
@ApiModel("实时监控-FCPM: 监控发动机启停次数视图对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MonitorFcpmSttoplvlRecordVO {

    @ApiModelProperty("主键，唯一标识")
    @ExcelIgnore
    private Long id;

    @ApiModelProperty("ccu id")
    @ExcelIgnore
    private String ccuId;

    @ApiModelProperty("projectName")
    @Excel(name = "项目名称", width = 20)
    private String projectName;

    @ApiModelProperty("ccuNo")
    @Excel(name = "ccuNo", width = 15)
    private String ccuNo;

    @ApiModelProperty("车辆名称")
    @Excel(name = "车辆名称", width = 15)
    private String vehicleName;

    @ApiModelProperty("vin")
    @Excel(name = "vin", width = 20)
    private String vin;

    @ApiModelProperty("发动机编号")
    @Excel(name = "发动机编号", width = 20)
    private String engineNo;

    @ApiModelProperty("发生日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    @Excel(name = "监控日期", width = 20, format = "yyyy-MM-dd")
    private Date occurDate;

    @ApiModelProperty("day Count")
    @Excel(name = "Count", width = 5)
    private Integer dayCount;

    @ApiModelProperty("发动机启动时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    @Excel(name = "发动机启动时间", width = 20, format = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    @ApiModelProperty("发动机停止时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    @Excel(name = "发动机停止时间", width = 20, format = "yyyy-MM-dd HH:mm:ss")
    private Date stopTime;

}
