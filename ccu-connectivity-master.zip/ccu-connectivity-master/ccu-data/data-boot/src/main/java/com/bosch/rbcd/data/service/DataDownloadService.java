package com.bosch.rbcd.data.service;

import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;

import java.util.concurrent.Future;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname DataDownloadService
 * @description TODO
 * @date 2023/5/24 13:23
 */
public interface DataDownloadService {

    public Future<String> asyncClusterCsv(CcuOnlineRecord ccuOnlineRecord);

    Future<String> asyncClusterMf4(CcuOnlineRecord ccuOnlineRecord);
}
