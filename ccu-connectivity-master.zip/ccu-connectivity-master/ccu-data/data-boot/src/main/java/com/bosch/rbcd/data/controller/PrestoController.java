//package com.bosch.rbcd.data.controller;
//
//import com.bosch.rbcd.common.result.Result;
//import com.bosch.rbcd.data.dto.AverageDayMileageDTO;
//import com.bosch.rbcd.data.dto.VehicleMileageDTO;
//import com.bosch.rbcd.data.service.PrestoService;
//import com.bosch.rbcd.data.service.VehicleMileageRunningTimeService;
//import com.bosch.rbcd.monitor.pojo.query.DeviceInfoWebQuery;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//import lombok.RequiredArgsConstructor;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.List;
//
//@Api(tags = "presto相关接口")
//@RestController
//@RequestMapping("/presto")
//@RequiredArgsConstructor
//public class PrestoController {
//
//    private final PrestoService prestoService;
//
//    private final VehicleMileageRunningTimeService vehicleMileageRunningTimeService;
//
//    @PostMapping("/getVehicleInfo")
//    public Result getVehicleInfo(@RequestBody DeviceInfoWebQuery DeviceInfoWebQuery){
//        return  prestoService.getVehicleInfo(DeviceInfoWebQuery);
//    }
//
//    @ApiOperation("CCU采集总时长")
//    @PostMapping("/getAllVehicleRunTime")
//    public Result<Integer> getAllVehicleRunTime(@RequestBody DeviceInfoWebQuery deviceInfoWebQuery){
//        return Result.success(vehicleMileageRunningTimeService.getAllVehicleRunTime(deviceInfoWebQuery));
//    }
//
//    @ApiOperation("CCU采集总里程")
//    @PostMapping("/getAllVehicleMileage")
//    public Result<Integer> getAllVehicleMileage(@RequestBody DeviceInfoWebQuery deviceInfoWebQuery){
//        return Result.success(vehicleMileageRunningTimeService.getAllVehicleMileage(deviceInfoWebQuery));
//    }
//
//    @PostMapping("/getTop10MileageVehicles")
//    public Result getTop10MileageVehicles(@RequestBody DeviceInfoWebQuery DeviceInfoWebQuery){
//        List<VehicleMileageDTO> top10MileageVehicles = prestoService.getTop10MileageVehicles(DeviceInfoWebQuery);
//        return Result.success(top10MileageVehicles);
//    }
//
//    @PostMapping("/getVehicle10DaysAverageMileage")
//    public Result getVehicle10DaysAverageMileage(@RequestBody DeviceInfoWebQuery DeviceInfoWebQuery){
//        List<AverageDayMileageDTO> vehicle10DaysAverageMileage = prestoService.getVehicle10DaysAverageMileage(DeviceInfoWebQuery);
//        return Result.success(vehicle10DaysAverageMileage);
//    }
//}
