package com.bosch.rbcd.data.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * @author jichenglu
 * @create 2018-02-02 15:20
 **/
@Slf4j
@ConditionalOnProperty(prefix = "custom.kafka", name = {"createBean"}, havingValue = "true", matchIfMissing = false)
@Configuration
@EnableKafka
public class KafkaConsumerConfig implements InitializingBean {

    @Value("${custom.kafka.bootstrapServersConfig}")
    private String bootstrapServersConfig;

    @Value("${custom.kafka.sslTruststoreLocationConfig}")
    private String sslTruststoreLocationConfig;

    @Value("${custom.kafka.sslTruststorePasswordConfig}")
    private String sslTruststorePasswordConfig;

    @Value("${custom.kafka.saslJaasUsername}")
    private String saslJaasUsername;

    @Value("${custom.kafka.saslJaasUsernamePassword}")
    private String saslJaasUsernamePassword;

    @Value("${custom.kafka:dataErrorGroup}")
    private String kafkaTopic;

    @Value("${custom.kafka.concurrency:1}")
    private Integer concurrency;

    public ConsumerFactory<Integer, String> createConsumerFactory(String groupId) {
        return new DefaultKafkaConsumerFactory<>(createConsumerConfigs(groupId));
    }



    public Map<String, Object> createConsumerConfigs(String groupId) {
        Map<String, Object> configs = new HashMap<>();

        /**
         * 取消kerberos
         */
//        System.setProperty("java.security.krb5.conf", "/rbcd/ccu_collect/krb5.conf");
//        System.setProperty("java.security.auth.login.config", "/rbcd/ccu_collect/jaas.conf");
        configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServersConfig);
        configs.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        configs.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
        configs.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
        configs.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");
        configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
        configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
        configs.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "1000");
        configs.put("security.protocol",  "SASL_SSL");
        configs.put(SaslConfigs.SASL_MECHANISM, "SCRAM-SHA-512");
        configs.put(SaslConfigs.SASL_JAAS_CONFIG, "org.apache.kafka.common.security.scram.ScramLoginModule required username=\""+saslJaasUsername+"\" password=\""+saslJaasUsernamePassword+"\";");
        // configure the following three settings for SSL Encryption
        configs.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslTruststoreLocationConfig);
        configs.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,  sslTruststorePasswordConfig);
        // ssl.endpoint.identification.algorithm为证书域名校验开关，为空则表示关闭，这里需要保持关闭状态，必须设置为空。
        configs.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG,  "");
//        configs.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");


//        props.put("security.protocol", "SASL_PLAINTEXT");
//        props.put("sasl.kerberos.service.name", "kafka");
//        props.put("sasl.mechanism", "GSSAPI");



        /**
         * 二代平台连接
         */
//        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "node1:9092,node2:9092,node3:9092");
//        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
//        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
//        //设置使用最开始的offset偏移量为该group.id的最早。如果不设置，则会是latest即该topic最新一个消息的offset
//        //如果采用latest，消费者只能得道其启动后，生产者生产的消息
////	    props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
//        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
//        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");
//        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
//        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
//        //超时时间内最大消费数量 10000
//        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG,"10000");
        return configs;
    }

    @Bean(name = "dataErrorGroupFactory")
    public KafkaListenerContainerFactory<?> dataErrorGroupFactory() {
        ConcurrentKafkaListenerContainerFactory<Integer, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(createConsumerFactory(kafkaTopic));
        factory.setConcurrency(concurrency);
        factory.setBatchListener(true);//设置为批量消费，每个批次数量在Kafka配置参数中设置ConsumerConfig.MAX_POLL_RECORDS_CONFIG
        return factory;
    }

    @Bean(name = "dataMonitorGroupFactory")
    public KafkaListenerContainerFactory<?> dataMonitorGroupFactory() {
        ConcurrentKafkaListenerContainerFactory<Integer, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(createConsumerFactory("dataMonitorGroupFactory"));
        factory.setConcurrency(concurrency);
        factory.setBatchListener(true);//设置为批量消费，每个批次数量在Kafka配置参数中设置ConsumerConfig.MAX_POLL_RECORDS_CONFIG
        return factory;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("KafkaConsumerConfig bean create success!");
    }
}
