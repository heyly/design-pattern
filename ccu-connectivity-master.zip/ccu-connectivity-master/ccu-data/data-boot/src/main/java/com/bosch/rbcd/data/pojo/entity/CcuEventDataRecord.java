package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.bosch.rbcd.common.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * ccu事件触发高频数据记录(CcuEventDataRecord)实体类
 *
 * @author wang bo
 * @since 2023-09-23 09:46:01
 */
@ApiModel("ccu事件触发高频数据记录实体类")
@Data
@Accessors(chain=true)
public class CcuEventDataRecord extends BaseEntity {

    @ApiModelProperty("主键，唯一标识")
    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("ccu id")
    private String ccuId;

    @ApiModelProperty("车辆id")
    private Long vehicleId;

    @ApiModelProperty("can通道")
    private String canChannel;

    @ApiModelProperty("事件类型：1-换挡触发， 2-故障触发， 4-驾驶循环")
    private String eventType;

    @ApiModelProperty("事件时间，ms")
    private Date eventTime;

    @ApiModelProperty("故障等级")
    private String faultLevel;

    @ApiModelProperty("故障数量")
    private String errorCounter;

    @ApiModelProperty("obs文件路径")
    private String filePath;

}
