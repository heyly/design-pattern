package com.bosch.rbcd.data.pojo.query;


import com.bosch.rbcd.common.base.BasePageQuery;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * (DataDownloadRecord)分页查询对象
 *
 * @author makejava
 * @since 2022-09-01 13:02:37
 */
@ApiModel("")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataDownloadRecordPageQuery extends BasePageQuery {

    @ApiModelProperty("")
    private Long id;
    
    @ApiModelProperty("")
    private Long userId;
    
    @ApiModelProperty("")
    private String path;
    
    @ApiModelProperty("")
    private String name;
    
    @ApiModelProperty("1.单车 2.多车")
    private Integer type;
    
    @ApiModelProperty("")
    private Long organizationId;
    
    @ApiModelProperty("")
    private Long vehicleId;
    
    @ApiModelProperty("")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date beginAt;
    
    @ApiModelProperty("")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date endAt;
    
    @ApiModelProperty("")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date createAt;
    
    @ApiModelProperty("")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date updateAt;

    private Long[] vehicleIds;
    
}
