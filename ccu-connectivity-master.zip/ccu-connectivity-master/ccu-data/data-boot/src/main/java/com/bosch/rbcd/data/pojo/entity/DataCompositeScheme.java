package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

/**
 * (CompositeScheme)表实体类
 */
@Data
public class DataCompositeScheme {
    @TableId(type = IdType.AUTO)
    private Long id;

    //方案名称
    private String name;

    //1:瞬时 2:窗口
    private Integer type;

    //动力类型
    private String fuelType;

    //窗口大小
    private Integer windowSize;

    //创建人
    private String createBy;

}
