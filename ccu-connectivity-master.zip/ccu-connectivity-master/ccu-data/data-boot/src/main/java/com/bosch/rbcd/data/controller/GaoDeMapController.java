package com.bosch.rbcd.data.controller;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.service.GaoDeMapService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname GaoDeMapController
 * @description TODO
 * @date 2023/7/19 11:19
 */
@Api("平台地图接口")
@RestController
@RequestMapping("/map")
@RequiredArgsConstructor
public class GaoDeMapController {

    private final GaoDeMapService gaoDeMapService;

    @ApiOperation("根据经纬度获取位置")
    @GetMapping("/getCityByGps")
    Result<String> getCityByGps(@ApiParam("经度") @RequestParam String longitude, @ApiParam("纬度") @RequestParam String latitude) {
        return Result.success(gaoDeMapService.getCityByGps(longitude, latitude));
    }
}
