package com.bosch.rbcd.data.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.CcuDownloadRecord;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.pojo.query.CcuDownloadRecordPageQuery;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuDownloadRecordVO;

import java.util.List;

/**
 * 车辆数据下载用户记录表(VehicleDownloadUserRecord)表服务接口
 *
 * @author wang bo
 * @since 2023-05-23 14:28:42
 */
public interface CcuDownloadRecordService extends IService<CcuDownloadRecord> {

    /**
     * VehicleDownloadUserRecord 分页列表
     *
     * @param: queryParams 分页查询条件
     * @return: IPage<VehicleDownloadUserRecordVO>
     * @author: wang bo
     * @date: 2023-05-23 14:28:42
     */
    IPage<CcuDownloadRecordVO> listCcuDownloadRecordPage(CcuDownloadRecordPageQuery queryParams);

    /**
     * @Description: 记录单车日数据下载
     * @Param: [vehicleDownloadUserRecordVO]
     * @return: void
     * @Author: Wang Bo (BCSC-EPA2)
     * @Date: 2023/5/23
     */
    CcuDownloadRecordVO recordOneCcuDayUserDown(String fileType, CcuOnlineRecord ccuOnlineRecord, boolean asyncFlag) throws Exception;

    String downOneCcuDay(Long vehicleId, String onlineDate, String fileType);

    List<CcuDownloadRecordVO> batchDownload(CcuOnlineRecordPageQuery query);
}

