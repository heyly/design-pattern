package com.bosch.rbcd.data;

import com.alibaba.druid.spring.boot.autoconfigure.DruidDataSourceAutoConfigure;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;


@EnableFeignClients(basePackages = {"com.bosch.rbcd.device2.api", "com.bosch.rbcd.fleet.api"})
@EnableDiscoveryClient
@EnableScheduling
@EnableAsync
@SpringBootApplication(exclude = DruidDataSourceAutoConfigure.class)
public class  DataApplication {
    public static void main(String[] args) {
        SpringApplication.run(DataApplication.class, args);
    }
}
