package com.bosch.rbcd.data.pojo.dto;

import lombok.Data;

@Data
public class JsonAddressDTO {

    private String formatted_address;
}
