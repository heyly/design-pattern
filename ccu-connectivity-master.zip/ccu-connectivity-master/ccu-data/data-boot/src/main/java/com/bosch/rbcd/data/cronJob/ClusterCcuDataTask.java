package com.bosch.rbcd.data.cronJob;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.data.mapper.CcuOnlineRecordMapper;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.service.CcuOnlineRecordService;
import com.bosch.rbcd.data.service.DataDownloadService;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname ClusterVehicleDataTask
 * @description TODO
 * @date 2023/5/27 22:03
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ClusterCcuDataTask {
    private final DataDownloadService dataDownloadService;

    private final CcuOnlineRecordService ccuOnlineRecordService;

    private final CcuOnlineRecordMapper ccuOnlineRecordMapper;

    private final RedisUtils redisUtil;

    @Value("${autoMf4.projectId}")
    private String[] mf4projectIds;

    @XxlJob("autoClusterData")
    public void autoClusterData() {
        // 离线计算结束时间: 9点前
        Date workingTime = DateUtil.offsetHour(new Date(), 8);
        // 判断当前时间是否小于工作时间
        while (new Date().before(workingTime)) {
            LambdaQueryWrapper<CcuOnlineRecord> query =
                    new LambdaQueryWrapper<CcuOnlineRecord>().in(CcuOnlineRecord::getClusterFlag, 0, 2).lt(CcuOnlineRecord::getOnlineDate, DateUtil.format(new Date(),
                            DatePattern.PURE_DATE_PATTERN)).orderByDesc(CcuOnlineRecord::getOnlineDate, CcuOnlineRecord::getCcuNo).last("limit 1");
            CcuOnlineRecord onlineRecord = ccuOnlineRecordService.getOne(query);
            if (onlineRecord != null) {
                // 设置并更新聚合状态为-1，表明此记录正处于定时任务生成中
                onlineRecord.setClusterFlag(-1);
                ccuOnlineRecordService.updateById(onlineRecord);
                Future<String> syncCsvTask = dataDownloadService.asyncClusterCsv(onlineRecord);
                try {
                    syncCsvTask.get(4, TimeUnit.HOURS);
                } catch (Exception e) {
                    log.error("====自动聚合csv{}_{}失败====", onlineRecord.getCcuNo(), onlineRecord.getOnlineDate(), e);
                    ccuOnlineRecordService.updateById(onlineRecord);
                }
                log.info("====自动聚合csv{}_{}结束====", onlineRecord.getCcuNo(), onlineRecord.getOnlineDate());
            } else {
                // 若当前没有待聚合的在线记录，则终止定时任务运行。
                return;
            }
        }
    }


    @XxlJob("autoClusterHighRateData")
    public void autoClusterHighRateData() {
        // 获取参数
        String ccuNameParam = XxlJobHelper.getJobParam();
        if (StrUtil.isBlank(ccuNameParam)) {
            return;
        }
        LambdaQueryWrapper<CcuOnlineRecord> query =
                new LambdaQueryWrapper<CcuOnlineRecord>().isNull(CcuOnlineRecord::getMf4Path)
                        .in(CcuOnlineRecord::getCcuNo, StrUtil.split(ccuNameParam, ","))
                        .eq(CcuOnlineRecord::getOnlineDate, DateUtil.format(DateUtil.yesterday(), DatePattern.PURE_DATE_PATTERN))
                        .orderByDesc(CcuOnlineRecord::getOnlineDate, CcuOnlineRecord::getCcuNo);
        List<CcuOnlineRecord> onlineRecordList = ccuOnlineRecordService.list(query);
        if (CollectionUtil.isNotEmpty(onlineRecordList)) {
            for (CcuOnlineRecord onlineRecord : onlineRecordList) {
                Future<String> syncCsvTask = dataDownloadService.asyncClusterMf4(onlineRecord);
                try {
                    syncCsvTask.get(1, TimeUnit.HOURS);
                } catch (Exception e) {
                    log.error("====自动聚合{}_{}失败====", onlineRecord.getCcuNo(), onlineRecord.getOnlineDate(), e);
                }
                log.info("====自动聚合{}_{}结束====", onlineRecord.getCcuNo(), onlineRecord.getOnlineDate());
            }
        } else {
            // 若当前没有待聚合的高频在线记录，则终止定时任务运行。
            return;
        }
    }

    @XxlJob("autoClusterMf4Data")
    public void autoClusterMf4Data() {
        log.info("mf4 auto create start");
        // 离线计算结束时间: 8点前
        Date endDay = DateUtil.isAM(new Date()) ? new Date() : DateUtil.tomorrow();
        Date endTime = DateUtil.beginOfDay(endDay).offset(DateField.HOUR_OF_DAY, 8);

        // 判断当前时间是否小于工作时间
        while (new Date().before(endTime)) {
            String mf4CreatingSet = "autoMf4:creatingSet";
            Set<Object> creatingIdSet = redisUtil.sGet(mf4CreatingSet);
            CcuOnlineRecord onlineRecord = ccuOnlineRecordMapper.getOneAutoMf4Record(mf4projectIds, creatingIdSet);
            if (onlineRecord != null) {
                if (!redisUtil.sHasKey(mf4CreatingSet, onlineRecord.getId())) {
                    log.info("mf4_{}_{}_{}", onlineRecord.getCcuNo(), onlineRecord.getOnlineDate(), onlineRecord.getId());
                    redisUtil.sSet(mf4CreatingSet, onlineRecord.getId());
                    Future<String> syncCsvTask = dataDownloadService.asyncClusterMf4(onlineRecord);
                    try {
                        syncCsvTask.get(4, TimeUnit.HOURS);
                    } catch (Exception e) {
                        log.error("====自动聚合mf4{}_{}失败====", onlineRecord.getCcuNo(), onlineRecord.getOnlineDate(), e);
                    } finally {
                        redisUtil.setRemove(mf4CreatingSet, onlineRecord.getId());
                    }
                }
            } else {
                // 若当前没有待聚合的在线记录，则终止定时任务运行。
                return;
            }
        }
    }
}
