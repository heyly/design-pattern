package com.bosch.rbcd.data.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.data.mapper.DgcMappingRuleMapper;
import com.bosch.rbcd.data.pojo.entity.DgcMappingRule;
import com.bosch.rbcd.data.service.DgcMappingRuleService;
import org.springframework.stereotype.Service;

@Service
public class DgcMappingRuleServiceImpl extends ServiceImpl<DgcMappingRuleMapper, DgcMappingRule> implements DgcMappingRuleService {

}
