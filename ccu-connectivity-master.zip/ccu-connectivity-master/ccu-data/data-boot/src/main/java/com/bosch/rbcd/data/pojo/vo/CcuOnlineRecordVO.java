package com.bosch.rbcd.data.pojo.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 车辆在线统计表(VehicleOnlineRecord)视图对象
 *
 * @author wang bo
 * @since 2023-05-23 14:25:04
 */
@ApiModel("车辆在线统计表视图对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CcuOnlineRecordVO {

    @ApiModelProperty("主键，唯一标识")
    private Long id;

    @ApiModelProperty("ccuNo")
    private String ccuNo;

    @ApiModelProperty("ccuId")
    private String ccuId;

    @ApiModelProperty("shortSn")
    private String shortSn;

    @ApiModelProperty("vin")
    private String vin;

    @ApiModelProperty("车辆主键")
    private Long vehicleId;

    @ApiModelProperty("车辆名称")
    private String vehicleName;

    @ApiModelProperty("发动机编号")
    private String engineNo;

    @ApiModelProperty("在线日期yyyymmdd")
    private String onlineDate;

    @ApiModelProperty("0:非聚合数据,1:聚合数据")
    private Integer clusterFlag;

    @ApiModelProperty("csv文件路径")
    private String csvPath;

    @ApiModelProperty("mf4文件路径")
    private String mf4Path;

    @ApiModelProperty("数据采集配置,逗号分隔")
    private String configId;

    @ApiModelProperty("数据总数")
    private int dataCount;

    @ApiModelProperty("创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    private Date createTime;

    @ApiModelProperty("修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8:00")
    private Date updateTime;
}
