package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("quality_data_jump_detail")
public class DataJumpDetail {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long requestId;

    private String label;

    private String correctValue;

    private String jumpValue;

    private String preTime;

    private String curTime;

    private String nextTime;
}
