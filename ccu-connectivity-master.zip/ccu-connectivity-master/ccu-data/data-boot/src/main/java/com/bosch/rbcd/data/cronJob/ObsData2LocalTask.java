package com.bosch.rbcd.data.cronJob;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.common.huawei.util.ObsUtil;
import com.bosch.rbcd.data.mapper.CcuEventDataRecordMapper;
import com.bosch.rbcd.data.mapper.CcuOnlineRecordMapper;
import com.bosch.rbcd.data.pojo.entity.CcuEventDataRecord;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuOnlineRecordVO;
import com.bosch.rbcd.data.service.CcuOnlineRecordService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname RemoveDataTask
 * @description csv数据搬迁服务
 * @date 2023/6/8 14:20
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ObsData2LocalTask {

    @Value("${obs.cluster-bucket}")
    private String clusterBucket;

    @Value("${tableau.autoFolder:}")
    private String autoFolder;

    @Value("${tableau.fleets:}")
    private String[] fleetNameList;

    @Value("${eventData.folder:}")
    private String eventDataFolder;

    @Value("${eventData.fleets:}")
    private String[] eventFleetNames;

    @Value("${eventData.eventTypes:}")
    private String[] eventTypes;


    private final ObsUtil obsUtil;

    private final static String defaultBucketName = "rbcd-filestorage";

    private final CcuOnlineRecordService ccuOnlineRecordService;
    private final CcuOnlineRecordMapper ccuOnlineRecordMapper;

    private final CcuEventDataRecordMapper ccuEventDataRecordMapper;

//    @Scheduled(cron = "${scheduled.expression}")
    public void moveToLocal() {
        String yesterday = DateUtil.format(DateUtil.yesterday(), DatePattern.PURE_DATE_PATTERN);
        moveDayData(yesterday, null, autoFolder);
    }

    public void moveDayData(String date, String fleetNames, String targetFolder) {
        if (fleetNameList.length == 0) {
            return;
        }
        log.info("====OBS搬迁日期：" + date);

        String[] fleetList = fleetNameList;
        if (StrUtil.isNotBlank(fleetNames)) {
            fleetList = fleetNames.split(",");
        }
        // 获取待搬迁所有的vehicleId
        for (String fleetName : fleetList) {
            try {
                String localFleetFolder = targetFolder + File.separator + fleetName;
                if (!FileUtil.exist(localFleetFolder)) {
                    FileUtil.mkdir(localFleetFolder);
                }
                File localFleetFile = new File(localFleetFolder);
                List<CcuOnlineRecord> clusterVehicleOnlineRecord =
                        ccuOnlineRecordService.list(new LambdaQueryWrapper<CcuOnlineRecord>().eq(CcuOnlineRecord::getOnlineDate, date).eq(CcuOnlineRecord::getClusterFlag, 1).like(CcuOnlineRecord::getCcuNo, fleetName));

                String localFleetYesterdayFolder = localFleetFolder + File.separator + date;
                if (!FileUtil.exist(localFleetFolder)) {
                    FileUtil.mkdir(localFleetFolder);
                }
                List<String> csvObsList = clusterVehicleOnlineRecord.stream().map(CcuOnlineRecord::getCsvPath).collect(Collectors.toList());
                if (CollectionUtil.isNotEmpty(csvObsList)) {
                    obsUtil.batchDownload(clusterBucket, localFleetYesterdayFolder, csvObsList, true, true);
                    FileUtil.loopFiles(localFleetYesterdayFolder).forEach(csvFile -> {
                        try {
                            List<String> csvNameInfo = StrUtil.split(FileUtil.mainName(csvFile), "_");
                            String configId = CollectionUtil.getLast(csvNameInfo);
                            String vehicleName = csvNameInfo.stream().filter(s -> s.startsWith(fleetName)).findFirst().orElse("");
                            String newCsvName = csvFile.getParent() + File.separator + StrUtil.join("_", vehicleName, date, configId);
                            File newFile = FileUtil.rename(csvFile, newCsvName, true, true);
                            FileUtil.move(newFile, localFleetFile, true);
                        } catch (Exception e) {
                            log.warn("移动文件失败{}", csvFile.getName(), e);
                        }
                    });
                    FileUtil.del(localFleetYesterdayFolder);
                }
            } catch (Exception e) {
                log.warn("车队下载文件失败{}", fleetName, e);
            }
        }
    }

    public void someVehicle(String vehicles, String dateRange, String manualFolder) {
        CcuOnlineRecordPageQuery queryParams = new CcuOnlineRecordPageQuery();
        queryParams.setCcuNoList(new HashSet<>(StrUtil.split(vehicles, ",")));
        queryParams.setStartTime(DateUtil.parse(dateRange.split(",")[0]));
        queryParams.setEndTime(DateUtil.parse(dateRange.split(",")[1]));
        List<CcuOnlineRecordVO> onlineRecords = ccuOnlineRecordMapper.listVehicleOnlineRecordPage(null, queryParams);
        String localFleetYesterdayFolder = manualFolder + File.separator + DateUtil.format(new Date(), DatePattern.PURE_DATETIME_FORMAT);
        if (!FileUtil.exist(localFleetYesterdayFolder)) {
            FileUtil.mkdir(localFleetYesterdayFolder);
        }
        List<String> csvObsList = onlineRecords.stream().map(CcuOnlineRecordVO::getCsvPath).collect(Collectors.toList());
        // 获取待搬迁所有的vehicleId

        if (CollectionUtil.isNotEmpty(csvObsList)) {
            obsUtil.batchDownload(clusterBucket, localFleetYesterdayFolder, csvObsList, true, true);
            FileUtil.loopFiles(localFleetYesterdayFolder).forEach(csvFile -> {
                List<String> csvNameInfo = StrUtil.split(FileUtil.mainName(csvFile), "_");
                String configId = CollectionUtil.getLast(csvNameInfo);
                String vehicleName = csvNameInfo.stream().filter(vehicles::contains).findFirst().orElse("");
                String date = csvNameInfo.stream().filter(s -> s.startsWith("20")).findFirst().orElse("");
                csvNameInfo.remove(1);
                String newCsvName = csvFile.getParent() + File.separator + StrUtil.join("_", vehicleName, date, configId);
                File newFile = FileUtil.rename(csvFile, newCsvName, true, true);
                FileUtil.move(newFile, new File(manualFolder), true);
            });
            FileUtil.del(localFleetYesterdayFolder);
        }
    }

    //        @Scheduled(cron = "0 0 4 ? * *")
    public void moveEventDataTask() {
        Date yesterday = DateUtil.yesterday();
        moveEventData(yesterday, eventFleetNames, eventDataFolder);
    }

    public void moveEventData(Date date, String[] eventFleets, String manualEventFolder) {
        if (eventFleets == null) {
            eventFleets = eventFleetNames;
        }
        if (StrUtil.isBlank(manualEventFolder)) {
            manualEventFolder = eventDataFolder;
        }
        for (String fleetName : eventFleets) {
            for (String eventType : eventTypes) {
                String eventTypeFolder = "default";
                switch (eventType) {
                    case "1":
                        eventTypeFolder = "Shift";
                        break;
                    case "2":
                        eventTypeFolder = "Fault";
                        break;
                    case "4":
                        eventTypeFolder = "Cycle";
                        break;
                }
                String localFleetFolder = manualEventFolder + File.separator + fleetName + File.separator + eventTypeFolder;
                String localFleetYesterdayFolder = localFleetFolder + File.separator + DateUtil.format(date, DatePattern.PURE_DATE_PATTERN);
                List<CcuEventDataRecord> eventDataList = ccuEventDataRecordMapper.selectList(new LambdaQueryWrapper<CcuEventDataRecord>().like(CcuEventDataRecord::getFilePath,
                        fleetName).eq(CcuEventDataRecord::getEventType, eventType).gt(CcuEventDataRecord::getEventTime, DateUtil.beginOfDay(date)).lt(CcuEventDataRecord::getEventTime, DateUtil.endOfDay(date)));
                if (CollectionUtil.isEmpty(eventDataList)) {
                    continue;
                }
                List<String> csvObsList = eventDataList.stream().map(CcuEventDataRecord::getFilePath).collect(Collectors.toList());
                if (CollectionUtil.isNotEmpty(csvObsList)) {
                    obsUtil.batchDownload(defaultBucketName, localFleetYesterdayFolder, csvObsList, true, true);
                    FileUtil.loopFiles(localFleetYesterdayFolder).forEach(csvFile -> {
//                        List<String> csvNameInfo = StrUtil.split(FileUtil.mainName(csvFile), "_");
//                        String configId = CollectionUtil.getLast(csvNameInfo);
//                        String vehicleName = csvNameInfo.stream().filter(vehicles::contains).findFirst().orElse("");
//                        String date = csvNameInfo.stream().filter(s -> s.startsWith("20")).findFirst().orElse("");
//                        csvNameInfo.remove(1);
//                        String newCsvName = csvFile.getParent() + File.separator + StrUtil.join("_", vehicleName, date, configId);
//                        File newFile = FileUtil.rename(csvFile, newCsvName, true, true);
                        FileUtil.move(csvFile, new File(localFleetFolder), true);
                    });
                    FileUtil.del(localFleetYesterdayFolder);
                }
            }
        }
    }

}
