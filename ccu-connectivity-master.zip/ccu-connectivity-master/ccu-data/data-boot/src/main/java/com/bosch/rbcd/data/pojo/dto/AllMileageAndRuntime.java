package com.bosch.rbcd.data.pojo.dto;

import lombok.Data;

@Data
public class AllMileageAndRuntime {

    private Double allMileage;

    private Double allRuntime;
}
