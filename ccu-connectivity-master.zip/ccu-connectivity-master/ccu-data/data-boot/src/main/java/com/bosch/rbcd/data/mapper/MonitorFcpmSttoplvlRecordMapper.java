package com.bosch.rbcd.data.mapper;

import java.util.Date;
import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Mapper;
import com.bosch.rbcd.data.pojo.entity.MonitorFcpmSttoplvlRecord;
import com.bosch.rbcd.data.pojo.query.MonitorFcpmSttoplvlRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.MonitorFcpmSttoplvlRecordVO;

/**
 * 实时监控-FCPM: 监控发动机启停次数(MonitorFcpmSttoplvlRecord)表数据库访问层
 *
 * @author wang bo
 * @since 2024-09-20 09:42:57
 */
@Mapper
public interface MonitorFcpmSttoplvlRecordMapper extends BaseMapper<MonitorFcpmSttoplvlRecord> {

    /**
     * 获取MonitorFcpmSttoplvlRecord分页列表
     *
     * @param page
     * @param queryParams 查询参数
     * @return
     */
    List<MonitorFcpmSttoplvlRecordVO> listMonitorFcpmSttoplvlRecordPage(Page<MonitorFcpmSttoplvlRecordVO> page, @Param("queryParams") MonitorFcpmSttoplvlRecordPageQuery queryParams);

    List<MonitorFcpmSttoplvlRecord> getCcuCountMap(@Param("ccuIds") List<String> ccuIds, @Param("date") Date date);
}

