package com.bosch.rbcd.data.pojo.dto;

import lombok.Data;

@Data
public class VehicleMileageAndRuntimeDTO {

    private String name;

    private Double distance;

    private Double runTime;
}
