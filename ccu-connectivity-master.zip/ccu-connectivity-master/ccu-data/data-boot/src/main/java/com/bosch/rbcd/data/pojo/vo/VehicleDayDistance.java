package com.bosch.rbcd.data.pojo.vo;

import lombok.Data;

@Data
public class VehicleDayDistance {

    private String name;

    private String day;

    private Double distance;
}
