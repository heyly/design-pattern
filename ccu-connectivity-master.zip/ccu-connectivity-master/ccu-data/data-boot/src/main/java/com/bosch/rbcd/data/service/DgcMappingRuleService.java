package com.bosch.rbcd.data.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.DgcMappingRule;

public interface DgcMappingRuleService extends IService<DgcMappingRule> {

}
