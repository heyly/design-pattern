package com.bosch.rbcd.data.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 实时监控-FCPM: 监控发动机启停次数(MonitorFcpmSttoplvlRecord)分页查询对象
 *
 * @author wang bo
 * @since 2024-09-20 09:42:57
 */
@ApiModel("实时监控-FCPM: 监控发动机启停次数分页查询对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MonitorFcpmSttoplvlRecordPageQuery extends BasePageQuery {

    @ApiModelProperty("主键，唯一标识")
    private Long id;

    @ApiModelProperty("ccu id")
    private String ccuId;

    @ApiModelProperty("发生日期")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8:00")
    private Date occurDate;

    @ApiModelProperty("发动机开始时间")
    private Date startTime;

    @ApiModelProperty("发动机停止时间")
    private Date stopTime;

}
