package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

@Data
@TableName("vehicle_mileage_runningtime")
public class VehicleMileageRunningTime {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String ccuId;

    private String ccuNo;

    /**
     * 截至日期的总运行里程
     */
    private Double totalMileage;

    /**
     * 截至日期的总运行时间
     */
    private Double totalRuntime;

    /**
     * 截至日期的当日里程
     */
    private Double todayMileage;

    /**
     * 截至日期的当日时间
     */
    private Double todayRuntime;

    /**
     * 计算日期
     */
    private Date day;

    /**
     * 车辆运行日期
     */
    private Date runningDate;

}
