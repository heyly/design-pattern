package com.bosch.rbcd.data.cache;

import com.google.common.cache.Cache;
import org.apache.commons.collections.CollectionUtils;

import java.util.List;
import java.util.Objects;

public abstract class BaseLocalCache<K, V> {

    public abstract Cache<K, V> getCache();

    public boolean isExist(K key) {
        if (key == null) {
            return false;
        }
        return !Objects.isNull(getCache().getIfPresent(key));
    }

    /**
     * 获取缓存
     *
     * @param key
     * @return
     */
    public V get(K key) {
        if (key == null) {
            return null;
        }
        return getCache().getIfPresent(key);
    }

    /**
     * 放入缓存
     *
     * @param key
     * @param value
     */
    public void put(K key, V value) {
        if (key != null && value != null) {
            getCache().put(key, value);
        }
    }

    /**
     * 移除缓存
     *
     * @param key
     */
    public void remove(K key) {
        if (key != null) {
            getCache().invalidate(key);
        }
    }

    /**
     * 批量删除缓存
     *
     * @param keys
     */
    public void removeBatch(List<Long> keys) {
        if (CollectionUtils.isNotEmpty(keys)) {
            getCache().invalidateAll(keys);
        }
    }
}
