package com.bosch.rbcd.data.service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.CcuEventDataRecord;
import com.bosch.rbcd.data.pojo.query.CcuEventDataRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuEventDataRecordVO;

/**
 * ccu事件触发高频数据记录(CcuEventDataRecord)表服务接口
 *
 * @author wang bo
 * @since 2023-09-23 09:46:01
 */
public interface CcuEventDataRecordService extends IService<CcuEventDataRecord> {

    /**
     * CcuEventDataRecord 分页列表
     *
     * @param: queryParams 分页查询条件
     * @return: IPage<CcuEventDataRecordVO>
     * @author: wang bo
     * @date: 2023-09-23 09:46:01
     */
    IPage<CcuEventDataRecordVO> listCcuEventDataRecordPage(CcuEventDataRecordPageQuery queryParams);

    void recordEventData(JSONObject ccuEventDataJson);
}

