package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("dgc_mapping_table_1031")
public class DgcMappingTable {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 分组或项目对应hive库名称
     */
    @TableField("database_name")
    private String databaseName;

    /**
     * 分组或项目对应dgc底表名称
     */
    @TableField("table_name")
    private String tableName;


    /**
     * 动力总成类型
     */
    @TableField("power_train_id")
    private String powerTrainId;

    /**
     * 项目id
     */
    @TableField("project_id")
    private Long projectId;

    @TableField("product_id")
    private Long productId;
}
