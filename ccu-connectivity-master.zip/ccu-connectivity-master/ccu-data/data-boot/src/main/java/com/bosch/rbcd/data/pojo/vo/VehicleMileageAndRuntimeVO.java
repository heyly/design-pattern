package com.bosch.rbcd.data.pojo.vo;

import lombok.Data;

@Data
public class VehicleMileageAndRuntimeVO {

    private String name;

    private Double mileage;

    private Double runtime;
}
