//package com.bosch.rbcd.data.controller;
//
//import com.bosch.rbcd.common.huawei.util.ObsUtil;
//import com.bosch.rbcd.common.result.Result;
//import com.bosch.rbcd.common.result.ResultCode;
//import com.bosch.rbcd.common.web.exception.BizException;
//import com.bosch.rbcd.data.service.IFileService;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//import io.swagger.annotations.ApiParam;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStream;
//
//@Api(tags = "文件相关接口")
//@RequestMapping("/file")
//@RestController
//@RequiredArgsConstructor
//@Slf4j
//public class FileController {
//
//    private final ObsUtil obsUtil;
//
//    private final IFileService iFileService;
//
//    @Value("${obs.cluster-bucket}")
//    private String clusterBucket;
//
//    @GetMapping("/download")
//    public void fileDownload(String filePath, HttpServletResponse response) {
//        try {
//            response.setCharacterEncoding("utf-8");
//            response.setContentType("multipart/form-data");
//            response.setHeader("Content-Disposition", "attachment;fileName=" + new String(filePath.substring(filePath.lastIndexOf("/") + 1).getBytes("GBK"), "ISO8859-1"));
//            InputStream inputStream;
//            if (obsUtil.isExisted(filePath)) {
//                inputStream = obsUtil.getFileInputStream(null, filePath);
//                OutputStream os = response.getOutputStream();
//                byte[] b = new byte[1024 * 1024];
//                int length;
//                while ((length = inputStream.read(b)) != -1) {
//                    os.write(b, 0, length);
//                }
//                inputStream.close();
//                os.close();
//            } else {
//                throw new BizException(ResultCode.DOWNLOAD_FILE_FAILED);
//            }
//
//        } catch (IOException e) {
//            throw new BizException(ResultCode.DOWNLOAD_FILE_FAILED);
//        }
//    }
//
//    @ApiOperation(value = "将csv/zip转换成MF4文件")
//    @GetMapping("/getMF4File")
//    public Result<Object> getMF4File(@ApiParam("桶名称 低频数据： iov-cluster-data  高频数据: rbcd-filestorage")  @RequestParam("bucketName") String bucketName,
//                                     @ApiParam("csv/zip路径")  @RequestParam("obsUrl") String obsUrl) throws Exception {
//        String mf4Url = iFileService.getMf4File(bucketName, obsUrl);
//        if (!mf4Url.isEmpty()) {
//            mf4Url = obsUtil.getFileUrl(bucketName, mf4Url);
//        }
//        return Result.success(mf4Url);
//    }
//
//    @ApiOperation(value = "将csv文件目录转换mf4文件目录")
//    @GetMapping("/convertFolderToMf4")
//    public Result<String> convertFolderToMf4(@ApiParam(value = "源文件目录") @RequestParam("sourceFolder") String sourceFolder,
//                                             @ApiParam(value = "源文件目录") @RequestParam("targetFolder") String targetFolder) {
//        String mf4Url = iFileService.convertFolderToMf4(sourceFolder, targetFolder);
//        return Result.success(mf4Url);
//    }
//
//    @ApiOperation("签名obs文件地址")
//    @GetMapping("/signObsFile")
//    public Result<String> signObsFile(@ApiParam("桶名称 低频数据： iov-cluster-data  高频数据: rbcd-filestorage ") @RequestParam("bucketName") String bucketName,
//                                            @ApiParam("csv/zip路径") @RequestParam String objectName) throws Exception {
//        return Result.success(obsUtil.getFileUrl(bucketName, objectName));
//    }
//
//}
