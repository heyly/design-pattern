package com.bosch.rbcd.data.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix="system")
public class SystemConfig {

    private String env;

    private String filePath;

    private String pythonPath;

    public final static String TOKEN = "X-boschrbcd-Token";

}
