package com.bosch.rbcd.data.service;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bosch.rbcd.data.pojo.entity.MonitorFcpmSttoplvlRecord;
import com.bosch.rbcd.data.pojo.query.MonitorFcpmSttoplvlRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.MonitorFcpmSttoplvlRecordVO;
import org.apache.poi.ss.usermodel.Workbook;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 实时监控-FCPM: 监控发动机启停次数(MonitorFcpmSttoplvlRecord)表服务接口
 *
 * @author wang bo
 * @since 2024-09-20 09:42:57
 */
public interface MonitorFcpmSttoplvlRecordService extends IService<MonitorFcpmSttoplvlRecord> {

    /**
     * MonitorFcpmSttoplvlRecord 分页列表
     *
     * @param: queryParams 分页查询条件
     * @return: IPage<MonitorFcpmSttoplvlRecordVO>
     * @author: wang bo
     * @date: 2024-09-20 09:42:57
     */
    IPage<MonitorFcpmSttoplvlRecordVO> listMonitorFcpmSttoplvlRecordPage(MonitorFcpmSttoplvlRecordPageQuery queryParams);

    Workbook generateExcel(MonitorFcpmSttoplvlRecordPageQuery query);

    void sendFcpmStTopLvMail(String ccuId, Date dataTime);

    Map<String, Integer> getCcuCountMap(List<String> ccuIds);
}

