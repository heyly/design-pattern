package com.bosch.rbcd.data.pojo.query;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class HistoryLocationQuery {

    private String ccuId;

    @ApiModelProperty("日期范围，如：20230220,20230220")
    private String dateRange;

    @ApiModelProperty("时间范围，如：00:00:00,23:59:59")
    private String timeRange;

}
