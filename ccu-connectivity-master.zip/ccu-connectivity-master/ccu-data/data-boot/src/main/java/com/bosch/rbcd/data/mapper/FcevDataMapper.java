package com.bosch.rbcd.data.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.data.dto.AverageDayMileageDTO;
import com.bosch.rbcd.data.dto.VehicleMileageDTO;
import com.bosch.rbcd.data.pojo.dto.VehicleMileageAndRuntimeDTO;
import com.bosch.rbcd.data.pojo.entity.presto.FcevData;
import com.bosch.rbcd.data.pojo.vo.VehicleDayDistance;
import com.bosch.rbcd.data.pojo.vo.VehicleDayRuntime;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@Mapper
@DS("presto")
public interface FcevDataMapper extends BaseMapper<FcevData> {
    @Select("${sql}")
    List<Map<String, Object>> queryBySql(@Param("sql") String sql);

    @Select("${sql}")
    Integer count(@Param("sql") String sql);

    @Select("${sql}")
    List<VehicleDayRuntime> listDayVehicleRunTime(@Param("sql") String sql);

    @Select("${sql}")
    List<VehicleDayDistance> listDayVehicleDistance(@Param("sql") String sql);

    List<VehicleMileageAndRuntimeDTO> listVehicleMileageAndRuntime(@Param("sql")String sql);

    Double getAllVehicleRunTime(@Param("sql") String sql);

    Double getAllVehicleMileage(@Param("sql") String sql);

    List<VehicleMileageDTO> getTop10MileageVehicles(@Param("sql") String sql);

    List<AverageDayMileageDTO> getVehicle10DaysAverageMileage(@Param("sql") String sql);


    String getLastDay(String dayQuery);
}
