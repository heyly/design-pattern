package com.bosch.rbcd.data.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.data.mapper.CcuOnlineRecordMapper;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuOnlineRecordVO;
import com.bosch.rbcd.data.service.CcuOnlineRecordService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * ccu在线统计表(CcuOnlineRecord)表服务实现类
 *
 * @author wang bo
 * @since 2023-05-23 14:25:04
 */
@Slf4j
@Service("vehicleOnlineRecordService")
@RequiredArgsConstructor
public class CcuOnlineRecordServiceImpl extends ServiceImpl<CcuOnlineRecordMapper, CcuOnlineRecord> implements CcuOnlineRecordService {

    @Override
    public IPage<CcuOnlineRecordVO> listVehicleOnlineRecordPage(CcuOnlineRecordPageQuery queryParams) {
        // 校验账号下有权限的项目
        Page<CcuOnlineRecordVO> page = new Page<>(queryParams.getPageNum(), queryParams.getPageSize());
//        if (CollectionUtil.isEmpty(queryParams.getProjectIdList())) {
//            List<Long> projectIdList = projectFeignClient.getProjectIdByUser(UserUtils.getUserId()).getData();
//            queryParams.setProjectIdList(projectIdList);
//        }
        page.setOrders(queryParams.getOrders());
        List<CcuOnlineRecordVO> list = this.baseMapper.listVehicleOnlineRecordPage(page, queryParams);
        page.setRecords(list);
        return page;
    }


    @Override
    public CcuOnlineRecordPageQuery getQueryParam(CcuOnlineRecordPageQuery query) {
        CcuOnlineRecordPageQuery queryInput = new CcuOnlineRecordPageQuery();
        // 获取动态结果列表
        List<Map<String, String>> vehicleAndVinList = this.baseMapper.listCcuAndVin(query);
        if (CollectionUtil.isNotEmpty(vehicleAndVinList)) {
            Set<String> vehicleNameSet = vehicleAndVinList.stream().map(m -> m.get("ccuNo")).sorted().collect(Collectors.toSet());
            queryInput.setCcuNoList(vehicleNameSet);
            Set<String> vinSet = vehicleAndVinList.stream().map(m -> m.get("vin")).sorted().collect(Collectors.toSet());
        }
        return queryInput;
    }

    @Override
    public List<String> listOnlineDate(CcuOnlineRecordPageQuery queryParams) {
        return this.baseMapper.listOnlineDate(queryParams);
    }


}

