package com.bosch.rbcd.data.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.common.huawei.util.ObsUtil;
import com.bosch.rbcd.data.mapper.CcuEventDataRecordMapper;
import com.bosch.rbcd.data.pojo.entity.CcuEventDataRecord;
import com.bosch.rbcd.data.pojo.query.CcuEventDataRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.CcuEventDataRecordVO;
import com.bosch.rbcd.data.service.CcuEventDataRecordService;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import com.bosch.rbcd.fleet.api.VehicleFeignClient;
import com.bosch.rbcd.fleet.dto.VehicleDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

/**
 * ccu事件触发高频数据记录(CcuEventDataRecord)表服务实现类
 *
 * @author wang bo
 * @since 2023-09-23 09:46:01
 */
@Service("ccuEventDataRecordService")
@RequiredArgsConstructor
public class CcuEventDataRecordServiceImpl extends ServiceImpl<CcuEventDataRecordMapper, CcuEventDataRecord> implements CcuEventDataRecordService {
    private final ObsUtil obsUtil;
    private final DeviceInfoFeignClient deviceInfoFeignClient;
    private final VehicleFeignClient vehicleFeignClient;

    @Value("${obs.obsName:rbcd-filestorage}")
    private String defaultBucket;

    @Override
    public IPage<CcuEventDataRecordVO> listCcuEventDataRecordPage(CcuEventDataRecordPageQuery queryParams) {
        Page<CcuEventDataRecordVO> page = new Page<>(queryParams.getPageNum(), queryParams.getPageSize());
//        if (CollectionUtil.isEmpty(queryParams.getProjectIdList())) {
//            List<Long> projectIdList = projectFeignClient.getProjectIdByUser(UserUtils.getUserId()).getData();
//            queryParams.setProjectIdList(new HashSet<>(projectIdList));
//        }
        if (CollectionUtil.isNotEmpty(queryParams.getProjectIdList())) {
            if (CollectionUtil.isNotEmpty(queryParams.getOrders())) {
                page.setOrders(queryParams.getOrders());
            } else {
                page.setOrders(Collections.singletonList(OrderItem.desc("cedr.event_time")));
            }
            List<CcuEventDataRecordVO> list = this.baseMapper.listCcuEventDataRecordPage(page, queryParams);
            page.setRecords(list);
        }
        return page;
    }

    @Override
    public void recordEventData(JSONObject ccuEventDataJson) {
        String imei = ccuEventDataJson.getString("device");
        ProjectVehicleCcuDTO ccuDevice = deviceInfoFeignClient.findByImei(imei).getData();
        if (ccuDevice != null) {
            CcuEventDataRecord ccuEventDataRecord = new CcuEventDataRecord();
            ccuEventDataRecord.setCcuId(ccuDevice.getCcuId());
            ccuEventDataRecord.setCanChannel(ccuEventDataJson.getString("canChannel"));
            ccuEventDataRecord.setEventType(ccuEventDataJson.getString("eventType"));
            Long timestamp = ccuEventDataJson.getLong("timestamp");
            ccuEventDataRecord.setEventTime(DateUtil.date(timestamp));
            ccuEventDataRecord.setFaultLevel(ccuEventDataJson.getString("faultLevel"));
            ccuEventDataRecord.setErrorCounter(ccuEventDataJson.getString("errorCounter"));
            VehicleDTO vehicle = vehicleFeignClient.queryVehicleByCcuId(ccuDevice.getCcuId()).getData();
            String vin = "";
            if (vehicle != null) {
                ccuEventDataRecord.setVehicleId(vehicle.getId());
                vin = vehicle.getVin();
            }
            String filePath = ccuEventDataJson.getString("filePath");
            String newFileName = StrUtil.format("{}/{}_{}_{}.csv.gz", StrUtil.subBefore(filePath, "/", true), ccuDevice.getCcuNo(), vin,
                    DateUtil.format(ccuEventDataRecord.getEventTime(), DatePattern.PURE_DATETIME_PATTERN));
            // 事件触发数据文件重命名
            if (StrUtil.isNotBlank(filePath) && obsUtil.isExisted(defaultBucket, filePath)) {
                obsUtil.renameObject(defaultBucket, filePath, newFileName);
            }
            // 文件存在才能入库
            if (obsUtil.isExisted(defaultBucket, newFileName)) {
                ccuEventDataRecord.setFilePath(newFileName);
                this.save(ccuEventDataRecord);
            }
        }
    }
}

