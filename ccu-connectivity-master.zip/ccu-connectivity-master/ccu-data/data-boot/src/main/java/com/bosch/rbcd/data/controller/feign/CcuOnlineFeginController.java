package com.bosch.rbcd.data.controller.feign;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.dto.OnlineCountDTO;
import com.bosch.rbcd.data.dto.VehicleMileageRunningTimeQuery;
import com.bosch.rbcd.data.mapper.CcuOnlineRecordMapper;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.pojo.query.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.query.CcuOnlineRecordFeignQuery;
import com.bosch.rbcd.data.service.CcuOnlineRecordService;
import com.bosch.rbcd.data.vo.CcuOnlineRecordStatisticVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname CcuOnlineFeginController
 * @description TODO
 * @date 23/12/12 13:50
 */
@RestController
@RequiredArgsConstructor
public class CcuOnlineFeginController {

    private final CcuOnlineRecordService ccuOnlineRecordService;

    private final CcuOnlineRecordMapper ccuOnlineRecordMapper;

    @ApiIgnore
    @RequestMapping("feign/ccu_online/judgeOnlineDuringDays")
    Result<Integer> judgeOnlineDuringDays(@RequestParam("ccuId") String ccuId, @RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate) {
        long onlineCount = ccuOnlineRecordService.count(new LambdaQueryWrapper<CcuOnlineRecord>().eq(CcuOnlineRecord::getCcuId, ccuId)
                .ge(CcuOnlineRecord::getOnlineDate, startDate).le(CcuOnlineRecord::getOnlineDate, endDate));
        return Result.success((int)onlineCount);
    }


    @ApiIgnore
    @PostMapping("feign/ccu_online/listDayOnlineCcu")
    Result<List<Map<String, Object>>> listDayOnlineCcu(@RequestBody CcuOnlineRecordPageQuery query) {
        List<Map<String, Object>> dayOnlineCcu = ccuOnlineRecordMapper.listDayOnlineCcu(query);
        return Result.success(dayOnlineCcu);
    }

    @GetMapping("/listCcuOnlineCount")
    Result<List<OnlineCountDTO>> listCcuOnlineCount(@RequestBody VehicleMileageRunningTimeQuery query) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("yyyy-MM");
        DateTimeFormatter dayFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        List<CcuOnlineRecord> list = ccuOnlineRecordMapper.selectList(new LambdaQueryWrapper<CcuOnlineRecord>()
                .between(CcuOnlineRecord::getOnlineDate, formatter.format(query.getStartDate()), formatter.format(query.getEndDate()))
                .in(CollectionUtil.isNotEmpty(query.getVehicleIdList()), CcuOnlineRecord::getVehicleId, query.getVehicleIdList()));
        List<OnlineCountDTO> collect = query.getXList().stream().map(x -> {
            long count = list.stream().filter(record -> {
                LocalDate localDate = LocalDate.parse(record.getOnlineDate(), formatter);
                boolean flag = localDate.getYear() == x.getYear() && localDate.getMonthValue() == x.getMonthValue();
                if (query.isDayFlag()) {
                    flag = flag && localDate.getDayOfMonth() == x.getDayOfMonth();
                }
                return flag;
            }).map(CcuOnlineRecord::getVehicleId).distinct().count();
            DateTimeFormatter f = query.isDayFlag() ? dayFormatter : monthFormatter;
            return new OnlineCountDTO(((int) count), f.format(x));
        }).collect(Collectors.toList());
        return Result.success(collect);
    }

    @GetMapping("feign/ccu_online/countPowerOnline")
    Result<Long> countPowerOnline(@RequestParam Long powertrainId) {
        return Result.success(ccuOnlineRecordMapper.countVehicleOnlineDate(powertrainId));
    }

    @PostMapping("feign/ccu_online/statistics")
    Result<List<CcuOnlineRecordStatisticVO>> statistics(@RequestBody CcuOnlineRecordFeignQuery query) {
        return Result.success(ccuOnlineRecordMapper.statistics(query.getProjectIdList(), query.getStartTime(), query.getEndTime()));
    }

    @GetMapping("/feign/online/data/count")
    Result<Long> dataCount(@RequestBody CcuOnlineRecordFeignQuery query) {
        Long dataCount = ccuOnlineRecordMapper.dataCount(query);
        return Result.success(dataCount);
    }
}
