package com.bosch.rbcd.data.pojo.query;

import lombok.Data;

@Data
public class TimeWindowQuery {

    private String label;

    private String max;

    private String min;

    private String logic;

    private Integer windowSize;

    private String functionName;

    public String getLabel() {
        if(label == null || label.isEmpty()){
            return  null;
        }
        return label;
    }

    public String getMax() {
        if(max == null || max.isEmpty()){
            return  null;
        }
        return max;
    }

    public String getMin() {
        if(min == null || min.isEmpty()){
            return  null;
        }
        return min;
    }

    public String getLogic() {
        if(logic == null || logic.isEmpty()){
            return  null;
        }
        return logic;
    }

    public String getFunctionName() {
        if(functionName == null || functionName.isEmpty()){
            return  null;
        }
        return functionName;
    }
}
