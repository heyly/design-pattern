package com.bosch.rbcd.data.pojo.vo;

import lombok.Data;

import java.util.List;

@Data
public class GroupLocation {

    private String startTime;

    private String endTime;

    List<String[]> locationList;

    private String startLocationInfo;
}
