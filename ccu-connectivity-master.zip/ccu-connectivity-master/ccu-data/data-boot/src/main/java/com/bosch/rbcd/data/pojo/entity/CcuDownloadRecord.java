package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.bosch.rbcd.common.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 车辆数据下载用户记录表(VehicleDownloadUserRecord)实体类
 *
 * @author wang bo
 * @since 2023-05-23 14:28:42
 */
@ApiModel("车辆数据下载用户记录表实体类")
@Data
@Accessors(chain=true)
public class CcuDownloadRecord extends BaseEntity {

    @ApiModelProperty("")
    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("用户名称")
    private String userName;

    @ApiModelProperty("车辆在线记录")
    private Long onlineRecordId;

    @ApiModelProperty("csv/mf4")
    private String fileType;

    @ApiModelProperty("0-已创建，1-生成中 ，2-下载中，3-已完成")
    private Integer status;

}
