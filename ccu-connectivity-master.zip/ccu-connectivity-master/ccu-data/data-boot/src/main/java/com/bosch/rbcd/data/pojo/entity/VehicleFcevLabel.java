package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

@Data
public class VehicleFcevLabel {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String vehicleApplication;

    private String system;

    private String signalName;

    private String descEng;

    private String descChn;

    private String unit;

    private String phyMin;

    private String phyMax;

    private String createBy;

    private String uploadBy;

    private String modifyBy;

}