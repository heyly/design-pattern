package com.bosch.rbcd.data.pojo.dto;

import java.util.Map;

/**
 * Created by admin on 2017/5/3.
 */
public class MessageDTO {
    private String imei;

    private String name;

    private String vehicleId;

    private String prjId;

    private String confId;

    private String confNo;

    private String samplingTime;

    private String rawData;

    private String longitude;

    private String latitude;

    private String createAt;

    private String arriveAt;

    /**
     * GpsSpeed gps 速度解析字段，获取的是最近一次存储在redis中的信息
     */
    private String gpsSpeed = "";

    /**
     * GpsDirection gps 方向字段，暂时在我们业务系统中，没有业务相关性
     */
    private String gpsDirection = "";

    /**
     * Measurement 0
     * LCM 1
     */
    private String deviceType;

    private Map<String,Object> data;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getPrjId() {
        return prjId;
    }

    public void setPrjId(String prjId) {
        this.prjId = prjId;
    }

    public String getConfId() {
        return confId;
    }

    public void setConfId(String confId) {
        this.confId = confId;
    }

    public String getConfNo() {
        return confNo;
    }

    public void setConfNo(String confNo) {
        this.confNo = confNo;
    }

    public String getSamplingTime() {
        return samplingTime;
    }

    public void setSamplingTime(String samplingTime) {
        this.samplingTime = samplingTime;
    }

    public String getRawData() {
        return rawData;
    }

    public void setRawData(String rawData) {
        this.rawData = rawData;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public String getCreateAt() {
        return createAt;
    }

    public void setCreateAt(String createAt) {
        this.createAt = createAt;
    }

    public String getGpsSpeed() {
        return gpsSpeed;
    }

    public void setGpsSpeed(String gpsSpeed) {
        this.gpsSpeed = gpsSpeed;
    }

    public String getGpsDirection() {
        return gpsDirection;
    }

    public void setGpsDirection(String gpsDirection) {
        this.gpsDirection = gpsDirection;
    }

    public String getArriveAt() {
        return arriveAt;
    }

    public void setArriveAt(String arriveAt) {
        this.arriveAt = arriveAt;
    }
}
