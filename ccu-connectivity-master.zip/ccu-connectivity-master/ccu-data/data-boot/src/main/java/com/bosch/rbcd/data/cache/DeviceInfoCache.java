package com.bosch.rbcd.data.cache;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalListener;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Slf4j
@Component("deviceInfoCache")
public class DeviceInfoCache extends BaseLocalCache<String, ProjectVehicleCcuDTO> {

    @Autowired
    private DeviceInfoFeignClient ccuDeviceInfoFeignClient;

    /**
     * 使用google guava缓存处理
     * key: ccuId
     * value: deviceInfo
     */
    private static final Cache<String, ProjectVehicleCcuDTO> cache;
    static {
        cache = CacheBuilder.newBuilder()
                .maximumSize(10000)
                .expireAfterWrite(2, TimeUnit.HOURS) // 2小时过期
                .initialCapacity(200)
                .removalListener((RemovalListener<String, ProjectVehicleCcuDTO>) rn -> {
                    if (log.isDebugEnabled()) {
                        log.debug("DeviceInfoCache 被移除缓存 ccuId = {}, deviceInfo = {}", rn.getKey(), rn.getValue());
                    }
                }).build();
    }

    @Override
    public Cache<String, ProjectVehicleCcuDTO> getCache() {
        return cache;
    }

    @Override
    public ProjectVehicleCcuDTO get(String ccuId) {
        if (StringUtils.isBlank(ccuId)) {
            return null;
        }
        ProjectVehicleCcuDTO deviceInfo = getCache().getIfPresent(ccuId);
        if (deviceInfo == null) {
            Result<ProjectVehicleCcuDTO> feignResult = ccuDeviceInfoFeignClient.findByCcuId(ccuId);
            if (feignResult != null && feignResult.getData() != null) {
                deviceInfo = feignResult.getData();
            }

            // 防止缓存穿透，本地缓存保留一份明显错误的数据
            if (deviceInfo == null) {
                deviceInfo = new ProjectVehicleCcuDTO();
                deviceInfo.setId(Long.MIN_VALUE);
            }

            getCache().put(ccuId, deviceInfo);

        }

        return deviceInfo;
    }
}
