package com.bosch.rbcd.data.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bosch.rbcd.common.result.PageResult;
import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.pojo.entity.MonitorFcpmSttoplvlRecord;
import com.bosch.rbcd.data.pojo.query.MonitorFcpmSttoplvlRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.MonitorFcpmSttoplvlRecordVO;
import com.bosch.rbcd.data.service.MonitorFcpmSttoplvlRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 实时监控-FCPM: 监控发动机启停次数(MonitorFcpmSttoplvlRecord)表控制层
 *
 * @author wang bo
 * @since 2024-09-20 09:42:57
 */
@Api(tags = "实时监控-FCPM: 监控发动机启停次数API")
@RestController
@RequestMapping("/monitorFcpmSttoplvlRecord")
@RequiredArgsConstructor
public class MonitorFcpmSttoplvlRecordController {

    private final MonitorFcpmSttoplvlRecordService monitorFcpmSttoplvlRecordService;

    @ApiOperation(value = "启停-分页查询")
    @PostMapping("/page")
    public PageResult<MonitorFcpmSttoplvlRecordVO> page(@RequestBody MonitorFcpmSttoplvlRecordPageQuery query) {
        IPage<MonitorFcpmSttoplvlRecordVO> result = monitorFcpmSttoplvlRecordService.listMonitorFcpmSttoplvlRecordPage(query);
        return PageResult.success(result);
    }

    @ApiIgnore(value = "启停-通过主键查询单条数据")
    @GetMapping("/getById/{id}")
    public Result<Object> getById(@PathVariable Serializable id) {
        return Result.success(monitorFcpmSttoplvlRecordService.getById(id));
    }

    @ApiIgnore(value = "启停-新增数据")
    @PostMapping("/insert")
    public Result<Object> insert(@RequestBody MonitorFcpmSttoplvlRecord monitorFcpmSttoplvlRecord) {
        return Result.success(monitorFcpmSttoplvlRecordService.saveOrUpdate(monitorFcpmSttoplvlRecord));
    }

    @ApiIgnore(value = "启停-修改数据")
    @PutMapping("/update")
    public Result<Object> update(@RequestBody MonitorFcpmSttoplvlRecord monitorFcpmSttoplvlRecord) {
        return Result.success(monitorFcpmSttoplvlRecordService.updateById(monitorFcpmSttoplvlRecord));
    }

    @ApiIgnore(value = "启停-删除数据")
    @DeleteMapping("/delete/{ids}")
    public Result<Object> delete(@ApiParam("主键id，多个以英文逗号(,)分割")  @PathVariable String ids) {
        List<Long> idList = Arrays.stream(ids.split(",")).map(Long::parseLong).collect(Collectors.toList());
        return Result.success(monitorFcpmSttoplvlRecordService.removeByIds(idList));
    }

    @ApiIgnore(value = "启停-获取ccu当日最新启停次数")
    @PostMapping("/feign/getCcuCountMap")
    public Result<Map<String,Integer>> getCcuCountMap(@RequestBody List<String> ccuIds) {
        return Result.success(monitorFcpmSttoplvlRecordService.getCcuCountMap(ccuIds));
    }
}

