package com.bosch.rbcd.data.pojo.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.Set;

/**
 * ccu事件触发高频数据记录(CcuEventDataRecord)分页查询对象
 *
 * @author wang bo
 * @since 2023-09-23 09:46:01
 */
@ApiModel("ccu事件触发高频数据记录分页查询对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CcuEventDataRecordPageQuery extends BasePageQuery {

    @ApiModelProperty("id列表，多选记录时传入此字段")
    private Set<Long> idList;

    @ApiModelProperty("ccu id列表, 单车下载记录")
    private Set<String> ccuIdList;

    @ApiModelProperty("项目id列表")
    private Set<Long> projectIdList;

    @ApiModelProperty("ccu no 列表")
    private Set<String> ccuNoList;

    @ApiModelProperty("ccuNo,模糊搜索")
    private String ccuNo;

    @ApiModelProperty("文件类型")
    private String fileType;

    @ApiModelProperty("车辆别名")
    private String vehicleName;

    @ApiModelProperty("车架号")
    private String vin;

    @ApiModelProperty("发动机编号")
    private String engineNo;

    @ApiModelProperty("ccu sn")
    private String shortSn;

    @ApiModelProperty("can通道")
    private String canChannel;

    @ApiModelProperty("事件类型：1-换挡触发， 2-故障触发， 4-驾驶循环")
    private String eventType;

    @ApiModelProperty("事件时间，ms")
    private Date eventTime;

    @ApiModelProperty("故障等级")
    private String faultLevel;

    @ApiModelProperty("故障数量")
    private String errorCounter;

    @ApiModelProperty("obs文件路径")
    private String filePath;

    @ApiModelProperty("分组id")
    private Set<Long> groupIdSet;
}
