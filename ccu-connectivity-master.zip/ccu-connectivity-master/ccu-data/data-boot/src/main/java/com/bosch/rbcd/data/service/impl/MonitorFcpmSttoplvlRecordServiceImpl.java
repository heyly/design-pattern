package com.bosch.rbcd.data.service.impl;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.Validator;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.common.utils.FreeMarkerUtil;
import com.bosch.rbcd.common.utils.communication.MailUtil;
import com.bosch.rbcd.data.mapper.MonitorFcpmSttoplvlRecordMapper;
import com.bosch.rbcd.data.pojo.entity.MonitorFcpmSttoplvlRecord;
import com.bosch.rbcd.data.pojo.query.MonitorFcpmSttoplvlRecordPageQuery;
import com.bosch.rbcd.data.pojo.vo.MonitorFcpmSttoplvlRecordVO;
import com.bosch.rbcd.data.service.MonitorFcpmSttoplvlRecordService;
import com.bosch.rbcd.device2.api.DeviceInfoFeignClient;
import com.bosch.rbcd.device2.dto.ProjectVehicleCcuDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 实时监控-FCPM: 监控发动机启停次数(MonitorFcpmSttoplvlRecord)表服务实现类
 *
 * @author wang bo
 * @since 2024-09-20 09:42:57
 */
@Service("monitorFcpmSttoplvlRecordService")
@RequiredArgsConstructor
public class MonitorFcpmSttoplvlRecordServiceImpl extends ServiceImpl<MonitorFcpmSttoplvlRecordMapper, MonitorFcpmSttoplvlRecord> implements MonitorFcpmSttoplvlRecordService {

    private final DeviceInfoFeignClient ccuDeviceInfoFeignClient;
    private final FreeMarkerUtil freeMarkerUtil;
    private final RedisUtils redisUtils;
    private final MailUtil mailUtil;

    @Override
    public IPage<MonitorFcpmSttoplvlRecordVO> listMonitorFcpmSttoplvlRecordPage(MonitorFcpmSttoplvlRecordPageQuery queryParams) {
        Page<MonitorFcpmSttoplvlRecordVO> page = new Page<>(queryParams.getPageNum(), queryParams.getPageSize());
        if (CollectionUtils.isNotEmpty(queryParams.getOrders())) {
            page.addOrder(queryParams.getOrders());
        } else {
            page.addOrder(OrderItem.asc("mfsr.stop_time"));
        }
        List<MonitorFcpmSttoplvlRecordVO> list = this.baseMapper.listMonitorFcpmSttoplvlRecordPage(page, queryParams);

        page.setRecords(list);
        return page;
    }

    @Override
    public Workbook generateExcel(MonitorFcpmSttoplvlRecordPageQuery query) {
        query.setPageSize(-1);
        IPage<MonitorFcpmSttoplvlRecordVO> recordList = this.listMonitorFcpmSttoplvlRecordPage(query);
        ExportParams exportParams = new ExportParams();
        exportParams.setType(ExcelType.XSSF);
        String sheetName = StrUtil.format("FCPM_On/Off_Record_{}", DateUtil.format(query.getOccurDate(), DatePattern.PURE_DATE_PATTERN));
        exportParams.setSheetName(sheetName);
        return ExcelExportUtil.exportExcel(exportParams, MonitorFcpmSttoplvlRecordVO.class, recordList.getRecords());
    }

    @Override
    public void sendFcpmStTopLvMail(String ccuId, Date dataTime) {
        ProjectVehicleCcuDTO ccuDevice = ccuDeviceInfoFeignClient.findByCcuId(ccuId).getData();
        if (ccuDevice == null) {
            return;
        }

        if (redisUtils.sHasKey("monitor:fcpm:tTopLvlIgnoreCcuSet", ccuDevice.getCcuNo())) {
            return;
        }

        MonitorFcpmSttoplvlRecordPageQuery query = new MonitorFcpmSttoplvlRecordPageQuery();
        query.setCcuId(ccuId);
        query.setOccurDate(dataTime);
        query.setPageSize(-1);

        List<MonitorFcpmSttoplvlRecordVO> fcpmRecordList = listMonitorFcpmSttoplvlRecordPage(query).getRecords();

        HashMap<String, Object> realMap = new HashMap<>();
        realMap.put("recordList", fcpmRecordList);

        String emailContent = freeMarkerUtil.fillTemplate("fcpmStTopLvlMailTemplate.ftl", realMap);

        ExportParams exportParams = new ExportParams();
        exportParams.setType(ExcelType.XSSF);
        String sheetName = StrUtil.format("FCPM_On/Off_Record_{}", DateUtil.format(query.getOccurDate(), DatePattern.PURE_DATE_PATTERN));
        exportParams.setSheetName(sheetName);
        Workbook workbook = ExcelExportUtil.exportExcel(exportParams, MonitorFcpmSttoplvlRecordVO.class, fcpmRecordList);
        String recordExcel = FileUtil.getTmpDirPath() + StrUtil.format("fcpm_StTopLvl_{}_{}.xlsx", ccuId, DateUtil.format(new Date(), DatePattern.PURE_DATETIME_PATTERN));

        // 生成汇总excel附件并发送邮件
        try (FileOutputStream fos = new FileOutputStream(recordExcel)) {
            workbook.write(fos);
        } catch (IOException e) {
            log.error("汇总excel失败", e);
        }

        String fcpmTipKey = "monitor:fcpm:tTopLvlMailSet:" + ccuDevice.getProjectId();
        if (!redisUtils.hasKey(fcpmTipKey)) {
            fcpmTipKey = "monitor:fcpm:tTopLvlMailSet:0";
        }
        List<String> emailList = redisUtils.sGet(fcpmTipKey).stream().map(String::valueOf).filter(Validator::isEmail).collect(Collectors.toList());
        mailUtil.sendAttachmentsMail(StrUtil.join(";", emailList), "FCPM FuCellStck_stTopLvlReq Tip", null, emailContent, recordExcel, true);
    }

    @Override
    public Map<String, Integer> getCcuCountMap(List<String> ccuIds) {
        Map<String, Integer> ccuCountMap = new HashMap<>();
        List<MonitorFcpmSttoplvlRecord> ccuCountList = this.baseMapper.getCcuCountMap(ccuIds, new Date());
        if (CollectionUtil.isNotEmpty(ccuCountList)) {
            ccuCountMap = ccuCountList.stream().collect(Collectors.toMap(MonitorFcpmSttoplvlRecord::getCcuId, MonitorFcpmSttoplvlRecord::getDayCount));
        }
        return ccuCountMap;
    }
}

