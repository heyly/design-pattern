package com.bosch.rbcd.data.pojo.query;

import lombok.Data;

import java.util.List;

@Data
public class TimeWindowDto {

    private List<TimeWindowQuery> queryList;

    private String startDate;

    private String endDate;

    private String[] vins;

    private Integer page;

    private Integer size;
}
