package com.bosch.rbcd.data.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.bosch.rbcd.common.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * 实时监控-FCPM: 监控发动机启停次数(MonitorFcpmSttoplvlRecord)实体类
 *
 * @author wang bo
 * @since 2024-09-20 09:42:57
 */
@ApiModel("实时监控-FCPM: 监控发动机启停次数实体类")
@Data
@Accessors(chain=true)
public class MonitorFcpmSttoplvlRecord extends BaseEntity {

    @ApiModelProperty("主键，唯一标识")
    @TableId(type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("ccu id")
    private String ccuId;

    @ApiModelProperty("day Count")
    private Integer dayCount;

    @ApiModelProperty("发生日期")
    private Date occurDate;

    @ApiModelProperty("发动机开始时间")
    private Date startTime;

    @ApiModelProperty("发动机停止时间")
    private Date stopTime;

}
