package com.bosch.rbcd.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.data.pojo.entity.DgcMappingTable;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DgcMappingTableMapper extends BaseMapper<DgcMappingTable> {

}
