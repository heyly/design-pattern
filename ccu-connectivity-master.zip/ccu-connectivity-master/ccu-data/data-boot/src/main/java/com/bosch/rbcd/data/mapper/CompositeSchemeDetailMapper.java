package com.bosch.rbcd.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bosch.rbcd.data.pojo.entity.DataCompositeSchemeDetail;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

/**
 * (CompositeSchemeDetail)表数据库访问层
 */
@Component
@Mapper
public interface CompositeSchemeDetailMapper extends BaseMapper<DataCompositeSchemeDetail> {

}
