package com.bosch.rbcd.data;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bosch.rbcd.common.huawei.util.ObsUtil;
import com.bosch.rbcd.data.cronJob.CcuOnlineTask;
import com.bosch.rbcd.data.cronJob.ClusterCcuDataTask;
import com.bosch.rbcd.data.pojo.entity.CcuOnlineRecord;
import com.bosch.rbcd.data.service.CcuOnlineRecordService;
import com.bosch.rbcd.data.service.DataDownloadService;
import com.bosch.rbcd.fleet.api.VehicleFeignClient;
import com.obs.services.model.ObjectMetadata;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname ClusterVehicleTaskTest
 * @description TODO
 * @date 2023/5/27 22:33
 */
@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class CcuOnlineTaskTest {
    @Autowired
    private ClusterCcuDataTask clusterVehicleTask;

    @Autowired
    private DataDownloadService dataDownloadService;

    @Autowired
    private CcuOnlineRecordService vehicleOnlineRecordService;

    @Autowired
    private CcuOnlineTask ccuOnlineTask;

    @Autowired
    private ObsUtil obsUtil;

    @Autowired
    private VehicleFeignClient vehicleFeignClient;

    @Value("${obs.cluster-bucket}")
    private String clusterBucket;

    @Test
    public void testClusterVehicleDataTask() {
        clusterVehicleTask.autoClusterData();
    }

    @Test
    public void testClusterMf4DataTask() {
        clusterVehicleTask.autoClusterMf4Data();
    }

    @Test
    public void testRealTimeRecordOnlineVehicle() {
        ccuOnlineTask.realTimeRecordOnlineVehicle();
    }

    @Test
    public void recordYesterdayOnlineVehicle() {
        ccuOnlineTask.recordYesterdayOnlineVehicle();
    }

    @Test
    public void testAutoClusterHighRateData() {
        clusterVehicleTask.autoClusterHighRateData();
    }

    @Test
    public void recoverMf4() {
        List<CcuOnlineRecord> list =
                vehicleOnlineRecordService.list(new LambdaQueryWrapper<CcuOnlineRecord>().eq(CcuOnlineRecord::getCcuNo, "QLFCEV002003").ge(CcuOnlineRecord::getOnlineDate,
                        "20230630").le(CcuOnlineRecord::getOnlineDate, "20230801"));
        list.stream().filter(s -> StrUtil.isBlank(s.getMf4Path())).forEach(record -> {
            Future<String> result = dataDownloadService.asyncClusterMf4(record);
            // 如果为同步实时任务
            try {
                System.out.println(result.get(1, TimeUnit.HOURS));
            } catch (Exception e) {
            }
        });
    }

    @Test
    public void getDisappearFile() {
        List<CcuOnlineRecord> cluserList = vehicleOnlineRecordService.list(new LambdaQueryWrapper<CcuOnlineRecord>().eq(CcuOnlineRecord::getClusterFlag, 1));
        cluserList.forEach(online -> {
            boolean csvLostFlag = !obsUtil.isExisted(clusterBucket, online.getCsvPath());
            boolean mf4LostFlag = StrUtil.isNotBlank(online.getMf4Path()) && !obsUtil.isExisted(clusterBucket, online.getMf4Path());
            if (csvLostFlag || mf4LostFlag) {
                if (csvLostFlag) {
                    online.setCsvPath("");
                    online.setClusterFlag(0);
                }
                if (mf4LostFlag) {
                    online.setMf4Path("");
                }
                vehicleOnlineRecordService.updateById(online);
            }
        });
    }


//    @Test
//    public void resetOnlineVehicleId() {
//        List<VehicleUpdateHistory> vehicleUpdateList = vehicleFeignClient.listVehicleHistory(8).getData();
//        Map<Long, List<VehicleUpdateHistory>> vehicleGroup =
//                vehicleUpdateList.stream().filter(v -> v.getVehicleId() != null).collect(Collectors.groupingBy(VehicleUpdateHistory::getVehicleId));
//        vehicleGroup.forEach((vehicleId, upList) -> {
//            upList = upList.stream().sorted(Comparator.comparing(VehicleUpdateHistory::getChangeTime)).collect(Collectors.toList());
//            for (int index = 0; index < upList.size(); index++) {
//                VehicleUpdateHistory vehicleUpdateHistory = upList.get(index);
//                LocalDateTime nextChangeTime = index != upList.size() - 1 ? upList.get(index + 1).getChangeTime() : null;
//                vehicleOnlineRecordService.update(new LambdaUpdateWrapper<CcuOnlineRecord>().set(CcuOnlineRecord::getVehicleId, vehicleId).eq(CcuOnlineRecord::getCcuId,
//                        vehicleUpdateHistory.getAfterValue()).ge(CcuOnlineRecord::getOnlineDate, DateUtil.format(vehicleUpdateHistory.getChangeTime(),
//                        DatePattern.PURE_DATE_PATTERN)).lt(nextChangeTime != null, CcuOnlineRecord::getOnlineDate, DateUtil.format(nextChangeTime, DatePattern.PURE_DATE_PATTERN)));
//            }
//        });
//    }


    @Test
    public void resetOnlineRecord() {
        Date weekAgo = DateUtil.parse("2023-01-19");
        Date yesterday = DateUtil.parse("2024-01-19");
        log.info(StrUtil.format("====兜底计算过去一周在线情况开始====="));
        List<DateTime> dateList = DateUtil.rangeToList(weekAgo, yesterday, DateField.DAY_OF_MONTH);
        for (DateTime date : dateList) {
            ccuOnlineTask.executeOnlineRecord(date, Arrays.asList(104L));
        }
    }

    @Test
    public void resetEmptyOnlineRecord() throws Exception {

        Page<CcuOnlineRecord> page = new Page<>(1, 1000);
        vehicleOnlineRecordService.page(page, new LambdaQueryWrapper<CcuOnlineRecord>().eq(CcuOnlineRecord::getClusterFlag, 1)
     .orderByDesc(CcuOnlineRecord::getOnlineDate));
        List<CcuOnlineRecord> list = new ArrayList<>();
        while (page.getCurrent() <= page.getPages()) {
            for (CcuOnlineRecord record : page.getRecords()) {
                ObjectMetadata fileInfo = obsUtil.getFileInfo(clusterBucket, record.getCsvPath());
                if (fileInfo != null && fileInfo.getContentLength() < 1000) {
                    log.info("文件生成异常 {} {}", record.getCcuNo(), record.getOnlineDate(), record.getDataCount(), fileInfo.getContentLength());
                    record.setClusterFlag(0);
                    record.setCsvPath("");
                    vehicleOnlineRecordService.updateById(record);
                    list.add(record);
                }

                ObjectMetadata mf4Info = obsUtil.getFileInfo(clusterBucket, record.getCsvPath());
                if (mf4Info != null && mf4Info.getContentLength() < 1000) {
                    log.info("mf4文件生成异常 {} {}", record.getCcuNo(), record.getOnlineDate(), record.getDataCount(), fileInfo.getContentLength());
                    record.setMf4Path("");
                    vehicleOnlineRecordService.updateById(record);
                }
            }
            // 翻页查询
            page.setCurrent(page.getCurrent() + 1);
            vehicleOnlineRecordService.page(page, new LambdaQueryWrapper<CcuOnlineRecord>().eq(CcuOnlineRecord::getClusterFlag, 1).orderByDesc(CcuOnlineRecord::getOnlineDate));
        }
        ExcelWriter writer = ExcelUtil.getWriter("C:\\Users\\wangbo\\Desktop\\failRecord.xlsx");
        writer.write(list);
    }


}
