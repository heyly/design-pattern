package com.bosch.rbcd.data;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.bosch.rbcd.common.hbase.constant.HBaseTableConstant;
import com.bosch.rbcd.common.hbase.utils.HbaseUtils;
import com.bosch.rbcd.common.redis.utils.RedisUtils;
import com.bosch.rbcd.data.service.MonitorFcpmSttoplvlRecordService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname DataFlowTest
 * @description TODO
 * @date 2024/1/9 10:08
 */
@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class DataFlowTest {

    @Autowired
    private HbaseUtils hbaseUtils;

    @Autowired
    private MonitorFcpmSttoplvlRecordService fcpmSttoplvlRecordService;

    @Autowired
    private RedisUtils redisUtils;

    @Test
    public void testReverseScan() {
        String rowKey = hbaseUtils.getRawTableRow(Long.valueOf("1705033776243019776"), DateUtil.parse("2024-01-07 15:25:48"));
        List<Map<String, String>> result = hbaseUtils.findBaseRowAroundCountData(HBaseTableConstant.RAW_DATA_TABLE_NAME, rowKey, 600, Arrays.asList("createAt", "DFES_numDFC_[6]"
                , "DFES_stEntry_[6]"), null);
        log.info(JSON.toJSONString(result));
    }

    @Test
    public void testSendFcpmMail() {
        fcpmSttoplvlRecordService.sendFcpmStTopLvMail("1629030184718045184", new Date());
    }

    @Test
    public void testInitFcpmEmail() {
        String[] defaultEmail = new String[]{"Hang.FU@cn.bosch.com", "Xinkai.LIU@cn.bosch.com", "wenyan.zhao@bosch.com"};

        String[] c70Email = new String[]{"Xinkai.LIU@cn.bosch.com", "Ling.LUO@cn.bosch.com", "Dan.PENG@cn.bosch.com"};
        String[] c75Email = new String[]{"Hao.WANG@cn.bosch.com", "Xinkai.LIU@cn.bosch.com", "Yue.GU2@cn.bosch.com", "fujie.zhang@bosch.com", "fujie.zhang@bosch.com", "Dan" +
                ".PENG@cn.bosch.com"};
        String[] c132Email = new String[]{"Hang.FU@cn.bosch.com", "Zhengxue.XIE@cn.bosch.com", "Zhaoming.FAN@cn.bosch.com", "Yun.ZHANG6@cn.bosch.com"};
        String[] c190Email = new String[]{"Shuai.LI2@cn.bosch.com", "Zhenchao.GAO@cn.bosch.com", "Qiulei.ZHANG@cn.bosch.com", "Xinkai.LIU@cn.bosch.com", "Yun.ZHANG6@cn.bosch.com"};

        Long[] c70ProjectId = new Long[]{72L};
        Long[] c75ProjectId = new Long[]{135L, 93L, 71L, 69L};
        Long[] c132ProjectId = new Long[]{116L, 70L, 155L};
        Long[] c190ProjectId = new Long[]{152L, 126L, 85L, 78L, 66L};


        String keyPreffix = "monitor:fcpm:tTopLvlMailSet:";

        redisUtils.sSet(keyPreffix + "0", defaultEmail);

        for (Long id : c70ProjectId) {
            redisUtils.sSet(keyPreffix + id, c70Email);
        }

        for (Long id : c75ProjectId) {
            redisUtils.sSet(keyPreffix + id, c75Email);
        }

        for (Long id : c132ProjectId) {
            redisUtils.sSet(keyPreffix + id, c132Email);
        }


        for (Long id : c190ProjectId) {
            redisUtils.sSet(keyPreffix + id, c190Email);
        }
    }

    @Test
    public void testSetZhaoWenYan() {
        String keyPreffix = "monitor:fcpm:tTopLvlMailSet:";
        Long[] projectId = new Long[]{135L, 93L, 71L, 69L, 116L, 70L, 155L, 152L, 126L, 85L, 78L, 66L, 72L};
        for (Long id : projectId) {
            redisUtils.sSet(keyPreffix + id, "wenyan.zhao@bosch.com");
        }
    }
}
