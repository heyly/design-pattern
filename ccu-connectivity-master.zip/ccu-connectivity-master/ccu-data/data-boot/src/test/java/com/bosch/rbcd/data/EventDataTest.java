package com.bosch.rbcd.data;

import com.alibaba.fastjson.JSON;
import com.bosch.rbcd.data.cronJob.ObsData2LocalTask;
import com.bosch.rbcd.data.service.CcuEventDataRecordService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname EventDataTest
 * @description TODO
 * @date 2023/10/30 11:44
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class EventDataTest {
   @Autowired
   private CcuEventDataRecordService eventDataRecordService;

   @Autowired
   private ObsData2LocalTask obsData2LocalTask;

    @Test
    public void testRecordEventData(){
        String str = "{\"errorCounter\":\"18\",\"messageType\":\"EventDataLoging\",\"filePath\":\"upload/event_data/868922052448236/20231029091531.csv.gz\",\"canChannel\":\"0\",\"eventType\":\"1\",\"device\":\"868922052448236\",\"faultLevel\":\"0\",\"timestamp\":\"1698542165272\"}";
        eventDataRecordService.recordEventData(JSON.parseObject(str));
    }

    @Test
    public void moveEventData(){
        obsData2LocalTask.moveEventDataTask();
    }
}
