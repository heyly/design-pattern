package com.bosch.rbcd.data.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OnlineCountDTO {

    private Integer activeVehicleCount;

    private String x;
}
