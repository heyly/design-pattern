package com.bosch.rbcd.data.dto;

import lombok.Data;

import java.util.Date;

@Data
public class VehicleMileageRunningTimeDTO {

    private Long id;

    private String ccuId;

    private String ccuNo;

    /**
     * 截至日期的总运行里程
     */
    private Double totalMileage;

    /**
     * 截至日期的总运行时间
     */
    private Double totalRuntime;

    /**
     * 截至日期的当日里程
     */
    private Double todayMileage;

    /**
     * 截至日期的当日时间
     */
    private Double todayRuntime;

    /**
     * 计算日期
     */
    private Date day;

    /**
     * 车辆运行日期
     */
    private Date runningDate;

}
