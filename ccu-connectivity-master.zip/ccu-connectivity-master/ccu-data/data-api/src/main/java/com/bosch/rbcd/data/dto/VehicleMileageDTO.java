package com.bosch.rbcd.data.dto;

import lombok.Data;

@Data
public class VehicleMileageDTO {

    private String name;

    private Double mileage;

}
