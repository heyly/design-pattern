package com.bosch.rbcd.data.vo;

import lombok.Data;

@Data
public class CcuOnlineRecordStatisticVO {

    private Integer onlineCount;

    // yyyyMMdd
    private String onlineDate;
}
