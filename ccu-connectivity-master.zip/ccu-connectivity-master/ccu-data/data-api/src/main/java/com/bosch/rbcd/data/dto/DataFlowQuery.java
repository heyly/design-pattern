package com.bosch.rbcd.data.dto;

import com.bosch.rbcd.common.base.BasePageQuery;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname DataFlowQuery
 * @description TODO
 * @date 2023/6/2 10:51
 */
@ApiModel("实时数据出图查询")
@Data
public class DataFlowQuery extends BasePageQuery {
    @ApiModelProperty("车辆id")
    @NotBlank(message = "请传入车辆id")
    private String ccuId;

    @ApiModelProperty("label列表, 精确查找")
    List<String> labelList;

    @ApiModelProperty("label前缀列表, 按前缀模糊查找")
    List<String> labelPrefixList;

    @ApiModelProperty(value = "倒序查找标记")
    private boolean reversFlag;

    @ApiModelProperty(value = "指定包数")
    private Integer count;
}
