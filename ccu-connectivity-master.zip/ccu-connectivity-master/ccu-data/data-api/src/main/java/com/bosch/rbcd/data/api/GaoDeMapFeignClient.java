package com.bosch.rbcd.data.api;

import com.bosch.rbcd.common.result.Result;
import io.swagger.annotations.ApiParam;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author wangbo
 * @version 1.0.0
 * @classname GaoDeMapFeignClient
 * @description TODO
 * @date 2023/7/19 11:45
 */
@RequestMapping("/map")
@FeignClient(value = "ccu-data", contextId = "gaodeMapClient")
public interface GaoDeMapFeignClient {

    @GetMapping("/getCityByGps")
    Result<String> getCityByGps(@ApiParam("经度") @RequestParam String longitude, @ApiParam("纬度") @RequestParam String latitude);
}
