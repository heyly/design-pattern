package com.bosch.rbcd.data.api;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.dto.VehicleMileageRunningTimeDTO;
import com.bosch.rbcd.data.dto.VehicleMileageRunningTimeQuery;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@FeignClient(value = "ccu-data", contextId = "vehicleMileage")
@RequestMapping("/feign/vehicle/mileage")
public interface VehicleMileageFeignClient {

    @GetMapping("/getByCcuId")
    Result<VehicleMileageRunningTimeDTO> getByCcuId(@RequestParam String ccuId);

    @GetMapping("/listRunTime")
    Result<List<VehicleMileageRunningTimeDTO>> listRunTime(@RequestBody VehicleMileageRunningTimeQuery query);

    @GetMapping("/getByCcuIdAndDate")
    Result<VehicleMileageRunningTimeDTO> getByCcuIdAndDate(@RequestParam String ccuId, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localDate);

    @GetMapping("/getTotalAddMileage")
    Result<Double> getTotalAddMileage(@RequestParam String ccuId, @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") LocalDateTime updateMileageTime);
}
