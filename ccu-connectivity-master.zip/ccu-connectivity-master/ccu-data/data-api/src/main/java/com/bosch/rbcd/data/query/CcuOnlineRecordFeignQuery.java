package com.bosch.rbcd.data.query;

import com.bosch.rbcd.common.base.BasePageQuery;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class CcuOnlineRecordFeignQuery extends BasePageQuery {

    private static final long serialVersionUID = -1189005088171372785L;

    private Long projectId;

    private List<Long> projectIdList;
}
