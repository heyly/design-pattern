package com.bosch.rbcd.data.api;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.dto.CcuOnlineRecordPageQuery;
import com.bosch.rbcd.data.dto.OnlineCountDTO;
import com.bosch.rbcd.data.dto.VehicleMileageRunningTimeQuery;
import com.bosch.rbcd.data.query.CcuOnlineRecordFeignQuery;
import com.bosch.rbcd.data.vo.CcuOnlineRecordStatisticVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @author WBO3WX
 * @version 1.0.0
 * @classname CcuOnlineFeignClient
 * @description TODO
 * @date 23/12/12 10:38
 */
@FeignClient(value = "ccu-data", contextId = "ccuOnlineFeignClient")
public interface CcuOnlineFeignClient {

    @RequestMapping("feign/ccu_online/judgeOnlineDuringDays")
    Result<Integer> judgeOnlineDuringDays(@RequestParam("ccuId") String ccuId, @RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate);

    @PostMapping("feign/ccu_online/listDayOnlineCcu")
    Result<List<Map<String, Object>>> listDayOnlineCcu(@RequestBody CcuOnlineRecordPageQuery query);

    @GetMapping("/listCcuOnlineCount")
    Result<List<OnlineCountDTO>> listCcuOnlineCount(@RequestBody VehicleMileageRunningTimeQuery query);

    @PostMapping("/ccuOnlineRecord/listOnlineDate")
    Result<List<String>> listOnlineDate(@RequestBody CcuOnlineRecordPageQuery query);

    @GetMapping("feign/ccu_online/countPowerOnline")
    Result<Long> countPowerOnline(@RequestParam Long powertrainId);

    // todo
    @PostMapping("feign/ccu_online/statistics")
    Result<List<CcuOnlineRecordStatisticVO>> statistics(@RequestBody CcuOnlineRecordFeignQuery ccuOnlineRecordFeignQuery);

    @GetMapping("/feign/online/data/count")
    Result<Long> dataCount(@RequestBody CcuOnlineRecordFeignQuery query);
}
