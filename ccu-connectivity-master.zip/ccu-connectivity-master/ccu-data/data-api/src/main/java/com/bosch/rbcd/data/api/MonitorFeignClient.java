package com.bosch.rbcd.data.api;

import com.bosch.rbcd.common.result.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;
import java.util.Map;

@FeignClient(value = "ccu-data", contextId = "monitorFeignClient")
public interface MonitorFeignClient {

    @ApiIgnore(value = "FCPM: 获取ccu当日最新启停次数")
    @PostMapping("/monitorFcpmSttoplvlRecord/feign/getCcuCountMap")
    public Result<Map<String, Integer>> getFcpmSttopCcuCountMap(@RequestBody List<String> ccuIds);
}
