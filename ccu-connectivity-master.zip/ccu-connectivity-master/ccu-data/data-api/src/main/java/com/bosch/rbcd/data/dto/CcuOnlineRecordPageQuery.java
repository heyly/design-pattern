package com.bosch.rbcd.data.dto;

import com.bosch.rbcd.common.base.BasePageQuery;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;
import java.util.Set;

/**
 * 车辆在线统计表(VehicleOnlineRecord)分页查询对象
 *
 * @author wang bo
 * @since 2023-05-23 14:25:04
 */
@ApiModel("车辆在线统计表分页查询对象")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CcuOnlineRecordPageQuery extends BasePageQuery {
    @ApiModelProperty("在线记录id列表，多选记录时传入此字段")
    private Set<Long> idList;

    @ApiModelProperty("ccu id列表, 单车下载记录")
    private Set<String> ccuIdList;

    @ApiModelProperty("项目id列表")
    private List<Long> projectIdList;

    @ApiModelProperty("ccu no 列表")
    private Set<String> ccuNoList;

    @ApiModelProperty("车辆别名")
    private String vehicleName;

    @ApiModelProperty("车架号")
    private String vin;

    @ApiModelProperty("发动机编号")
    private String engineNo;

    @ApiModelProperty("ccu sn")
    private String shortSn;

    @ApiModelProperty("在线日列表: [ccuId-onlineDate]")
    private List<String> ccuIdDateList;

    @ApiModelProperty("车辆id列表")
    private Set<Long> fleetIdList;

    @ApiModelProperty("文件类型")
    private String fileType;

    @ApiModelProperty("中文国际化")
    private boolean cnFlag;

}
