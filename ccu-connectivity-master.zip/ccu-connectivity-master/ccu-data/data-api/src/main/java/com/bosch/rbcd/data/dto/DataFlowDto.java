package com.bosch.rbcd.data.dto;

import cn.hutool.core.builder.CompareToBuilder;
import com.bosch.rbcd.common.base.BaseEntity;
import lombok.Data;

@Data
public class DataFlowDto extends BaseEntity implements Comparable<DataFlowDto> {
    private String xValue;
    private String yValue;
    private String type;
    private String xUnit;
    private String yUnit;
    private String range;
    private Integer sort;
    private String translateMethod;
    private String translateMethodY;
    private String pretreatment;
    private String vehicleId;
    private String vehicleName;
    private String fleetId;
    private String id;
    private String organizationName;
    private String fleetName;
    private String startDate;
    private String endDate;


    @Override
    public int compareTo(DataFlowDto o) {
        return new CompareToBuilder().append(sort, o.sort).toComparison();
    }

    @Override
    public String toString() {
        return "ResultDto{" +
                "xValue='" + xValue + '\'' +
                ", yValue='" + yValue + '\'' +
                ", type='" + type + '\'' +
                ", xUnit='" + xUnit + '\'' +
                ", yUnit='" + yUnit + '\'' +
                ", range='" + range + '\'' +
                ", sort=" + sort +
                ", translateMethod='" + translateMethod + '\'' +
                ", translateMethodY='" + translateMethodY + '\'' +
                ", pretreatment='" + pretreatment + '\'' +
                ", ccuId='" + vehicleId + '\'' +
                ", ccuNo='" + vehicleName + '\'' +
                ", fleetId='" + fleetId + '\'' +
                ", id='" + id + '\'' +
                ", organizationName='" + organizationName + '\'' +
                ", fleetName='" + fleetName + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                '}';
    }
}
