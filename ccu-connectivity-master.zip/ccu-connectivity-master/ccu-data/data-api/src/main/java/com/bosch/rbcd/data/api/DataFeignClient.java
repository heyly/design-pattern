package com.bosch.rbcd.data.api;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.dto.DataFlowDto;
import com.bosch.rbcd.data.dto.FcevHiveQuery;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@FeignClient(value = "ccu-data", contextId = "dataClient")
public interface DataFeignClient {

    @GetMapping("/compositeScheme/listSystem")
    Result<List<String>> listSystem();

    @GetMapping("/data/dataFlow")
    Result<List<DataFlowDto>> dataFlow(@RequestParam String vehicleId,
                                       @RequestParam String label, String imei,
                                       @RequestParam String startTime,
                                       @RequestParam String endTime);

    @GetMapping("/data/dataFlowByLabels")
    Result<List<Map<String, String>>> dataFlowByLabels(@RequestParam String vehicleId,
                                                       @RequestParam String labels,
                                                       @RequestParam String imei,
                                                       @RequestParam String startTime,
                                                       @RequestParam String endTime);

    /**
     * 获取车辆总运行里程
     * @param fcevHiveQuery
     * @return
     */
    @PostMapping("/presto/getAllVehicleMileage")
    Result getAllVehicleMileage(@RequestBody FcevHiveQuery fcevHiveQuery);

    /**
     * 获取车辆总运行时间
     * @param fcevHiveQuery
     * @return
     */
    @PostMapping("/presto/getAllVehicleRunTime")
    Result getAllVehicleRunTime(@RequestBody FcevHiveQuery fcevHiveQuery);


    /**
     * 获取运行里程前十的车辆
     * @param fcevHiveQuery
     * @return
     */
    @PostMapping("/presto/getTop10MileageVehicles")
    Result getTop10MileageVehicles(@RequestBody FcevHiveQuery fcevHiveQuery);

    /**
     * 获取10天内单车平均运行时间
     * @param fcevHiveQuery
     * @return
     */
    @PostMapping("/presto/getVehicle10DaysAverageMileage")
    Result getVehicle10DaysAverageMileage(@RequestBody FcevHiveQuery fcevHiveQuery);

}
