package com.bosch.rbcd.data.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class VehicleMileageRunningTimeQuery {

    private LocalDate startDate;

    private LocalDate endDate;

    private List<String> ccuIdList;

    private List<Long> vehicleIdList;

    private List<LocalDate> xList;

    private boolean dayFlag;
}
