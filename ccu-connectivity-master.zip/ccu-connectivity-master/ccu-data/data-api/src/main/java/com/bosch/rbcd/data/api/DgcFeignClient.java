package com.bosch.rbcd.data.api;

import com.bosch.rbcd.common.result.Result;
import com.bosch.rbcd.data.vo.DgcDataRangeVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@RequestMapping("/feign/dgc")
@FeignClient(value = "ccu-data", contextId = "dgcFeignClient")
public interface DgcFeignClient {

    @RequestMapping("/queryRules")
    Result<Map<String, DgcDataRangeVO>> queryRules(@RequestParam Long projectId);
}
