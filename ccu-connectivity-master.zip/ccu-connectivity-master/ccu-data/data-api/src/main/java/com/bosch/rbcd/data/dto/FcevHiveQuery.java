package com.bosch.rbcd.data.dto;

import lombok.Data;

@Data
public class FcevHiveQuery {

    private String startDate;

    private String endDate;

    private String vehicleNames;
}
