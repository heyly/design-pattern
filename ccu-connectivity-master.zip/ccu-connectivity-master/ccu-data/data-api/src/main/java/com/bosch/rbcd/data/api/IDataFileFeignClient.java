package com.bosch.rbcd.data.api;

import com.alibaba.fastjson.JSONObject;
import com.bosch.rbcd.common.result.Result;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import springfox.documentation.annotations.ApiIgnore;

@FeignClient(value = "ccu-data", contextId = "dataFileFeignClient")
public interface IDataFileFeignClient {

    @GetMapping("/file/convertFolderToMf4")
    Result<String> convertFolderToMf4(@RequestParam("sourceFolder") String sourceFolder, @RequestParam("targetFolder") String targetFolder);

    @ApiOperation(value = "单天csv/mf4数据下载")
    @GetMapping("/vehicleDownloadUserRecord/downOneVehicleDay")
    Result<String> downOneVehicleDay(@RequestParam Long vehicleId, @RequestParam String onlineDate, @RequestParam String fileType);

    @ApiIgnore(value = "新增事件触发数据")
    @PostMapping("/ccuEventDataRecord/recordEventData")
    Result<Object> recordEventData(@RequestBody JSONObject ccuEventDataJson);
}
