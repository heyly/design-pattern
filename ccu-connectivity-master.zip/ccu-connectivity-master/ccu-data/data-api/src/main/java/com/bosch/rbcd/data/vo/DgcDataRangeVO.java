package com.bosch.rbcd.data.vo;

import lombok.Getter;

@Getter
public class DgcDataRangeVO {

    private final Double min;

    private final Double max;

    private final Integer must;

    public DgcDataRangeVO(Double min, Double max, Integer must) {
        this.min = min;
        this.max = max;
        this.must = must;
    }
}
